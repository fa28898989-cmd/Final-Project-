package com.personal.movielink.ui.components

import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.ImageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.personal.movielink.ui.theme.LocalMovieLinkPalette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt

private fun detectContactSheetFrames(width: Int, height: Int): Int {
    if (width <= 0 || height <= 0 || height <= width * 1.12f) return 1
    val candidates = intArrayOf(4, 3, 5, 2, 6)
    for (n in candidates) {
        val ratio = width.toFloat() / (height.toFloat() / n)
        if (ratio in 1.25f..2.7f) return n
    }
    return max(1, (height.toFloat() / (width * 9f / 16f)).roundToInt())
}

private fun sliceContactSheet(bitmap: Bitmap): List<ImageBitmap> {
    val frames = detectContactSheetFrames(bitmap.width, bitmap.height)
    if (frames <= 1) return listOf(bitmap.asImageBitmap())
    val frameHeight = (bitmap.height / frames).coerceAtLeast(1)
    return (0 until frames).map { idx ->
        val y = idx * frameHeight
        val h = minOf(frameHeight, bitmap.height - y).coerceAtLeast(1)
        Bitmap.createBitmap(bitmap, 0, y, bitmap.width, h).asImageBitmap()
    }
}

@Composable
fun SingleCoverScreenshotsSection(
    screenshotUrls: List<String>,
    imageLoader: ImageLoader,
    modifier: Modifier = Modifier
) {
    if (screenshotUrls.isEmpty()) return

    val palette = LocalMovieLinkPalette.current
    val reduceMotion = LocalReduceMotion.current
    val context = LocalContext.current
    var slicedFrames by remember(screenshotUrls) { mutableStateOf<List<ImageBitmap>>(emptyList()) }
    var loading by remember(screenshotUrls) { mutableStateOf(true) }
    var retryNonce by remember(screenshotUrls) { mutableStateOf(0) }
    var showGallery by remember { mutableStateOf(false) }

    LaunchedEffect(screenshotUrls, retryNonce) {
        loading = true
        withContext(Dispatchers.IO) {
            val perUrlFrames = arrayOfNulls<List<ImageBitmap>>(screenshotUrls.size)
            val mutex = Mutex()
            coroutineScope {
                screenshotUrls.mapIndexed { idx, url ->
                    async {
                        var attempt = 0
                        var parsed: List<ImageBitmap>? = null
                        while (attempt < 2 && parsed == null) {
                            attempt++
                            try {
                                val req = ImageRequest.Builder(context)
                                    .data(url)
                                    .allowHardware(false)
                                    .allowRgb565(true)
                                    .build()
                                val result = imageLoader.execute(req)
                                if (result is SuccessResult) {
                                    val bmp = (result.drawable as? BitmapDrawable)?.bitmap
                                    if (bmp != null) {
                                        parsed = sliceContactSheet(bmp)
                                    }
                                }
                            } catch (_: Exception) {
                            }
                        }
                        if (parsed != null) {
                            val combined = mutex.withLock {
                                perUrlFrames[idx] = parsed
                                perUrlFrames.filterNotNull().flatten()
                            }
                            withContext(Dispatchers.Main) {
                                slicedFrames = combined
                            }
                        }
                    }
                }.awaitAll()
            }
        }
        loading = false
    }

    val totalCount = if (slicedFrames.isNotEmpty()) slicedFrames.size else screenshotUrls.size
    val coverInteraction = remember { MutableInteractionSource() }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "Screenshots",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = palette.textPrimary
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .pressScale(coverInteraction, pressedScale = 0.975f)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.Black)
                .border(1.5.dp, palette.boxBorder, RoundedCornerShape(12.dp))
                .clickable(interactionSource = coverInteraction, indication = null) {
                    if (slicedFrames.isNotEmpty()) {
                        showGallery = true
                    } else if (!loading) {
                        retryNonce++
                    }
                }
        ) {
            val cover = slicedFrames.firstOrNull()
            val coverAlpha by animateFloatAsState(
                targetValue = if (cover != null || reduceMotion) 1f else 0f,
                animationSpec = tween(durationMillis = if (reduceMotion) 0 else 220),
                label = "screenshot_cover_alpha"
            )
            if (cover != null) {
                Image(
                    bitmap = cover,
                    contentDescription = "Screenshot Frame 1",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer { alpha = coverAlpha }
                )
            } else {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    if (loading) {
                        SkeletonBox(
                            modifier = Modifier.fillMaxSize(),
                            shape = RoundedCornerShape(12.dp)
                        )
                    } else {
                        Text(
                            text = "Tap to retry screenshots",
                            fontSize = 12.5.sp,
                            color = Color(0xFFA1A1AA)
                        )
                    }
                }
            }

            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color(0xE005070B))
                        )
                    )
                    .padding(horizontal = 12.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PhotoLibrary,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Tap to view all screenshots",
                            color = Color.White,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(palette.fg)
                            .border(1.dp, palette.boxBorder, RoundedCornerShape(8.dp))
                            .padding(horizontal = 9.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = if (totalCount == 1) "1 Photo" else "$totalCount Photos",
                            color = palette.onAccent,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }
    }

    if (showGallery && slicedFrames.isNotEmpty()) {
        Dialog(
            onDismissRequest = { showGallery = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xF504060A))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0A0C12))
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Screenshots (${slicedFrames.size})",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = { showGallery = false }) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Close Gallery",
                            tint = Color.White
                        )
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    itemsIndexed(slicedFrames) { idx, frame ->
                        val aspect = (frame.width.toFloat() / frame.height.toFloat()).coerceIn(1.1f, 2.5f)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(aspect)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF0F1219))
                                .border(1.dp, Color(0x28FFFFFF), RoundedCornerShape(10.dp))
                        ) {
                            Image(
                                bitmap = frame,
                                contentDescription = "Screenshot ${idx + 1} of ${slicedFrames.size}",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(8.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xCC000000))
                                    .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "${idx + 1} / ${slicedFrames.size}",
                                    color = Color.White,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }
            }
        }
    }
}
