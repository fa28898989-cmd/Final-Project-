package com.personal.movielink

import android.app.Application
import androidx.compose.runtime.Immutable
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

sealed interface NavScreen {
    data class Catalog(val url: String) : NavScreen
    data class Detail(val url: String) : NavScreen
}

@Immutable
data class CategoryHomeRowData(
    val items: List<UnifiedPosterItem> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val hasMore: Boolean = false
)

@Immutable
data class CombinedHomeSectionState(
    val key: String,
    val title: String,
    val items: List<UnifiedPosterItem> = emptyList(),
    val moreUrl: String? = null,
    val isLoading: Boolean = false,
    val error: String? = null
)

@Immutable
data class HeroSourceOption(
    val key: String,
    val title: String,
    val providerLabel: String,
    val isAvailable: Boolean = true
)

@Immutable
data class HeroSectionState(
    val items: List<UnifiedPosterItem> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val activeSourceTitle: String? = null,
    val hidden: Boolean = false
)

@Immutable
data class MovieLinkSearchSectionState(
    val items: List<UnifiedPosterItem> = emptyList(),
    val nextPageUrl: String? = null,
    val isLoading: Boolean = false,
    val isLoadingMore: Boolean = false,
    val error: String? = null
)

@Immutable
data class UnifiedSearchState(
    val query: String = "",
    val hasSearched: Boolean = false,
    val movieLink: MovieLinkSearchSectionState = MovieLinkSearchSectionState()
)

@Immutable
data class PendingVideoChoice(
    val url: String,
    val title: String,
    val userAgent: String,
    val contentDisposition: String?,
    val mimeType: String?
)

@Immutable
data class PendingDownloaderChoice(
    val url: String,
    val userAgent: String,
    val contentDisposition: String?,
    val mimeType: String?
)

@Immutable
data class FallbackWebRequest(
    val url: String,
    val title: String,
    val isCloudflareChallenge: Boolean = false,
    val retryTargetUrl: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    val settingsStore = AppSettingsStore(application)
    val metadataEnrichmentService = MetadataEnrichmentService()
    val unifiedHomeCatalogManager = UnifiedHomeCatalogManager(application)
    val imageLoader = MovieLinkNetwork.buildImageLoader(application) { settingsStore.settings.value }
    val httpClient = MovieLinkNetwork.buildHttpClient { settingsStore.settings.value }
    val streamHttpClient = MovieLinkNetwork.buildStreamHttpClient { settingsStore.settings.value }
    private val repository = MovieLinkRepository(httpClient) { settingsStore.settings.value }

    val settings: StateFlow<UserSettings> = settingsStore.settings
    val unifiedHomeCatalogs: StateFlow<List<UnifiedHomeCatalogEntry>> = unifiedHomeCatalogManager.entries
    val history: StateFlow<List<HistoryItem>> = settingsStore.history
    val myList: StateFlow<List<MyListItem>> = settingsStore.myList
    val watchedUrls: StateFlow<Set<String>> = settingsStore.watchedUrls
    val playbackProgress: StateFlow<List<PlaybackProgressItem>> = settingsStore.playbackProgress
    val unifiedContinueWatching: StateFlow<List<PlaybackProgressItem>> = playbackProgress
        .map { items -> deduplicateContinueWatching(items) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val sessionBlockedCount: StateFlow<Int> = AdBlocker.sessionBlockedCount
    private var latestMovieLinkHomeSections: List<CatalogSection>? = null

    private val _heroEnrichedItems = MutableStateFlow<Map<String, UnifiedPosterItem>>(emptyMap())
    val heroEnrichedItems: StateFlow<Map<String, UnifiedPosterItem>> = _heroEnrichedItems.asStateFlow()
    private val inFlightHeroEnrichKeys = java.util.Collections.synchronizedSet(HashSet<String>())
    private val completedHeroEnrichKeys = java.util.Collections.synchronizedSet(HashSet<String>())
    private val heroEnrichPermits = Semaphore(4)

    private val _backStack = MutableStateFlow<List<NavScreen>>(emptyList())
    val backStack: StateFlow<List<NavScreen>> = _backStack.asStateFlow()

    private val _catalog = MutableStateFlow<CatalogPage?>(null)
    val catalog: StateFlow<CatalogPage?> = _catalog.asStateFlow()

    private val _catalogLoading = MutableStateFlow(false)
    val catalogLoading: StateFlow<Boolean> = _catalogLoading.asStateFlow()

    private val _catalogError = MutableStateFlow<String?>(null)
    val catalogError: StateFlow<String?> = _catalogError.asStateFlow()

    private val _detail = MutableStateFlow<MediaDetail?>(null)
    val detail: StateFlow<MediaDetail?> = _detail.asStateFlow()

    private val _detailLoading = MutableStateFlow(false)
    val detailLoading: StateFlow<Boolean> = _detailLoading.asStateFlow()

    private val _detailError = MutableStateFlow<String?>(null)
    val detailError: StateFlow<String?> = _detailError.asStateFlow()

    private val _playerRequest = MutableStateFlow<PlayerLaunchRequest?>(null)
    val playerRequest: StateFlow<PlayerLaunchRequest?> = _playerRequest.asStateFlow()

    private val _fallbackWeb = MutableStateFlow<FallbackWebRequest?>(null)
    val fallbackWeb: StateFlow<FallbackWebRequest?> = _fallbackWeb.asStateFlow()

    private val _trailerId = MutableStateFlow<Pair<String, String>?>(null)
    val trailerId: StateFlow<Pair<String, String>?> = _trailerId.asStateFlow()

    private val _pendingVideoChoice = MutableStateFlow<PendingVideoChoice?>(null)
    val pendingVideoChoice: StateFlow<PendingVideoChoice?> = _pendingVideoChoice.asStateFlow()

    private val _pendingDownloaderChoice = MutableStateFlow<PendingDownloaderChoice?>(null)
    val pendingDownloaderChoice: StateFlow<PendingDownloaderChoice?> = _pendingDownloaderChoice.asStateFlow()

    private val _categoryHomeRows = MutableStateFlow<Map<String, CategoryHomeRowData>>(emptyMap())
    private val inFlightCategoryCatalogKeys = java.util.Collections.synchronizedSet(HashSet<String>())

    private val _heroCategoryRows = MutableStateFlow<Map<String, CategoryHomeRowData>>(emptyMap())
    private val inFlightHeroCategoryKeys = java.util.Collections.synchronizedSet(HashSet<String>())

    private val _heroShuffleSeed = MutableStateFlow(System.nanoTime())
    private var activeDetailSeq = 0L
    private val initialSessionHeroKey: String? = settingsStore.getLastHeroLeadKey()
    private var lastSavedHeroKey: String? = initialSessionHeroKey
    private var excludeHeroKeyForSeed: String? = initialSessionHeroKey

    private val detailCache = object : LinkedHashMap<String, MediaDetail>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, MediaDetail>?): Boolean = size > 24
    }
    private val catalogCache = object : LinkedHashMap<String, CatalogPage>(8, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, CatalogPage>?): Boolean = size > 10
    }

    private fun cacheKey(url: String): String = url.trim().trimEnd('/').lowercase()

    private val _unifiedSearch = MutableStateFlow(UnifiedSearchState())
    val unifiedSearch: StateFlow<UnifiedSearchState> = _unifiedSearch.asStateFlow()
    private var activeSearchJob: Job? = null

    val availableHeroSources: StateFlow<List<HeroSourceOption>> = combine(
        _catalog,
        unifiedHomeCatalogs
    ) { page: CatalogPage?, homeEntries: List<UnifiedHomeCatalogEntry> ->
        val mlTitles = if (page != null && !page.isSearchOrGrid && isHomePageUrl(page.url) && page.sections.isNotEmpty()) {
            page.sections.map { it.title.trim() }.filter { it.isNotEmpty() }.distinctBy { it.lowercase() }
        } else {
            UnifiedHomeCatalogManager.DEFAULT_MOVIELINK_SECTIONS
        }
        val mlOptions = mlTitles.map { title ->
            HeroSourceOption(
                key = UnifiedHomeCatalogManager.movieLinkKey(title),
                title = title,
                providerLabel = "MovieLinkBD Home",
                isAvailable = true
            )
        }
        val catEntries = homeEntries.filter { it.movieLinkCategoryUrl != null || it.key.startsWith("ml:cat:") }
        val catOptions = if (catEntries.isNotEmpty()) {
            catEntries.map { entry ->
                HeroSourceOption(
                    key = entry.key,
                    title = entry.title,
                    providerLabel = "Category · MovieLinkBD",
                    isAvailable = true
                )
            }
        } else {
            UnifiedHomeCatalogManager.DEFAULT_MOVIELINK_CATEGORIES.map { chip ->
                HeroSourceOption(
                    key = UnifiedHomeCatalogManager.movieLinkCategoryKey(chip.label),
                    title = chip.label,
                    providerLabel = "Category · MovieLinkBD",
                    isAvailable = true
                )
            }
        }
        mlOptions + catOptions
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val baseHeroState: StateFlow<HeroSectionState> = combine(
        _catalog,
        settings,
        _heroCategoryRows,
        _categoryHomeRows,
        _heroShuffleSeed
    ) { page: CatalogPage?,
        userSettings: UserSettings,
        heroCatRowsMap: Map<String, CategoryHomeRowData>,
        catHomeRowsMap: Map<String, CategoryHomeRowData>,
        shuffleSeed: Long ->
        val mlHeroOn = userSettings.movieLinkHeroEnabled
        if (!mlHeroOn) {
            return@combine HeroSectionState(hidden = true)
        }

        val selectedKeys = userSettings.effectiveHeroSourceKeys()
        val isHomePage = page != null && !page.isSearchOrGrid && isHomePageUrl(page.url)
        val sourcePools = mutableListOf<List<UnifiedPosterItem>>()
        val sourceLabels = mutableListOf<String>()
        var anyCategoryLoading = false
        var firstCategoryError: String? = null

        if (selectedKeys.isEmpty()) {
            if (!isHomePage || page == null) {
                return@combine HeroSectionState(hidden = true)
            }
            val movieSectionItems = page.sections
                .filter {
                    it.title.equals("Movies", ignoreCase = true) ||
                        (it.title.contains("Movie", ignoreCase = true) &&
                            !it.title.contains("Recently", ignoreCase = true))
                }
                .flatMap { it.items }
            val otherMovieItems = page.sections
                .filterNot {
                    it.title.contains("Recently Updated", ignoreCase = true) ||
                        it.title.contains("Recently Uploaded", ignoreCase = true)
                }
                .flatMap { it.items }
                .filter { it.url.contains("/movie/", ignoreCase = true) }
            val nonRecentFallback = page.sections
                .filterNot {
                    it.title.contains("Recently Updated", ignoreCase = true) ||
                        it.title.contains("Recently Uploaded", ignoreCase = true)
                }
                .flatMap { it.items }
            val prioritized = (movieSectionItems + otherMovieItems).ifEmpty {
                nonRecentFallback.ifEmpty { page.sections.flatMap { it.items } }
            }
            val autoPool = prioritized
                .filter { it.posterUrl.isNotBlank() }
                .distinctBy { it.url }
                .take(18)
                .map { UnifiedPosterItem.fromMovieLink(it) }
            if (autoPool.isNotEmpty()) {
                sourcePools += autoPool
                sourceLabels += "MovieLinkBD Auto"
            }
        } else {
            val activeKeys = selectedKeys.filter { it.startsWith("ml:") }
            if (activeKeys.isEmpty()) {
                return@combine HeroSectionState(hidden = true)
            }

            activeKeys.sorted().forEach { key ->
                when {
                    key.startsWith("ml:cat:") -> {
                        val cached = heroCatRowsMap[key] ?: catHomeRowsMap[key]
                        if (cached == null || cached.isLoading) {
                            anyCategoryLoading = true
                        }
                        if (firstCategoryError == null && !cached?.error.isNullOrBlank()) {
                            firstCategoryError = cached?.error
                        }
                        val catItems = cached?.items.orEmpty()
                            .filter { it.posterUrl.isNotBlank() }
                            .distinctBy { it.stableKey }
                            .take(18)
                        if (catItems.isNotEmpty()) {
                            sourcePools += catItems
                            val catTitle = unifiedHomeCatalogs.value.firstOrNull { it.key == key }?.title
                                ?: key.removePrefix("ml:cat:").replaceFirstChar { it.uppercase() }
                            sourceLabels += catTitle
                        }
                    }
                    key.startsWith("ml:") -> {
                        if (isHomePage && page != null) {
                            val targetTitle = key.removePrefix("ml:").trim().lowercase()
                            val sec = page.sections.firstOrNull { it.title.trim().lowercase() == targetTitle }
                            val mlItems = sec?.items.orEmpty()
                                .filter { it.posterUrl.isNotBlank() }
                                .distinctBy { it.url }
                                .take(14)
                                .map { UnifiedPosterItem.fromMovieLink(it) }
                            if (mlItems.isNotEmpty()) {
                                sourcePools += mlItems
                                sec?.title?.takeIf { it.isNotBlank() }?.let { sourceLabels += it }
                            }
                        }
                    }
                }
            }
        }

        val combinedCandidates = interleaveAndDeduplicate(sourcePools, maxItems = 36)
        if (combinedCandidates.isEmpty()) {
            val hasCategorySelected = selectedKeys.any { it.startsWith("ml:cat:") }
            if (hasCategorySelected && anyCategoryLoading) {
                return@combine HeroSectionState(
                    items = emptyList(),
                    isLoading = true,
                    error = firstCategoryError,
                    activeSourceTitle = sourceLabels.firstOrNull(),
                    hidden = false
                )
            }
            return@combine HeroSectionState(
                items = emptyList(),
                isLoading = false,
                error = firstCategoryError,
                hidden = true
            )
        }

        val shuffled = combinedCandidates
            .shuffled(kotlin.random.Random(shuffleSeed))
            .take(10)
            .toMutableList()

        val featuredIdx = if (userSettings.heroLayoutStyle == Config.HeroLayoutStyle.CAROUSEL && shuffled.size >= 3) {
            1
        } else {
            0
        }
        val excludedKey = excludeHeroKeyForSeed
        if (excludedKey != null && shuffled.size > 1 && shuffled[featuredIdx].stableKey == excludedKey) {
            val swapIdx = shuffled.indices.firstOrNull { idx ->
                idx != featuredIdx && shuffled[idx].stableKey != excludedKey
            }
            if (swapIdx != null) {
                val tmp = shuffled[featuredIdx]
                shuffled[featuredIdx] = shuffled[swapIdx]
                shuffled[swapIdx] = tmp
            }
        }

        val currentFeaturedKey = shuffled.getOrNull(featuredIdx)?.stableKey
        if (!currentFeaturedKey.isNullOrBlank() && currentFeaturedKey != lastSavedHeroKey) {
            lastSavedHeroKey = currentFeaturedKey
            settingsStore.setLastHeroLeadKey(currentFeaturedKey)
        }

        val activeTitle = when {
            sourceLabels.isEmpty() -> null
            sourceLabels.size == 1 -> sourceLabels.first()
            else -> "${sourceLabels.size} Catalogues"
        }

        HeroSectionState(
            items = shuffled,
            isLoading = anyCategoryLoading && shuffled.isEmpty(),
            error = firstCategoryError,
            activeSourceTitle = activeTitle,
            hidden = false
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, HeroSectionState())

    val heroState: StateFlow<HeroSectionState> = combine(
        baseHeroState,
        _heroEnrichedItems
    ) { state: HeroSectionState, enrichedMap: Map<String, UnifiedPosterItem> ->
        if (state.items.isEmpty() || enrichedMap.isEmpty()) {
            state
        } else {
            state.copy(
                items = state.items.map { item ->
                    val enriched = enrichedMap[item.stableKey] ?: return@map item
                    item.copy(
                        posterUrl = enriched.posterUrl.ifBlank { item.posterUrl },
                        fallbackPosterUrl = item.fallbackPosterUrl.ifBlank { enriched.fallbackPosterUrl },
                        backdropUrl = enriched.backdropUrl.ifBlank { item.backdropUrl },
                        logoUrl = enriched.logoUrl.ifBlank { item.logoUrl },
                        rating = enriched.rating.ifBlank { item.rating },
                        yearOrRelease = enriched.yearOrRelease.ifBlank { item.yearOrRelease },
                        genres = enriched.genres.ifEmpty { item.genres },
                        description = enriched.description.ifBlank { item.description },
                        imdbId = enriched.imdbId ?: item.imdbId
                    )
                }
            )
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, HeroSectionState())

    val combinedHomeSections: StateFlow<List<CombinedHomeSectionState>> = combine(
        _catalog,
        unifiedHomeCatalogs,
        _categoryHomeRows
    ) { page: CatalogPage?,
        entries: List<UnifiedHomeCatalogEntry>,
        categoryRowsMap: Map<String, CategoryHomeRowData> ->
        if (page == null || page.isSearchOrGrid || !isHomePageUrl(page.url)) {
            emptyList()
        } else {
            val mlSectionByLower = page.sections.associateBy { it.title.trim().lowercase() }
            if (entries.isEmpty()) {
                page.sections.map { sec ->
                    CombinedHomeSectionState(
                        key = UnifiedHomeCatalogManager.movieLinkKey(sec.title),
                        title = sec.title,
                        items = sec.items.map { UnifiedPosterItem.fromMovieLink(it) },
                        moreUrl = sec.moreUrl
                    )
                }
            } else {
                entries.mapNotNull { entry ->
                    if (!entry.enabled || !entry.isAvailable) return@mapNotNull null
                    if (entry.movieLinkCategoryUrl != null || entry.key.startsWith("ml:cat:")) {
                        val rowState = categoryRowsMap[entry.key]
                        val catItems = rowState?.items.orEmpty()
                        val catUrl = entry.movieLinkCategoryUrl ?: findKnownCategoryUrl(entry.key)
                        CombinedHomeSectionState(
                            key = entry.key,
                            title = entry.title,
                            items = catItems,
                            moreUrl = catUrl,
                            isLoading = (rowState == null || rowState.isLoading) && catItems.isEmpty(),
                            error = rowState?.error
                        )
                    } else {
                        val secTitle = (entry.movieLinkSectionTitle ?: entry.title).trim().lowercase()
                        val matched = mlSectionByLower[secTitle] ?: return@mapNotNull null
                        CombinedHomeSectionState(
                            key = entry.key,
                            title = matched.title,
                            items = matched.items.map { UnifiedPosterItem.fromMovieLink(it) },
                            moreUrl = matched.moreUrl
                        )
                    }
                }
            }
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        unifiedHomeCatalogManager.syncSources(null, null, settings.value.mirrorUrl)
        val startUrl = settingsStore.startupUrl()
        if (isDetailUrl(startUrl)) {
            _backStack.value = listOf(
                NavScreen.Catalog(settings.value.mirrorUrl),
                NavScreen.Detail(startUrl)
            )
            loadCatalog(settings.value.mirrorUrl, recordVisit = false)
            loadDetail(startUrl)
        } else {
            _backStack.value = listOf(NavScreen.Catalog(startUrl))
            loadCatalog(startUrl, recordVisit = true)
        }

        viewModelScope.launch {
            unifiedHomeCatalogs.collect {
                refreshEnabledCategoryHomeSections(forceRefresh = false)
            }
        }

        viewModelScope.launch {
            var lastSelectedHeroKeys: Set<String>? = null
            settings.collect { s ->
                val heroKeys = s.effectiveHeroSourceKeys()
                if (lastSelectedHeroKeys != null && lastSelectedHeroKeys != heroKeys) {
                    bumpHeroShuffleSeed()
                }
                lastSelectedHeroKeys = heroKeys
                val heroCatKeys = heroKeys.filter { it.startsWith("ml:cat:") }
                if (heroCatKeys.isNotEmpty()) {
                    refreshHeroCategorySources(heroCatKeys.toSet(), forceRefresh = false)
                }
            }
        }

        viewModelScope.launch {
            combine(baseHeroState, settings) { state, s ->
                state.items to Triple(s.tmdbMetadataEnabled, s.tmdbApiKey, s.betterPosterProvider)
            }.collect { (items, _) ->
                if (items.isNotEmpty()) {
                    ensureHeroArtworkEnriched(items)
                }
            }
        }
    }

    fun currentUrl(): String {
        return when (val top = _backStack.value.lastOrNull()) {
            is NavScreen.Detail -> top.url
            is NavScreen.Catalog -> top.url
            null -> settings.value.mirrorUrl
        }
    }

    fun isDetailUrl(url: String): Boolean {
        val lower = url.lowercase()
        return lower.contains("/movie/") ||
            lower.contains("/series/") ||
            lower.contains("/drama/") ||
            lower.contains("/anime/")
    }

    fun openCatalogUrl(url: String) {
        val normalized = Config.normalizeUrl(url)
        _backStack.value = listOf(NavScreen.Catalog(normalized))
        val cached = synchronized(catalogCache) { catalogCache[cacheKey(normalized)] }
        if (cached != null) {
            _catalog.value = cached
            _catalogError.value = null
            _catalogLoading.value = false
            syncCatalogHomeMetadata(cached)
            settingsStore.recordHistory(cached.pageTitle, cached.url)
        } else {
            loadCatalog(normalized, recordVisit = true, forceRefresh = false)
        }
    }

    fun searchCatalog(query: String) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return

        val currentSearch = _unifiedSearch.value
        if (currentSearch.hasSearched && currentSearch.query == trimmed && currentSearch.movieLink.isLoading) {
            return
        }

        activeSearchJob?.cancel()
        val runMl = settings.value.movieLinkSearchEnabled
        _unifiedSearch.value = UnifiedSearchState(
            query = trimmed,
            hasSearched = true,
            movieLink = MovieLinkSearchSectionState(isLoading = runMl)
        )

        if (!runMl) return

        activeSearchJob = viewModelScope.launch {
            executeMovieLinkSearch(trimmed)
        }
    }

    private suspend fun executeMovieLinkSearch(query: String) {
        try {
            val page = repository.searchCatalog(query)
            val items = page.sections
                .flatMap { it.items }
                .distinctBy { it.url }
                .map { UnifiedPosterItem.fromMovieLink(it) }
            _unifiedSearch.update { state ->
                state.copy(
                    movieLink = MovieLinkSearchSectionState(
                        items = items,
                        nextPageUrl = page.nextPageUrl,
                        isLoading = false,
                        error = null
                    )
                )
            }
            settingsStore.recordHistory(page.pageTitle, page.url)
        } catch (cf: CloudflareRequiredException) {
            _unifiedSearch.update { state ->
                state.copy(
                    movieLink = state.movieLink.copy(
                        isLoading = false,
                        error = "Cloudflare verification required"
                    )
                )
            }
            _fallbackWeb.value = FallbackWebRequest(cf.url, "Security Check", isCloudflareChallenge = true, retryTargetUrl = cf.url)
        } catch (e: Exception) {
            _unifiedSearch.update { state ->
                state.copy(
                    movieLink = state.movieLink.copy(
                        isLoading = false,
                        error = e.message ?: "Unable to search MovieLinkBD"
                    )
                )
            }
        }
    }

    fun clearUnifiedSearch() {
        activeSearchJob?.cancel()
        _unifiedSearch.value = UnifiedSearchState()
    }

    fun retryMovieLinkSearch() {
        val q = _unifiedSearch.value.query.trim()
        if (q.isEmpty() || !settings.value.movieLinkSearchEnabled) return
        _unifiedSearch.update { state ->
            state.copy(movieLink = state.movieLink.copy(isLoading = true, error = null))
        }
        viewModelScope.launch {
            executeMovieLinkSearch(q)
        }
    }

    fun loadMoreMovieLinkSearch() {
        val ml = _unifiedSearch.value.movieLink
        val nextUrl = ml.nextPageUrl ?: return
        if (ml.isLoading || ml.isLoadingMore) return
        _unifiedSearch.update { state ->
            state.copy(movieLink = state.movieLink.copy(isLoadingMore = true, error = null))
        }
        viewModelScope.launch {
            try {
                val page = repository.fetchCatalogPage(nextUrl)
                val nextItems = page.sections.flatMap { it.items }.map { UnifiedPosterItem.fromMovieLink(it) }
                _unifiedSearch.update { state ->
                    val merged = (state.movieLink.items + nextItems).distinctBy { it.stableKey }
                    state.copy(
                        movieLink = state.movieLink.copy(
                            items = merged,
                            nextPageUrl = page.nextPageUrl,
                            isLoadingMore = false,
                            error = null
                        )
                    )
                }
            } catch (cf: CloudflareRequiredException) {
                _unifiedSearch.update { state ->
                    state.copy(movieLink = state.movieLink.copy(isLoadingMore = false, error = "Cloudflare verification required"))
                }
                _fallbackWeb.value = FallbackWebRequest(cf.url, "Security Check", isCloudflareChallenge = true, retryTargetUrl = cf.url)
            } catch (e: Exception) {
                _unifiedSearch.update { state ->
                    state.copy(movieLink = state.movieLink.copy(isLoadingMore = false, error = e.message ?: "Failed to load more results"))
                }
            }
        }
    }

    fun openDetailUrl(url: String, titleHint: String? = null, posterHint: String = "") {
        val currentStack = _backStack.value.ifEmpty { listOf(NavScreen.Catalog(settings.value.mirrorUrl)) }
        _backStack.value = currentStack + NavScreen.Detail(url)
        val cached = synchronized(detailCache) { detailCache[cacheKey(url)] }
        if (cached != null) {
            _detail.value = cached
            _detailError.value = null
            _detailLoading.value = false
            settingsStore.recordHistory(cached.title.ifBlank { titleHint }, cached.url, cached.posterUrl)
        } else {
            _detail.value = null
            _detailError.value = null
            loadDetail(url, titleHint, posterHint, forceRefresh = true)
        }
    }

    fun openUrlSmart(url: String, titleHint: String? = null, posterHint: String = "") {
        if (isDetailUrl(url)) {
            openDetailUrl(url, titleHint, posterHint)
        } else {
            openCatalogUrl(url)
        }
    }

    fun refreshCurrent() {
        when (val top = _backStack.value.lastOrNull()) {
            is NavScreen.Detail -> loadDetail(top.url, forceRefresh = true)
            is NavScreen.Catalog -> {
                if (isHomePageUrl(top.url)) {
                    bumpHeroShuffleSeed()
                    refreshEnabledCategoryHomeSections(forceRefresh = true)
                    val heroCatKeys = settings.value.effectiveHeroSourceKeys().filter { it.startsWith("ml:cat:") }.toSet()
                    if (heroCatKeys.isNotEmpty()) {
                        refreshHeroCategorySources(heroCatKeys, forceRefresh = true)
                    }
                }
                loadCatalog(top.url, recordVisit = false, forceRefresh = true)
            }
            null -> openCatalogUrl(settings.value.mirrorUrl)
        }
    }

    fun navigateBack(): Boolean {
        val stack = _backStack.value
        if (stack.size <= 1) return false
        val next = stack.dropLast(1)
        when (val top = next.last()) {
            is NavScreen.Detail -> {
                val cached = synchronized(detailCache) { detailCache[cacheKey(top.url)] }
                if (cached != null) {
                    _detail.value = cached
                    _detailError.value = null
                    _detailLoading.value = false
                    _backStack.value = next
                } else {
                    _detail.value = null
                    _backStack.value = next
                    loadDetail(top.url, forceRefresh = true)
                }
            }
            is NavScreen.Catalog -> {
                _backStack.value = next
                if (cacheKey(_catalog.value?.url.orEmpty()) != cacheKey(top.url)) {
                    val cached = synchronized(catalogCache) { catalogCache[cacheKey(top.url)] }
                    if (cached != null) {
                        _catalog.value = cached
                        _catalogError.value = null
                        _catalogLoading.value = false
                    } else {
                        loadCatalog(top.url, recordVisit = false, forceRefresh = false)
                    }
                }
            }
        }
        return true
    }

    fun isHomePageUrl(url: String): Boolean {
        val cleanPath = android.net.Uri.parse(Config.normalizeUrl(url)).path?.trim('/').orEmpty()
        return cleanPath.isEmpty() || cleanPath.equals("index.php", ignoreCase = true)
    }

    private fun syncCatalogHomeMetadata(page: CatalogPage) {
        if (!page.isSearchOrGrid && isHomePageUrl(page.url)) {
            latestMovieLinkHomeSections = page.sections
            unifiedHomeCatalogManager.syncSources(
                page.sections,
                page.categories,
                settings.value.mirrorUrl
            )
        } else if (page.categories.isNotEmpty()) {
            unifiedHomeCatalogManager.syncSources(
                latestMovieLinkHomeSections,
                page.categories,
                settings.value.mirrorUrl
            )
        }
    }

    private fun loadCatalog(url: String, recordVisit: Boolean, forceRefresh: Boolean = false) {
        viewModelScope.launch {
            _catalogLoading.value = true
            _catalogError.value = null
            try {
                val page = repository.fetchCatalogPage(url)
                synchronized(catalogCache) {
                    catalogCache[cacheKey(url)] = page
                    catalogCache[cacheKey(page.url)] = page
                }
                _catalog.value = page
                syncCatalogHomeMetadata(page)
                if (recordVisit) {
                    settingsStore.recordHistory(page.pageTitle, page.url)
                }
            } catch (cf: CloudflareRequiredException) {
                _catalogError.value = "Cloudflare verification required"
                _fallbackWeb.value = FallbackWebRequest(cf.url, "Security Check", isCloudflareChallenge = true, retryTargetUrl = cf.url)
            } catch (e: Exception) {
                _catalogError.value = e.message ?: "Connection failed"
            } finally {
                _catalogLoading.value = false
            }
        }
    }

    private fun loadDetail(
        url: String,
        titleHint: String? = null,
        posterHint: String = "",
        forceRefresh: Boolean = false
    ) {
        if (!forceRefresh) {
            val cached = synchronized(detailCache) { detailCache[cacheKey(url)] }
            if (cached != null) {
                _detail.value = cached
                _detailError.value = null
                _detailLoading.value = false
                return
            }
        }
        val reqSeq = ++activeDetailSeq
        val heroCached = _heroEnrichedItems.value.values.firstOrNull { cached ->
            cached.movieLinkUrl.equals(url, ignoreCase = true) ||
                (!titleHint.isNullOrBlank() && cached.title.equals(titleHint, ignoreCase = true))
        }
        viewModelScope.launch {
            _detailLoading.value = true
            _detailError.value = null
            try {
                val d = repository.fetchDetail(url)
                val mergedPoster = d.posterUrl
                    .ifBlank { heroCached?.posterUrl.orEmpty() }
                    .ifBlank { posterHint }
                val preEnriched = d.copy(
                    posterUrl = mergedPoster,
                    backdropUrl = d.backdropUrl.ifBlank { heroCached?.backdropUrl.orEmpty() },
                    logoUrl = d.logoUrl.ifBlank { heroCached?.logoUrl.orEmpty() },
                    genres = d.genres.ifEmpty { heroCached?.genres.orEmpty() }
                )
                synchronized(detailCache) {
                    detailCache[cacheKey(url)] = preEnriched
                    detailCache[cacheKey(preEnriched.url)] = preEnriched
                }
                if (reqSeq != activeDetailSeq) return@launch
                _detail.value = preEnriched
                settingsStore.recordHistory(preEnriched.title.ifBlank { titleHint }, preEnriched.url, mergedPoster)
                val s = settings.value
                val enriched = metadataEnrichmentService.enrichMovieLinkDetail(
                    detail = preEnriched,
                    settings = s,
                    titleHint = titleHint.orEmpty()
                )
                synchronized(detailCache) {
                    detailCache[cacheKey(url)] = enriched
                    detailCache[cacheKey(enriched.url)] = enriched
                }
                if (reqSeq == activeDetailSeq && _detail.value?.url == preEnriched.url) {
                    _detail.value = enriched
                }
            } catch (cf: CloudflareRequiredException) {
                if (reqSeq == activeDetailSeq) {
                    _detailError.value = "Cloudflare verification required"
                    _fallbackWeb.value = FallbackWebRequest(cf.url, "Security Check", isCloudflareChallenge = true, retryTargetUrl = cf.url)
                }
            } catch (e: Exception) {
                if (reqSeq == activeDetailSeq) {
                    _detailError.value = e.message ?: "Unable to load movie details"
                }
            } finally {
                if (reqSeq == activeDetailSeq) {
                    _detailLoading.value = false
                }
            }
        }
    }

    fun launchPlayer(request: PlayerLaunchRequest) {
        _playerRequest.value = request
    }

    fun closePlayer() {
        _playerRequest.value = null
    }

    fun resumeContinueWatching(item: PlaybackProgressItem) {
        if (item.streamUrl.isNotBlank()) {
            launchPlayer(
                PlayerLaunchRequest(
                    streamUrl = item.streamUrl,
                    title = item.title,
                    subtitle = item.subtitle,
                    refererUrl = item.refererUrl,
                    isEmbedPage = item.isEmbedPage,
                    requestHeaders = item.requestHeaders,
                    mimeTypeHint = item.mimeTypeHint,
                    sourceLabel = item.sourceLabel,
                    mediaKey = item.mediaKey,
                    posterUrl = item.posterUrl,
                    contentType = item.contentType,
                    isLocalMedia = item.sourceType == "local"
                )
            )
            return
        }
        if (item.refererUrl.isNotBlank()) {
            openDetailUrl(item.refererUrl, item.title, item.posterUrl)
        }
    }

    fun myListKeyForPoster(item: UnifiedPosterItem): String =
        item.movieLinkUrl.orEmpty()

    fun togglePosterMyList(item: UnifiedPosterItem): Boolean {
        val key = myListKeyForPoster(item)
        if (key.isBlank()) return false
        return settingsStore.toggleMyList(
            MyListItem(
                url = key,
                title = item.title,
                posterUrl = item.posterUrl,
                type = item.type.ifBlank { "Title" },
                quality = item.qualityOrBadge.ifBlank { item.rating.takeIf { it.isNotBlank() }?.let { "★ $it" }.orEmpty() },
                language = item.language.ifBlank { item.yearOrRelease },
                addedAt = System.currentTimeMillis()
            )
        )
    }

    fun openMyListItem(item: MyListItem) {
        if (item.url.isNotBlank()) {
            openDetailUrl(item.url, item.title, item.posterUrl)
        }
    }

    private fun deduplicateContinueWatching(items: List<PlaybackProgressItem>): List<PlaybackProgressItem> {
        if (items.isEmpty()) return emptyList()
        val seenKeys = HashSet<String>()
        val result = ArrayList<PlaybackProgressItem>(items.size)
        for (item in items.sortedByDescending { it.updatedAt }) {
            if (item.positionMs < 5_000L) continue
            val canonicalKey = when {
                item.mediaKey.startsWith("ml:") -> {
                    "ml:" + item.mediaKey.removePrefix("ml:").trim().trimEnd('/').lowercase()
                }
                else -> item.mediaKey.trim().trimEnd('/').lowercase()
            }
            if (seenKeys.add(canonicalKey)) {
                result.add(item)
            }
            if (result.size >= 15) break
        }
        return result
    }

    fun openFallbackWeb(url: String, title: String = "Noxera Browser") {
        _fallbackWeb.value = FallbackWebRequest(url, title, isCloudflareChallenge = false, retryTargetUrl = null)
    }

    fun closeFallbackWeb() {
        _fallbackWeb.value = null
    }

    fun onCloudflareSolved() {
        val retryUrl = _fallbackWeb.value?.retryTargetUrl
        _fallbackWeb.value = null
        if (!retryUrl.isNullOrBlank()) {
            when {
                retryUrl.contains("/search", ignoreCase = true) && _unifiedSearch.value.hasSearched ->
                    retryMovieLinkSearch()
                isDetailUrl(retryUrl) -> loadDetail(retryUrl)
                else -> loadCatalog(retryUrl, recordVisit = true)
            }
        } else {
            refreshCurrent()
        }
    }

    fun openTrailer(youtubeId: String, title: String) {
        _trailerId.value = youtubeId to title
    }

    fun closeTrailer() {
        _trailerId.value = null
    }

    fun showVideoChoice(choice: PendingVideoChoice) {
        _pendingVideoChoice.value = choice
    }

    fun dismissVideoChoice() {
        _pendingVideoChoice.value = null
    }

    fun showDownloaderChoice(choice: PendingDownloaderChoice) {
        _pendingDownloaderChoice.value = choice
    }

    fun dismissDownloaderChoice() {
        _pendingDownloaderChoice.value = null
    }

    fun setUnifiedHomeCatalogEnabled(key: String, enabled: Boolean) {
        unifiedHomeCatalogManager.setCatalogEnabled(key, enabled)
    }

    fun moveUnifiedHomeCatalog(fromIndex: Int, toIndex: Int) {
        unifiedHomeCatalogManager.moveCatalog(fromIndex, toIndex)
    }

    fun retryCategoryHomeSection(entryKey: String) {
        _categoryHomeRows.update { map -> map - entryKey }
        refreshEnabledCategoryHomeSections(forceRefresh = true)
    }

    fun findKnownCategoryUrl(key: String): String? {
        val entry = unifiedHomeCatalogs.value.firstOrNull { it.key == key }
        if (!entry?.movieLinkCategoryUrl.isNullOrBlank()) return entry?.movieLinkCategoryUrl
        val label = key.removePrefix("ml:cat:")
        val matched = UnifiedHomeCatalogManager.DEFAULT_MOVIELINK_CATEGORIES.firstOrNull {
            it.label.trim().lowercase() == label.trim().lowercase()
        } ?: return null
        val mirror = settings.value.mirrorUrl.ifBlank { Config.DEFAULT_HOME_URL }
        return if (matched.url.startsWith("http", ignoreCase = true)) {
            matched.url
        } else {
            mirror.trimEnd('/') + "/" + matched.url.trimStart('/')
        }
    }

    fun refreshEnabledCategoryHomeSections(forceRefresh: Boolean = false) {
        val enabledCatEntries = unifiedHomeCatalogs.value.filter {
            it.enabled && it.isAvailable && (it.movieLinkCategoryUrl != null || it.key.startsWith("ml:cat:"))
        }
        for (entry in enabledCatEntries) {
            val catUrl = entry.movieLinkCategoryUrl ?: findKnownCategoryUrl(entry.key) ?: continue
            val existing = _categoryHomeRows.value[entry.key]
            if (!forceRefresh && existing != null && existing.items.isNotEmpty() && existing.error == null) {
                continue
            }
            if (!inFlightCategoryCatalogKeys.add(entry.key)) continue

            _categoryHomeRows.update { map ->
                map + (entry.key to CategoryHomeRowData(
                    items = existing?.items.orEmpty(),
                    isLoading = true,
                    error = null
                ))
            }

            viewModelScope.launch {
                try {
                    val page = repository.fetchCatalogPage(catUrl)
                    val rawItems = page.sections.flatMap { it.items }
                    val items = rawItems.distinctBy { it.url }.map { UnifiedPosterItem.fromMovieLink(it) }
                    _categoryHomeRows.update { map ->
                        map + (entry.key to CategoryHomeRowData(
                            items = items,
                            isLoading = false,
                            error = null,
                            hasMore = page.nextPageUrl != null
                        ))
                    }
                } catch (e: Exception) {
                    _categoryHomeRows.update { map ->
                        map + (entry.key to CategoryHomeRowData(
                            items = existing?.items.orEmpty(),
                            isLoading = false,
                            error = e.message ?: "Failed to load category"
                        ))
                    }
                } finally {
                    inFlightCategoryCatalogKeys.remove(entry.key)
                }
            }
        }
    }

    fun refreshHeroCategorySources(keys: Set<String>, forceRefresh: Boolean = false) {
        for (key in keys) {
            val catUrl = findKnownCategoryUrl(key) ?: continue
            val existing = _heroCategoryRows.value[key] ?: _categoryHomeRows.value[key]
            if (!forceRefresh && existing != null && existing.items.isNotEmpty() && existing.error == null) {
                if (_heroCategoryRows.value[key] == null) {
                    _heroCategoryRows.update { map -> map + (key to existing) }
                }
                continue
            }
            if (!inFlightHeroCategoryKeys.add(key)) continue

            _heroCategoryRows.update { map ->
                map + (key to CategoryHomeRowData(
                    items = existing?.items.orEmpty(),
                    isLoading = true,
                    error = null
                ))
            }

            viewModelScope.launch {
                try {
                    val page = repository.fetchCatalogPage(catUrl)
                    val rawItems = page.sections.flatMap { it.items }
                    val items = rawItems.distinctBy { it.url }.map { UnifiedPosterItem.fromMovieLink(it) }
                    _heroCategoryRows.update { map ->
                        map + (key to CategoryHomeRowData(
                            items = items,
                            isLoading = false,
                            error = null
                        ))
                    }
                } catch (e: Exception) {
                    _heroCategoryRows.update { map ->
                        map + (key to CategoryHomeRowData(
                            items = existing?.items.orEmpty(),
                            isLoading = false,
                            error = e.message ?: "Failed to load hero category"
                        ))
                    }
                } finally {
                    inFlightHeroCategoryKeys.remove(key)
                }
            }
        }
    }

    private fun bumpHeroShuffleSeed() {
        val currentItems = heroState.value.items
        val currentFeaturedIdx = if (settings.value.heroLayoutStyle == Config.HeroLayoutStyle.CAROUSEL && currentItems.size >= 3) {
            1
        } else {
            0
        }
        excludeHeroKeyForSeed = currentItems.getOrNull(currentFeaturedIdx)?.stableKey ?: lastSavedHeroKey
        _heroShuffleSeed.value = System.nanoTime()
    }

    private fun interleaveAndDeduplicate(
        pools: List<List<UnifiedPosterItem>>,
        maxItems: Int
    ): List<UnifiedPosterItem> {
        if (pools.isEmpty()) return emptyList()
        if (pools.size == 1) return pools.first().distinctBy { it.stableKey }.take(maxItems)
        val result = ArrayList<UnifiedPosterItem>(maxItems)
        val seen = HashSet<String>()
        val maxLen = pools.maxOf { it.size }
        for (i in 0 until maxLen) {
            for (pool in pools) {
                val item = pool.getOrNull(i) ?: continue
                if (seen.add(item.stableKey)) {
                    result.add(item)
                    if (result.size >= maxItems) return result
                }
            }
        }
        return result
    }

    fun ensureHeroArtworkEnriched(items: List<UnifiedPosterItem>) {
        if (items.isEmpty()) return
        val s = settings.value
        val tmdbSig = "${s.tmdbMetadataEnabled}|${s.tmdbApiKey.take(6)}|${s.betterPosterProvider.id}"
        items.forEach { item ->
            val hasRealBackdrop = item.backdropUrl.isNotBlank() && item.backdropUrl != item.posterUrl
            if (hasRealBackdrop && item.logoUrl.isNotBlank() && item.posterUrl.isNotBlank()) return@forEach

            val key = item.stableKey
            val flightKey = "$key|$tmdbSig"
            if (completedHeroEnrichKeys.contains(flightKey)) return@forEach

            val cached = _heroEnrichedItems.value[key]
            val cachedOk = cached != null &&
                cached.backdropUrl.isNotBlank() &&
                cached.logoUrl.isNotBlank() &&
                cached.posterUrl.isNotBlank()
            if (cachedOk) return@forEach

            if (!inFlightHeroEnrichKeys.add(flightKey)) return@forEach

            viewModelScope.launch {
                try {
                    val enriched = heroEnrichPermits.withPermit {
                        metadataEnrichmentService.enrichHeroItem(item, settings.value)
                    }
                    completedHeroEnrichKeys.add(flightKey)
                    if (enriched.backdropUrl.isNotBlank() ||
                        enriched.logoUrl.isNotBlank() ||
                        enriched.posterUrl.isNotBlank() ||
                        enriched.genres.isNotEmpty() ||
                        enriched.yearOrRelease.isNotBlank()
                    ) {
                        _heroEnrichedItems.update { current ->
                            current + (key to enriched)
                        }
                    }
                } finally {
                    inFlightHeroEnrichKeys.remove(flightKey)
                }
            }
        }
    }

    fun openUnifiedPoster(item: UnifiedPosterItem) {
        val resolvedItem = _heroEnrichedItems.value[item.stableKey] ?: item
        val url = resolvedItem.movieLinkUrl.orEmpty()
        if (url.isNotBlank()) {
            openUrlSmart(url, resolvedItem.title, resolvedItem.posterUrl)
        }
    }

    suspend fun testMetadataIntegration(
        kind: String,
        tmdbKey: String,
        mdbKey: String,
        bpProvider: Config.BetterPosterProvider,
        rpdbKey: String,
        customTemplate: String
    ): Result<String> {
        return when (kind) {
            "tmdb" -> metadataEnrichmentService.testTmdbConnection(tmdbKey)
            "mdblist" -> metadataEnrichmentService.testMdbListConnection(mdbKey)
            "better_poster" -> metadataEnrichmentService.testBetterPoster(bpProvider, rpdbKey, customTemplate)
            else -> Result.failure(IllegalArgumentException("Unknown integration"))
        }
    }
}
