package com.personal.movielink.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.personal.movielink.Config
import com.personal.movielink.HeroSourceOption
import com.personal.movielink.UserSettings
import com.personal.movielink.ui.theme.LocalMovieLinkPalette
import kotlin.math.roundToInt

@Composable
fun HeroSettingsSubpage(
    settings: UserSettings,
    heroSources: List<HeroSourceOption>,
    onUpdateSettings: ((UserSettings) -> UserSettings) -> Unit
) {
    val palette = LocalMovieLinkPalette.current

    val selectedKeys = settings.effectiveHeroSourceKeys()
    val validKeys = heroSources.map { it.key }.toSet()
    val unavailableSelected = selectedKeys.filter { it !in validKeys }

    fun toggleCatalogKey(key: String) {
        onUpdateSettings { current ->
            val currSet = current.effectiveHeroSourceKeys()
            val nextSet = if (key in currSet) currSet - key else currSet + key
            current.copy(
                heroSourceKeys = nextSet,
                heroSourceKey = nextSet.firstOrNull()
            )
        }
    }

    fun selectAutoDefault() {
        onUpdateSettings { current ->
            current.copy(
                heroSourceKeys = emptySet(),
                heroSourceKey = null
            )
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "Select one or more MovieLinkBD sections or categories to supply the Home screen hero section. The featured item changes automatically on every Home refresh and every time you reopen the app.",
            color = palette.textSecondary,
            fontSize = 12.sp,
            lineHeight = 17.sp
        )

        HeroSectionHeader("Home Hero Layout")
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            HeroLayoutOptionChip(
                title = "Coverflow Carousel",
                subtitle = "Poster deck",
                selected = settings.heroLayoutStyle == Config.HeroLayoutStyle.CAROUSEL,
                onClick = { onUpdateSettings { it.copy(heroLayoutStyle = Config.HeroLayoutStyle.CAROUSEL) } },
                modifier = Modifier.weight(1f)
            )
            HeroLayoutOptionChip(
                title = "Spotlight Banner",
                subtitle = "Full-bleed hero",
                selected = settings.heroLayoutStyle == Config.HeroLayoutStyle.SPOTLIGHT,
                onClick = { onUpdateSettings { it.copy(heroLayoutStyle = Config.HeroLayoutStyle.SPOTLIGHT) } },
                modifier = Modifier.weight(1f)
            )
        }

        HeroSectionHeader("Hero Size")
        HeroSizeScaleCard(
            title = "Home Screen Hero Size",
            subtitle = "Adjusts spotlight banner height & coverflow poster scale on Home",
            percent = settings.heroSizePercent,
            onPercentChange = { pct ->
                onUpdateSettings { it.copy(heroSizePercent = pct.coerceIn(75, 130)) }
            }
        )
        HeroSizeScaleCard(
            title = "Detail Screen Hero Size",
            subtitle = "Adjusts hero backdrop & full poster height on Movie/Series details",
            percent = settings.detailHeroSizePercent,
            onPercentChange = { pct ->
                onUpdateSettings { it.copy(detailHeroSizePercent = pct.coerceIn(75, 130)) }
            }
        )

        HeroSectionHeader("Hero Behavior")
        HeroToggleRow(
            title = "Show Hero Section on Home",
            subtitle = "Allow MovieLinkBD catalogues and categories to supply hero posters",
            checked = settings.movieLinkHeroEnabled,
            onCheckedChange = { v -> onUpdateSettings { it.copy(movieLinkHeroEnabled = v) } }
        )
        HeroToggleRow(
            title = "Automatic Poster Rotation",
            subtitle = "Automatically cycle through hero carousel posters every 4.5s",
            checked = settings.heroAutoRotate,
            onCheckedChange = { v -> onUpdateSettings { it.copy(heroAutoRotate = v) } }
        )

        if (!settings.movieLinkHeroEnabled) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(palette.altBg)
                    .border(1.dp, palette.border.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                    .padding(12.dp)
            ) {
                Text(
                    text = "Hero section is turned off. The hero banner is currently hidden on the Home screen.",
                    color = Color(0xFFFBBF24),
                    fontSize = 11.5.sp,
                    lineHeight = 16.sp
                )
            }
        } else if (unavailableSelected.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(palette.altBg)
                    .border(1.dp, Color(0xFFFBBF24).copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                    .padding(12.dp)
            ) {
                Text(
                    text = "${unavailableSelected.size} previously selected hero catalogue(s) are currently unavailable.",
                    color = Color(0xFFFBBF24),
                    fontSize = 11.5.sp,
                    lineHeight = 16.sp
                )
            }
        }

        Spacer(Modifier.height(2.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            HeroSectionHeader("MovieLinkBD Hero Sources")
            if (selectedKeys.isNotEmpty()) {
                Text(
                    text = "${selectedKeys.size} selected · Reset",
                    color = palette.fg,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { selectAutoDefault() }
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }

        HeroRadioOptionRow(
            title = "Auto (MovieLinkBD Default)",
            badge = "MovieLinkBD",
            subtitle = "Uses default Movies & Featured sections (clears custom multi-selection)",
            selected = selectedKeys.isEmpty(),
            enabled = settings.movieLinkHeroEnabled,
            onClick = { selectAutoDefault() }
        )

        val mlHomeSources = heroSources.filter { !it.key.startsWith("ml:cat:") }
        val catSources = heroSources.filter { it.key.startsWith("ml:cat:") }

        mlHomeSources.forEach { src ->
            HeroCheckboxOptionRow(
                title = src.title,
                badge = src.providerLabel,
                subtitle = if (settings.movieLinkHeroEnabled) "Include live ${src.title} posters in hero pool" else "Hero Section disabled",
                checked = src.key in selectedKeys,
                enabled = settings.movieLinkHeroEnabled && src.isAvailable,
                onClick = { toggleCatalogKey(src.key) }
            )
        }

        if (catSources.isNotEmpty()) {
            Spacer(Modifier.height(4.dp))
            HeroSectionHeader("MovieLinkBD Categories (${catSources.size})")
            catSources.forEach { src ->
                HeroCheckboxOptionRow(
                    title = src.title,
                    badge = src.providerLabel,
                    subtitle = if (settings.movieLinkHeroEnabled) "Supply hero carousel with live ${src.title} titles" else "Hero Section disabled",
                    checked = src.key in selectedKeys,
                    enabled = settings.movieLinkHeroEnabled && src.isAvailable,
                    onClick = { toggleCatalogKey(src.key) }
                )
            }
        }
    }
}

@Composable
private fun HeroSizeScaleCard(
    title: String,
    subtitle: String,
    percent: Int,
    onPercentChange: (Int) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val clamped = percent.coerceIn(75, 130)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.altBg)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                Text(
                    text = title,
                    color = palette.textPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = subtitle,
                    color = palette.textSecondary,
                    fontSize = 11.sp,
                    lineHeight = 14.5.sp
                )
            }
            Text(
                text = "$clamped%",
                color = palette.fg,
                fontSize = 13.sp,
                fontWeight = FontWeight.ExtraBold
            )
        }

        Slider(
            value = clamped.toFloat(),
            onValueChange = { v -> onPercentChange(v.roundToInt().coerceIn(75, 130)) },
            valueRange = 75f..130f,
            colors = SliderDefaults.colors(
                thumbColor = palette.fg,
                activeTrackColor = palette.fg,
                inactiveTrackColor = palette.border.copy(alpha = 0.35f)
            )
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val sizePresets = listOf(
                80 to "Compact",
                100 to "Standard",
                120 to "Large"
            )
            sizePresets.forEach { (pct, label) ->
                val isSelected = clamped == pct
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(9.dp))
                        .background(if (isSelected) palette.boxBg else palette.cardBg)
                        .border(
                            width = if (isSelected) 1.2.dp else 1.dp,
                            color = if (isSelected) palette.fg else palette.border.copy(alpha = 0.25f),
                            shape = RoundedCornerShape(9.dp)
                        )
                        .clickable { onPercentChange(pct) }
                        .padding(vertical = 7.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "$label ($pct%)",
                        color = if (isSelected) palette.fg else palette.textSecondary,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun HeroLayoutOptionChip(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalMovieLinkPalette.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) palette.boxBg else palette.altBg)
            .border(
                width = if (selected) 1.3.dp else 1.dp,
                color = if (selected) palette.fg else palette.border.copy(alpha = 0.25f),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(
            text = title,
            color = if (selected) palette.fg else palette.textPrimary,
            fontSize = 12.5.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = subtitle,
            color = palette.textSecondary,
            fontSize = 10.5.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun HeroSectionHeader(title: String) {
    val palette = LocalMovieLinkPalette.current
    Text(
        text = title,
        color = palette.fg,
        fontSize = 13.5.sp,
        fontWeight = FontWeight.ExtraBold
    )
}

@Composable
private fun HeroToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.altBg)
            .clickable(enabled = enabled) { onCheckedChange(!checked) }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
            Text(
                text = title,
                color = if (enabled) palette.textPrimary else palette.textSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = subtitle,
                color = palette.textSecondary,
                fontSize = 11.sp,
                lineHeight = 14.5.sp
            )
        }
        Switch(
            checked = checked,
            enabled = enabled,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = palette.onAccent,
                checkedTrackColor = palette.fg
            )
        )
    }
}

@Composable
private fun HeroRadioOptionRow(
    title: String,
    badge: String,
    subtitle: String,
    selected: Boolean,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) palette.boxBg else palette.altBg)
            .border(
                width = if (selected) 1.2.dp else 1.dp,
                color = if (selected) palette.fg else palette.border.copy(alpha = 0.25f),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = selected,
            enabled = enabled,
            onClick = if (enabled) onClick else null,
            colors = RadioButtonDefaults.colors(
                selectedColor = palette.fg,
                unselectedColor = palette.textSecondary
            )
        )
        HeroOptionTextColumn(
            title = title,
            badge = badge,
            subtitle = subtitle,
            enabled = enabled,
            modifier = Modifier.weight(1f).padding(end = 6.dp)
        )
    }
}

@Composable
private fun HeroCheckboxOptionRow(
    title: String,
    badge: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (checked) palette.boxBg else palette.altBg)
            .border(
                width = if (checked) 1.2.dp else 1.dp,
                color = if (checked) palette.fg else palette.border.copy(alpha = 0.25f),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = checked,
            enabled = enabled,
            onCheckedChange = if (enabled) { _ -> onClick() } else null,
            colors = CheckboxDefaults.colors(
                checkedColor = palette.fg,
                checkmarkColor = palette.onAccent,
                uncheckedColor = palette.textSecondary
            )
        )
        HeroOptionTextColumn(
            title = title,
            badge = badge,
            subtitle = subtitle,
            enabled = enabled,
            modifier = Modifier.weight(1f).padding(end = 6.dp)
        )
    }
}

@Composable
private fun HeroOptionTextColumn(
    title: String,
    badge: String,
    subtitle: String,
    enabled: Boolean,
    modifier: Modifier = Modifier
) {
    val palette = LocalMovieLinkPalette.current
    Column(modifier = modifier) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = title,
                color = if (enabled) palette.textPrimary else palette.textSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false)
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(5.dp))
                    .background(palette.cardBg)
                    .border(
                        0.8.dp,
                        palette.border.copy(alpha = 0.4f),
                        RoundedCornerShape(5.dp)
                    )
                    .padding(horizontal = 5.dp, vertical = 1.dp)
            ) {
                Text(
                    text = badge,
                    color = palette.textSecondary,
                    fontSize = 9.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1
                )
            }
        }
        Text(
            text = subtitle,
            color = palette.textSecondary,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
