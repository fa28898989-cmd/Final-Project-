package com.personal.movielink.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DragHandle
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.personal.movielink.UnifiedHomeCatalogEntry
import com.personal.movielink.ui.theme.LocalMovieLinkPalette

@Composable
fun HomeCatalogManagerSubpage(
    entries: List<UnifiedHomeCatalogEntry>,
    onToggleCatalog: (String, Boolean) -> Unit,
    onMoveCatalog: (Int, Int) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val currentEntries by rememberUpdatedState(entries)
    val itemHeightsPx = remember { mutableStateMapOf<String, Int>() }
    var draggingKey by remember { mutableStateOf<String?>(null) }
    var dragOffsetY by remember { mutableFloatStateOf(0f) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "Manage and reorder MovieLinkBD Home sections and categories in one list. Drag the handle (≡) or use arrows to change Home order.",
            color = palette.textSecondary,
            fontSize = 12.sp,
            lineHeight = 17.sp
        )

        val enabledMl = entries.count { !it.key.startsWith("ml:cat:") && it.movieLinkCategoryUrl == null && it.enabled && it.isAvailable }
        val enabledCats = entries.count { (it.key.startsWith("ml:cat:") || it.movieLinkCategoryUrl != null) && it.enabled && it.isAvailable }
        Text(
            text = "Home Feed Order (${entries.size} total · $enabledMl Home · $enabledCats Categories active)",
            color = palette.fg,
            fontSize = 13.sp,
            fontWeight = FontWeight.ExtraBold
        )

        if (entries.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(palette.altBg)
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Open the Home screen once to populate available catalogues and categories.",
                    color = palette.textSecondary,
                    fontSize = 12.sp
                )
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                entries.forEachIndexed { index, entry ->
                    key(entry.key) {
                        val isDragging = draggingKey == entry.key
                        val isCategory = entry.key.startsWith("ml:cat:") || entry.movieLinkCategoryUrl != null
                        val providerLabel = if (isCategory) "Category · MovieLinkBD" else "MovieLinkBD"

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .zIndex(if (isDragging) 1f else 0f)
                                .graphicsLayer {
                                    translationY = if (isDragging) dragOffsetY else 0f
                                    scaleX = if (isDragging) 1.015f else 1f
                                    scaleY = if (isDragging) 1.015f else 1f
                                }
                                .onSizeChanged { size ->
                                    itemHeightsPx[entry.key] = size.height
                                }
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isDragging) palette.cardBg else palette.altBg)
                                .border(
                                    width = if (isDragging) 1.5.dp else 1.dp,
                                    color = if (isDragging) {
                                        palette.fg
                                    } else {
                                        palette.boxBorder.copy(alpha = if (entry.enabled) 0.55f else 0.25f)
                                    },
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { onToggleCatalog(entry.key, !entry.enabled) }
                                .padding(horizontal = 8.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(palette.cardBg)
                                    .pointerInput(entry.key) {
                                        detectVerticalDragGestures(
                                            onDragStart = {
                                                draggingKey = entry.key
                                                dragOffsetY = 0f
                                            },
                                            onDragEnd = {
                                                draggingKey = null
                                                dragOffsetY = 0f
                                            },
                                            onDragCancel = {
                                                draggingKey = null
                                                dragOffsetY = 0f
                                            },
                                            onVerticalDrag = { change, dragAmount ->
                                                change.consume()
                                                dragOffsetY += dragAmount
                                                val listSnapshot = currentEntries
                                                val currIdx = listSnapshot.indexOfFirst { it.key == entry.key }
                                                if (currIdx >= 0) {
                                                    val selfHeight = (itemHeightsPx[entry.key] ?: 140).coerceAtLeast(80)
                                                    val stepPx = selfHeight + 16f
                                                    if (dragOffsetY > stepPx * 0.55f && currIdx < listSnapshot.lastIndex) {
                                                        val targetIdx = currIdx + 1
                                                        onMoveCatalog(currIdx, targetIdx)
                                                        dragOffsetY -= stepPx
                                                    } else if (dragOffsetY < -stepPx * 0.55f && currIdx > 0) {
                                                        val targetIdx = currIdx - 1
                                                        onMoveCatalog(currIdx, targetIdx)
                                                        dragOffsetY += stepPx
                                                    }
                                                }
                                            }
                                        )
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.DragHandle,
                                    contentDescription = "Drag to reorder",
                                    tint = if (isDragging) palette.fg else palette.textSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "${index + 1}.",
                                        color = palette.textSecondary,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = entry.title,
                                        color = if (entry.isAvailable) palette.textPrimary else palette.textSecondary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Spacer(Modifier.height(3.dp))

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(5.dp))
                                            .background(palette.boxBg)
                                            .border(
                                                1.dp,
                                                palette.boxBorder.copy(alpha = 0.6f),
                                                RoundedCornerShape(5.dp)
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = providerLabel,
                                            color = palette.textPrimary,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }

                                    if (!entry.isAvailable && !entry.availabilityNote.isNullOrBlank()) {
                                        Text(
                                            text = entry.availabilityNote,
                                            color = Color(0xFFFBBF24),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }

                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Rounded.KeyboardArrowUp,
                                    contentDescription = "Move up",
                                    tint = if (index > 0) palette.textSecondary else palette.textSecondary.copy(alpha = 0.25f),
                                    modifier = Modifier
                                        .size(20.dp)
                                        .clickable(enabled = index > 0) {
                                            onMoveCatalog(index, index - 1)
                                        }
                                )
                                Icon(
                                    imageVector = Icons.Rounded.KeyboardArrowDown,
                                    contentDescription = "Move down",
                                    tint = if (index < entries.lastIndex) palette.textSecondary else palette.textSecondary.copy(alpha = 0.25f),
                                    modifier = Modifier
                                        .size(20.dp)
                                        .clickable(enabled = index < entries.lastIndex) {
                                            onMoveCatalog(index, index + 1)
                                        }
                                )
                            }

                            Switch(
                                checked = entry.enabled,
                                onCheckedChange = { checked -> onToggleCatalog(entry.key, checked) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = palette.onAccent,
                                    checkedTrackColor = palette.fg
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
