package com.personal.movielink.ui.components

import android.graphics.Color as AndroidColor
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.personal.movielink.Config
import com.personal.movielink.ui.theme.LocalMovieLinkPalette
import kotlin.math.roundToInt

@Composable
fun ColorWheelDialog(
    title: String,
    initialHex: String,
    minBrightness: Float = 0.0f,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val initialHsv = remember(initialHex, minBrightness) {
        val arr = FloatArray(3)
        try {
            AndroidColor.colorToHSV(AndroidColor.parseColor(initialHex), arr)
        } catch (_: Exception) {
            arr[0] = 270f; arr[1] = 0.7f; arr[2] = 0.85f
        }
        if (arr[2] < minBrightness) arr[2] = minBrightness
        arr
    }

    var hue by remember(initialHex) { mutableFloatStateOf(initialHsv[0].coerceIn(0f, 360f)) }
    var sat by remember(initialHex) { mutableFloatStateOf(initialHsv[1].coerceIn(0f, 1f)) }
    var brightness by remember(initialHex) { mutableFloatStateOf(initialHsv[2].coerceIn(minBrightness, 1f)) }

    val selectedInt = remember(hue, sat, brightness) {
        AndroidColor.HSVToColor(floatArrayOf(hue.coerceIn(0f, 360f) % 360f, sat.coerceIn(0f, 1f), brightness.coerceIn(0f, 1f)))
    }
    val selectedHex = remember(selectedInt) { Config.toHex(selectedInt) }
    val selectedComposeColor = remember(selectedInt) { Color(selectedInt) }

    val hueGradient = remember {
        listOf(
            Color(0xFFFF0000),
            Color(0xFFFFFF00),
            Color(0xFF00FF00),
            Color(0xFF00FFFF),
            Color(0xFF0000FF),
            Color(0xFFFF00FF),
            Color(0xFFFF0000)
        )
    }
    val satEndColor = remember(hue) {
        Color(AndroidColor.HSVToColor(floatArrayOf(hue % 360f, 1f, 1f)))
    }
    val valEndColor = remember(hue, sat) {
        Color(AndroidColor.HSVToColor(floatArrayOf(hue % 360f, sat, 1f)))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = if (palette.isLightBg) palette.cardBg else Color(0xFF111216),
        titleContentColor = palette.textPrimary,
        textContentColor = palette.textPrimary,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    modifier = Modifier.weight(1f)
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(selectedComposeColor)
                            .border(1.2.dp, palette.border.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                    )
                    Text(
                        text = selectedHex,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = palette.textSecondary
                    )
                }
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                HsbGradientSlider(
                    label = "Hue",
                    valueLabel = "${hue.roundToInt()}°",
                    fraction = (hue / 360f).coerceIn(0f, 1f),
                    gradientColors = hueGradient,
                    onFractionChange = { f -> hue = (f * 360f).coerceIn(0f, 360f) }
                )

                HsbGradientSlider(
                    label = "Saturation",
                    valueLabel = "${(sat * 100f).roundToInt()}%",
                    fraction = sat.coerceIn(0f, 1f),
                    gradientColors = listOf(Color.White, satEndColor),
                    onFractionChange = { f -> sat = f.coerceIn(0f, 1f) }
                )

                val minFrac = minBrightness.coerceIn(0f, 0.99f)
                HsbGradientSlider(
                    label = "Brightness",
                    valueLabel = "${(brightness * 100f).roundToInt()}%",
                    fraction = ((brightness - minFrac) / (1f - minFrac)).coerceIn(0f, 1f),
                    gradientColors = listOf(
                        Color(AndroidColor.HSVToColor(floatArrayOf(hue % 360f, sat, minFrac))),
                        valEndColor
                    ),
                    onFractionChange = { f ->
                        brightness = (minFrac + f * (1f - minFrac)).coerceIn(minFrac, 1f)
                    }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(selectedHex) }) {
                Text("Apply", color = palette.fg, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = palette.textSecondary)
            }
        }
    )
}

@Composable
private fun HsbGradientSlider(
    label: String,
    valueLabel: String,
    fraction: Float,
    gradientColors: List<Color>,
    onFractionChange: (Float) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val latestOnChange by rememberUpdatedState(onFractionChange)

    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = palette.textPrimary
            )
            Text(
                text = valueLabel,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = palette.textSecondary
            )
        }

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(30.dp)
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        val pad = 11.dp.toPx()
                        val usable = (size.width - pad * 2f).coerceAtLeast(1f)
                        latestOnChange(((offset.x - pad) / usable).coerceIn(0f, 1f))
                    }
                }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures { change, _ ->
                        change.consume()
                        val pad = 11.dp.toPx()
                        val usable = (size.width - pad * 2f).coerceAtLeast(1f)
                        latestOnChange(((change.position.x - pad) / usable).coerceIn(0f, 1f))
                    }
                }
        ) {
            val pad = 11.dp.toPx()
            val trackH = 6.dp.toPx()
            val cy = size.height / 2f
            val trackWidth = (size.width - pad * 2f).coerceAtLeast(1f)

            drawRoundRect(
                brush = Brush.horizontalGradient(
                    colors = gradientColors,
                    startX = pad,
                    endX = pad + trackWidth
                ),
                topLeft = Offset(pad, cy - trackH / 2f),
                size = Size(trackWidth, trackH),
                cornerRadius = CornerRadius(trackH / 2f, trackH / 2f)
            )

            val thumbX = pad + fraction.coerceIn(0f, 1f) * trackWidth
            val thumbR = 11.dp.toPx()

            drawCircle(
                color = Color(0x40000000),
                radius = thumbR + 1.5.dp.toPx(),
                center = Offset(thumbX, cy)
            )
            drawCircle(
                color = Color.White,
                radius = thumbR,
                center = Offset(thumbX, cy)
            )
            drawCircle(
                color = Color(0x26000000),
                radius = thumbR,
                center = Offset(thumbX, cy),
                style = Stroke(width = 1.dp.toPx())
            )
        }
    }
}
