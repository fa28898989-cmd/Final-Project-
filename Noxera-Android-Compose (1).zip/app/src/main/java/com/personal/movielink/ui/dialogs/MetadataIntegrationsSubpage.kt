package com.personal.movielink.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.personal.movielink.Config
import com.personal.movielink.UserSettings
import com.personal.movielink.ui.theme.LocalMovieLinkPalette
import kotlinx.coroutines.launch

@Composable
fun MetadataIntegrationsSubpage(
    settings: UserSettings,
    onUpdateSettings: ((UserSettings) -> UserSettings) -> Unit,
    onTestMetadataIntegration: suspend (
        kind: String,
        tmdbKey: String,
        mdbKey: String,
        bpProvider: Config.BetterPosterProvider,
        rpdbKey: String,
        customTemplate: String
    ) -> Result<String>
) {
    val palette = LocalMovieLinkPalette.current
    val scope = rememberCoroutineScope()

    var tmdbKeyInput by remember(settings.tmdbApiKey) { mutableStateOf(settings.tmdbApiKey) }
    var mdbKeyInput by remember(settings.mdbListApiKey) { mutableStateOf(settings.mdbListApiKey) }
    var rpdbKeyInput by remember(settings.rpdbApiKey) { mutableStateOf(settings.rpdbApiKey) }
    var customTplInput by remember(settings.betterPosterCustomTemplate) {
        mutableStateOf(settings.betterPosterCustomTemplate)
    }

    var testingKind by remember { mutableStateOf<String?>(null) }
    var testStatus by remember { mutableStateOf<Pair<Boolean, String>?>(null) }

    fun saveAllInputs() {
        onUpdateSettings { s ->
            s.copy(
                tmdbApiKey = tmdbKeyInput.trim(),
                mdbListApiKey = mdbKeyInput.trim(),
                rpdbApiKey = rpdbKeyInput.trim(),
                betterPosterCustomTemplate = customTplInput.trim().ifBlank { s.betterPosterCustomTemplate }
            )
        }
    }

    fun runTest(kind: String) {
        saveAllInputs()
        testingKind = kind
        testStatus = null
        scope.launch {
            val res = onTestMetadataIntegration(
                kind,
                tmdbKeyInput.trim(),
                mdbKeyInput.trim(),
                settings.betterPosterProvider,
                rpdbKeyInput.trim(),
                customTplInput.trim()
            )
            testingKind = null
            testStatus = res.fold(
                onSuccess = { true to it },
                onFailure = { false to (it.message ?: "Connection test failed") }
            )
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "Optional metadata and artwork enrichment for MovieLinkBD hero, spotlight, and detail screens. Leave disabled if you only want native site posters and info.",
            color = palette.textSecondary,
            fontSize = 12.sp,
            lineHeight = 17.sp
        )

        testStatus?.let { (ok, msg) ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (ok) Color(0x1E22C55E) else Color(0x1EEF4444))
                    .border(
                        1.dp,
                        if (ok) Color(0xFF4ADE80).copy(alpha = 0.6f) else Color(0xFFF87171).copy(alpha = 0.6f),
                        RoundedCornerShape(10.dp)
                    )
                    .padding(10.dp)
            ) {
                Text(
                    text = msg,
                    color = if (ok) Color(0xFF4ADE80) else Color(0xFFF87171),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        MetadataSectionHeader("TMDB Artwork & Metadata")
        MetadataToggleCard(
            title = "Enable TMDB Enrichment",
            subtitle = "Fetches high-res backdrops, transparent title logos, genres, and ratings for Hero & Details",
            checked = settings.tmdbMetadataEnabled,
            onCheckedChange = { v -> onUpdateSettings { it.copy(tmdbMetadataEnabled = v) } }
        )
        OutlinedTextField(
            value = tmdbKeyInput,
            onValueChange = { tmdbKeyInput = it },
            singleLine = true,
            label = { Text("TMDB API Key (v3)", fontSize = 12.sp) },
            textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = palette.fg,
                unfocusedBorderColor = palette.border.copy(alpha = 0.45f),
                focusedTextColor = palette.textPrimary,
                unfocusedTextColor = palette.textPrimary
            ),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                enabled = testingKind == null,
                onClick = { runTest("tmdb") },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                if (testingKind == "tmdb") {
                    CircularProgressIndicator(color = palette.fg, strokeWidth = 2.dp, modifier = Modifier.size(16.dp))
                } else {
                    Text("Test TMDB", color = palette.fg, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
            Button(
                onClick = { saveAllInputs() },
                colors = ButtonDefaults.buttonColors(containerColor = palette.fg, contentColor = palette.onAccent),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Save Keys", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(2.dp))
        MetadataSectionHeader("MDBList Ratings (IMDb / Rotten Tomatoes / Metacritic)")
        MetadataToggleCard(
            title = "Enable MDBList Ratings",
            subtitle = "Displays aggregated critic and audience scores on movie & series detail pages",
            checked = settings.mdbListEnabled,
            onCheckedChange = { v -> onUpdateSettings { it.copy(mdbListEnabled = v) } }
        )
        OutlinedTextField(
            value = mdbKeyInput,
            onValueChange = { mdbKeyInput = it },
            singleLine = true,
            label = { Text("MDBList API Key", fontSize = 12.sp) },
            textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = palette.fg,
                unfocusedBorderColor = palette.border.copy(alpha = 0.45f),
                focusedTextColor = palette.textPrimary,
                unfocusedTextColor = palette.textPrimary
            ),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedButton(
            enabled = testingKind == null,
            onClick = { runTest("mdblist") },
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            if (testingKind == "mdblist") {
                CircularProgressIndicator(color = palette.fg, strokeWidth = 2.dp, modifier = Modifier.size(16.dp))
            } else {
                Text("Test MDBList Connection", color = palette.fg, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(2.dp))
        MetadataSectionHeader("Better Poster Provider")
        Config.BetterPosterProvider.entries.forEach { provider ->
            val selected = settings.betterPosterProvider == provider
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (selected) palette.boxBg else palette.altBg)
                    .border(
                        1.dp,
                        if (selected) palette.fg else palette.border.copy(alpha = 0.25f),
                        RoundedCornerShape(10.dp)
                    )
                    .clickable {
                        onUpdateSettings { it.copy(betterPosterProvider = provider) }
                    }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = selected,
                    onClick = { onUpdateSettings { it.copy(betterPosterProvider = provider) } },
                    colors = RadioButtonDefaults.colors(
                        selectedColor = palette.fg,
                        unselectedColor = palette.textSecondary
                    )
                )
                Text(
                    text = provider.label,
                    color = palette.textPrimary,
                    fontSize = 12.5.sp,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                )
            }
        }

        if (settings.betterPosterProvider == Config.BetterPosterProvider.RPDB) {
            OutlinedTextField(
                value = rpdbKeyInput,
                onValueChange = { rpdbKeyInput = it },
                singleLine = true,
                label = { Text("RPDB API Key", fontSize = 12.sp) },
                textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = palette.fg,
                    unfocusedBorderColor = palette.border.copy(alpha = 0.45f),
                    focusedTextColor = palette.textPrimary,
                    unfocusedTextColor = palette.textPrimary
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            )
        } else if (settings.betterPosterProvider == Config.BetterPosterProvider.CUSTOM) {
            OutlinedTextField(
                value = customTplInput,
                onValueChange = { customTplInput = it },
                singleLine = true,
                label = { Text("Custom Template ({imdb_id}, {type})", fontSize = 12.sp) },
                textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 11.5.sp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = palette.fg,
                    unfocusedBorderColor = palette.border.copy(alpha = 0.45f),
                    focusedTextColor = palette.textPrimary,
                    unfocusedTextColor = palette.textPrimary
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (settings.betterPosterProvider != Config.BetterPosterProvider.NONE) {
            MetadataToggleCard(
                title = "Apply Better Posters on Hero Cards",
                subtitle = "Replaces default posters when IMDb ID is resolved via TMDB or MDBList",
                checked = settings.betterPosterOnCards,
                onCheckedChange = { v -> onUpdateSettings { it.copy(betterPosterOnCards = v) } }
            )
            OutlinedButton(
                enabled = testingKind == null,
                onClick = { runTest("better_poster") },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (testingKind == "better_poster") {
                    CircularProgressIndicator(color = palette.fg, strokeWidth = 2.dp, modifier = Modifier.size(16.dp))
                } else {
                    Text("Test Better Poster Image", color = palette.fg, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun MetadataSectionHeader(title: String) {
    val palette = LocalMovieLinkPalette.current
    Text(
        text = title,
        color = palette.fg,
        fontSize = 13.5.sp,
        fontWeight = FontWeight.ExtraBold
    )
}

@Composable
private fun MetadataToggleCard(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.altBg)
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
            Text(text = title, color = palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(text = subtitle, color = palette.textSecondary, fontSize = 11.sp, lineHeight = 14.5.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = palette.onAccent,
                checkedTrackColor = palette.fg
            )
        )
    }
}
