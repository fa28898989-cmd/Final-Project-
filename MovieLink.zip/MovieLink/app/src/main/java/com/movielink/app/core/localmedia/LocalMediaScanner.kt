package com.movielink.app.core.localmedia

import android.content.ContentUris
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object LocalMediaScanner {

    suspend fun scanDeviceVideos(context: Context): List<LocalVideoItem> = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        val projection = buildList {
            add(MediaStore.Video.Media._ID)
            add(MediaStore.Video.Media.TITLE)
            add(MediaStore.Video.Media.DISPLAY_NAME)
            add(MediaStore.Video.Media.DURATION)
            add(MediaStore.Video.Media.SIZE)
            add(MediaStore.Video.Media.WIDTH)
            add(MediaStore.Video.Media.HEIGHT)
            add(MediaStore.Video.Media.MIME_TYPE)
            add(MediaStore.Video.Media.DATE_ADDED)
            add(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                add(MediaStore.Video.Media.RELATIVE_PATH)
            } else {
                @Suppress("DEPRECATION")
                add(MediaStore.Video.Media.DATA)
            }
        }.toTypedArray()

        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"
        val items = mutableListOf<LocalVideoItem>()

        try {
            resolver.query(collection, projection, null, null, sortOrder)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val titleCol = cursor.getColumnIndex(MediaStore.Video.Media.TITLE)
                val nameCol = cursor.getColumnIndex(MediaStore.Video.Media.DISPLAY_NAME)
                val durCol = cursor.getColumnIndex(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndex(MediaStore.Video.Media.SIZE)
                val widthCol = cursor.getColumnIndex(MediaStore.Video.Media.WIDTH)
                val heightCol = cursor.getColumnIndex(MediaStore.Video.Media.HEIGHT)
                val mimeCol = cursor.getColumnIndex(MediaStore.Video.Media.MIME_TYPE)
                val dateCol = cursor.getColumnIndex(MediaStore.Video.Media.DATE_ADDED)
                val bucketCol = cursor.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                val pathCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.Video.Media.RELATIVE_PATH)
                } else {
                    @Suppress("DEPRECATION")
                    cursor.getColumnIndex(MediaStore.Video.Media.DATA)
                }

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                    val displayName = if (nameCol >= 0) cursor.getString(nameCol).orEmpty() else ""
                    val rawTitle = if (titleCol >= 0) cursor.getString(titleCol).orEmpty() else ""
                    val title = rawTitle.ifBlank {
                        displayName.substringBeforeLast('.').ifBlank { "Video #$id" }
                    }
                    val duration = if (durCol >= 0) cursor.getLong(durCol).coerceAtLeast(0L) else 0L
                    val size = if (sizeCol >= 0) cursor.getLong(sizeCol).coerceAtLeast(0L) else 0L
                    val width = if (widthCol >= 0) cursor.getInt(widthCol).coerceAtLeast(0) else 0
                    val height = if (heightCol >= 0) cursor.getInt(heightCol).coerceAtLeast(0) else 0
                    val mime = if (mimeCol >= 0) cursor.getString(mimeCol).orEmpty() else "video/*"
                    val dateAdded = if (dateCol >= 0) cursor.getLong(dateCol).coerceAtLeast(0L) else 0L
                    val bucketName = if (bucketCol >= 0) cursor.getString(bucketCol).orEmpty() else ""
                    val rawPath = if (pathCol >= 0) cursor.getString(pathCol).orEmpty() else ""

                    val folderPath = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        rawPath.trimEnd('/').ifBlank { "Internal Storage" }
                    } else {
                        rawPath.substringBeforeLast('/', "Internal Storage").ifBlank { "Internal Storage" }
                    }
                    val folderName = bucketName.ifBlank {
                        folderPath.substringAfterLast('/').ifBlank { "Storage" }
                    }

                    if (size > 0L || duration > 0L) {
                        items.add(
                            LocalVideoItem(
                                id = id,
                                contentUri = uri,
                                title = title,
                                displayName = displayName.ifBlank { title },
                                folderPath = folderPath,
                                folderName = folderName,
                                durationMs = duration,
                                sizeBytes = size,
                                width = width,
                                height = height,
                                mimeType = mime.ifBlank { "video/*" },
                                dateAddedSec = dateAdded
                            )
                        )
                    }
                }
            }
        } catch (_: SecurityException) {
            return@withContext emptyList()
        } catch (_: Exception) {
            return@withContext emptyList()
        }

        items
    }

    fun groupByFolder(videos: List<LocalVideoItem>): List<LocalVideoFolder> {
        return videos.groupBy { it.folderPath }
            .map { (path, list) ->
                LocalVideoFolder(
                    path = path,
                    name = list.first().folderName,
                    videoCount = list.size,
                    totalSizeBytes = list.sumOf { it.sizeBytes },
                    previewUri = list.firstOrNull()?.contentUri
                )
            }
            .sortedByDescending { it.videoCount }
    }

    suspend fun inspectPickedUri(context: Context, uri: Uri): LocalVideoItem = withContext(Dispatchers.IO) {
        var displayName = "Picked Video"
        var sizeBytes = 0L
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val nameIdx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIdx = c.getColumnIndex(OpenableColumns.SIZE)
                if (c.moveToFirst()) {
                    if (nameIdx >= 0) displayName = c.getString(nameIdx) ?: displayName
                    if (sizeIdx >= 0) sizeBytes = c.getLong(sizeIdx).coerceAtLeast(0L)
                }
            }
        } catch (_: Exception) {
        }

        var durationMs = 0L
        var width = 0
        var height = 0
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                ?.toIntOrNull() ?: 0
            height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                ?.toIntOrNull() ?: 0
        } catch (_: Exception) {
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }

        val mime = context.contentResolver.getType(uri).orEmpty().ifBlank { "video/*" }
        LocalVideoItem(
            id = uri.toString().hashCode().toLong(),
            contentUri = uri,
            title = displayName.substringBeforeLast('.').ifBlank { displayName },
            displayName = displayName,
            folderPath = "Picked File",
            folderName = "Picked File",
            durationMs = durationMs,
            sizeBytes = sizeBytes,
            width = width,
            height = height,
            mimeType = mime,
            dateAddedSec = System.currentTimeMillis() / 1000L
        )
    }
}
