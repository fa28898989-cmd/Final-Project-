package com.movielink.app.core.player

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import java.util.Locale

data class SelectableTrackOption(
    val groupIndex: Int,
    val trackIndex: Int,
    val trackGroup: Tracks.Group,
    val label: String,
    val detail: String,
    val isSelected: Boolean,
    val isSupported: Boolean
)

@OptIn(UnstableApi::class)
object PlaybackTrackUtils {

    fun extractTracks(tracks: Tracks, trackType: @C.TrackType Int): List<SelectableTrackOption> {
        val out = mutableListOf<SelectableTrackOption>()
        tracks.groups.forEachIndexed { groupIdx, group ->
            if (group.type != trackType) return@forEachIndexed
            for (trackIdx in 0 until group.length) {
                val format = group.getTrackFormat(trackIdx)
                val supported = group.isTrackSupported(trackIdx)
                val selected = group.isTrackSelected(trackIdx)
                val (label, detail) = describeFormat(format, out.size + 1, trackType)
                out.add(
                    SelectableTrackOption(
                        groupIndex = groupIdx,
                        trackIndex = trackIdx,
                        trackGroup = group,
                        label = label,
                        detail = detail,
                        isSelected = selected,
                        isSupported = supported
                    )
                )
            }
        }
        return out
    }

    fun selectAudioTrack(player: ExoPlayer, option: SelectableTrackOption) {
        val builder = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
            .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
            .addOverride(
                TrackSelectionOverride(
                    option.trackGroup.mediaTrackGroup,
                    listOf(option.trackIndex)
                )
            )
        player.trackSelectionParameters = builder.build()
    }

    fun selectSubtitleTrack(player: ExoPlayer, option: SelectableTrackOption?) {
        val builder = player.trackSelectionParameters.buildUpon()
            .clearOverridesOfType(C.TRACK_TYPE_TEXT)
        if (option == null) {
            builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
        } else {
            builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                .addOverride(
                    TrackSelectionOverride(
                        option.trackGroup.mediaTrackGroup,
                        listOf(option.trackIndex)
                    )
                )
        }
        player.trackSelectionParameters = builder.build()
    }

    fun buildMediaItem(
        uri: Uri,
        title: String,
        externalSubtitleUri: Uri? = null,
        externalSubtitleMime: String? = null
    ): MediaItem {
        val builder = MediaItem.Builder()
            .setUri(uri)
            .setMediaMetadata(
                androidx.media3.common.MediaMetadata.Builder()
                    .setTitle(title)
                    .build()
            )
        if (externalSubtitleUri != null) {
            val mime = externalSubtitleMime ?: MimeTypes.APPLICATION_SUBRIP
            val subConfig = MediaItem.SubtitleConfiguration.Builder(externalSubtitleUri)
                .setMimeType(mime)
                .setLanguage("en")
                .setLabel("External Subtitle")
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .build()
            builder.setSubtitleConfigurations(listOf(subConfig))
        }
        return builder.build()
    }

    fun guessSubtitleMime(context: Context, uri: Uri): String {
        var name = uri.lastPathSegment.orEmpty().lowercase(Locale.US)
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && idx >= 0) {
                    name = c.getString(idx).orEmpty().lowercase(Locale.US)
                }
            }
        } catch (_: Exception) {
        }
        return when {
            name.endsWith(".vtt") -> MimeTypes.TEXT_VTT
            name.endsWith(".ass") || name.endsWith(".ssa") -> MimeTypes.TEXT_SSA
            else -> MimeTypes.APPLICATION_SUBRIP
        }
    }

    private fun describeFormat(
        format: Format,
        fallbackIndex: Int,
        trackType: @C.TrackType Int
    ): Pair<String, String> {
        val langCode = format.language?.takeIf { it.isNotBlank() && it != C.LANGUAGE_UNDETERMINED }
        val langName = langCode?.let { Locale.forLanguageTag(it).getDisplayLanguage(Locale.ENGLISH) }
            ?.takeIf { it.isNotBlank() }
        val baseLabel = format.label?.takeIf { it.isNotBlank() }
            ?: langName
            ?: if (trackType == C.TRACK_TYPE_AUDIO) "Audio Track $fallbackIndex" else "Subtitle $fallbackIndex"

        val detailParts = buildList {
            if (langName != null && baseLabel != langName) add(langName)
            format.sampleMimeType?.substringAfter('/')?.uppercase(Locale.US)?.let { add(it) }
            if (trackType == C.TRACK_TYPE_AUDIO && format.channelCount > 0) {
                add(if (format.channelCount >= 6) "5.1" else "${format.channelCount}ch")
            }
        }
        return baseLabel to detailParts.joinToString(" • ")
    }
}
