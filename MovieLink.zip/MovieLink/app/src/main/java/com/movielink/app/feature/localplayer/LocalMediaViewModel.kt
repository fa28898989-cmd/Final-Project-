package com.movielink.app.feature.localplayer

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import coil.ImageLoader
import coil.decode.VideoFrameDecoder
import com.movielink.app.core.localmedia.LocalLibraryTab
import com.movielink.app.core.localmedia.LocalMediaScanner
import com.movielink.app.core.localmedia.LocalPlaybackHistoryStore
import com.movielink.app.core.localmedia.LocalPlaybackRecord
import com.movielink.app.core.localmedia.LocalSortOrder
import com.movielink.app.core.localmedia.LocalVideoFolder
import com.movielink.app.core.localmedia.LocalVideoItem
import com.movielink.app.core.localmedia.PlayerMediaRequest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class LocalMediaViewModel(application: Application) : AndroidViewModel(application) {

    private val historyStore = LocalPlaybackHistoryStore(application)

    val videoImageLoader: ImageLoader = ImageLoader.Builder(application)
        .components {
            add(VideoFrameDecoder.Factory())
        }
        .crossfade(true)
        .build()

    private val _videos = MutableStateFlow<List<LocalVideoItem>>(emptyList())
    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _hasStoragePermission = MutableStateFlow(checkVideoPermission())
    val hasStoragePermission: StateFlow<Boolean> = _hasStoragePermission.asStateFlow()

    private val _activeTab = MutableStateFlow(LocalLibraryTab.ALL_VIDEOS)
    val activeTab: StateFlow<LocalLibraryTab> = _activeTab.asStateFlow()

    private val _sortOrder = MutableStateFlow(LocalSortOrder.DATE_DESC)
    val sortOrder: StateFlow<LocalSortOrder> = _sortOrder.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedFolderPath = MutableStateFlow<String?>(null)
    val selectedFolderPath: StateFlow<String?> = _selectedFolderPath.asStateFlow()

    private val _activePlayerRequest = MutableStateFlow<PlayerMediaRequest?>(null)
    val activePlayerRequest: StateFlow<PlayerMediaRequest?> = _activePlayerRequest.asStateFlow()

    val playbackRecords: StateFlow<List<LocalPlaybackRecord>> = historyStore.records

    val filteredVideos: StateFlow<List<LocalVideoItem>> = combine(
        _videos,
        _sortOrder,
        _searchQuery,
        _selectedFolderPath
    ) { list, sort, query, folderPath ->
        val q = query.trim().lowercase()
        val scoped = list.filter { item ->
            val folderMatch = folderPath == null || item.folderPath == folderPath
            val queryMatch = q.isEmpty() ||
                item.title.lowercase().contains(q) ||
                item.displayName.lowercase().contains(q) ||
                item.folderName.lowercase().contains(q)
            folderMatch && queryMatch
        }
        when (sort) {
            LocalSortOrder.DATE_DESC -> scoped.sortedByDescending { it.dateAddedSec }
            LocalSortOrder.NAME_ASC -> scoped.sortedBy { it.title.lowercase() }
            LocalSortOrder.SIZE_DESC -> scoped.sortedByDescending { it.sizeBytes }
            LocalSortOrder.DURATION_DESC -> scoped.sortedByDescending { it.durationMs }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val folders: StateFlow<List<LocalVideoFolder>> = combine(
        _videos,
        _searchQuery
    ) { list, query ->
        val q = query.trim().lowercase()
        val grouped = LocalMediaScanner.groupByFolder(list)
        if (q.isEmpty()) grouped else grouped.filter { it.name.lowercase().contains(q) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        if (_hasStoragePermission.value) {
            refreshScan()
        }
    }

    fun requiredPermissions(): Array<String> {
        return when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE -> arrayOf(
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
            )
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> arrayOf(
                Manifest.permission.READ_MEDIA_VIDEO
            )
            else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    fun checkVideoPermission(): Boolean {
        val ctx = getApplication<Application>()
        return when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE -> {
                val full = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_MEDIA_VIDEO) ==
                    PackageManager.PERMISSION_GRANTED
                val partial = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) ==
                    PackageManager.PERMISSION_GRANTED
                full || partial
            }
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> {
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_MEDIA_VIDEO) ==
                    PackageManager.PERMISSION_GRANTED
            }
            else -> {
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_EXTERNAL_STORAGE) ==
                    PackageManager.PERMISSION_GRANTED
            }
        }
    }

    fun onPermissionUpdated() {
        val granted = checkVideoPermission()
        _hasStoragePermission.value = granted
        if (granted) {
            refreshScan()
        }
    }

    fun refreshScan() {
        if (!checkVideoPermission()) {
            _hasStoragePermission.value = false
            return
        }
        _hasStoragePermission.value = true
        viewModelScope.launch {
            _isScanning.value = true
            _videos.value = LocalMediaScanner.scanDeviceVideos(getApplication())
            _isScanning.value = false
        }
    }

    fun selectTab(tab: LocalLibraryTab) {
        _activeTab.value = tab
        if (tab != LocalLibraryTab.FOLDERS) {
            _selectedFolderPath.value = null
        }
    }

    fun openFolder(folderPath: String?) {
        _selectedFolderPath.value = folderPath
    }

    fun setSortOrder(order: LocalSortOrder) {
        _sortOrder.value = order
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun playVideo(item: LocalVideoItem, forceFromStart: Boolean = false) {
        val resumeMs = if (forceFromStart) 0L else historyStore.getPositionFor(item.contentUri.toString())
        val subtitle = listOf(item.extensionLabel, item.resolutionLabel)
            .filter { it.isNotBlank() }
            .joinToString(" • ")
        _activePlayerRequest.value = PlayerMediaRequest(
            uri = item.contentUri,
            title = item.title,
            subtitle = subtitle,
            isLocal = true,
            resumePositionMs = resumeMs
        )
    }

    fun playRecord(record: LocalPlaybackRecord) {
        val uri = Uri.parse(record.uriString)
        val matched = _videos.value.firstOrNull { it.contentUri.toString() == record.uriString }
        if (matched != null) {
            playVideo(matched)
        } else {
            _activePlayerRequest.value = PlayerMediaRequest(
                uri = uri,
                title = record.title,
                subtitle = "Resume",
                isLocal = true,
                resumePositionMs = historyStore.getPositionFor(record.uriString)
            )
        }
    }

    fun playStreamUrl(url: String, title: String) {
        val uri = Uri.parse(url)
        _activePlayerRequest.value = PlayerMediaRequest(
            uri = uri,
            title = title,
            subtitle = "Web Stream",
            isLocal = false,
            resumePositionMs = historyStore.getPositionFor(url)
        )
    }

    fun openPickedDocument(uri: Uri) {
        val ctx = getApplication<Application>()
        try {
            ctx.contentResolver.takePersistableUriPermission(
                uri,
                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) {
        }
        viewModelScope.launch {
            val inspected = LocalMediaScanner.inspectPickedUri(ctx, uri)
            playVideo(inspected)
        }
    }

    fun savePlaybackProgress(uri: String, title: String, positionMs: Long, durationMs: Long) {
        historyStore.saveProgress(uri, title, positionMs, durationMs)
    }

    fun removeHistoryRecord(uriString: String) {
        historyStore.removeRecord(uriString)
    }

    fun closePlayer() {
        _activePlayerRequest.value = null
    }

    override fun onCleared() {
        super.onCleared()
        videoImageLoader.shutdown()
    }
}
