package com.movielink.app.core.downloads

import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment

data class InstalledDownloadManagers(
    val idmPackage: String?,
    val admPackage: String?
) {
    val has1dmOrIdm: Boolean get() = idmPackage != null
    val hasAdm: Boolean get() = admPackage != null
}

data class DownloadDispatchResult(
    val launched: Boolean,
    val message: String
)

object DownloadRouter {

    private val ONE_DM_PACKAGES = listOf(
        "idm.internet.download.manager.plus",
        "idm.internet.download.manager",
        "idm.internet.download.manager.adm.lite"
    )

    private val ADM_PACKAGES = listOf(
        "com.dv.adm.pay",
        "com.dv.adm"
    )

    fun detectInstalledManagers(context: Context): InstalledDownloadManagers {
        val pm = context.packageManager
        val idm = ONE_DM_PACKAGES.firstOrNull { isPackageInstalled(pm, it) }
        val adm = ADM_PACKAGES.firstOrNull { isPackageInstalled(pm, it) }
        return InstalledDownloadManagers(idmPackage = idm, admPackage = adm)
    }

    fun sendTo1dmOrIdm(
        context: Context,
        url: String,
        title: String
    ): DownloadDispatchResult {
        if (!isValidHttpUrl(url)) {
            return DownloadDispatchResult(false, "Invalid download URL")
        }
        val pkg = ONE_DM_PACKAGES.firstOrNull { isPackageInstalled(context.packageManager, it) }
            ?: return DownloadDispatchResult(false, "1DM / IDM is not installed on this device")

        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                setPackage(pkg)
                putExtra("title", title)
                putExtra("extra_filename", sanitizeFilename(title))
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            DownloadDispatchResult(true, "Sent to 1DM / IDM")
        } catch (e: Exception) {
            DownloadDispatchResult(false, "Failed to open 1DM/IDM: ${e.message ?: "Error"}")
        }
    }

    fun sendToAdm(
        context: Context,
        url: String,
        title: String
    ): DownloadDispatchResult {
        if (!isValidHttpUrl(url)) {
            return DownloadDispatchResult(false, "Invalid download URL")
        }
        val pkg = ADM_PACKAGES.firstOrNull { isPackageInstalled(context.packageManager, it) }
            ?: return DownloadDispatchResult(false, "ADM is not installed on this device")

        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                setPackage(pkg)
                putExtra("com.android.extra.filename", sanitizeFilename(title))
                putExtra("title", title)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            DownloadDispatchResult(true, "Sent to ADM")
        } catch (e: Exception) {
            DownloadDispatchResult(false, "Failed to open ADM: ${e.message ?: "Error"}")
        }
    }

    fun enqueueSystemDownload(
        context: Context,
        url: String,
        title: String
    ): DownloadDispatchResult {
        if (!isValidHttpUrl(url)) {
            return DownloadDispatchResult(false, "Invalid download URL")
        }
        return try {
            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val fileName = sanitizeFilename(title)
            val req = DownloadManager.Request(Uri.parse(url))
                .setTitle(title)
                .setDescription("Downloading via MovieLink")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            dm.enqueue(req)
            DownloadDispatchResult(true, "Queued in Android Downloads ($fileName)")
        } catch (e: Exception) {
            DownloadDispatchResult(false, "System download failed: ${e.message ?: "Error"}")
        }
    }

    fun copyToClipboard(context: Context, label: String, url: String) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, url))
    }

    fun isLikelyDirectFile(url: String): Boolean {
        val clean = url.substringBefore('?').lowercase()
        return clean.endsWith(".mp4") ||
            clean.endsWith(".mkv") ||
            clean.endsWith(".webm") ||
            clean.endsWith(".avi") ||
            clean.endsWith(".zip") ||
            clean.endsWith(".srt")
    }

    private fun isValidHttpUrl(url: String): Boolean {
        return url.startsWith("http://", ignoreCase = true) ||
            url.startsWith("https://", ignoreCase = true)
    }

    private fun sanitizeFilename(title: String): String {
        val cleaned = title
            .replace(Regex("""[^\w\s.\-()]"""), "_")
            .replace(Regex("""\s+"""), " ")
            .trim()
            .take(80)
        return if (cleaned.isBlank()) "MovieLink_Download" else cleaned
    }

    @Suppress("DEPRECATION")
    private fun isPackageInstalled(pm: PackageManager, pkg: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
            } else {
                pm.getPackageInfo(pkg, 0)
            }
            true
        } catch (_: Exception) {
            false
        }
    }
}
