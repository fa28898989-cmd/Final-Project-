package com.movielink.app.core.adblock

import android.content.Context
import android.content.SharedPreferences
import com.movielink.app.core.model.ProviderId
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject

data class AdBlockSettingsState(
    val globalEnabled: Boolean = true,
    val blockPopups: Boolean = true,
    val providerEnabled: Map<ProviderId, Boolean> = ProviderId.entries.associateWith { true },
    val allowedDomains: Set<String> = emptySet(),
    val customBlockedDomains: Set<String> = emptySet()
)

data class BlockedRequestEvent(
    val id: Long,
    val timestampMs: Long,
    val providerId: ProviderId?,
    val host: String,
    val reason: String
)

/**
 * Persistent settings store for global & per-provider Ad Blocking rules and whitelists.
 */
object AdBlockStore {

    private const val PREFS_NAME = "movielink_adblock_v1"
    private const val KEY_STATE = "adblock_state"

    private var prefs: SharedPreferences? = null

    private val _settings = MutableStateFlow(AdBlockSettingsState())
    val settings: StateFlow<AdBlockSettingsState> = _settings.asStateFlow()

    fun init(context: Context) {
        if (prefs != null) return
        val sp = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs = sp
        loadFromPrefs(sp)
    }

    fun setGlobalEnabled(enabled: Boolean) {
        updateAndPersist { it.copy(globalEnabled = enabled) }
    }

    fun setBlockPopups(enabled: Boolean) {
        updateAndPersist { it.copy(blockPopups = enabled) }
    }

    fun setProviderAdBlock(providerId: ProviderId, enabled: Boolean) {
        updateAndPersist { cur ->
            cur.copy(providerEnabled = cur.providerEnabled + (providerId to enabled))
        }
    }

    fun addAllowedDomain(rawDomain: String): Boolean {
        val clean = normalizeDomainInput(rawDomain) ?: return false
        updateAndPersist { cur ->
            cur.copy(
                allowedDomains = cur.allowedDomains + clean,
                customBlockedDomains = cur.customBlockedDomains - clean
            )
        }
        return true
    }

    fun removeAllowedDomain(domain: String) {
        updateAndPersist { cur -> cur.copy(allowedDomains = cur.allowedDomains - domain) }
    }

    fun addCustomBlockedDomain(rawDomain: String): Boolean {
        val clean = normalizeDomainInput(rawDomain) ?: return false
        updateAndPersist { cur ->
            cur.copy(
                customBlockedDomains = cur.customBlockedDomains + clean,
                allowedDomains = cur.allowedDomains - clean
            )
        }
        return true
    }

    fun removeCustomBlockedDomain(domain: String) {
        updateAndPersist { cur -> cur.copy(customBlockedDomains = cur.customBlockedDomains - domain) }
    }

    fun isAdBlockActiveFor(providerId: ProviderId?): Boolean {
        val st = _settings.value
        if (!st.globalEnabled) return false
        if (providerId == null) return true
        return st.providerEnabled[providerId] ?: true
    }

    fun normalizeDomainInput(raw: String): String? {
        val trimmed = raw.trim().lowercase()
        if (trimmed.isEmpty()) return null
        val extracted = if (trimmed.contains("://")) {
            android.net.Uri.parse(trimmed).host?.lowercase().orEmpty()
        } else {
            trimmed.substringBefore('/').substringBefore(':').removePrefix("www.")
        }
        return if (extracted.contains('.') && !extracted.contains(' ')) extracted else null
    }

    private fun updateAndPersist(transform: (AdBlockSettingsState) -> AdBlockSettingsState) {
        _settings.update { cur ->
            val next = transform(cur)
            persist(next)
            next
        }
    }

    private fun loadFromPrefs(sp: SharedPreferences) {
        val raw = sp.getString(KEY_STATE, null) ?: return
        try {
            val obj = JSONObject(raw)
            val globalEnabled = obj.optBoolean("global", true)
            val blockPopups = obj.optBoolean("popups", true)
            val provObj = obj.optJSONObject("providers")
            val provMap = ProviderId.entries.associateWith { pid ->
                provObj?.optBoolean(pid.id, true) ?: true
            }
            val allowed = jsonArrayToSet(obj.optJSONArray("allowed"))
            val blocked = jsonArrayToSet(obj.optJSONArray("blocked"))
            _settings.value = AdBlockSettingsState(
                globalEnabled = globalEnabled,
                blockPopups = blockPopups,
                providerEnabled = provMap,
                allowedDomains = allowed,
                customBlockedDomains = blocked
            )
        } catch (_: Exception) {
        }
    }

    private fun persist(state: AdBlockSettingsState) {
        val sp = prefs ?: return
        val provObj = JSONObject().apply {
            state.providerEnabled.forEach { (pid, v) -> put(pid.id, v) }
        }
        val root = JSONObject().apply {
            put("global", state.globalEnabled)
            put("popups", state.blockPopups)
            put("providers", provObj)
            put("allowed", JSONArray(state.allowedDomains.toList()))
            put("blocked", JSONArray(state.customBlockedDomains.toList()))
        }
        sp.edit().putString(KEY_STATE, root.toString()).apply()
    }

    private fun jsonArrayToSet(arr: JSONArray?): Set<String> {
        if (arr == null) return emptySet()
        return buildSet {
            for (i in 0 until arr.length()) {
                arr.optString(i).takeIf { it.isNotBlank() }?.let { add(it) }
            }
        }
    }

    fun exportBackupJson(): JSONObject {
        val st = _settings.value
        val provObj = JSONObject().apply {
            st.providerEnabled.forEach { (pid, v) -> put(pid.id, v) }
        }
        return JSONObject().apply {
            put("global", st.globalEnabled)
            put("popups", st.blockPopups)
            put("providers", provObj)
            put("allowed", JSONArray(st.allowedDomains.toList()))
            put("blocked", JSONArray(st.customBlockedDomains.toList()))
        }
    }

    fun importBackupJson(obj: JSONObject) {
        val globalEnabled = obj.optBoolean("global", true)
        val blockPopups = obj.optBoolean("popups", true)
        val provObj = obj.optJSONObject("providers")
        val provMap = ProviderId.entries.associateWith { pid ->
            provObj?.optBoolean(pid.id, true) ?: true
        }
        val allowed = jsonArrayToSet(obj.optJSONArray("allowed"))
        val blocked = jsonArrayToSet(obj.optJSONArray("blocked"))
        val next = AdBlockSettingsState(
            globalEnabled = globalEnabled,
            blockPopups = blockPopups,
            providerEnabled = provMap,
            allowedDomains = allowed,
            customBlockedDomains = blocked
        )
        _settings.value = next
        persist(next)
    }
}
