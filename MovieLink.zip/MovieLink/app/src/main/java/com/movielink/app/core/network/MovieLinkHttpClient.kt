package com.movielink.app.core.network

import com.movielink.app.core.model.ProviderId
import com.movielink.app.core.sources.providers.CloudflareChallengeException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

data class HttpProbeOutcome(
    val requestedUrl: String,
    val resolvedUrl: String,
    val reachable: Boolean,
    val httpCode: Int?,
    val latencyMs: Long,
    val message: String
)

data class HtmlFetchOutcome(
    val finalUrl: String,
    val html: String
)

object MovieLinkHttpClient {

    const val DEFAULT_USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"

    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .cookieJar(MovieLinkCookieJar)
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    suspend fun fetchHtml(
        url: String,
        providerId: ProviderId,
        timeoutSeconds: Int = 12,
        userAgent: String = DEFAULT_USER_AGENT
    ): HtmlFetchOutcome = withContext(Dispatchers.IO) {
        val scopedClient = scopedClient(timeoutSeconds)
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", userAgent.ifBlank { DEFAULT_USER_AGENT })
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .header("Accept-Language", "en-US,en;q=0.9")
            .build()

        scopedClient.newCall(req).execute().use { resp ->
            val finalUrl = resp.request.url.toString()
            val body = resp.body?.string().orEmpty()
            val cfHeader = resp.header("cf-mitigated")
            if (resp.code in listOf(403, 503) &&
                (cfHeader.equals("challenge", ignoreCase = true) || looksLikeCloudflareChallenge(body))
            ) {
                throw CloudflareChallengeException(providerId, finalUrl)
            }
            if (looksLikeCloudflareChallenge(body)) {
                throw CloudflareChallengeException(providerId, finalUrl)
            }
            if (!resp.isSuccessful && body.isBlank()) {
                throw IOException("HTTP ${resp.code} while loading $finalUrl")
            }
            HtmlFetchOutcome(finalUrl = finalUrl, html = body)
        }
    }

    suspend fun probeEndpoint(
        url: String,
        timeoutSeconds: Int = 12,
        userAgent: String = DEFAULT_USER_AGENT
    ): HttpProbeOutcome = withContext(Dispatchers.IO) {
        val startNs = System.nanoTime()
        val scopedClient = scopedClient(timeoutSeconds)

        val headResult = executeProbe(scopedClient, url, userAgent, useHead = true)
        val finalResult = if (headResult.httpCode == 405 || headResult.httpCode == 501) {
            executeProbe(scopedClient, url, userAgent, useHead = false)
        } else {
            headResult
        }

        val elapsedMs = ((System.nanoTime() - startNs) / 1_000_000L).coerceAtLeast(1L)
        finalResult.copy(latencyMs = elapsedMs)
    }

    private fun scopedClient(timeoutSeconds: Int): OkHttpClient {
        return if (timeoutSeconds == 12) {
            client
        } else {
            val clamped = timeoutSeconds.coerceIn(4, 30).toLong()
            client.newBuilder()
                .connectTimeout(clamped, TimeUnit.SECONDS)
                .readTimeout(clamped, TimeUnit.SECONDS)
                .build()
        }
    }

    private fun looksLikeCloudflareChallenge(html: String): Boolean {
        if (html.length > 40_000) return false
        val lower = html.lowercase()
        return lower.contains("cf-browser-verification") ||
            lower.contains("challenge-platform") ||
            (lower.contains("just a moment") && lower.contains("cloudflare"))
    }

    private fun executeProbe(
        okHttp: OkHttpClient,
        url: String,
        userAgent: String,
        useHead: Boolean
    ): HttpProbeOutcome {
        return try {
            val builder = Request.Builder()
                .url(url)
                .header("User-Agent", userAgent.ifBlank { DEFAULT_USER_AGENT })
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            if (useHead) builder.head() else builder.get()

            okHttp.newCall(builder.build()).execute().use { response ->
                val code = response.code
                val finalUrl = response.request.url.toString()
                val reachable = code in 200..399 || code == 403
                val note = when {
                    code in 200..299 -> "HTTP $code OK"
                    code in 300..399 -> "HTTP $code Redirect"
                    code == 403 -> "HTTP 403 (Host reachable, security check active)"
                    else -> "HTTP $code"
                }
                HttpProbeOutcome(
                    requestedUrl = url,
                    resolvedUrl = finalUrl,
                    reachable = reachable,
                    httpCode = code,
                    latencyMs = 0L,
                    message = note
                )
            }
        } catch (e: IOException) {
            HttpProbeOutcome(
                requestedUrl = url,
                resolvedUrl = url,
                reachable = false,
                httpCode = null,
                latencyMs = 0L,
                message = e.message?.take(90) ?: "Connection failed"
            )
        } catch (e: Exception) {
            HttpProbeOutcome(
                requestedUrl = url,
                resolvedUrl = url,
                reachable = false,
                httpCode = null,
                latencyMs = 0L,
                message = e.message?.take(90) ?: "Invalid URL"
            )
        }
    }
}
