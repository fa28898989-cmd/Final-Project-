package com.movielink.app.core.sources

import android.content.Context
import android.content.SharedPreferences
import com.movielink.app.core.model.ProviderId
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicLong

/**
 * Persistent configuration and live diagnostics state store for the 3 independent providers.
 */
object WebsiteSourcesStore {

    private const val PREFS_NAME = "movielink_website_sources_v1"
    private const val KEY_CONFIGS = "provider_configs"
    private const val KEY_HOME_PROVIDER = "active_home_provider"

    private var prefs: SharedPreferences? = null
    private val eventIdSeq = AtomicLong(1L)

    private val _configs = MutableStateFlow(defaultConfigMap())
    val configs: StateFlow<Map<ProviderId, WebsiteSourceConfig>> = _configs.asStateFlow()

    private val _activeHomeProvider = MutableStateFlow(ProviderId.MOVIELINKBD)
    val activeHomeProvider: StateFlow<ProviderId> = _activeHomeProvider.asStateFlow()

    private val _probeResults = MutableStateFlow<Map<ProviderId, MirrorProbeResult>>(
        ProviderId.entries.associateWith {
            MirrorProbeResult(url = it.defaultBaseUrl, status = ProviderHealthStatus.UNKNOWN)
        }
    )
    val probeResults: StateFlow<Map<ProviderId, MirrorProbeResult>> = _probeResults.asStateFlow()

    private val _diagnostics = MutableStateFlow<List<ProviderDiagnosticsEvent>>(emptyList())
    val diagnostics: StateFlow<List<ProviderDiagnosticsEvent>> = _diagnostics.asStateFlow()

    fun init(context: Context) {
        if (prefs != null) return
        val sp = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs = sp
        loadFromPrefs(sp)
    }

    fun isEnabled(providerId: ProviderId): Boolean =
        _configs.value[providerId]?.enabled ?: true

    fun configFor(providerId: ProviderId): WebsiteSourceConfig =
        _configs.value[providerId] ?: WebsiteSourceConfig(providerId)

    fun enabledProviders(): List<ProviderId> =
        ProviderId.entries.filter { isEnabled(it) }

    fun setProviderEnabled(providerId: ProviderId, enabled: Boolean) {
        _configs.update { current ->
            val target = current[providerId] ?: WebsiteSourceConfig(providerId)
            val next = current + (providerId to target.copy(enabled = enabled))
            persistConfigs(next)
            next
        }
        if (!enabled) {
            updateProbeResult(
                providerId,
                MirrorProbeResult(
                    url = configFor(providerId).activeBaseUrl,
                    status = ProviderHealthStatus.DISABLED,
                    message = "Disabled by user",
                    checkedAtMs = System.currentTimeMillis()
                )
            )
            // Fall back Home provider to an enabled one if current was disabled
            if (_activeHomeProvider.value == providerId) {
                enabledProviders().firstOrNull()?.let { setActiveHomeProvider(it) }
            }
            appendEvent(providerId, isError = false, message = "Provider disabled")
        } else {
            updateProbeResult(
                providerId,
                MirrorProbeResult(
                    url = configFor(providerId).activeBaseUrl,
                    status = ProviderHealthStatus.UNKNOWN,
                    message = "Enabled — ready to check"
                )
            )
            appendEvent(providerId, isError = false, message = "Provider enabled")
        }
    }

    fun setActiveHomeProvider(providerId: ProviderId) {
        if (!isEnabled(providerId)) return
        _activeHomeProvider.value = providerId
        prefs?.edit()?.putString(KEY_HOME_PROVIDER, providerId.id)?.apply()
        appendEvent(providerId, isError = false, message = "Set as active Home provider")
    }

    fun selectActiveMirror(providerId: ProviderId, rawUrl: String) {
        val normalized = normalizeProviderUrl(rawUrl) ?: return
        _configs.update { current ->
            val target = current[providerId] ?: WebsiteSourceConfig(providerId)
            val updatedMirrors = if (normalized in target.mirrors) target.mirrors else target.mirrors + normalized
            val next = current + (providerId to target.copy(
                activeBaseUrl = normalized,
                mirrors = updatedMirrors
            ))
            persistConfigs(next)
            next
        }
        appendEvent(providerId, isError = false, message = "Active URL set to $normalized")
    }

    fun addCustomMirror(providerId: ProviderId, rawUrl: String): Boolean {
        val normalized = normalizeProviderUrl(rawUrl) ?: return false
        _configs.update { current ->
            val target = current[providerId] ?: WebsiteSourceConfig(providerId)
            val updatedMirrors = (target.mirrors + normalized).distinct()
            val next = current + (providerId to target.copy(
                activeBaseUrl = normalized,
                mirrors = updatedMirrors
            ))
            persistConfigs(next)
            next
        }
        appendEvent(providerId, isError = false, message = "Added & activated mirror $normalized")
        return true
    }

    fun removeMirror(providerId: ProviderId, url: String) {
        val defaults = defaultMirrorsFor(providerId)
        if (url in defaults) return
        _configs.update { current ->
            val target = current[providerId] ?: WebsiteSourceConfig(providerId)
            val remaining = target.mirrors.filterNot { it == url }.ifEmpty { defaults }
            val nextActive = if (target.activeBaseUrl == url) remaining.first() else target.activeBaseUrl
            val next = current + (providerId to target.copy(
                activeBaseUrl = nextActive,
                mirrors = remaining
            ))
            persistConfigs(next)
            next
        }
        appendEvent(providerId, isError = false, message = "Removed custom mirror $url")
    }

    fun setTimeoutSeconds(providerId: ProviderId, seconds: Int) {
        val clamped = seconds.coerceIn(5, 30)
        _configs.update { current ->
            val target = current[providerId] ?: WebsiteSourceConfig(providerId)
            val next = current + (providerId to target.copy(timeoutSeconds = clamped))
            persistConfigs(next)
            next
        }
    }

    fun resetProviderDefaults(providerId: ProviderId) {
        _configs.update { current ->
            val next = current + (providerId to WebsiteSourceConfig(providerId))
            persistConfigs(next)
            next
        }
        updateProbeResult(
            providerId,
            MirrorProbeResult(url = providerId.defaultBaseUrl, status = ProviderHealthStatus.UNKNOWN)
        )
        appendEvent(providerId, isError = false, message = "Reset provider mirrors & settings to default")
    }

    fun resetAllDefaults() {
        val fresh = defaultConfigMap()
        _configs.value = fresh
        persistConfigs(fresh)
        _activeHomeProvider.value = ProviderId.MOVIELINKBD
        prefs?.edit()?.putString(KEY_HOME_PROVIDER, ProviderId.MOVIELINKBD.id)?.apply()
        _probeResults.value = ProviderId.entries.associateWith {
            MirrorProbeResult(url = it.defaultBaseUrl, status = ProviderHealthStatus.UNKNOWN)
        }
        appendEvent(ProviderId.MOVIELINKBD, isError = false, message = "All website sources reset to defaults")
    }

    fun updateProbeResult(providerId: ProviderId, result: MirrorProbeResult) {
        _probeResults.update { it + (providerId to result) }
    }

    fun appendEvent(providerId: ProviderId, isError: Boolean, message: String) {
        val entry = ProviderDiagnosticsEvent(
            id = eventIdSeq.getAndIncrement(),
            timestampMs = System.currentTimeMillis(),
            providerId = providerId,
            isError = isError,
            message = message
        )
        _diagnostics.update { (listOf(entry) + it).take(60) }
    }

    fun clearDiagnostics() {
        _diagnostics.value = emptyList()
    }

    private fun defaultConfigMap(): Map<ProviderId, WebsiteSourceConfig> =
        ProviderId.entries.associateWith { WebsiteSourceConfig(it) }

    private fun loadFromPrefs(sp: SharedPreferences) {
        val raw = sp.getString(KEY_CONFIGS, null)
        val map = defaultConfigMap().toMutableMap()
        if (!raw.isNullOrBlank()) {
            try {
                val root = JSONObject(raw)
                ProviderId.entries.forEach { pid ->
                    val obj = root.optJSONObject(pid.id) ?: return@forEach
                    val enabled = obj.optBoolean("enabled", true)
                    val active = normalizeProviderUrl(obj.optString("active", pid.defaultBaseUrl))
                        ?: pid.defaultBaseUrl
                    val timeout = obj.optInt("timeout", 12).coerceIn(5, 30)
                    val adBlock = obj.optBoolean("adBlock", true)
                    val mirrorArr = obj.optJSONArray("mirrors")
                    val mirrors = buildList {
                        addAll(defaultMirrorsFor(pid))
                        if (mirrorArr != null) {
                            for (i in 0 until mirrorArr.length()) {
                                normalizeProviderUrl(mirrorArr.optString(i))?.let { add(it) }
                            }
                        }
                        add(active)
                    }.distinct()
                    map[pid] = WebsiteSourceConfig(
                        providerId = pid,
                        enabled = enabled,
                        activeBaseUrl = active,
                        mirrors = mirrors,
                        timeoutSeconds = timeout,
                        adBlockEnabled = adBlock
                    )
                }
            } catch (_: Exception) {
            }
        }
        _configs.value = map

        val savedHomeId = sp.getString(KEY_HOME_PROVIDER, ProviderId.MOVIELINKBD.id).orEmpty()
        val desiredHome = ProviderId.fromId(savedHomeId)
        _activeHomeProvider.value = if (map[desiredHome]?.enabled == true) {
            desiredHome
        } else {
            map.values.firstOrNull { it.enabled }?.providerId ?: desiredHome
        }

        _probeResults.value = ProviderId.entries.associateWith { pid ->
            val cfg = map[pid] ?: WebsiteSourceConfig(pid)
            MirrorProbeResult(
                url = cfg.activeBaseUrl,
                status = if (cfg.enabled) ProviderHealthStatus.UNKNOWN else ProviderHealthStatus.DISABLED
            )
        }
    }

    private fun persistConfigs(map: Map<ProviderId, WebsiteSourceConfig>) {
        val sp = prefs ?: return
        val root = JSONObject()
        map.forEach { (pid, cfg) ->
            root.put(
                pid.id,
                JSONObject().apply {
                    put("enabled", cfg.enabled)
                    put("active", cfg.activeBaseUrl)
                    put("timeout", cfg.timeoutSeconds)
                    put("adBlock", cfg.adBlockEnabled)
                    put("mirrors", JSONArray(cfg.mirrors))
                }
            )
        }
        sp.edit().putString(KEY_CONFIGS, root.toString()).apply()
    }

    fun exportBackupJson(): JSONObject {
        val configsObj = JSONObject()
        _configs.value.forEach { (pid, cfg) ->
            configsObj.put(
                pid.id,
                JSONObject().apply {
                    put("enabled", cfg.enabled)
                    put("active", cfg.activeBaseUrl)
                    put("timeout", cfg.timeoutSeconds)
                    put("adBlock", cfg.adBlockEnabled)
                    put("mirrors", JSONArray(cfg.mirrors))
                }
            )
        }
        return JSONObject().apply {
            put("homeProvider", _activeHomeProvider.value.id)
            put("providers", configsObj)
        }
    }

    fun importBackupJson(obj: JSONObject) {
        val provObj = obj.optJSONObject("providers") ?: return
        prefs?.edit()?.putString(KEY_CONFIGS, provObj.toString())?.apply()
        val desiredHome = obj.optString("homeProvider", ProviderId.MOVIELINKBD.id)
        prefs?.edit()?.putString(KEY_HOME_PROVIDER, desiredHome)?.apply()
        prefs?.let { loadFromPrefs(it) }
    }
}
