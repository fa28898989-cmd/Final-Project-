package com.movielink.app.core.network

import android.webkit.CookieManager
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl

/**
 * Bridges OkHttp requests with Android WebView's CookieManager so Cloudflare
 * clearance cookies (cf_clearance) solved inside WebView work seamlessly in scrapers.
 */
object MovieLinkCookieJar : CookieJar {

    override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
        try {
            val cm = CookieManager.getInstance()
            val urlStr = url.toString()
            for (cookie in cookies) {
                cm.setCookie(urlStr, cookie.toString())
            }
            cm.flush()
        } catch (_: Exception) {
        }
    }

    override fun loadForRequest(url: HttpUrl): List<Cookie> {
        return try {
            val raw = CookieManager.getInstance().getCookie(url.toString()).orEmpty()
            if (raw.isBlank()) return emptyList()
            raw.split(';').mapNotNull { part ->
                Cookie.parse(url, part.trim())
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun hasCloudflareClearance(url: String): Boolean {
        return try {
            val raw = CookieManager.getInstance().getCookie(url).orEmpty()
            raw.contains("cf_clearance=", ignoreCase = true)
        } catch (_: Exception) {
            false
        }
    }
}
