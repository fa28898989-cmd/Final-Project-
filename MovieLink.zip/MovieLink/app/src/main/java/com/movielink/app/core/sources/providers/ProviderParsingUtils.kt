package com.movielink.app.core.sources.providers

import android.util.Base64
import com.movielink.app.core.model.OttPlatformItem
import com.movielink.app.core.model.ProviderId
import java.net.URI

class CloudflareChallengeException(
    val providerId: ProviderId,
    val challengeUrl: String
) : IllegalStateException("${providerId.displayName} requires security verification before loading.")

object ProviderParsingUtils {

    fun resolveUrl(baseUrl: String, relativeOrAbsolute: String): String {
        val trimmed = relativeOrAbsolute.trim()
        if (trimmed.isEmpty() || trimmed == "#" || trimmed.startsWith("javascript:", true)) return ""
        if (trimmed.startsWith("//")) return "https:$trimmed"
        return try {
            URI(baseUrl).resolve(trimmed).toString()
        } catch (_: Exception) {
            if (trimmed.startsWith("http", ignoreCase = true)) trimmed
            else baseUrl.trimEnd('/') + "/" + trimmed.trimStart('/')
        }
    }

    /**
     * Decodes click-based download tokens (`data-dl` / `data-ds` / `data-dr`)
     * using MovieLinkBD's 32-bit LCG XOR cipher.
     */
    fun decodeToken(dataDl: String, dataDs: String, dataDr: Int): String? {
        if (dataDl.isBlank()) return null
        return try {
            var x = (dataDs.trim().toLongOrNull(16) ?: 0L) and 0xFFFFFFFFL
            val rounds = dataDr.coerceIn(0, 5000)
            repeat(rounds) {
                x = (x * 1103515245L + 12345L) and 0xFFFFFFFFL
            }
            val raw = Base64.decode(dataDl, Base64.DEFAULT)
            val out = StringBuilder(raw.size)
            for (b in raw) {
                x = (x * 1103515245L + 12345L) and 0xFFFFFFFFL
                val keyByte = ((x ushr 16) and 0xFFL).toInt()
                val ch = (b.toInt() and 0xFF) xor keyByte
                out.append(ch.toChar())
            }
            out.toString().takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }
    }

    fun parseHexColor(raw: String?, fallback: Long): Long {
        if (raw.isNullOrBlank()) return fallback
        val clean = raw.trim().removePrefix("#")
        val expanded = when (clean.length) {
            3 -> "${clean[0]}${clean[0]}${clean[1]}${clean[1]}${clean[2]}${clean[2]}"
            6 -> clean
            else -> return fallback
        }
        return try {
            0xFF000000L or expanded.toLong(16)
        } catch (_: Exception) {
            fallback
        }
    }

    fun buildOttItem(
        id: String,
        name: String,
        shortCode: String,
        brandColorHex: Long
    ): OttPlatformItem = OttPlatformItem(
        id = id,
        name = name,
        shortCode = shortCode.ifBlank { name.take(2).uppercase() },
        brandColorHex = brandColorHex
    )

    fun extractYearFromTitle(raw: String): String {
        val m = Regex("""\b(19\d{2}|20\d{2})\b""").find(raw)
        return m?.groupValues?.getOrNull(1).orEmpty()
    }

    fun cleanTitleYearSplit(rawTitle: String): Pair<String, String> {
        val year = extractYearFromTitle(rawTitle)
        val clean = rawTitle
            .replace(Regex("""\(\s*(19\d{2}|20\d{2})\s*\)"""), "")
            .replace(Regex("""\s{2,}"""), " ")
            .trim()
        return clean.ifBlank { rawTitle.trim() } to year
    }
}

object BanglaUiNormalizer {
    private val bnDigits = mapOf(
        '০' to '0', '১' to '1', '২' to '2', '৩' to '3', '৪' to '4',
        '৫' to '5', '৬' to '6', '৭' to '7', '৮' to '8', '৯' to '9'
    )

    private val phrases = listOf(
        "নতুন পর্ব" to "New Episode",
        "নতুন এপিসোড" to "New Episode",
        "ডাউনলোড" to "Download",
        "পর্ব" to "Episode",
        "সিজন" to "Season",
        "বাংলা" to "Bangla",
        "হিন্দি" to "Hindi",
        "ইংরেজি" to "English",
        "নতুন" to "New"
    )

    private val clutterPatterns = listOf(
        Regex("""MovieLinkBD\s*[—\-]+\s*Unlimited\s+Downloads""", RegexOption.IGNORE_CASE),
        Regex("""Working\s+official\s+link""", RegexOption.IGNORE_CASE),
        Regex("""1\.1\.1\.1\s*VPN""", RegexOption.IGNORE_CASE),
        Regex("""Join\s+(?:Us\s+On\s+)?Telegram""", RegexOption.IGNORE_CASE),
        Regex("""Join\s+(?:Facebook\s+)?Group""", RegexOption.IGNORE_CASE)
    )

    fun isClutterText(text: String): Boolean {
        val clean = text.trim()
        return clean.isNotEmpty() && clutterPatterns.any { it.containsMatchIn(clean) }
    }

    fun normalizeUiText(input: String): String {
        if (input.isBlank()) return ""
        var out = input
        if (out.any { it in '\u0980'..'\u09FF' }) {
            for ((bn, en) in phrases) {
                if (out.contains(bn)) out = out.replace(bn, en)
            }
            val sb = StringBuilder(out.length)
            for (ch in out) sb.append(bnDigits[ch] ?: ch)
            out = sb.toString()
        }
        return out.replace(Regex("""\s{2,}"""), " ").trim()
    }
}
