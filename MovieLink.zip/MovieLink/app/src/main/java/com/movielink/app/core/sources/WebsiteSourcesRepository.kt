package com.movielink.app.core.sources

import com.movielink.app.core.model.MediaDetail
import com.movielink.app.core.model.MediaSummary
import com.movielink.app.core.model.ProviderCatalog
import com.movielink.app.core.model.ProviderId
import com.movielink.app.core.network.MovieLinkHttpClient
import com.movielink.app.core.sample.SampleMediaData
import com.movielink.app.core.sources.providers.CineFreakProvider
import com.movielink.app.core.sources.providers.MovieLinkBDProvider
import com.movielink.app.core.sources.providers.RtallyProvider
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.supervisorScope

class ProviderDisabledException(val providerId: ProviderId) :
    IllegalStateException("${providerId.displayName} is disabled in Website Sources.")

/**
 * Central orchestrator for the 3 completely independent website providers.
 * Guarantees isolated execution so one provider failing never blocks others.
 */
object WebsiteSourcesRepository {

    private val providers: Map<ProviderId, MediaSourceProvider> = mapOf(
        ProviderId.MOVIELINKBD to MovieLinkBDProvider(),
        ProviderId.CINEFREAK to CineFreakProvider(),
        ProviderId.RTALLY to RtallyProvider()
    )

    fun providerFor(providerId: ProviderId): MediaSourceProvider =
        providers.getValue(providerId)

    fun capabilitiesFor(providerId: ProviderId): ProviderCapabilities =
        providerFor(providerId).capabilities

    suspend fun loadHomeCatalog(providerId: ProviderId): Result<ProviderCatalog> {
        val cfg = WebsiteSourcesStore.configFor(providerId)
        if (!cfg.enabled) {
            return Result.failure(ProviderDisabledException(providerId))
        }
        return providerFor(providerId).fetchHomeCatalog(cfg.activeBaseUrl).onFailure { err ->
            WebsiteSourcesStore.appendEvent(
                providerId,
                isError = true,
                message = "Catalog load failed: ${err.message ?: "Unknown error"}"
            )
        }
    }

    suspend fun searchProvider(providerId: ProviderId, query: String): Result<List<MediaSummary>> {
        val cfg = WebsiteSourcesStore.configFor(providerId)
        if (!cfg.enabled) {
            return Result.failure(ProviderDisabledException(providerId))
        }
        return providerFor(providerId).search(cfg.activeBaseUrl, query).onFailure { err ->
            WebsiteSourcesStore.appendEvent(
                providerId,
                isError = true,
                message = "Search failed for \"$query\": ${err.message ?: "Unknown error"}"
            )
        }
    }

    suspend fun loadDetails(providerId: ProviderId, mediaId: String): Result<MediaDetail> {
        if (!mediaId.startsWith("http://", true) && !mediaId.startsWith("https://", true) && !mediaId.startsWith("/")) {
            return Result.success(SampleMediaData.detailFor(mediaId, providerId))
        }
        val cfg = WebsiteSourcesStore.configFor(providerId)
        return providerFor(providerId).fetchDetails(cfg.activeBaseUrl, mediaId).onFailure { err ->
            WebsiteSourcesStore.appendEvent(
                providerId,
                isError = true,
                message = "Details load failed ($mediaId): ${err.message ?: "Unknown error"}"
            )
        }
    }

    suspend fun probeActiveEndpoint(providerId: ProviderId): MirrorProbeResult {
        val cfg = WebsiteSourcesStore.configFor(providerId)
        if (!cfg.enabled) {
            val disabled = MirrorProbeResult(
                url = cfg.activeBaseUrl,
                status = ProviderHealthStatus.DISABLED,
                message = "Disabled in Website Sources",
                checkedAtMs = System.currentTimeMillis()
            )
            WebsiteSourcesStore.updateProbeResult(providerId, disabled)
            return disabled
        }

        WebsiteSourcesStore.updateProbeResult(
            providerId,
            MirrorProbeResult(
                url = cfg.activeBaseUrl,
                status = ProviderHealthStatus.CHECKING,
                message = "Probing ${cfg.activeBaseUrl}…"
            )
        )

        val outcome = MovieLinkHttpClient.probeEndpoint(
            url = cfg.activeBaseUrl,
            timeoutSeconds = cfg.timeoutSeconds,
            userAgent = cfg.customUserAgent
        )

        val result = MirrorProbeResult(
            url = outcome.requestedUrl,
            resolvedUrl = outcome.resolvedUrl,
            status = if (outcome.reachable) ProviderHealthStatus.ONLINE else ProviderHealthStatus.UNREACHABLE,
            httpCode = outcome.httpCode,
            latencyMs = outcome.latencyMs,
            message = outcome.message,
            checkedAtMs = System.currentTimeMillis()
        )
        WebsiteSourcesStore.updateProbeResult(providerId, result)
        WebsiteSourcesStore.appendEvent(
            providerId = providerId,
            isError = !outcome.reachable,
            message = "${outcome.requestedUrl} → ${outcome.message} (${outcome.latencyMs}ms)"
        )
        return result
    }

    /**
     * Probes every configured mirror in parallel and switches to the fastest reachable one.
     */
    suspend fun autoSelectBestMirror(providerId: ProviderId): MirrorProbeResult {
        val cfg = WebsiteSourcesStore.configFor(providerId)
        if (!cfg.enabled) {
            return probeActiveEndpoint(providerId)
        }

        WebsiteSourcesStore.updateProbeResult(
            providerId,
            MirrorProbeResult(
                url = cfg.activeBaseUrl,
                status = ProviderHealthStatus.CHECKING,
                message = "Testing ${cfg.mirrors.size} mirrors…"
            )
        )

        val outcomes = supervisorScope {
            cfg.mirrors.map { mirrorUrl ->
                async {
                    MovieLinkHttpClient.probeEndpoint(
                        url = mirrorUrl,
                        timeoutSeconds = cfg.timeoutSeconds,
                        userAgent = cfg.customUserAgent
                    )
                }
            }.awaitAll()
        }

        val best = outcomes.filter { it.reachable }.minByOrNull { it.latencyMs }
        val chosen = best ?: outcomes.firstOrNull()
        val result = if (chosen != null) {
            if (best != null && best.requestedUrl != cfg.activeBaseUrl) {
                WebsiteSourcesStore.selectActiveMirror(providerId, best.requestedUrl)
            }
            MirrorProbeResult(
                url = chosen.requestedUrl,
                resolvedUrl = chosen.resolvedUrl,
                status = if (chosen.reachable) ProviderHealthStatus.ONLINE else ProviderHealthStatus.UNREACHABLE,
                httpCode = chosen.httpCode,
                latencyMs = chosen.latencyMs,
                message = if (best != null) {
                    "Best mirror: ${best.message} (${best.latencyMs}ms)"
                } else {
                    "All ${outcomes.size} mirrors unreachable (${chosen.message})"
                },
                checkedAtMs = System.currentTimeMillis()
            )
        } else {
            MirrorProbeResult(
                url = cfg.activeBaseUrl,
                status = ProviderHealthStatus.UNREACHABLE,
                message = "No mirrors configured",
                checkedAtMs = System.currentTimeMillis()
            )
        }

        WebsiteSourcesStore.updateProbeResult(providerId, result)
        WebsiteSourcesStore.appendEvent(
            providerId = providerId,
            isError = result.status != ProviderHealthStatus.ONLINE,
            message = "Mirror scan: ${result.message}"
        )
        return result
    }

    suspend fun probeAllEnabledProviders() = coroutineScope {
        supervisorScope {
            ProviderId.entries.map { pid ->
                async {
                    if (WebsiteSourcesStore.isEnabled(pid)) {
                        probeActiveEndpoint(pid)
                    }
                }
            }.awaitAll()
        }
    }
}
