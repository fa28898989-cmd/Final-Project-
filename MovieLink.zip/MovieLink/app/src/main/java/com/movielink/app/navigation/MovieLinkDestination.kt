package com.movielink.app.navigation

import android.net.Uri
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Bookmarks
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material.icons.rounded.Bookmarks
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.ui.graphics.vector.ImageVector

enum class TopLevelDestination(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    HOME(
        route = "home",
        label = "Home",
        selectedIcon = Icons.Rounded.Home,
        unselectedIcon = Icons.Outlined.Home
    ),
    SEARCH(
        route = "search",
        label = "Search",
        selectedIcon = Icons.Rounded.Search,
        unselectedIcon = Icons.Outlined.Search
    ),
    LIBRARY(
        route = "library",
        label = "Library",
        selectedIcon = Icons.Rounded.Bookmarks,
        unselectedIcon = Icons.Outlined.Bookmarks
    ),
    LOCAL_PLAYER(
        route = "local_player",
        label = "Local",
        selectedIcon = Icons.Rounded.VideoLibrary,
        unselectedIcon = Icons.Outlined.VideoLibrary
    ),
    SETTINGS(
        route = "settings",
        label = "Settings",
        selectedIcon = Icons.Rounded.Settings,
        unselectedIcon = Icons.Outlined.Settings
    )
}

object MovieLinkRoutes {
    const val DETAILS = "details/{providerId}/{mediaId}"
    const val SETTINGS_SECTION = "settings_section/{sectionId}"

    fun details(providerId: String, mediaId: String): String =
        "details/$providerId/${Uri.encode(mediaId)}"

    fun settingsSection(sectionId: String): String =
        "settings_section/$sectionId"
}
