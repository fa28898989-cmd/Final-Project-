package com.movielink.app.feature.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.movielink.app.core.designsystem.FilterPill
import com.movielink.app.core.designsystem.LocalMovieLinkColors
import com.movielink.app.core.designsystem.MovieLinkCard
import com.movielink.app.core.designsystem.MovieLinkRadius
import com.movielink.app.core.designsystem.PrimaryActionButton
import com.movielink.app.core.designsystem.SecondaryActionButton
import com.movielink.app.core.designsystem.SubtleHairlineDivider
import com.movielink.app.core.integrations.BetterPosterResolver
import com.movielink.app.core.integrations.IntegrationProbeResult
import com.movielink.app.core.integrations.IntegrationsStore
import com.movielink.app.core.integrations.MdblistClient
import com.movielink.app.core.integrations.MetadataEnrichmentEngine
import com.movielink.app.core.integrations.OmdbClient
import com.movielink.app.core.integrations.TmdbClient
import kotlinx.coroutines.launch

private enum class EditingIntegrationKey {
    TMDB,
    OMDB,
    MDBLIST,
    BETTER_POSTER
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun IntegrationsSettingsContent(
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    val settings by IntegrationsStore.settings.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    var editingKey by remember { mutableStateOf<EditingIntegrationKey?>(null) }
    var probeResults by remember { mutableStateOf<Map<EditingIntegrationKey, IntegrationProbeResult>>(emptyMap()) }
    var probing by remember { mutableStateOf<Set<EditingIntegrationKey>>(emptySet()) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section A: Poster and Artwork Enrichment
        item(key = "artwork_section") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "A. Poster & Artwork Enrichment",
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                    IntegrationSwitchRow(
                        title = "Enable Artwork Enrichment",
                        subtitle = "Enhance missing posters, backdrops and clearlogos via TMDB or Better Poster",
                        checked = settings.artworkEnrichmentEnabled,
                        onCheckedChange = { checked ->
                            IntegrationsStore.update { it.copy(artworkEnrichmentEnabled = checked) }
                            MetadataEnrichmentEngine.clearCache()
                        }
                    )
                    SubtleHairlineDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Artwork Fields",
                            style = MaterialTheme.typography.labelLarge,
                            color = colors.textPrimary
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterPill(
                                label = "Posters",
                                selected = settings.fields.posters,
                                onClick = {
                                    IntegrationsStore.updateFields { it.copy(posters = !it.posters) }
                                    MetadataEnrichmentEngine.clearCache()
                                }
                            )
                            FilterPill(
                                label = "Backdrops",
                                selected = settings.fields.backdrops,
                                onClick = {
                                    IntegrationsStore.updateFields { it.copy(backdrops = !it.backdrops) }
                                    MetadataEnrichmentEngine.clearCache()
                                }
                            )
                            FilterPill(
                                label = "Title Logos",
                                selected = settings.fields.titleLogos,
                                onClick = {
                                    IntegrationsStore.updateFields { it.copy(titleLogos = !it.titleLogos) }
                                    MetadataEnrichmentEngine.clearCache()
                                }
                            )
                        }
                    }
                }
            }
        }

        // Section B: External Metadata Enrichment
        item(key = "metadata_section") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "B. External Metadata Enrichment",
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                    IntegrationSwitchRow(
                        title = "Enable External Metadata",
                        subtitle = "Fetch optional details from TMDB, OMDb & MDBList without overwriting website data",
                        checked = settings.metadataEnrichmentEnabled,
                        onCheckedChange = { checked ->
                            IntegrationsStore.update { it.copy(metadataEnrichmentEnabled = checked) }
                            MetadataEnrichmentEngine.clearCache()
                        }
                    )
                    SubtleHairlineDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    IntegrationSwitchRow(
                        title = "Prefer External Over Website",
                        subtitle = if (settings.preferExternalOverWebsite) {
                            "Use external ratings/overview when available (toggle to Original in Details anytime)"
                        } else {
                            "Fill missing website fields only (keep website values intact)"
                        },
                        checked = settings.preferExternalOverWebsite,
                        onCheckedChange = { checked ->
                            IntegrationsStore.update { it.copy(preferExternalOverWebsite = checked) }
                            MetadataEnrichmentEngine.clearCache()
                        }
                    )
                    SubtleHairlineDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Metadata Fields to Enrich",
                            style = MaterialTheme.typography.labelLarge,
                            color = colors.textPrimary
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterPill(
                                label = "Ratings",
                                selected = settings.fields.ratings,
                                onClick = {
                                    IntegrationsStore.updateFields { it.copy(ratings = !it.ratings) }
                                    MetadataEnrichmentEngine.clearCache()
                                }
                            )
                            FilterPill(
                                label = "Overview",
                                selected = settings.fields.overview,
                                onClick = {
                                    IntegrationsStore.updateFields { it.copy(overview = !it.overview) }
                                    MetadataEnrichmentEngine.clearCache()
                                }
                            )
                            FilterPill(
                                label = "Genres",
                                selected = settings.fields.genres,
                                onClick = {
                                    IntegrationsStore.updateFields { it.copy(genres = !it.genres) }
                                    MetadataEnrichmentEngine.clearCache()
                                }
                            )
                            FilterPill(
                                label = "Release Dates",
                                selected = settings.fields.releaseDates,
                                onClick = {
                                    IntegrationsStore.updateFields { it.copy(releaseDates = !it.releaseDates) }
                                    MetadataEnrichmentEngine.clearCache()
                                }
                            )
                            FilterPill(
                                label = "Runtime",
                                selected = settings.fields.runtime,
                                onClick = {
                                    IntegrationsStore.updateFields { it.copy(runtime = !it.runtime) }
                                    MetadataEnrichmentEngine.clearCache()
                                }
                            )
                            FilterPill(
                                label = "Cast",
                                selected = settings.fields.cast,
                                onClick = {
                                    IntegrationsStore.updateFields { it.copy(cast = !it.cast) }
                                    MetadataEnrichmentEngine.clearCache()
                                }
                            )
                        }
                    }
                }
            }
        }

        // Configured Providers
        item(key = "providers_header") {
            Text(
                text = "Integration Sources",
                style = MaterialTheme.typography.titleSmall,
                color = colors.textSecondary,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
        }

        item(key = "tmdb_card") {
            IntegrationProviderCard(
                name = "TMDB (The Movie Database)",
                description = "Posters, backdrops, transparent title logos, overview, cast & runtime",
                enabled = settings.tmdbEnabled,
                keyPreview = maskKey(settings.tmdbApiKey),
                probeResult = probeResults[EditingIntegrationKey.TMDB],
                isTesting = EditingIntegrationKey.TMDB in probing,
                onToggleEnabled = { on ->
                    IntegrationsStore.update { it.copy(tmdbEnabled = on) }
                    MetadataEnrichmentEngine.clearCache()
                },
                onConfigure = { editingKey = EditingIntegrationKey.TMDB },
                onTest = {
                    scope.launch {
                        probing = probing + EditingIntegrationKey.TMDB
                        val res = TmdbClient.testConnection(settings.tmdbApiKey)
                        probeResults = probeResults + (EditingIntegrationKey.TMDB to res)
                        probing = probing - EditingIntegrationKey.TMDB
                    }
                }
            )
        }

        item(key = "omdb_card") {
            IntegrationProviderCard(
                name = "OMDb API",
                description = "IMDb, Rotten Tomatoes & Metacritic ratings, certification & director",
                enabled = settings.omdbEnabled,
                keyPreview = maskKey(settings.omdbApiKey),
                probeResult = probeResults[EditingIntegrationKey.OMDB],
                isTesting = EditingIntegrationKey.OMDB in probing,
                onToggleEnabled = { on ->
                    IntegrationsStore.update { it.copy(omdbEnabled = on) }
                    MetadataEnrichmentEngine.clearCache()
                },
                onConfigure = { editingKey = EditingIntegrationKey.OMDB },
                onTest = {
                    scope.launch {
                        probing = probing + EditingIntegrationKey.OMDB
                        val res = OmdbClient.testConnection(settings.omdbApiKey)
                        probeResults = probeResults + (EditingIntegrationKey.OMDB to res)
                        probing = probing - EditingIntegrationKey.OMDB
                    }
                }
            )
        }

        item(key = "mdblist_card") {
            IntegrationProviderCard(
                name = "MDBList",
                description = "Aggregated multi-source scores & supplemental metadata",
                enabled = settings.mdblistEnabled,
                keyPreview = maskKey(settings.mdblistApiKey),
                probeResult = probeResults[EditingIntegrationKey.MDBLIST],
                isTesting = EditingIntegrationKey.MDBLIST in probing,
                onToggleEnabled = { on ->
                    IntegrationsStore.update { it.copy(mdblistEnabled = on) }
                    MetadataEnrichmentEngine.clearCache()
                },
                onConfigure = { editingKey = EditingIntegrationKey.MDBLIST },
                onTest = {
                    scope.launch {
                        probing = probing + EditingIntegrationKey.MDBLIST
                        val res = MdblistClient.testConnection(settings.mdblistApiKey)
                        probeResults = probeResults + (EditingIntegrationKey.MDBLIST to res)
                        probing = probing - EditingIntegrationKey.MDBLIST
                    }
                }
            )
        }

        item(key = "better_poster_card") {
            IntegrationProviderCard(
                name = "Better Poster / RPDB Artwork",
                description = "Rating-badged and enhanced posters via RPDB-compatible endpoint",
                enabled = settings.betterPosterEnabled,
                keyPreview = if (settings.betterPosterApiKey.isBlank()) {
                    "No key set"
                } else {
                    "${maskKey(settings.betterPosterApiKey)} • ${settings.betterPosterBaseUrl}"
                },
                probeResult = probeResults[EditingIntegrationKey.BETTER_POSTER],
                isTesting = EditingIntegrationKey.BETTER_POSTER in probing,
                onToggleEnabled = { on ->
                    IntegrationsStore.update { it.copy(betterPosterEnabled = on) }
                    MetadataEnrichmentEngine.clearCache()
                },
                onConfigure = { editingKey = EditingIntegrationKey.BETTER_POSTER },
                onTest = {
                    scope.launch {
                        probing = probing + EditingIntegrationKey.BETTER_POSTER
                        val res = BetterPosterResolver.testConnection(
                            settings.betterPosterBaseUrl,
                            settings.betterPosterApiKey
                        )
                        probeResults = probeResults + (EditingIntegrationKey.BETTER_POSTER to res)
                        probing = probing - EditingIntegrationKey.BETTER_POSTER
                    }
                }
            )
        }

        item(key = "reset_integrations") {
            SecondaryActionButton(
                text = "Clear Enrichment Cache & Reset Keys",
                onClick = {
                    IntegrationsStore.resetAll()
                    MetadataEnrichmentEngine.clearCache()
                    probeResults = emptyMap()
                },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }

    editingKey?.let { target ->
        IntegrationKeyDialog(
            target = target,
            initialKey = when (target) {
                EditingIntegrationKey.TMDB -> settings.tmdbApiKey
                EditingIntegrationKey.OMDB -> settings.omdbApiKey
                EditingIntegrationKey.MDBLIST -> settings.mdblistApiKey
                EditingIntegrationKey.BETTER_POSTER -> settings.betterPosterApiKey
            },
            initialBaseUrl = settings.betterPosterBaseUrl,
            onSave = { newKey, newBaseUrl ->
                IntegrationsStore.update { prev ->
                    when (target) {
                        EditingIntegrationKey.TMDB -> prev.copy(
                            tmdbApiKey = newKey.trim(),
                            tmdbEnabled = prev.tmdbEnabled || newKey.isNotBlank()
                        )
                        EditingIntegrationKey.OMDB -> prev.copy(
                            omdbApiKey = newKey.trim(),
                            omdbEnabled = prev.omdbEnabled || newKey.isNotBlank()
                        )
                        EditingIntegrationKey.MDBLIST -> prev.copy(
                            mdblistApiKey = newKey.trim(),
                            mdblistEnabled = prev.mdblistEnabled || newKey.isNotBlank()
                        )
                        EditingIntegrationKey.BETTER_POSTER -> prev.copy(
                            betterPosterApiKey = newKey.trim(),
                            betterPosterBaseUrl = newBaseUrl.trim().ifBlank {
                                com.movielink.app.core.integrations.IntegrationsSettings.DEFAULT_BETTER_POSTER_URL
                            },
                            betterPosterEnabled = prev.betterPosterEnabled || newKey.isNotBlank()
                        )
                    }
                }
                MetadataEnrichmentEngine.clearCache()
                probeResults = probeResults - target
                editingKey = null
            },
            onDismiss = { editingKey = null }
        )
    }
}

@Composable
private fun IntegrationProviderCard(
    name: String,
    description: String,
    enabled: Boolean,
    keyPreview: String,
    probeResult: IntegrationProbeResult?,
    isTesting: Boolean,
    onToggleEnabled: (Boolean) -> Unit,
    onConfigure: () -> Unit,
    onTest: () -> Unit
) {
    val colors = LocalMovieLinkColors.current
    MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    Text(
                        text = description,
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = enabled,
                    onCheckedChange = onToggleEnabled,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = colors.onAccent,
                        checkedTrackColor = colors.accent
                    )
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(MovieLinkRadius.Sm))
                    .clickable(onClick = onConfigure)
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Key,
                    contentDescription = null,
                    tint = colors.textSecondary,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "Key: $keyPreview",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textPrimary,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "Edit",
                    style = MaterialTheme.typography.labelLarge,
                    color = colors.accent
                )
            }

            if (probeResult != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = if (probeResult.ok) Icons.Rounded.CheckCircle else Icons.Rounded.ErrorOutline,
                        contentDescription = null,
                        tint = if (probeResult.ok) colors.success else colors.danger,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = probeResult.message,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (probeResult.ok) colors.success else colors.danger
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SecondaryActionButton(
                    text = "Configure Key",
                    onClick = onConfigure,
                    modifier = Modifier.weight(1f)
                )
                if (isTesting) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp,
                            color = colors.accent
                        )
                    }
                } else {
                    PrimaryActionButton(
                        text = "Test",
                        onClick = onTest,
                        modifier = Modifier.weight(0.75f)
                    )
                }
            }
        }
    }
}

@Composable
private fun IntegrationSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val colors = LocalMovieLinkColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = colors.onAccent,
                checkedTrackColor = colors.accent
            )
        )
    }
}

@Composable
private fun IntegrationKeyDialog(
    target: EditingIntegrationKey,
    initialKey: String,
    initialBaseUrl: String,
    onSave: (key: String, baseUrl: String) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalMovieLinkColors.current
    var apiKey by remember { mutableStateOf(initialKey) }
    var baseUrl by remember { mutableStateOf(initialBaseUrl) }

    val title = when (target) {
        EditingIntegrationKey.TMDB -> "TMDB API Key / Token"
        EditingIntegrationKey.OMDB -> "OMDb API Key"
        EditingIntegrationKey.MDBLIST -> "MDBList API Key"
        EditingIntegrationKey.BETTER_POSTER -> "Better Poster / RPDB"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.surfaceElevated,
        title = {
            Text(title, color = colors.textPrimary, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = when (target) {
                        EditingIntegrationKey.TMDB -> "Supports TMDB v3 API key or v4 Read Access Bearer token."
                        EditingIntegrationKey.OMDB -> "Enter your personal omdbapi.com API key."
                        EditingIntegrationKey.MDBLIST -> "Enter your mdblist.com API key."
                        EditingIntegrationKey.BETTER_POSTER -> "Enter your RPDB / Better Poster API key and server URL."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    singleLine = true,
                    label = { Text("API Key") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = colors.accent,
                        unfocusedBorderColor = colors.borderSubtle,
                        focusedTextColor = colors.textPrimary,
                        unfocusedTextColor = colors.textPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                if (target == EditingIntegrationKey.BETTER_POSTER) {
                    OutlinedTextField(
                        value = baseUrl,
                        onValueChange = { baseUrl = it },
                        singleLine = true,
                        label = { Text("Endpoint Base URL") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = colors.accent,
                            unfocusedBorderColor = colors.borderSubtle,
                            focusedTextColor = colors.textPrimary,
                            unfocusedTextColor = colors.textPrimary
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(apiKey, baseUrl) }) {
                Text("Save", color = colors.accent)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = colors.textSecondary)
            }
        }
    )
}

private fun maskKey(key: String): String {
    val clean = key.trim()
    if (clean.isEmpty()) return "Not configured"
    if (clean.length <= 8) return "••••${clean.takeLast(2)}"
    return "${clean.take(4)}••••${clean.takeLast(4)}"
}
