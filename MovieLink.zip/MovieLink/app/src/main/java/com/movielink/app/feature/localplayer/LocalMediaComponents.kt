package com.movielink.app.feature.localplayer

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.ImageLoader
import coil.compose.SubcomposeAsyncImage
import com.movielink.app.core.designsystem.LocalMovieLinkColors
import com.movielink.app.core.designsystem.MovieLinkCard
import com.movielink.app.core.designsystem.MovieLinkRadius
import com.movielink.app.core.designsystem.PrimaryActionButton
import com.movielink.app.core.designsystem.SecondaryActionButton
import com.movielink.app.core.designsystem.SubtleHairlineDivider
import com.movielink.app.core.localmedia.LocalMediaFormatters
import com.movielink.app.core.localmedia.LocalPlaybackRecord
import com.movielink.app.core.localmedia.LocalVideoFolder
import com.movielink.app.core.localmedia.LocalVideoItem

@Composable
fun VideoThumbnailBox(
    uri: Uri?,
    imageLoader: ImageLoader,
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(MovieLinkRadius.Sm))
            .background(colors.surfaceElevated)
            .border(1.dp, colors.borderSubtle, RoundedCornerShape(MovieLinkRadius.Sm)),
        contentAlignment = Alignment.Center
    ) {
        if (uri != null) {
            SubcomposeAsyncImage(
                model = uri,
                imageLoader = imageLoader,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
                loading = {
                    Icon(
                        imageVector = Icons.Rounded.Movie,
                        contentDescription = null,
                        tint = colors.textTertiary,
                        modifier = Modifier.size(24.dp)
                    )
                },
                error = {
                    Icon(
                        imageVector = Icons.Rounded.Movie,
                        contentDescription = null,
                        tint = colors.textTertiary,
                        modifier = Modifier.size(24.dp)
                    )
                }
            )
        } else {
            Icon(
                imageVector = Icons.Rounded.Movie,
                contentDescription = null,
                tint = colors.textTertiary,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
fun LocalVideoRowCard(
    video: LocalVideoItem,
    record: LocalPlaybackRecord?,
    imageLoader: ImageLoader,
    onPlay: () -> Unit,
    onInfo: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    MovieLinkCard(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        cornerRadius = MovieLinkRadius.Md,
        onClick = onPlay
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .width(116.dp)
                        .height(68.dp)
                ) {
                    VideoThumbnailBox(
                        uri = video.contentUri,
                        imageLoader = imageLoader,
                        modifier = Modifier.fillMaxSize()
                    )
                    if (video.durationMs > 0L) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(4.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color.Black.copy(alpha = 0.78f))
                                .padding(horizontal = 5.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = LocalMediaFormatters.formatDuration(video.durationMs),
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White
                            )
                        }
                    }
                }

                Spacer(Modifier.width(12.dp))

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = video.title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.textPrimary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    val meta = buildList {
                        add(video.extensionLabel)
                        if (video.resolutionLabel.isNotBlank()) add(video.resolutionLabel)
                        add(LocalMediaFormatters.formatSize(video.sizeBytes))
                    }.joinToString(" • ")

                    Text(
                        text = meta,
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Text(
                        text = video.folderName,
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.textTertiary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(onClick = onInfo) {
                    Icon(
                        imageVector = Icons.Outlined.Info,
                        contentDescription = "File info",
                        tint = colors.textSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            if (record != null && record.progressFraction > 0.02f) {
                LinearProgressIndicator(
                    progress = { record.progressFraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp),
                    color = colors.accent,
                    trackColor = colors.surfaceElevated
                )
            }
        }
    }
}

@Composable
fun LocalFolderRowCard(
    folder: LocalVideoFolder,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    MovieLinkCard(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        cornerRadius = MovieLinkRadius.Md,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(MovieLinkRadius.Sm))
                    .background(colors.surfaceElevated),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.Folder,
                    contentDescription = null,
                    tint = colors.accent,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = folder.name,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${folder.videoCount} videos • ${LocalMediaFormatters.formatSize(folder.totalSizeBytes)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
                Text(
                    text = folder.path,
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.textTertiary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun RecentlyPlayedRowCard(
    record: LocalPlaybackRecord,
    imageLoader: ImageLoader,
    onResume: () -> Unit,
    onRemove: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    MovieLinkCard(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        cornerRadius = MovieLinkRadius.Md,
        onClick = onResume
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .width(108.dp)
                        .height(64.dp)
                ) {
                    VideoThumbnailBox(
                        uri = Uri.parse(record.uriString),
                        imageLoader = imageLoader,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.65f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PlayArrow,
                            contentDescription = "Resume",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                Spacer(Modifier.width(12.dp))
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = record.title,
                        style = MaterialTheme.typography.titleSmall,
                        color = colors.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    val pos = LocalMediaFormatters.formatDuration(record.positionMs)
                    val dur = LocalMediaFormatters.formatDuration(record.durationMs)
                    Text(
                        text = "Resume at $pos / $dur",
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                }
                IconButton(onClick = onRemove) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = "Remove",
                        tint = colors.textTertiary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            if (record.progressFraction > 0f) {
                LinearProgressIndicator(
                    progress = { record.progressFraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp),
                    color = colors.accent,
                    trackColor = colors.surfaceElevated
                )
            }
        }
    }
}

@Composable
fun StoragePermissionCard(
    onGrantPermission: () -> Unit,
    onPickFile: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    MovieLinkCard(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        cornerRadius = MovieLinkRadius.Md
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Access Device Videos",
                style = MaterialTheme.typography.titleMedium,
                color = colors.textPrimary
            )
            Text(
                text = "Grant video permission to scan folders and thumbnails automatically, or pick an individual video file without broad permission.",
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                PrimaryActionButton(
                    text = "Scan Videos",
                    onClick = onGrantPermission,
                    modifier = Modifier.weight(1f)
                )
                SecondaryActionButton(
                    text = "Open File",
                    icon = Icons.Rounded.FolderOpen,
                    onClick = onPickFile,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun VideoInfoDialog(
    video: LocalVideoItem,
    record: LocalPlaybackRecord?,
    onPlay: (fromStart: Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalMovieLinkColors.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.surface,
        titleContentColor = colors.textPrimary,
        title = {
            Text(
                text = "File Information",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                InfoFieldRow("File Name", video.displayName)
                SubtleHairlineDivider()
                InfoFieldRow("Folder", video.folderPath)
                SubtleHairlineDivider()
                InfoFieldRow("Format", "${video.extensionLabel} (${video.mimeType})")
                SubtleHairlineDivider()
                InfoFieldRow(
                    "Resolution",
                    if (video.width > 0 && video.height > 0) "${video.width} x ${video.height}" else "Unknown"
                )
                SubtleHairlineDivider()
                InfoFieldRow("Duration", LocalMediaFormatters.formatDuration(video.durationMs))
                SubtleHairlineDivider()
                InfoFieldRow("File Size", LocalMediaFormatters.formatSize(video.sizeBytes))
                if (record != null && record.positionMs > 0L) {
                    SubtleHairlineDivider()
                    InfoFieldRow(
                        "Saved Position",
                        "${LocalMediaFormatters.formatDuration(record.positionMs)} (${(record.progressFraction * 100).toInt()}%)"
                    )
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (record != null && record.positionMs > 5_000L) {
                    TextButton(onClick = {
                        onDismiss()
                        onPlay(true)
                    }) {
                        Text("Start Over", color = colors.textSecondary)
                    }
                    PrimaryActionButton(
                        text = "Resume",
                        onClick = {
                            onDismiss()
                            onPlay(false)
                        }
                    )
                } else {
                    TextButton(onClick = onDismiss) {
                        Text("Close", color = colors.textSecondary)
                    }
                    PrimaryActionButton(
                        text = "Play",
                        onClick = {
                            onDismiss()
                            onPlay(false)
                        }
                    )
                }
            }
        }
    )
}

@Composable
private fun InfoFieldRow(label: String, value: String) {
    val colors = LocalMovieLinkColors.current
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = colors.textSecondary
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = colors.textPrimary
        )
    }
}
