package com.movielink.app.feature.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.movielink.app.core.adblock.AdBlockStore
import com.movielink.app.core.adblock.AdBlockerEngine
import com.movielink.app.core.designsystem.EmptyStateCard
import com.movielink.app.core.designsystem.LocalMovieLinkColors
import com.movielink.app.core.designsystem.MovieLinkCard
import com.movielink.app.core.designsystem.MovieLinkRadius
import com.movielink.app.core.designsystem.SecondaryActionButton
import com.movielink.app.core.designsystem.SubtleHairlineDivider
import com.movielink.app.core.model.ProviderId
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class DomainDialogMode {
    ALLOW,
    BLOCK
}

@Composable
fun AdBlockingSettingsContent(
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    val state by AdBlockStore.settings.collectAsStateWithLifecycle()
    val blockedCount by AdBlockerEngine.sessionBlockedCount.collectAsStateWithLifecycle()
    val recentBlocked by AdBlockerEngine.recentBlocked.collectAsStateWithLifecycle()
    val timeFormatter = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }

    var domainDialog by remember { mutableStateOf<DomainDialogMode?>(null) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item(key = "stats_card") {
            MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Shield,
                            contentDescription = null,
                            tint = colors.accent,
                            modifier = Modifier.size(28.dp)
                        )
                        Column {
                            Text(
                                text = "$blockedCount Requests Blocked",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                            Text(
                                text = "Current session popups, trackers & ad-redirects",
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textSecondary
                            )
                        }
                    }
                    IconButton(onClick = { AdBlockerEngine.clearSessionStats() }) {
                        Icon(
                            imageVector = Icons.Rounded.DeleteSweep,
                            contentDescription = "Reset counter",
                            tint = colors.textSecondary
                        )
                    }
                }
            }
        }

        item(key = "global_rules") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Global Protection",
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                    AdBlockSwitchRow(
                        title = "Enable Built-in Ad Blocking",
                        subtitle = "Block known ad/popunder networks and redirect scripts",
                        checked = state.globalEnabled,
                        onCheckedChange = { AdBlockStore.setGlobalEnabled(it) }
                    )
                    SubtleHairlineDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    AdBlockSwitchRow(
                        title = "Block Pop-up Windows",
                        subtitle = "Prevent WebView new-tab ad spawns and click-under traps",
                        checked = state.blockPopups,
                        onCheckedChange = { AdBlockStore.setBlockPopups(it) }
                    )
                }
            }
        }

        item(key = "per_provider") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Per-Provider Ad Rules",
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                    ProviderId.entries.forEachIndexed { index, provider ->
                        val enabled = state.providerEnabled[provider] ?: true
                        AdBlockSwitchRow(
                            title = "${provider.displayName} (${provider.shortLabel})",
                            subtitle = if (enabled) "Filtering ad hosts & scripts" else "Filtering paused for this source",
                            checked = enabled && state.globalEnabled,
                            onCheckedChange = { AdBlockStore.setProviderAdBlock(provider, it) }
                        )
                        if (index < ProviderId.entries.lastIndex) {
                            SubtleHairlineDivider(modifier = Modifier.padding(horizontal = 16.dp))
                        }
                    }
                }
            }
        }

        item(key = "whitelists") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Allowed Domains (Whitelist)",
                        style = MaterialTheme.typography.titleSmall,
                        color = colors.textSecondary,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                    TextButton(onClick = { domainDialog = DomainDialogMode.ALLOW }) {
                        Icon(Icons.Rounded.Add, null, tint = colors.accent, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Allow Domain", color = colors.accent)
                    }
                }
                MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                    if (state.allowedDomains.isEmpty()) {
                        Text(
                            text = "No custom allowed domains. Active provider mirrors are always exempt.",
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary,
                            modifier = Modifier.padding(16.dp)
                        )
                    } else {
                        val list = state.allowedDomains.sorted()
                        list.forEachIndexed { idx, domain ->
                            DomainListRow(
                                domain = domain,
                                onRemove = { AdBlockStore.removeAllowedDomain(domain) }
                            )
                            if (idx < list.lastIndex) {
                                SubtleHairlineDivider(modifier = Modifier.padding(horizontal = 16.dp))
                            }
                        }
                    }
                }
            }
        }

        item(key = "custom_blocked") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Custom Blocked Domains",
                        style = MaterialTheme.typography.titleSmall,
                        color = colors.textSecondary,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                    TextButton(onClick = { domainDialog = DomainDialogMode.BLOCK }) {
                        Icon(Icons.Rounded.Add, null, tint = colors.accent, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Block Domain", color = colors.accent)
                    }
                }
                MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                    if (state.customBlockedDomains.isEmpty()) {
                        Text(
                            text = "No extra user-blocked domains added.",
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary,
                            modifier = Modifier.padding(16.dp)
                        )
                    } else {
                        val list = state.customBlockedDomains.sorted()
                        list.forEachIndexed { idx, domain ->
                            DomainListRow(
                                domain = domain,
                                onRemove = { AdBlockStore.removeCustomBlockedDomain(domain) }
                            )
                            if (idx < list.lastIndex) {
                                SubtleHairlineDivider(modifier = Modifier.padding(horizontal = 16.dp))
                            }
                        }
                    }
                }
            }
        }

        item(key = "recent_log_heading") {
            Text(
                text = "Recent Blocked Activity (${recentBlocked.size})",
                style = MaterialTheme.typography.titleSmall,
                color = colors.textSecondary,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
        }

        if (recentBlocked.isEmpty()) {
            item(key = "empty_blocked") {
                EmptyStateCard(
                    title = "No blocked requests yet",
                    description = "Ad networks, trackers, and redirect traps intercepted while resolving links will appear here.",
                    icon = Icons.Rounded.Shield
                )
            }
        } else {
            items(recentBlocked, key = { it.id }) { evt ->
                MovieLinkCard(cornerRadius = MovieLinkRadius.Sm) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = evt.host,
                                style = MaterialTheme.typography.titleSmall,
                                color = colors.textPrimary
                            )
                            Text(
                                text = "${evt.providerId?.displayName ?: "Global"} • ${evt.reason}",
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textSecondary
                            )
                        }
                        Text(
                            text = timeFormatter.format(Date(evt.timestampMs)),
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.textTertiary
                        )
                    }
                }
            }
        }

        item { Spacer(Modifier.height(10.dp)) }
    }

    domainDialog?.let { mode ->
        DomainInputDialog(
            isAllow = mode == DomainDialogMode.ALLOW,
            onConfirm = { raw ->
                val ok = if (mode == DomainDialogMode.ALLOW) {
                    AdBlockStore.addAllowedDomain(raw)
                } else {
                    AdBlockStore.addCustomBlockedDomain(raw)
                }
                if (ok) domainDialog = null
                ok
            },
            onDismiss = { domainDialog = null }
        )
    }
}

@Composable
private fun AdBlockSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val colors = LocalMovieLinkColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = colors.onAccent,
                checkedTrackColor = colors.accent
            )
        )
    }
}

@Composable
private fun DomainListRow(
    domain: String,
    onRemove: () -> Unit
) {
    val colors = LocalMovieLinkColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = domain,
            style = MaterialTheme.typography.bodyMedium,
            color = colors.textPrimary,
            modifier = Modifier.weight(1f)
        )
        IconButton(onClick = onRemove, modifier = Modifier.size(28.dp)) {
            Icon(
                imageVector = Icons.Rounded.Close,
                contentDescription = "Remove domain",
                tint = colors.textTertiary,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
private fun DomainInputDialog(
    isAllow: Boolean,
    onConfirm: (String) -> Boolean,
    onDismiss: () -> Unit
) {
    val colors = LocalMovieLinkColors.current
    var input by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.surface,
        titleContentColor = colors.textPrimary,
        title = {
            Text(
                text = if (isAllow) "Allow Domain" else "Block Domain",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = if (isAllow) "Add a host domain that should never be blocked." else "Add an ad or redirect domain to block.",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
                OutlinedTextField(
                    value = input,
                    onValueChange = {
                        input = it
                        errorText = null
                    },
                    singleLine = true,
                    placeholder = { Text("example.com", color = colors.textTertiary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = colors.borderStrong,
                        unfocusedBorderColor = colors.borderSubtle,
                        focusedTextColor = colors.textPrimary,
                        unfocusedTextColor = colors.textPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                if (errorText != null) {
                    Text(
                        text = errorText!!,
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.danger
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (!onConfirm(input)) {
                        errorText = "Enter a valid domain (e.g. host.com)."
                    }
                }
            ) {
                Text(if (isAllow) "Allow" else "Block", color = colors.accent)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = colors.textSecondary)
            }
        }
    )
}
