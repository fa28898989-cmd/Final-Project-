package com.movielink.app.core.designsystem

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import com.movielink.app.core.model.MediaSummary

/**
 * Renders full artwork without unwanted cropping when a URL is present,
 * and falls back cleanly to crisp, high-contrast stylized poster/backdrop
 * graphics for Stage 2 offline sample items.
 */
@Composable
fun MediaArtwork(
    media: MediaSummary,
    isBackdrop: Boolean,
    modifier: Modifier = Modifier,
    showEmbeddedTitle: Boolean = false
) {
    val imageUrl = if (isBackdrop) {
        media.backdropUrl.ifBlank { media.posterUrl }
    } else {
        media.posterUrl
    }

    if (imageUrl.isNotBlank()) {
        SubcomposeAsyncImage(
            model = imageUrl,
            contentDescription = media.title,
            contentScale = if (isBackdrop) ContentScale.Crop else ContentScale.Fit,
            modifier = modifier,
            loading = {
                FallbackPosterGraphic(media, isBackdrop, showEmbeddedTitle)
            },
            error = {
                FallbackPosterGraphic(media, isBackdrop, showEmbeddedTitle)
            }
        )
    } else {
        FallbackPosterGraphic(
            media = media,
            isBackdrop = isBackdrop,
            showEmbeddedTitle = showEmbeddedTitle,
            modifier = modifier
        )
    }
}

@Composable
private fun FallbackPosterGraphic(
    media: MediaSummary,
    isBackdrop: Boolean,
    showEmbeddedTitle: Boolean,
    modifier: Modifier = Modifier
) {
    val topColor = Color(media.accentHex)
    val bottomColor = Color(media.secondaryHex)
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    colors = listOf(topColor, bottomColor, Color(0xFF050507))
                )
            )
    ) {
        // Subtle radial highlight simulating theatrical lighting
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.14f),
                            Color.Transparent
                        )
                    )
                )
        )

        if (showEmbeddedTitle) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = media.title.uppercase(),
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = if (isBackdrop) 26.sp else 16.sp,
                    lineHeight = if (isBackdrop) 30.sp else 20.sp,
                    textAlign = TextAlign.Center,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
                if (media.subtitle.isNotBlank() && !isBackdrop) {
                    Text(
                        text = media.subtitle,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.72f),
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
