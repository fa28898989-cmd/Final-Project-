package com.movielink.app.feature.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.NetworkCheck
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.movielink.app.core.designsystem.LocalMovieLinkColors
import com.movielink.app.core.designsystem.MovieLinkCard
import com.movielink.app.core.designsystem.MovieLinkRadius
import com.movielink.app.core.designsystem.PrimaryActionButton
import com.movielink.app.core.designsystem.SecondaryActionButton
import com.movielink.app.core.designsystem.SubtleHairlineDivider
import com.movielink.app.core.model.ProviderId
import com.movielink.app.core.sources.MirrorProbeResult
import com.movielink.app.core.sources.ProviderHealthStatus
import com.movielink.app.core.sources.WebsiteSourceConfig
import com.movielink.app.core.sources.WebsiteSourcesRepository
import com.movielink.app.core.sources.WebsiteSourcesStore
import com.movielink.app.core.sources.defaultMirrorsFor
import com.movielink.app.core.sources.normalizeProviderUrl
import kotlinx.coroutines.launch

@Composable
fun WebsiteSourcesSettingsContent(
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    val configs by WebsiteSourcesStore.configs.collectAsStateWithLifecycle()
    val activeHome by WebsiteSourcesStore.activeHomeProvider.collectAsStateWithLifecycle()
    val probes by WebsiteSourcesStore.probeResults.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    var addMirrorTarget by remember { mutableStateOf<ProviderId?>(null) }
    val enabledList = remember(configs) {
        ProviderId.entries.filter { configs[it]?.enabled ?: true }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item(key = "top_actions") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                PrimaryActionButton(
                    text = "Test All Enabled",
                    icon = Icons.Rounded.NetworkCheck,
                    onClick = {
                        scope.launch { WebsiteSourcesRepository.probeAllEnabledProviders() }
                    },
                    modifier = Modifier.weight(1f)
                )
                SecondaryActionButton(
                    text = "Reset All",
                    icon = Icons.Rounded.Refresh,
                    onClick = { WebsiteSourcesStore.resetAllDefaults() },
                    modifier = Modifier.weight(0.7f)
                )
            }
        }

        item(key = "home_provider") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Default Home Content Source",
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                    if (enabledList.isEmpty()) {
                        Text(
                            text = "All website providers are disabled. Enable at least one source below to populate the Home tab.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = colors.textSecondary,
                            modifier = Modifier.padding(16.dp)
                        )
                    } else {
                        enabledList.forEachIndexed { index, provider ->
                            val cfg = configs[provider] ?: WebsiteSourceConfig(provider)
                            val probe = probes[provider]
                            val selected = activeHome == provider
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { WebsiteSourcesStore.setActiveHomeProvider(provider) }
                                    .padding(horizontal = 16.dp, vertical = 13.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${provider.shortLabel} — ${provider.displayName}",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = colors.textPrimary
                                    )
                                    Text(
                                        text = cfg.activeBaseUrl,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = colors.textSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    if (probe != null && probe.status != ProviderHealthStatus.UNKNOWN) {
                                        HealthDot(status = probe.status)
                                    }
                                    if (selected) {
                                        Box(
                                            modifier = Modifier
                                                .size(22.dp)
                                                .clip(CircleShape)
                                                .background(colors.accent),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.Check,
                                                contentDescription = null,
                                                tint = colors.onAccent,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                }
                            }
                            if (index < enabledList.lastIndex) {
                                SubtleHairlineDivider(modifier = Modifier.padding(horizontal = 16.dp))
                            }
                        }
                    }
                }
            }
        }

        item(key = "providers_heading") {
            Text(
                text = "Independent Providers & Mirrors",
                style = MaterialTheme.typography.titleSmall,
                color = colors.textSecondary,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
        }

        items(ProviderId.entries, key = { it.id }) { provider ->
            val cfg = configs[provider] ?: WebsiteSourceConfig(provider)
            val probe = probes[provider] ?: MirrorProbeResult(url = cfg.activeBaseUrl)
            val capabilities = remember(provider) {
                WebsiteSourcesRepository.capabilitiesFor(provider)
            }

            ProviderSourceCard(
                provider = provider,
                config = cfg,
                probe = probe,
                capabilities = capabilities.badgeLabels(),
                onToggleEnabled = { enabled ->
                    WebsiteSourcesStore.setProviderEnabled(provider, enabled)
                },
                onSelectMirror = { url ->
                    WebsiteSourcesStore.selectActiveMirror(provider, url)
                },
                onRemoveMirror = { url ->
                    WebsiteSourcesStore.removeMirror(provider, url)
                },
                onAddMirrorClick = { addMirrorTarget = provider },
                onTestActive = {
                    scope.launch { WebsiteSourcesRepository.probeActiveEndpoint(provider) }
                },
                onFindBestMirror = {
                    scope.launch { WebsiteSourcesRepository.autoSelectBestMirror(provider) }
                },
                onResetProvider = {
                    WebsiteSourcesStore.resetProviderDefaults(provider)
                }
            )
        }

        item { Spacer(Modifier.height(10.dp)) }
    }

    addMirrorTarget?.let { target ->
        AddMirrorDialog(
            provider = target,
            onConfirm = { rawUrl ->
                val added = WebsiteSourcesStore.addCustomMirror(target, rawUrl)
                if (added) {
                    addMirrorTarget = null
                    scope.launch { WebsiteSourcesRepository.probeActiveEndpoint(target) }
                }
                added
            },
            onDismiss = { addMirrorTarget = null }
        )
    }
}

@Composable
private fun ProviderSourceCard(
    provider: ProviderId,
    config: WebsiteSourceConfig,
    probe: MirrorProbeResult,
    capabilities: List<String>,
    onToggleEnabled: (Boolean) -> Unit,
    onSelectMirror: (String) -> Unit,
    onRemoveMirror: (String) -> Unit,
    onAddMirrorClick: () -> Unit,
    onTestActive: () -> Unit,
    onFindBestMirror: () -> Unit,
    onResetProvider: () -> Unit
) {
    val colors = LocalMovieLinkColors.current
    val defaults = remember(provider) { defaultMirrorsFor(provider).toSet() }

    MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = provider.displayName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                        Text(
                            text = provider.shortLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.textSecondary
                        )
                    }
                    Spacer(Modifier.height(2.dp))
                    HealthStatusLine(probe = probe, enabled = config.enabled)
                }

                Switch(
                    checked = config.enabled,
                    onCheckedChange = onToggleEnabled,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = colors.onAccent,
                        checkedTrackColor = colors.accent
                    )
                )
            }

            // Capabilities row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                capabilities.forEach { badge ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(MovieLinkRadius.Xs))
                            .background(colors.surfaceElevated)
                            .border(1.dp, colors.borderSubtle, RoundedCornerShape(MovieLinkRadius.Xs))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = badge,
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.textSecondary
                        )
                    }
                }
            }

            SubtleHairlineDivider()

            // Mirrors selection
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Mirrors & Active Domain",
                        style = MaterialTheme.typography.labelLarge,
                        color = colors.textPrimary
                    )
                    TextButton(onClick = onAddMirrorClick) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = null,
                            tint = colors.accent,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text("Add Mirror", color = colors.accent)
                    }
                }

                config.mirrors.forEach { mirror ->
                    val isSelected = mirror == config.activeBaseUrl
                    val isDefault = mirror in defaults
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(MovieLinkRadius.Sm))
                            .background(if (isSelected) colors.surfaceElevated else Color.Transparent)
                            .border(
                                1.dp,
                                if (isSelected) colors.borderStrong else colors.borderSubtle,
                                RoundedCornerShape(MovieLinkRadius.Sm)
                            )
                            .clickable(enabled = config.enabled) { onSelectMirror(mirror) }
                            .padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = mirror,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (config.enabled) colors.textPrimary else colors.textTertiary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Rounded.Check,
                                    contentDescription = "Active",
                                    tint = colors.accent,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            if (!isDefault) {
                                IconButton(
                                    onClick = { onRemoveMirror(mirror) },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Close,
                                        contentDescription = "Remove mirror",
                                        tint = colors.textTertiary,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (probe.message.isNotBlank()) {
                Text(
                    text = probe.message,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (probe.status == ProviderHealthStatus.UNREACHABLE) {
                        colors.danger
                    } else {
                        colors.textSecondary
                    }
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SecondaryActionButton(
                    text = "Check URL",
                    icon = Icons.Rounded.NetworkCheck,
                    onClick = onTestActive,
                    modifier = Modifier.weight(1f)
                )
                SecondaryActionButton(
                    text = "Best Mirror",
                    icon = Icons.Rounded.AutoFixHigh,
                    onClick = onFindBestMirror,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onResetProvider) {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = "Reset provider",
                        tint = colors.textSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun HealthStatusLine(
    probe: MirrorProbeResult,
    enabled: Boolean
) {
    val colors = LocalMovieLinkColors.current
    val effectiveStatus = if (!enabled) ProviderHealthStatus.DISABLED else probe.status
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (effectiveStatus == ProviderHealthStatus.CHECKING) {
            CircularProgressIndicator(
                modifier = Modifier.size(12.dp),
                strokeWidth = 2.dp,
                color = colors.accent
            )
        } else {
            HealthDot(status = effectiveStatus)
        }
        val label = when {
            !enabled -> "Disabled"
            effectiveStatus == ProviderHealthStatus.ONLINE && probe.latencyMs > 0 ->
                "Reachable • ${probe.latencyMs}ms"
            else -> effectiveStatus.label
        }
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = when (effectiveStatus) {
                ProviderHealthStatus.ONLINE -> Color(0xFF4ADE80)
                ProviderHealthStatus.UNREACHABLE -> colors.danger
                else -> colors.textSecondary
            }
        )
    }
}

@Composable
private fun HealthDot(status: ProviderHealthStatus) {
    val dotColor = when (status) {
        ProviderHealthStatus.ONLINE -> Color(0xFF22C55E)
        ProviderHealthStatus.UNREACHABLE -> Color(0xFFEF4444)
        ProviderHealthStatus.CHECKING -> Color(0xFFF59E0B)
        ProviderHealthStatus.DISABLED -> Color(0xFF52525B)
        ProviderHealthStatus.UNKNOWN -> Color(0xFF71717A)
    }
    Box(
        modifier = Modifier
            .size(8.dp)
            .clip(CircleShape)
            .background(dotColor)
    )
}

@Composable
private fun AddMirrorDialog(
    provider: ProviderId,
    onConfirm: (String) -> Boolean,
    onDismiss: () -> Unit
) {
    val colors = LocalMovieLinkColors.current
    var input by remember { mutableStateOf("https://") }
    var errorText by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.surface,
        titleContentColor = colors.textPrimary,
        title = {
            Text(
                text = "Add ${provider.displayName} Mirror",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Enter an alternate HTTPS domain or mirror URL.",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
                OutlinedTextField(
                    value = input,
                    onValueChange = {
                        input = it
                        errorText = null
                    },
                    singleLine = true,
                    placeholder = { Text("https://mirror.example.com/", color = colors.textTertiary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = colors.borderStrong,
                        unfocusedBorderColor = colors.borderSubtle,
                        focusedTextColor = colors.textPrimary,
                        unfocusedTextColor = colors.textPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                if (errorText != null) {
                    Text(
                        text = errorText!!,
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.danger
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val valid = normalizeProviderUrl(input)
                    if (valid == null) {
                        errorText = "Enter a valid HTTP or HTTPS host URL."
                    } else if (!onConfirm(valid)) {
                        errorText = "Could not add mirror URL."
                    }
                }
            ) {
                Text("Add & Activate", color = colors.accent)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = colors.textSecondary)
            }
        }
    )
}
