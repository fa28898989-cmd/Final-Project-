package com.movielink.app.core.localmedia

import android.net.Uri
import java.util.Locale

enum class LocalLibraryTab(val label: String) {
    ALL_VIDEOS("All Videos"),
    FOLDERS("Folders"),
    RECENTLY_PLAYED("Recently Played")
}

enum class LocalSortOrder(val label: String) {
    DATE_DESC("Newest first"),
    NAME_ASC("Name (A–Z)"),
    SIZE_DESC("Largest first"),
    DURATION_DESC("Longest first")
}

data class LocalVideoItem(
    val id: Long,
    val contentUri: Uri,
    val title: String,
    val displayName: String,
    val folderPath: String,
    val folderName: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val width: Int,
    val height: Int,
    val mimeType: String,
    val dateAddedSec: Long
) {
    val extensionLabel: String
        get() {
            val ext = displayName.substringAfterLast('.', "").uppercase(Locale.US)
            if (ext.isNotBlank() && ext.length <= 5) return ext
            return when {
                mimeType.contains("matroska", true) -> "MKV"
                mimeType.contains("webm", true) -> "WEBM"
                mimeType.contains("avi", true) || mimeType.contains("msvideo", true) -> "AVI"
                mimeType.contains("mp4", true) -> "MP4"
                else -> "VIDEO"
            }
        }

    val resolutionLabel: String
        get() {
            val minDim = minOf(width, height)
            val maxDim = maxOf(width, height)
            return when {
                minDim >= 2160 || maxDim >= 3840 -> "4K"
                minDim >= 1080 || maxDim >= 1920 -> "1080p"
                minDim >= 720 || maxDim >= 1280 -> "720p"
                minDim >= 480 -> "480p"
                width > 0 && height > 0 -> "${width}x${height}"
                else -> ""
            }
        }
}

data class LocalVideoFolder(
    val path: String,
    val name: String,
    val videoCount: Int,
    val totalSizeBytes: Long,
    val previewUri: Uri?
)

data class LocalPlaybackRecord(
    val uriString: String,
    val title: String,
    val positionMs: Long,
    val durationMs: Long,
    val lastPlayedAtMs: Long
) {
    val progressFraction: Float
        get() = if (durationMs > 0L) {
            (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
        } else {
            0f
        }
}

data class PlayerMediaRequest(
    val uri: Uri,
    val title: String,
    val subtitle: String = "",
    val isLocal: Boolean = true,
    val resumePositionMs: Long = 0L
)

object LocalMediaFormatters {
    fun formatDuration(ms: Long): String {
        if (ms <= 0L) return "0:00"
        val totalSec = ms / 1000L
        val hours = totalSec / 3600L
        val minutes = (totalSec % 3600L) / 60L
        val seconds = totalSec % 60L
        return if (hours > 0L) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%d:%02d", minutes, seconds)
        }
    }

    fun formatSize(bytes: Long): String {
        if (bytes <= 0L) return "0 MB"
        val kb = 1024.0
        val mb = kb * 1024.0
        val gb = mb * 1024.0
        return when {
            bytes >= gb -> String.format(Locale.US, "%.2f GB", bytes / gb)
            bytes >= mb -> String.format(Locale.US, "%.1f MB", bytes / mb)
            else -> String.format(Locale.US, "%.0f KB", bytes / kb)
        }
    }
}
