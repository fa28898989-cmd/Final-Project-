package com.movielink.app.core.sources

import com.movielink.app.core.model.MediaDetail
import com.movielink.app.core.model.MediaSummary
import com.movielink.app.core.model.ProviderCatalog
import com.movielink.app.core.model.ProviderId

/**
 * Strict contract implemented independently by each website provider
 * (MovieLinkBD, CineFreak, Rtally). No shared parser assumptions.
 */
interface MediaSourceProvider {
    val providerId: ProviderId
    val capabilities: ProviderCapabilities

    suspend fun fetchHomeCatalog(baseUrl: String): Result<ProviderCatalog>

    suspend fun search(baseUrl: String, query: String): Result<List<MediaSummary>>

    suspend fun fetchDetails(baseUrl: String, mediaId: String): Result<MediaDetail>
}
