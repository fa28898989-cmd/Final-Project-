package com.movielink.app.feature.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBackIosNew
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.movielink.app.core.designsystem.FilterPill
import com.movielink.app.core.designsystem.LocalMovieLinkColors
import com.movielink.app.core.designsystem.MovieLinkCard
import com.movielink.app.core.designsystem.MovieLinkRadius
import com.movielink.app.core.designsystem.ScreenTitleHeader
import com.movielink.app.core.designsystem.SubtleHairlineDivider

enum class SettingsSection(
    val id: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector
) {
    APPEARANCE("appearance", "Appearance", "AMOLED theme, custom colors, hero style & size", Icons.Rounded.Palette),
    WEBSITE_SOURCES("sources", "Website Sources", "Enable providers, mirrors & availability checks", Icons.Rounded.Language),
    INTEGRATIONS("integrations", "Integrations", "Optional TMDB, OMDb, MDBList & artwork enrichment", Icons.Rounded.Extension),
    AD_BLOCKING("ad_blocking", "Ad Blocking", "Per-provider request rules, pop-ups & whitelist", Icons.Rounded.Shield),
    PLAYBACK("playback", "Playback", "Media3 player, gestures, speed & track defaults", Icons.Rounded.PlayCircle),
    DOWNLOADS("downloads", "Downloads", "IDM, 1DM, ADM & download routing preferences", Icons.Rounded.Download),
    LIBRARY("library", "Library", "Watchlist, history & Continue Watching behavior", Icons.Rounded.VideoLibrary),
    BACKUP_RESTORE("backup", "Backup & Restore", "Export and import validated configuration files", Icons.Rounded.Restore),
    STORAGE("storage", "Storage", "Artwork cache and local cache controls", Icons.Rounded.Storage),
    DIAGNOSTICS("diagnostics", "Diagnostics", "Provider health, ad-block counters & logs", Icons.Rounded.Folder),
    ABOUT("about", "About", "Version info and architecture notes", Icons.Rounded.Info);

    companion object {
        fun fromId(id: String): SettingsSection =
            entries.firstOrNull { it.id == id } ?: APPEARANCE
    }
}

@Composable
fun SettingsScreen(
    onOpenSection: (SettingsSection) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    val groups = listOf(
        "Personalization & Sources" to listOf(
            SettingsSection.APPEARANCE,
            SettingsSection.WEBSITE_SOURCES,
            SettingsSection.INTEGRATIONS,
            SettingsSection.AD_BLOCKING
        ),
        "Media & Library" to listOf(
            SettingsSection.PLAYBACK,
            SettingsSection.DOWNLOADS,
            SettingsSection.LIBRARY
        ),
        "Data & System" to listOf(
            SettingsSection.BACKUP_RESTORE,
            SettingsSection.STORAGE,
            SettingsSection.DIAGNOSTICS,
            SettingsSection.ABOUT
        )
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item(key = "header") {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                colors.surfaceElevated.copy(alpha = 0.72f),
                                colors.background
                            )
                        )
                    )
                    .statusBarsPadding()
                    .padding(top = 6.dp)
            ) {
                ScreenTitleHeader(
                    title = "Settings",
                    subtitle = "Appearance, Website Sources, Integrations, Ad Blocking & Playback"
                )
            }
        }

        groups.forEach { (groupTitle, items) ->
            item(key = groupTitle) {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = groupTitle,
                        style = MaterialTheme.typography.titleSmall,
                        color = colors.textSecondary,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                    MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                        items.forEachIndexed { index, section ->
                            SettingsRow(
                                section = section,
                                onClick = { onOpenSection(section) }
                            )
                            if (index < items.lastIndex) {
                                SubtleHairlineDivider(modifier = Modifier.padding(start = 52.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsRow(
    section: SettingsSection,
    onClick: () -> Unit
) {
    val colors = LocalMovieLinkColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = section.icon,
            contentDescription = null,
            tint = colors.textPrimary,
            modifier = Modifier.size(20.dp)
        )
        Spacer(Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = section.title,
                style = MaterialTheme.typography.titleSmall,
                color = colors.textPrimary
            )
            Text(
                text = section.subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary
            )
        }
        Icon(
            imageVector = Icons.Rounded.ChevronRight,
            contentDescription = null,
            tint = colors.textTertiary,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
fun SettingsSectionDetailScreen(
    sectionId: String,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    var activeSection by remember(sectionId) { mutableStateOf(SettingsSection.fromId(sectionId)) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background)
    ) {
        // Atmospheric top header matching Reference Images 2–3
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            colors.surfaceElevated.copy(alpha = 0.78f),
                            colors.background
                        )
                    )
                )
                .statusBarsPadding()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onBack)
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Rounded.ArrowBackIosNew,
                    contentDescription = "Back",
                    tint = colors.textPrimary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "Back",
                    style = MaterialTheme.typography.labelLarge,
                    color = colors.textPrimary
                )
            }

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(SettingsSection.entries, key = { it.id }) { section ->
                    FilterPill(
                        label = section.title,
                        selected = section == activeSection,
                        onClick = { activeSection = section }
                    )
                }
            }

            ScreenTitleHeader(
                title = activeSection.title,
                subtitle = activeSection.subtitle
            )
        }

        when (activeSection) {
            SettingsSection.APPEARANCE -> AppearanceSettingsContent(modifier = Modifier.weight(1f))
            SettingsSection.WEBSITE_SOURCES -> WebsiteSourcesSettingsContent(modifier = Modifier.weight(1f))
            SettingsSection.INTEGRATIONS -> IntegrationsSettingsContent(modifier = Modifier.weight(1f))
            SettingsSection.AD_BLOCKING -> AdBlockingSettingsContent(modifier = Modifier.weight(1f))
            SettingsSection.PLAYBACK -> PlaybackSettingsContent(modifier = Modifier.weight(1f))
            SettingsSection.DOWNLOADS -> DownloadsSettingsContent(modifier = Modifier.weight(1f))
            SettingsSection.LIBRARY -> LibrarySettingsContent(modifier = Modifier.weight(1f))
            SettingsSection.BACKUP_RESTORE -> BackupRestoreSettingsContent(modifier = Modifier.weight(1f))
            SettingsSection.STORAGE -> StorageSettingsContent(modifier = Modifier.weight(1f))
            SettingsSection.DIAGNOSTICS -> DiagnosticsSettingsContent(modifier = Modifier.weight(1f))
            SettingsSection.ABOUT -> AboutSettingsContent(modifier = Modifier.weight(1f))
        }
    }
}

