package com.movielink.app.core.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LibraryDao {

    @Query("SELECT * FROM library_items")
    fun observeAllLibraryItems(): Flow<List<LibraryItemEntity>>

    @Query("SELECT * FROM library_items WHERE mediaId = :mediaId LIMIT 1")
    suspend fun findItemById(mediaId: String): LibraryItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertLibraryItem(item: LibraryItemEntity)

    @Query("UPDATE library_items SET isInWatchlist = 0 WHERE mediaId = :mediaId")
    suspend fun removeFromWatchlist(mediaId: String)

    @Query("UPDATE library_items SET isInWatchlist = 0")
    suspend fun clearWatchlist()

    @Query("UPDATE library_items SET lastVisitedAtMs = 0 WHERE mediaId = :mediaId")
    suspend fun clearVisitTimestamp(mediaId: String)

    @Query("UPDATE library_items SET lastVisitedAtMs = 0")
    suspend fun clearAllVisitTimestamps()

    @Query("DELETE FROM library_items WHERE isInWatchlist = 0 AND isWatched = 0 AND lastVisitedAtMs = 0")
    suspend fun pruneOrphanedItems()

    @Query("SELECT * FROM playback_progress ORDER BY updatedAtMs DESC")
    fun observeContinueWatching(): Flow<List<PlaybackProgressEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPlaybackProgress(entry: PlaybackProgressEntity)

    @Query("DELETE FROM playback_progress WHERE mediaId = :mediaId")
    suspend fun deletePlaybackProgress(mediaId: String)

    @Query("DELETE FROM playback_progress")
    suspend fun clearContinueWatching()
}
