package com.movielink.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.movielink.app.core.adblock.AdBlockStore
import com.movielink.app.core.designsystem.MovieLinkTheme
import com.movielink.app.core.integrations.IntegrationsStore
import com.movielink.app.core.sources.WebsiteSourcesStore
import com.movielink.app.core.state.AppUiStateStore
import com.movielink.app.core.state.UserPreferencesStore
import com.movielink.app.ui.MovieLinkApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        WebsiteSourcesStore.init(applicationContext)
        AdBlockStore.init(applicationContext)
        IntegrationsStore.init(applicationContext)
        UserPreferencesStore.init(applicationContext)
        AppUiStateStore.init(applicationContext)

        setContent {
            val appearance by AppUiStateStore.appearance.collectAsStateWithLifecycle()
            MovieLinkTheme(
                backgroundColor = appearance.backgroundColor,
                accentColor = appearance.accentColor
            ) {
                MovieLinkApp()
            }
        }
    }
}
