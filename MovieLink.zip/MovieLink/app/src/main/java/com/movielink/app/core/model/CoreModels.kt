package com.movielink.app.core.model

enum class ProviderId(
    val id: String,
    val displayName: String,
    val shortLabel: String,
    val defaultBaseUrl: String
) {
    MOVIELINKBD("movielinkbd", "MovieLinkBD", "Website 1", "https://movielinkbd.tv/"),
    CINEFREAK("cinefreak", "CineFreak", "Website 2", "https://cinefreak.net/"),
    RTALLY("rtally", "Rtally", "Website 3", "https://rtally.lol/");

    companion object {
        fun fromId(id: String): ProviderId =
            entries.firstOrNull { it.id == id } ?: MOVIELINKBD
    }
}

enum class HomeHeroStyle(val id: String, val label: String) {
    CINEMATIC("cinematic", "Cinematic Hero"),
    POSTER_CAROUSEL("poster_carousel", "Poster Carousel")
}

enum class MediaKind {
    MOVIE,
    SERIES
}

enum class HomeCategoryFilter(val label: String) {
    ALL("All"),
    TV_SHOWS("TV Shows"),
    MOVIES("Movies")
}

data class MediaSummary(
    val id: String,
    val providerId: ProviderId,
    val title: String,
    val subtitle: String = "",
    val year: String = "",
    val runtime: String = "",
    val rating: String = "",
    val certification: String = "",
    val statusBadge: String = "",
    val languageTag: String = "",
    val genres: List<String> = emptyList(),
    val kind: MediaKind = MediaKind.MOVIE,
    val posterUrl: String = "",
    val backdropUrl: String = "",
    val accentHex: Long = 0xFF1F2937,
    val secondaryHex: Long = 0xFF09090B,
    val qualityBadge: String = "",
    val sourceUrl: String = "",
    val titleLogoUrl: String = ""
)

data class OttPlatformItem(
    val id: String,
    val name: String,
    val shortCode: String,
    val brandColorHex: Long,
    val contentColorHex: Long = 0xFFFFFFFF,
    val badge: String = ""
)

data class CatalogSection(
    val id: String,
    val title: String,
    val items: List<MediaSummary>,
    val hasViewAll: Boolean = true
)

data class ProviderCatalog(
    val providerId: ProviderId,
    val heroItems: List<MediaSummary>,
    val ottPlatforms: List<OttPlatformItem>,
    val categories: List<String>,
    val sections: List<CatalogSection>
)

data class MovieInfoField(
    val label: String,
    val value: String
)

data class DownloadSourceLink(
    val id: String,
    val label: String,
    val quality: String,
    val size: String,
    val formatTag: String = "",
    val isSubtitle: Boolean = false,
    val url: String = "",
    val watchUrl: String = "",
    val isZip: Boolean = false
)

data class CastMember(
    val name: String,
    val role: String,
    val avatarColorHex: Long,
    val profileImageUrl: String = ""
)

data class EpisodeItem(
    val number: Int,
    val title: String,
    val runtime: String,
    val isNew: Boolean = false,
    val downloads: List<DownloadSourceLink>
)

data class SeasonGroup(
    val seasonNumber: Int,
    val title: String,
    val episodes: List<EpisodeItem>
)

data class MediaDetail(
    val summary: MediaSummary,
    val overview: String,
    val screenshots: List<String>,
    val infoFields: List<MovieInfoField>,
    val sources: List<String>,
    val downloadLinks: List<DownloadSourceLink>,
    val cast: List<CastMember>,
    val seasons: List<SeasonGroup>,
    val recommendations: List<MediaSummary>,
    val trailerLabel: String = "Official Trailer",
    val watchEmbedUrl: String? = null,
    val trailerUrl: String? = null,
    val externalRatings: List<MovieInfoField> = emptyList(),
    val enrichedBy: List<String> = emptyList()
)

data class ContinueWatchingEntry(
    val media: MediaSummary,
    val episodeLabel: String? = null,
    val progressFraction: Float,
    val remainingLabel: String
)

data class VisitHistoryEntry(
    val media: MediaSummary,
    val visitedAtLabel: String
)

sealed interface ProviderSearchState {
    data object Idle : ProviderSearchState
    data object Loading : ProviderSearchState
    data class Success(val items: List<MediaSummary>) : ProviderSearchState
    data class Error(val message: String) : ProviderSearchState
}
