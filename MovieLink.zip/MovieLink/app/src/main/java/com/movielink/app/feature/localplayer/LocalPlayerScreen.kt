package com.movielink.app.feature.localplayer

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.movielink.app.core.designsystem.EmptyStateCard
import com.movielink.app.core.designsystem.FilterPill
import com.movielink.app.core.designsystem.LocalMovieLinkColors
import com.movielink.app.core.designsystem.MovieLinkRadius
import com.movielink.app.core.designsystem.ScreenTitleHeader
import com.movielink.app.core.localmedia.LocalLibraryTab
import com.movielink.app.core.localmedia.LocalSortOrder
import com.movielink.app.core.localmedia.LocalVideoItem

@Composable
fun LocalPlayerScreen(
    viewModel: LocalMediaViewModel,
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    val hasPermission by viewModel.hasStoragePermission.collectAsStateWithLifecycle()
    val isScanning by viewModel.isScanning.collectAsStateWithLifecycle()
    val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
    val sortOrder by viewModel.sortOrder.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedFolderPath by viewModel.selectedFolderPath.collectAsStateWithLifecycle()
    val videos by viewModel.filteredVideos.collectAsStateWithLifecycle()
    val folders by viewModel.folders.collectAsStateWithLifecycle()
    val records by viewModel.playbackRecords.collectAsStateWithLifecycle()

    var showSearch by remember { mutableStateOf(false) }
    var showSortMenu by remember { mutableStateOf(false) }
    var inspectedVideo by remember { mutableStateOf<LocalVideoItem?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.onPermissionUpdated()
    }

    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.openPickedDocument(uri)
        }
    }

    val recordMap = remember(records) { records.associateBy { it.uriString } }
    val currentFolderPath = selectedFolderPath

    BackHandler(enabled = activeTab == LocalLibraryTab.FOLDERS && currentFolderPath != null) {
        viewModel.openFolder(null)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background)
            .statusBarsPadding()
    ) {
        ScreenTitleHeader(
            title = "Local Media",
            subtitle = "MKV, MP4, WebM & AVI (device codec support)",
            trailing = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { showSearch = !showSearch }) {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = "Search local videos",
                            tint = if (showSearch) colors.accent else colors.textSecondary
                        )
                    }
                    Box {
                        IconButton(onClick = { showSortMenu = true }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.Sort,
                                contentDescription = "Sort videos",
                                tint = colors.textSecondary
                            )
                        }
                        DropdownMenu(
                            expanded = showSortMenu,
                            onDismissRequest = { showSortMenu = false },
                            modifier = Modifier.background(colors.surfaceElevated)
                        ) {
                            LocalSortOrder.entries.forEach { order ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = order.label,
                                            color = if (order == sortOrder) colors.accent else colors.textPrimary
                                        )
                                    },
                                    onClick = {
                                        viewModel.setSortOrder(order)
                                        showSortMenu = false
                                    }
                                )
                            }
                        }
                    }
                    IconButton(onClick = { documentPickerLauncher.launch(arrayOf("video/*")) }) {
                        Icon(
                            imageVector = Icons.Rounded.FolderOpen,
                            contentDescription = "Open file",
                            tint = colors.textSecondary
                        )
                    }
                    IconButton(onClick = { viewModel.refreshScan() }) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = "Rescan",
                            tint = colors.textSecondary
                        )
                    }
                }
            }
        )

        if (showSearch) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                singleLine = true,
                placeholder = { Text("Filter local videos or folders...", color = colors.textSecondary) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.setSearchQuery("") }) {
                            Icon(Icons.Rounded.Close, "Clear", tint = colors.textSecondary)
                        }
                    }
                },
                shape = RoundedCornerShape(MovieLinkRadius.Pill),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = colors.surface,
                    unfocusedContainerColor = colors.surface,
                    focusedBorderColor = colors.borderStrong,
                    unfocusedBorderColor = colors.borderSubtle,
                    focusedTextColor = colors.textPrimary,
                    unfocusedTextColor = colors.textPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            )
        }

        // Tabs: All Videos / Folders / Recently Played
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            LocalLibraryTab.entries.forEach { tab ->
                FilterPill(
                    label = tab.label,
                    selected = activeTab == tab,
                    onClick = { viewModel.selectTab(tab) }
                )
            }
        }

        if (!hasPermission && activeTab != LocalLibraryTab.RECENTLY_PLAYED) {
            Spacer(Modifier.height(6.dp))
            StoragePermissionCard(
                onGrantPermission = {
                    permissionLauncher.launch(viewModel.requiredPermissions())
                },
                onPickFile = {
                    documentPickerLauncher.launch(arrayOf("video/*"))
                }
            )
        } else if (isScanning) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = colors.accent)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(top = 6.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                when (activeTab) {
                    LocalLibraryTab.ALL_VIDEOS -> {
                        if (videos.isEmpty()) {
                            item {
                                EmptyStateCard(
                                    title = "No local videos found",
                                    description = "Tap the folder icon above to pick any video file directly, or tap refresh after adding videos to device storage.",
                                    icon = Icons.Rounded.VideoLibrary,
                                    modifier = Modifier.padding(horizontal = 16.dp)
                                )
                            }
                        } else {
                            items(videos, key = { it.id }) { video ->
                                LocalVideoRowCard(
                                    video = video,
                                    record = recordMap[video.contentUri.toString()],
                                    imageLoader = viewModel.videoImageLoader,
                                    onPlay = { viewModel.playVideo(video) },
                                    onInfo = { inspectedVideo = video }
                                )
                            }
                        }
                    }

                    LocalLibraryTab.FOLDERS -> {
                        if (currentFolderPath == null) {
                            if (folders.isEmpty()) {
                                item {
                                    EmptyStateCard(
                                        title = "No video folders found",
                                        description = "Scanned folders containing video files will appear here.",
                                        icon = Icons.Rounded.FolderOpen,
                                        modifier = Modifier.padding(horizontal = 16.dp)
                                    )
                                }
                            } else {
                                items(folders, key = { it.path }) { folder ->
                                    LocalFolderRowCard(
                                        folder = folder,
                                        onClick = { viewModel.openFolder(folder.path) }
                                    )
                                }
                            }
                        } else {
                            item(key = "folder_breadcrumb") {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.openFolder(null) }
                                        .padding(horizontal = 16.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                        contentDescription = "All folders",
                                        tint = colors.accent,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        text = "All Folders / ${currentFolderPath.substringAfterLast('/')}",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = colors.accent
                                    )
                                }
                            }
                            items(videos, key = { it.id }) { video ->
                                LocalVideoRowCard(
                                    video = video,
                                    record = recordMap[video.contentUri.toString()],
                                    imageLoader = viewModel.videoImageLoader,
                                    onPlay = { viewModel.playVideo(video) },
                                    onInfo = { inspectedVideo = video }
                                )
                            }
                        }
                    }

                    LocalLibraryTab.RECENTLY_PLAYED -> {
                        if (records.isEmpty()) {
                            item {
                                EmptyStateCard(
                                    title = "No recently played videos",
                                    description = "Local videos you watch will save playback position here for instant resume.",
                                    icon = Icons.Rounded.VideoLibrary,
                                    modifier = Modifier.padding(horizontal = 16.dp)
                                )
                            }
                        } else {
                            items(records, key = { it.uriString }) { record ->
                                RecentlyPlayedRowCard(
                                    record = record,
                                    imageLoader = viewModel.videoImageLoader,
                                    onResume = { viewModel.playRecord(record) },
                                    onRemove = { viewModel.removeHistoryRecord(record.uriString) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    inspectedVideo?.let { video ->
        VideoInfoDialog(
            video = video,
            record = recordMap[video.contentUri.toString()],
            onPlay = { fromStart -> viewModel.playVideo(video, forceFromStart = fromStart) },
            onDismiss = { inspectedVideo = null }
        )
    }
}
