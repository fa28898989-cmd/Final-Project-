package com.movielink.app.core.integrations

import com.movielink.app.core.model.CastMember
import com.movielink.app.core.model.MediaDetail
import com.movielink.app.core.model.MediaSummary
import com.movielink.app.core.model.MovieInfoField
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.supervisorScope
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Coordinates optional external metadata and artwork enrichment (TMDB, OMDb, MDBList, Better Poster).
 * Never runs when disabled, respects granular field toggles, deduplicates entries, and
 * preserves original website data cleanly.
 */
object MetadataEnrichmentEngine {

    private val detailCache = ConcurrentHashMap<String, MediaDetail>()
    private val summaryArtworkCache = ConcurrentHashMap<String, MediaSummary>()

    fun clearCache() {
        detailCache.clear()
        summaryArtworkCache.clear()
    }

    /**
     * Lightweight artwork/logo enrichment used when Poster & Artwork Enrichment is turned on
     * for hero banners. Safe no-op if disabled or no artwork integration is configured.
     */
    suspend fun enrichSummaryArtwork(summary: MediaSummary): MediaSummary {
        val settings = IntegrationsStore.settings.value
        if (!settings.artworkEnrichmentEnabled || !settings.hasAnyArtworkSource) {
            return summary
        }

        val cacheKey = "${summary.id}|${settings.tmdbEnabled}|${settings.betterPosterEnabled}|${settings.fields.posters}|${settings.fields.backdrops}|${settings.fields.titleLogos}|${settings.preferExternalOverWebsite}"
        summaryArtworkCache[cacheKey]?.let { return it }

        val tmdbPayload = if (settings.tmdbEnabled && settings.tmdbApiKey.isNotBlank()) {
            try {
                TmdbClient.lookup(settings.tmdbApiKey, summary.title, summary.year, summary.kind)
            } catch (_: Exception) {
                null
            }
        } else {
            null
        }

        val betterPosterUrl = if (settings.betterPosterEnabled && settings.betterPosterApiKey.isNotBlank()) {
            BetterPosterResolver.buildPosterUrl(
                baseUrl = settings.betterPosterBaseUrl,
                apiKey = settings.betterPosterApiKey,
                imdbId = tmdbPayload?.imdbId,
                tmdbId = tmdbPayload?.tmdbId,
                kind = summary.kind
            )
        } else {
            ""
        }

        val enrichedPoster = betterPosterUrl.ifBlank { tmdbPayload?.posterUrl.orEmpty() }
        val enrichedBackdrop = tmdbPayload?.backdropUrl.orEmpty()
        val enrichedLogo = tmdbPayload?.titleLogoUrl.orEmpty()

        val preferExternal = settings.preferExternalOverWebsite
        val f = settings.fields
        val updated = summary.copy(
            posterUrl = pickValue(summary.posterUrl, if (f.posters) enrichedPoster else "", preferExternal || betterPosterUrl.isNotBlank()),
            backdropUrl = pickValue(summary.backdropUrl, if (f.backdrops) enrichedBackdrop else "", preferExternal),
            titleLogoUrl = pickValue(summary.titleLogoUrl, if (f.titleLogos) enrichedLogo else "", preferExternal)
        )
        summaryArtworkCache[cacheKey] = updated
        return updated
    }

    /**
     * Enriches a website-provided MediaDetail according to Artwork vs Metadata switches
     * and per-field toggles without clobbering or duplicating website data.
     */
    suspend fun enrichDetail(detail: MediaDetail): MediaDetail = coroutineScope {
        val settings = IntegrationsStore.settings.value
        val wantArtwork = settings.artworkEnrichmentEnabled && settings.hasAnyArtworkSource
        val wantMetadata = settings.metadataEnrichmentEnabled && settings.hasAnyMetadataSource
        if (!wantArtwork && !wantMetadata) {
            return@coroutineScope detail
        }

        val cacheKey = buildString {
            append(detail.summary.id)
            append("|art=").append(wantArtwork)
            append("|meta=").append(wantMetadata)
            append("|pref=").append(settings.preferExternalOverWebsite)
            append("|tmdb=").append(settings.tmdbEnabled)
            append("|omdb=").append(settings.omdbEnabled)
            append("|mdb=").append(settings.mdblistEnabled)
            append("|bp=").append(settings.betterPosterEnabled)
            append("|f=").append(settings.fields.hashCode())
        }
        detailCache[cacheKey]?.let { return@coroutineScope it }

        val s = detail.summary

        // 1. Fetch TMDB first if enabled so IMDb ID & TMDB ID can improve OMDb / MDBList / Better Poster accuracy.
        val tmdbPayload = if (settings.tmdbEnabled && settings.tmdbApiKey.isNotBlank()) {
            try {
                TmdbClient.lookup(settings.tmdbApiKey, s.title, s.year, s.kind)
            } catch (_: Exception) {
                null
            }
        } else {
            null
        }

        // 2. Fetch OMDb and MDBList in parallel (gracefully isolated)
        val (omdbPayload, mdbPayload) = supervisorScope {
            val omdbJob = async {
                if (settings.omdbEnabled && settings.omdbApiKey.isNotBlank()) {
                    try {
                        OmdbClient.lookup(
                            apiKey = settings.omdbApiKey,
                            imdbId = tmdbPayload?.imdbId,
                            title = s.title,
                            year = s.year.ifBlank { tmdbPayload?.year.orEmpty() },
                            kind = s.kind
                        )
                    } catch (_: Exception) {
                        null
                    }
                } else {
                    null
                }
            }
            val mdbJob = async {
                if (settings.mdblistEnabled && settings.mdblistApiKey.isNotBlank()) {
                    try {
                        MdblistClient.lookup(
                            apiKey = settings.mdblistApiKey,
                            imdbId = tmdbPayload?.imdbId,
                            tmdbId = tmdbPayload?.tmdbId,
                            title = s.title,
                            year = s.year.ifBlank { tmdbPayload?.year.orEmpty() },
                            kind = s.kind
                        )
                    } catch (_: Exception) {
                        null
                    }
                } else {
                    null
                }
            }
            omdbJob.await() to mdbJob.await()
        }

        val resolvedImdb = tmdbPayload?.imdbId ?: omdbPayload?.imdbId ?: mdbPayload?.imdbId
        val resolvedTmdb = tmdbPayload?.tmdbId ?: mdbPayload?.tmdbId

        val betterPosterUrl = if (wantArtwork && settings.betterPosterEnabled && settings.betterPosterApiKey.isNotBlank()) {
            BetterPosterResolver.buildPosterUrl(
                baseUrl = settings.betterPosterBaseUrl,
                apiKey = settings.betterPosterApiKey,
                imdbId = resolvedImdb,
                tmdbId = resolvedTmdb,
                kind = s.kind
            )
        } else {
            ""
        }

        val payloads = listOfNotNull(tmdbPayload, omdbPayload, mdbPayload)
        if (payloads.isEmpty() && betterPosterUrl.isBlank()) {
            return@coroutineScope detail
        }

        val f = settings.fields
        val preferExternal = settings.preferExternalOverWebsite

        // Artwork enrichment
        val extPoster = listOf(betterPosterUrl, tmdbPayload?.posterUrl, omdbPayload?.posterUrl, mdbPayload?.posterUrl)
            .firstOrNull { !it.isNullOrBlank() }.orEmpty()
        val extBackdrop = listOf(tmdbPayload?.backdropUrl, mdbPayload?.backdropUrl)
            .firstOrNull { !it.isNullOrBlank() }.orEmpty()
        val extLogo = tmdbPayload?.titleLogoUrl.orEmpty()

        val nextPoster = if (wantArtwork && f.posters) {
            pickValue(s.posterUrl, extPoster, preferExternal || betterPosterUrl.isNotBlank())
        } else s.posterUrl

        val nextBackdrop = if (wantArtwork && f.backdrops) {
            pickValue(s.backdropUrl, extBackdrop, preferExternal)
        } else s.backdropUrl

        val nextLogo = if (wantArtwork && f.titleLogos) {
            pickValue(s.titleLogoUrl, extLogo, preferExternal)
        } else s.titleLogoUrl

        // Metadata enrichment
        val extOverview = payloads.firstNotNullOfOrNull { it.overview.takeIf { o -> o.isNotBlank() } }.orEmpty()
        val nextOverview = if (wantMetadata && f.overview) {
            pickValue(detail.overview, extOverview, preferExternal)
        } else detail.overview

        val extGenres = payloads.flatMap { it.genres }
        val nextGenres = if (wantMetadata && f.genres) {
            mergeUniqueStrings(s.genres, extGenres, preferExternal)
        } else s.genres

        val extYear = payloads.firstNotNullOfOrNull { it.year.takeIf { y -> y.isNotBlank() } }.orEmpty()
        val nextYear = if (wantMetadata && f.releaseDates) {
            pickValue(s.year, extYear, preferExternal)
        } else s.year

        val extRuntime = payloads.firstNotNullOfOrNull { it.runtime.takeIf { r -> r.isNotBlank() } }.orEmpty()
        val nextRuntime = if (wantMetadata && f.runtime) {
            pickValue(s.runtime, extRuntime, preferExternal)
        } else s.runtime

        val extRating = omdbPayload?.primaryRating?.takeIf { it.isNotBlank() }
            ?: tmdbPayload?.primaryRating?.takeIf { it.isNotBlank() }
            ?: ""
        val nextPrimaryRating = if (wantMetadata && f.ratings) {
            pickValue(s.rating, extRating, preferExternal)
        } else s.rating

        val extCert = payloads.firstNotNullOfOrNull { it.certification.takeIf { c -> c.isNotBlank() } }.orEmpty()
        val nextCert = if (wantMetadata) {
            pickValue(s.certification, extCert, preferExternal)
        } else s.certification

        val mergedRatings = if (wantMetadata && f.ratings) {
            dedupeFields(payloads.flatMap { it.extraRatings })
        } else detail.externalRatings

        val candidateInfo = buildList {
            payloads.forEach { p ->
                p.extraInfoFields.forEach { field ->
                    val norm = field.label.lowercase(Locale.US)
                    val allowed = when {
                        norm.contains("release") -> f.releaseDates
                        norm.contains("runtime") -> f.runtime
                        else -> true
                    }
                    if (allowed) add(field)
                }
            }
        }
        val mergedInfoFields = if (wantMetadata) {
            mergeInfoFields(detail.infoFields, candidateInfo, preferExternal)
        } else detail.infoFields

        val nextCast = if (wantMetadata && f.cast) {
            mergeCast(detail.cast, payloads.flatMap { it.cast })
        } else detail.cast

        val attributedSources = buildList {
            if (wantArtwork && betterPosterUrl.isNotBlank()) add("Better Poster")
            payloads.forEach { add(it.sourceName) }
        }.distinct()

        val enrichedSummary = s.copy(
            posterUrl = nextPoster,
            backdropUrl = nextBackdrop,
            titleLogoUrl = nextLogo,
            genres = nextGenres,
            year = nextYear,
            runtime = nextRuntime,
            rating = nextPrimaryRating,
            certification = nextCert
        )

        val result = detail.copy(
            summary = enrichedSummary,
            overview = nextOverview,
            infoFields = mergedInfoFields,
            cast = nextCast,
            externalRatings = mergedRatings,
            enrichedBy = attributedSources
        )
        detailCache[cacheKey] = result
        result
    }

    private fun pickValue(existing: String, incoming: String, preferExternal: Boolean): String {
        if (incoming.isBlank()) return existing
        if (existing.isBlank()) return incoming
        return if (preferExternal) incoming else existing
    }

    private fun mergeUniqueStrings(
        existing: List<String>,
        incoming: List<String>,
        preferExternal: Boolean
    ): List<String> {
        val base = if (preferExternal && incoming.isNotEmpty()) incoming + existing else existing + incoming
        val seen = LinkedHashSet<String>()
        val out = mutableListOf<String>()
        for (raw in base) {
            val clean = raw.trim()
            val key = clean.lowercase(Locale.US)
            if (clean.isNotBlank() && seen.add(key)) {
                out.add(clean)
            }
        }
        return out
    }

    private fun dedupeFields(fields: List<MovieInfoField>): List<MovieInfoField> {
        val seen = LinkedHashSet<String>()
        val out = mutableListOf<MovieInfoField>()
        for (f in fields) {
            val key = f.label.trim().lowercase(Locale.US)
            if (f.label.isNotBlank() && f.value.isNotBlank() && seen.add(key)) {
                out.add(f)
            }
        }
        return out
    }

    private fun mergeInfoFields(
        existing: List<MovieInfoField>,
        incoming: List<MovieInfoField>,
        preferExternal: Boolean
    ): List<MovieInfoField> {
        val ordered = LinkedHashMap<String, MovieInfoField>()
        fun normalizeKey(label: String): String {
            val low = label.trim().lowercase(Locale.US)
            return when {
                low.contains("release") -> "release_date"
                low.contains("runtime") || low.contains("duration") -> "runtime"
                low.contains("genre") -> "genres"
                else -> low
            }
        }
        if (preferExternal) {
            incoming.forEach { ordered.putIfAbsent(normalizeKey(it.label), it) }
            existing.forEach { ordered.putIfAbsent(normalizeKey(it.label), it) }
        } else {
            existing.forEach { ordered.putIfAbsent(normalizeKey(it.label), it) }
            incoming.forEach { ordered.putIfAbsent(normalizeKey(it.label), it) }
        }
        return ordered.values.toList()
    }

    private fun mergeCast(
        existing: List<CastMember>,
        incoming: List<CastMember>
    ): List<CastMember> {
        val map = LinkedHashMap<String, CastMember>()
        existing.forEach { member ->
            map[member.name.trim().lowercase(Locale.US)] = member
        }
        incoming.forEach { member ->
            val key = member.name.trim().lowercase(Locale.US)
            val prev = map[key]
            if (prev == null) {
                map[key] = member
            } else if (prev.profileImageUrl.isBlank() && member.profileImageUrl.isNotBlank()) {
                map[key] = prev.copy(profileImageUrl = member.profileImageUrl)
            }
        }
        return map.values.take(18).toList()
    }
}
