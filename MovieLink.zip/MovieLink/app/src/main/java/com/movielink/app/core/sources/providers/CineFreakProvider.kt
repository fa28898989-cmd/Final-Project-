package com.movielink.app.core.sources.providers

import com.movielink.app.core.adblock.AdBlockerEngine
import com.movielink.app.core.model.CatalogSection
import com.movielink.app.core.model.DownloadSourceLink
import com.movielink.app.core.model.MediaDetail
import com.movielink.app.core.model.MediaKind
import com.movielink.app.core.model.MediaSummary
import com.movielink.app.core.model.MovieInfoField
import com.movielink.app.core.model.OttPlatformItem
import com.movielink.app.core.model.ProviderCatalog
import com.movielink.app.core.model.ProviderId
import com.movielink.app.core.network.MovieLinkHttpClient
import com.movielink.app.core.sources.MediaSourceProvider
import com.movielink.app.core.sources.ProviderCapabilities
import com.movielink.app.core.sources.WebsiteSourcesStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLEncoder

/**
 * Website 2 — CineFreak live Jsoup/OkHttp parser matching cinefreak.net's actual DOM
 * while ignoring hidden aria-hidden decoy ad links.
 */
class CineFreakProvider : MediaSourceProvider {
    override val providerId: ProviderId = ProviderId.CINEFREAK

    override val capabilities = ProviderCapabilities(
        supportsHomeCatalog = true,
        supportsOttFilter = true,
        supportsSeries = true,
        supportsDownloads = true,
        supportsDirectStreams = true
    )

    override suspend fun fetchHomeCatalog(baseUrl: String): Result<ProviderCatalog> = withContext(Dispatchers.IO) {
        runCatching {
            val cfg = WebsiteSourcesStore.configFor(providerId)
            val fetch = MovieLinkHttpClient.fetchHtml(baseUrl, providerId, cfg.timeoutSeconds, cfg.customUserAgent)
            val doc = Jsoup.parse(fetch.html, fetch.finalUrl)
            parseHomeDocument(doc, fetch.finalUrl)
        }
    }

    override suspend fun search(baseUrl: String, query: String): Result<List<MediaSummary>> = withContext(Dispatchers.IO) {
        runCatching {
            val cfg = WebsiteSourcesStore.configFor(providerId)
            val encoded = URLEncoder.encode(query.trim(), "UTF-8")
            val candidateUrls = listOf(
                "${baseUrl.trimEnd('/')}/?s=$encoded",
                "${baseUrl.trimEnd('/')}/search/$encoded",
                "${baseUrl.trimEnd('/')}/search?q=$encoded"
            )
            var results = emptyList<MediaSummary>()
            for (url in candidateUrls) {
                try {
                    val fetch = MovieLinkHttpClient.fetchHtml(url, providerId, cfg.timeoutSeconds, cfg.customUserAgent)
                    val doc = Jsoup.parse(fetch.html, fetch.finalUrl)
                    results = doc.select("a.movie-card")
                        .mapNotNull { parseCard(it, fetch.finalUrl) }
                        .distinctBy { it.id }
                    if (results.isNotEmpty()) break
                } catch (_: Exception) {
                }
            }
            results
        }
    }

    override suspend fun fetchDetails(baseUrl: String, mediaId: String): Result<MediaDetail> = withContext(Dispatchers.IO) {
        runCatching {
            val cfg = WebsiteSourcesStore.configFor(providerId)
            val targetUrl = if (mediaId.startsWith("http", true)) {
                mediaId
            } else {
                ProviderParsingUtils.resolveUrl(baseUrl, mediaId)
            }
            val fetch = MovieLinkHttpClient.fetchHtml(targetUrl, providerId, cfg.timeoutSeconds, cfg.customUserAgent)
            val doc = Jsoup.parse(fetch.html, fetch.finalUrl)
            parseDetailDocument(doc, fetch.finalUrl)
        }
    }

    private fun parseHomeDocument(doc: Document, finalUrl: String): ProviderCatalog {
        val allCards = doc.select("a.movie-card")
            .mapNotNull { parseCard(it, finalUrl) }
            .distinctBy { it.id }

        val sections = mutableListOf<CatalogSection>()
        val grids = doc.select(".card-grid")
        grids.forEachIndexed { idx, grid ->
            val cards = grid.select("a.movie-card")
                .mapNotNull { parseCard(it, finalUrl) }
                .distinctBy { it.id }
            if (cards.isNotEmpty()) {
                val heading = grid.previousElementSibling()?.text()?.trim()
                    ?.takeIf { it.isNotBlank() && it.length <= 40 }
                    ?: if (idx == 0) "Trending & Recently Updated" else "Latest Uploads"
                sections.add(CatalogSection(id = "cf_grid_$idx", title = heading, items = cards))
            }
        }

        if (sections.isEmpty() && allCards.isNotEmpty()) {
            sections.add(CatalogSection(id = "cf_latest", title = "Recently Updated", items = allCards))
        }

        val ottPlatforms = doc.select("a.cf-ott-item").mapNotNull { a ->
            val name = a.selectFirst(".cf-ott-name")?.text()?.trim().orEmpty()
            if (name.isBlank()) return@mapNotNull null
            val mark = a.selectFirst(".cf-ott-mark")?.text()?.trim().orEmpty()
            val brandStr = Regex("""--cf-brand\s*:\s*(#[0-9a-fA-F]{3,8})""")
                .find(a.attr("style"))?.groupValues?.getOrNull(1)
            ProviderParsingUtils.buildOttItem(
                id = name.lowercase().replace(" ", "_"),
                name = name,
                shortCode = mark.ifBlank { name.take(2).uppercase() },
                brandColorHex = ProviderParsingUtils.parseHexColor(brandStr, 0xFF1F2937)
            )
        }.distinctBy { it.id }

        val categories = doc.select(".cf-genre-pill").mapNotNull { pill ->
            pill.text().trim().takeIf { it.isNotBlank() && it.length <= 28 }
        }.distinct().take(24)

        val heroItems = allCards.take(8)
        return ProviderCatalog(
            providerId = providerId,
            heroItems = heroItems,
            ottPlatforms = ottPlatforms,
            categories = categories,
            sections = sections
        )
    }

    private fun parseCard(card: Element, baseUrl: String): MediaSummary? {
        val href = card.attr("href").trim()
        val absUrl = ProviderParsingUtils.resolveUrl(baseUrl, href)
        if (absUrl.isBlank() || AdBlockerEngine.shouldBlockUrl(absUrl, providerId)) return null

        val ariaLabel = card.attr("aria-label").trim()
        val nfTitle = card.selectFirst(".nf-title, .movie-title, h3, h4")?.text()?.trim().orEmpty()
        val img = card.selectFirst("img")
        val rawTitle = nfTitle.ifBlank {
            ariaLabel.substringBefore("Hindi").substringBefore("Dual Audio")
                .substringBefore("Full Movie").substringBefore("details").trim()
        }.ifBlank { img?.attr("alt")?.substringBefore("Movie Poster")?.trim().orEmpty() }
        if (rawTitle.isBlank()) return null

        val (cleanTitle, year) = ProviderParsingUtils.cleanTitleYearSplit(rawTitle)

        val posterRaw = img?.attr("data-src")?.trim()?.takeIf { it.isNotBlank() && !it.startsWith("data:") }
            ?: img?.attr("src")?.trim()?.takeIf { it.isNotBlank() && !it.startsWith("data:") }
            ?: ""
        val posterUrl = if (posterRaw.isNotEmpty()) ProviderParsingUtils.resolveUrl(baseUrl, posterRaw) else ""

        val quality = card.selectFirst(".movie-card-format, .nf-b-ep, .nf-b")?.text()?.trim().orEmpty()
        val langTag = when {
            ariaLabel.contains("Dual Audio", true) -> "Dual Audio"
            ariaLabel.contains("Hindi Dubbed", true) -> "Hindi Dubbed"
            ariaLabel.contains("Bangla", true) -> "Bangla"
            ariaLabel.contains("Tamil", true) -> "Tamil"
            ariaLabel.contains("English", true) -> "English"
            else -> ""
        }
        val isSeries = ariaLabel.contains("Season", true) ||
            absUrl.contains("series", true) ||
            absUrl.contains("season", true) ||
            card.selectFirst(".nf-b-ep") != null

        return MediaSummary(
            id = absUrl,
            providerId = providerId,
            title = cleanTitle,
            year = year,
            languageTag = langTag,
            kind = if (isSeries) MediaKind.SERIES else MediaKind.MOVIE,
            posterUrl = posterUrl,
            backdropUrl = posterUrl,
            qualityBadge = quality,
            sourceUrl = absUrl
        )
    }

    private fun parseDetailDocument(doc: Document, finalUrl: String): MediaDetail {
        val rawMainTitle = doc.selectFirst("h1 .pt-main")?.text()?.trim()
            ?: doc.selectFirst("h1")?.text()?.trim()
            ?: doc.title().substringBefore("|").trim()
        val subLine = doc.selectFirst("h1 .pt-sub")?.text()?.trim().orEmpty()
        val (cleanTitle, year) = ProviderParsingUtils.cleanTitleYearSplit(rawMainTitle)

        val posterRaw = doc.selectFirst("meta[property=og:image]")?.attr("content")?.trim()
            ?: doc.selectFirst(".poster img, .movie-poster img")?.attr("src")?.trim()
            ?: ""
        val posterUrl = if (posterRaw.isNotBlank() && !posterRaw.startsWith("data:")) {
            ProviderParsingUtils.resolveUrl(finalUrl, posterRaw)
        } else ""

        val screenshots = doc.select(".screenshot-container img.screenshot-image, .screenshot-container img")
            .mapNotNull { img ->
                val raw = img.attr("data-src").trim().ifBlank { img.attr("src").trim() }
                if (raw.isNotBlank() && !raw.startsWith("data:")) {
                    ProviderParsingUtils.resolveUrl(finalUrl, raw)
                } else null
            }.distinct()

        val infoFields = mutableListOf<MovieInfoField>()
        doc.select(".metadata-grid-wrapper .meta-item-box").forEach { box ->
            val label = box.selectFirst(".meta-tag-label")?.text()?.trim().orEmpty()
            val value = box.text().removePrefix(label).trim().removePrefix(":").trim()
            if (label.isNotBlank() && value.isNotBlank()) {
                infoFields.add(MovieInfoField(label, value))
            }
        }

        val genres = doc.select(".meta-badge.badge-genre").mapNotNull {
            it.text().trim().takeIf { t -> t.isNotBlank() }
        }.distinct()

        val overview = doc.selectFirst(".storyline, .synopsis, .entry-content > p")
            ?.text()?.trim().orEmpty().ifBlank { subLine }

        // Extract links from .download-links-div strictly skipping [aria-hidden=true] decoy wrappers
        val downloadLinks = mutableListOf<DownloadSourceLink>()
        val seenUrls = hashSetOf<String>()
        var primaryWatchUrl: String? = null

        val dlContainer = doc.selectFirst(".download-links-div")
        if (dlContainer != null) {
            dlContainer.select("a.dlbtn[href]").forEachIndexed { idx, a ->
                if (a.parents().any { it.attr("aria-hidden") == "true" }) return@forEachIndexed
                val absUrl = ProviderParsingUtils.resolveUrl(finalUrl, a.attr("href"))
                if (absUrl.isBlank() || AdBlockerEngine.shouldBlockUrl(absUrl, providerId)) return@forEachIndexed

                val headingTitle = a.parent()?.previousElementSibling()?.takeIf {
                    it.tagName().equals("h4", true) || it.hasClass("movie-title")
                }?.text()?.trim().orEmpty()

                val isWatch = a.hasClass("dlbtn-watch")
                if (isWatch && primaryWatchUrl == null) {
                    primaryWatchUrl = absUrl
                }
                val quality = a.attr("data-hq").ifBlank {
                    Regex("""(2160p|4K|1080p|720p|480p)""", RegexOption.IGNORE_CASE)
                        .find(headingTitle)?.groupValues?.getOrNull(1)?.uppercase() ?: "HD"
                }
                val size = a.attr("data-hs").ifBlank {
                    Regex("""\[([^\]]*(?:MB|GB)[^\]]*)]""", RegexOption.IGNORE_CASE)
                        .find(headingTitle)?.groupValues?.getOrNull(1).orEmpty()
                }
                val label = headingTitle.ifBlank { a.text().trim().ifBlank { "Download $quality" } }
                if (seenUrls.add(absUrl)) {
                    downloadLinks.add(
                        DownloadSourceLink(
                            id = "cf_dl_$idx",
                            label = label,
                            quality = quality,
                            size = size,
                            url = absUrl,
                            watchUrl = if (isWatch) absUrl else ""
                        )
                    )
                }

                // Also expose alternate variant URL (e.g. non-HEVC fallback) if present
                val altHref = a.attr("data-alt").trim()
                if (altHref.isNotBlank()) {
                    val altAbs = ProviderParsingUtils.resolveUrl(finalUrl, altHref)
                    if (altAbs.isNotBlank() && !AdBlockerEngine.shouldBlockUrl(altAbs, providerId) && seenUrls.add(altAbs)) {
                        val aq = a.attr("data-aq").ifBlank { quality }
                        val aSize = a.attr("data-as").ifBlank { size }
                        downloadLinks.add(
                            DownloadSourceLink(
                                id = "cf_dl_alt_$idx",
                                label = "$aq Alternate Server" + if (aSize.isNotBlank()) " [$aSize]" else "",
                                quality = aq,
                                size = aSize,
                                url = altAbs
                            )
                        )
                    }
                }
            }
        }

        val related = doc.select("a.movie-card")
            .mapNotNull { parseCard(it, finalUrl) }
            .filterNot { it.id == finalUrl }
            .distinctBy { it.id }
            .take(12)

        val summary = MediaSummary(
            id = finalUrl,
            providerId = providerId,
            title = cleanTitle,
            subtitle = subLine,
            year = year,
            genres = genres,
            kind = if (finalUrl.contains("series", true) || subLine.contains("Season", true)) {
                MediaKind.SERIES
            } else {
                MediaKind.MOVIE
            },
            posterUrl = posterUrl,
            backdropUrl = screenshots.firstOrNull() ?: posterUrl,
            sourceUrl = finalUrl
        )

        val sources = buildList {
            if (primaryWatchUrl != null) add("Watch Online (${providerId.displayName})")
            if (downloadLinks.isNotEmpty()) add("CineCloud Downloads (${downloadLinks.size})")
        }.ifEmpty { listOf("Website Page") }

        return MediaDetail(
            summary = summary,
            overview = overview,
            screenshots = screenshots,
            infoFields = infoFields,
            sources = sources,
            downloadLinks = downloadLinks,
            cast = emptyList(),
            seasons = emptyList(),
            recommendations = related,
            watchEmbedUrl = primaryWatchUrl
        )
    }
}
