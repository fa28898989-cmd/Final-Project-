package com.movielink.app.feature.details

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import com.movielink.app.core.designsystem.FilterPill
import com.movielink.app.core.designsystem.LocalMovieLinkColors
import com.movielink.app.core.designsystem.MediaArtwork
import com.movielink.app.core.designsystem.MovieLinkCard
import com.movielink.app.core.designsystem.MovieLinkRadius
import com.movielink.app.core.designsystem.SubtleHairlineDivider
import com.movielink.app.core.model.CastMember
import com.movielink.app.core.model.DownloadSourceLink
import com.movielink.app.core.model.MediaSummary
import com.movielink.app.core.model.MovieInfoField
import com.movielink.app.core.model.SeasonGroup
import com.movielink.app.feature.home.CatalogPosterCard

@Composable
fun ScreenshotsPreviewCard(
    summary: MediaSummary,
    screenshotCount: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    previewImageUrl: String? = null
) {
    val colors = LocalMovieLinkColors.current
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = "Screenshots",
            style = MaterialTheme.typography.titleLarge,
            color = colors.textPrimary
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(190.dp)
                .clip(RoundedCornerShape(MovieLinkRadius.Md))
                .border(1.dp, colors.borderSubtle, RoundedCornerShape(MovieLinkRadius.Md))
                .clickable(onClick = onClick)
        ) {
            val hasHttpPreview = !previewImageUrl.isNullOrBlank() &&
                (previewImageUrl.startsWith("http://", ignoreCase = true) ||
                    previewImageUrl.startsWith("https://", ignoreCase = true))
            if (hasHttpPreview) {
                SubcomposeAsyncImage(
                    model = previewImageUrl,
                    contentDescription = "${summary.title} screenshot preview",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                    loading = {
                        MediaArtwork(
                            media = summary,
                            isBackdrop = true,
                            showEmbeddedTitle = false,
                            modifier = Modifier.fillMaxSize()
                        )
                    },
                    error = {
                        MediaArtwork(
                            media = summary,
                            isBackdrop = true,
                            showEmbeddedTitle = false,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                )
            } else {
                MediaArtwork(
                    media = summary,
                    isBackdrop = true,
                    showEmbeddedTitle = false,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            0.2f to Color.Transparent,
                            1f to Color.Black.copy(alpha = 0.85f)
                        )
                    )
            )
            Row(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PhotoLibrary,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "Tap to view all screenshots",
                        style = MaterialTheme.typography.labelLarge,
                        color = Color.White
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(MovieLinkRadius.Xs))
                        .background(Color.White)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "$screenshotCount Photos",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }
            }
        }
    }
}

@Composable
fun MovieDetailsTableSection(
    fields: List<MovieInfoField>,
    modifier: Modifier = Modifier
) {
    if (fields.isEmpty()) return
    val colors = LocalMovieLinkColors.current
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "Movie Details",
            style = MaterialTheme.typography.titleLarge,
            color = colors.textPrimary
        )

        Column(modifier = Modifier.fillMaxWidth()) {
            fields.forEachIndexed { index, field ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = field.label,
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.textSecondary
                    )
                    Text(
                        text = field.value,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.textPrimary
                    )
                }
                if (index < fields.lastIndex) {
                    SubtleHairlineDivider()
                }
            }
        }
    }
}

@Composable
fun DownloadLinksSection(
    links: List<DownloadSourceLink>,
    onLinkClick: (DownloadSourceLink) -> Unit,
    modifier: Modifier = Modifier
) {
    if (links.isEmpty()) return
    val colors = LocalMovieLinkColors.current
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = "Download Links",
            style = MaterialTheme.typography.titleLarge,
            color = colors.textPrimary
        )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            links.forEach { link ->
                MovieLinkCard(
                    cornerRadius = MovieLinkRadius.Sm,
                    onClick = { onLinkClick(link) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Download,
                            contentDescription = null,
                            tint = colors.textSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(
                            text = link.label,
                            style = MaterialTheme.typography.titleSmall,
                            color = colors.textPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = "Open",
                            style = MaterialTheme.typography.labelLarge,
                            color = colors.textSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CastRailSection(
    cast: List<CastMember>,
    modifier: Modifier = Modifier
) {
    if (cast.isEmpty()) return
    val colors = LocalMovieLinkColors.current
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Cast",
            style = MaterialTheme.typography.titleLarge,
            color = colors.textPrimary,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(cast, key = { "${it.name}_${it.role}" }) { member ->
                Column(
                    modifier = Modifier.width(80.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(66.dp)
                            .clip(CircleShape)
                            .background(Color(member.avatarColorHex))
                            .border(1.dp, colors.borderStrong, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        val initials = member.name
                            .split(" ")
                            .take(2)
                            .mapNotNull { it.firstOrNull()?.uppercaseChar() }
                            .joinToString("")
                        val hasPhoto = member.profileImageUrl.startsWith("http", ignoreCase = true)
                        if (hasPhoto) {
                            SubcomposeAsyncImage(
                                model = member.profileImageUrl,
                                contentDescription = member.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize(),
                                loading = {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = initials,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                },
                                error = {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = initials,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                }
                            )
                        } else {
                            Text(
                                text = initials,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                    Text(
                        text = member.name,
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.textPrimary,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = member.role,
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.textSecondary,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun SeasonsAndEpisodesSection(
    seasons: List<SeasonGroup>,
    onPlayEpisode: (String) -> Unit,
    onDownloadEpisode: (DownloadSourceLink) -> Unit,
    modifier: Modifier = Modifier
) {
    if (seasons.isEmpty()) return
    val colors = LocalMovieLinkColors.current
    var selectedSeasonIndex by remember(seasons) { mutableIntStateOf(0) }
    val activeSeason = seasons.getOrElse(selectedSeasonIndex) { seasons.first() }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Seasons & Episodes",
            style = MaterialTheme.typography.titleLarge,
            color = colors.textPrimary
        )

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(seasons.size) { index ->
                val season = seasons[index]
                FilterPill(
                    label = season.title,
                    selected = index == selectedSeasonIndex,
                    onClick = { selectedSeasonIndex = index }
                )
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            activeSeason.episodes.forEach { episode ->
                MovieLinkCard(cornerRadius = MovieLinkRadius.Sm) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onPlayEpisode("S${activeSeason.seasonNumber} · E${episode.number}") }
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(colors.surfaceElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.PlayArrow,
                                contentDescription = null,
                                tint = colors.textPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = episode.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = colors.textPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (episode.isNew) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(colors.primaryButtonBg)
                                            .padding(horizontal = 5.dp, vertical = 1.dp)
                                    ) {
                                        Text(
                                            text = "NEW",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = colors.primaryButtonContent
                                        )
                                    }
                                }
                            }
                            Text(
                                text = "${episode.runtime}  •  ${episode.downloads.size} download links",
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textSecondary
                            )
                        }
                        episode.downloads.firstOrNull()?.let { primaryDl ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(MovieLinkRadius.Xs))
                                    .background(colors.surfaceElevated)
                                    .clickable { onDownloadEpisode(primaryDl) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = primaryDl.quality,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = colors.textPrimary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MoreLikeThisSection(
    items: List<MediaSummary>,
    onMediaClick: (MediaSummary) -> Unit,
    modifier: Modifier = Modifier
) {
    if (items.isEmpty()) return
    val colors = LocalMovieLinkColors.current
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "More Like This",
            style = MaterialTheme.typography.titleLarge,
            color = colors.textPrimary,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(items, key = { it.id }) { media ->
                CatalogPosterCard(
                    media = media,
                    showRatingBadge = true,
                    onClick = { onMediaClick(media) },
                    modifier = Modifier.width(114.dp)
                )
            }
        }
    }
}
