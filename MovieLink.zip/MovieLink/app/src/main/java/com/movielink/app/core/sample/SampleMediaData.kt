package com.movielink.app.core.sample

import com.movielink.app.core.model.CastMember
import com.movielink.app.core.model.CatalogSection
import com.movielink.app.core.model.ContinueWatchingEntry
import com.movielink.app.core.model.DownloadSourceLink
import com.movielink.app.core.model.EpisodeItem
import com.movielink.app.core.model.MediaDetail
import com.movielink.app.core.model.MediaKind
import com.movielink.app.core.model.MediaSummary
import com.movielink.app.core.model.MovieInfoField
import com.movielink.app.core.model.OttPlatformItem
import com.movielink.app.core.model.ProviderCatalog
import com.movielink.app.core.model.ProviderId
import com.movielink.app.core.model.SeasonGroup
import com.movielink.app.core.model.VisitHistoryEntry

object SampleMediaData {

    val defaultOttPlatforms = listOf(
        OttPlatformItem("netflix", "Netflix", "N", 0xFF141414, 0xFFE50914, "NEW"),
        OttPlatformItem("prime", "Prime", "prime\nvideo", 0xFF00A8E1, 0xFFFFFFFF),
        OttPlatformItem("jiohotstar", "JioHotstar", "✦", 0xFF1B1464, 0xFF38BDF8),
        OttPlatformItem("sonyliv", "SonyLiv", "SONY\nliv", 0xFF311042, 0xFFFACC15),
        OttPlatformItem("zee5", "Zee5", "ZEE5", 0xFF111827, 0xFFE879F9)
    )

    val allMedia: List<MediaSummary> = listOf(
        MediaSummary(
            id = "mlbd-resident-evil",
            providerId = ProviderId.MOVIELINKBD,
            title = "RESIDENT EVIL",
            subtitle = "Survival Horror",
            year = "2026",
            runtime = "1h 34m",
            rating = "7.5",
            certification = "R",
            statusBadge = "RELEASED",
            languageTag = "EN",
            genres = listOf("Horror", "Action", "Sci-Fi"),
            kind = MediaKind.MOVIE,
            accentHex = 0xFF7F1D1D,
            secondaryHex = 0xFF1C1917,
            qualityBadge = "4K"
        ),
        MediaSummary(
            id = "mlbd-jailer-2",
            providerId = ProviderId.MOVIELINKBD,
            title = "JAILER 2",
            subtitle = "Tiger Muthuvel Pandian Returns",
            year = "2026",
            runtime = "2h 45m",
            rating = "7.7",
            certification = "NR",
            statusBadge = "Released",
            languageTag = "Dual [Hindi–Tamil]",
            genres = listOf("Action", "Comedy"),
            kind = MediaKind.MOVIE,
            accentHex = 0xFF991B1B,
            secondaryHex = 0xFF18181B,
            qualityBadge = "4K-HD"
        ),
        MediaSummary(
            id = "mlbd-inkaar",
            providerId = ProviderId.MOVIELINKBD,
            title = "Inkaar (2013)",
            subtitle = "Hindi Drama",
            year = "2013",
            runtime = "2h 10m",
            rating = "5.4",
            certification = "UA",
            statusBadge = "Released",
            languageTag = "Hindi",
            genres = listOf("Drama", "Romance"),
            kind = MediaKind.MOVIE,
            accentHex = 0xFF1E3A5F,
            secondaryHex = 0xFF0F172A,
            qualityBadge = "1080p"
        ),
        MediaSummary(
            id = "mlbd-operation-mole",
            providerId = ProviderId.MOVIELINKBD,
            title = "O.M: Operation Mole",
            subtitle = "Covert Thriller",
            year = "2026",
            runtime = "2h 18m",
            rating = "7.9",
            certification = "UA",
            statusBadge = "Released",
            languageTag = "Hindi · Bangla",
            genres = listOf("Thriller", "Action"),
            kind = MediaKind.MOVIE,
            accentHex = 0xFF78350F,
            secondaryHex = 0xFF14110F,
            qualityBadge = "1080p"
        ),
        MediaSummary(
            id = "mlbd-nine-to-six",
            providerId = ProviderId.MOVIELINKBD,
            title = "Nine to Six (2026)",
            subtitle = "Workplace K-Drama",
            year = "2026",
            runtime = "55m / ep",
            rating = "8.1",
            certification = "TV-14",
            statusBadge = "Ongoing",
            languageTag = "Korean · Eng Sub",
            genres = listOf("Drama", "Comedy"),
            kind = MediaKind.SERIES,
            accentHex = 0xFF334155,
            secondaryHex = 0xFF0F172A,
            qualityBadge = "1080p"
        ),
        MediaSummary(
            id = "mlbd-remarried-empress",
            providerId = ProviderId.MOVIELINKBD,
            title = "The Remarried Empress",
            subtitle = "Royal Fantasy Series",
            year = "2026",
            runtime = "1h 02m / ep",
            rating = "8.6",
            certification = "TV-14",
            statusBadge = "Ongoing",
            languageTag = "Multi Audio",
            genres = listOf("Fantasy", "Romance", "Drama"),
            kind = MediaKind.SERIES,
            accentHex = 0xFF831843,
            secondaryHex = 0xFF1F1220,
            qualityBadge = "4K"
        ),
        MediaSummary(
            id = "mlbd-inception",
            providerId = ProviderId.MOVIELINKBD,
            title = "Inception (2010)",
            subtitle = "Mind-Bending Sci-Fi",
            year = "2010",
            runtime = "2h 28m",
            rating = "8.8",
            certification = "PG-13",
            statusBadge = "Released",
            languageTag = "Dual [Hindi–English]",
            genres = listOf("Sci-Fi", "Action", "Thriller"),
            kind = MediaKind.MOVIE,
            accentHex = 0xFF1E293B,
            secondaryHex = 0xFF090D16,
            qualityBadge = "4K"
        ),
        MediaSummary(
            id = "cf-inception",
            providerId = ProviderId.CINEFREAK,
            title = "Inception (2010)",
            subtitle = "IMAX Remastered",
            year = "2010",
            runtime = "2h 28m",
            rating = "8.4",
            certification = "PG-13",
            statusBadge = "Released",
            languageTag = "Dual [Hindi–English]",
            genres = listOf("Sci-Fi", "Thriller"),
            kind = MediaKind.MOVIE,
            accentHex = 0xFF0F172A,
            secondaryHex = 0xFF1E293B,
            qualityBadge = "1080p"
        ),
        MediaSummary(
            id = "cf-dune-prophecy",
            providerId = ProviderId.CINEFREAK,
            title = "Dune: Prophecy",
            subtitle = "Sci-Fi Saga",
            year = "2025",
            runtime = "1h 05m / ep",
            rating = "8.2",
            certification = "TV-MA",
            statusBadge = "Season 1",
            languageTag = "English · Hindi",
            genres = listOf("Sci-Fi", "Drama"),
            kind = MediaKind.SERIES,
            accentHex = 0xFF713F12,
            secondaryHex = 0xFF1C1917,
            qualityBadge = "4K"
        ),
        MediaSummary(
            id = "cf-double",
            providerId = ProviderId.CINEFREAK,
            title = "The Double",
            subtitle = "Espionage Thriller",
            year = "2024",
            runtime = "1h 45m",
            rating = "5.9",
            certification = "PG-13",
            statusBadge = "Released",
            languageTag = "English",
            genres = listOf("Action", "Mystery"),
            kind = MediaKind.MOVIE,
            accentHex = 0xFF27272A,
            secondaryHex = 0xFF09090B,
            qualityBadge = "4K"
        ),
        MediaSummary(
            id = "rt-inception",
            providerId = ProviderId.RTALLY,
            title = "Inception (2010)",
            subtitle = "4K HDR10+",
            year = "2010",
            runtime = "2h 28m",
            rating = "8.8",
            certification = "PG-13",
            statusBadge = "Released",
            languageTag = "English [EN]",
            genres = listOf("Sci-Fi", "Action"),
            kind = MediaKind.MOVIE,
            accentHex = 0xFF164E63,
            secondaryHex = 0xFF082F49,
            qualityBadge = "4K"
        ),
        MediaSummary(
            id = "rt-enforcer",
            providerId = ProviderId.RTALLY,
            title = "The Enforcer",
            subtitle = "Crime Action",
            year = "2024",
            runtime = "1h 30m",
            rating = "5.4",
            certification = "R",
            statusBadge = "Released",
            languageTag = "Dual Audio",
            genres = listOf("Action", "Crime"),
            kind = MediaKind.MOVIE,
            accentHex = 0xFF7C2D12,
            secondaryHex = 0xFF1C1917,
            qualityBadge = "4K"
        ),
        MediaSummary(
            id = "rt-substance",
            providerId = ProviderId.RTALLY,
            title = "The Substance",
            subtitle = "Body Horror",
            year = "2024",
            runtime = "2h 21m",
            rating = "7.3",
            certification = "R",
            statusBadge = "Released",
            languageTag = "English",
            genres = listOf("Horror", "Drama"),
            kind = MediaKind.MOVIE,
            accentHex = 0xFF065F46,
            secondaryHex = 0xFF052E16,
            qualityBadge = "4K"
        )
    )

    fun catalogFor(providerId: ProviderId): ProviderCatalog {
        return when (providerId) {
            ProviderId.MOVIELINKBD -> {
                val items = allMedia.filter { it.providerId == ProviderId.MOVIELINKBD }
                ProviderCatalog(
                    providerId = providerId,
                    heroItems = items.take(5),
                    ottPlatforms = defaultOttPlatforms,
                    categories = listOf(
                        "Action", "Horror", "Sci-Fi", "Thriller",
                        "K-Drama", "Hindi", "Bangla", "Anime", "4K UHD"
                    ),
                    sections = listOf(
                        CatalogSection(
                            id = "recent",
                            title = "Recently Updated",
                            items = listOf(items[3], items[4], items[5], items[1], items[0])
                        ),
                        CatalogSection(
                            id = "trending",
                            title = "Trending Movies",
                            items = listOf(items[1], items[0], items[6], items[2])
                        ),
                        CatalogSection(
                            id = "series",
                            title = "Popular Series",
                            items = listOf(items[4], items[5])
                        )
                    )
                )
            }

            ProviderId.CINEFREAK -> {
                val items = allMedia.filter { it.providerId == ProviderId.CINEFREAK }
                ProviderCatalog(
                    providerId = providerId,
                    heroItems = items,
                    ottPlatforms = defaultOttPlatforms.take(3),
                    categories = listOf("Dual Audio", "4K BluRay", "Sci-Fi", "Series"),
                    sections = listOf(
                        CatalogSection(
                            id = "cf-recent",
                            title = "Recently Updated",
                            items = items
                        ),
                        CatalogSection(
                            id = "cf-dual",
                            title = "Dual Audio Releases",
                            items = items.reversed()
                        )
                    )
                )
            }

            ProviderId.RTALLY -> {
                val items = allMedia.filter { it.providerId == ProviderId.RTALLY }
                // Intentionally omits OTT section to verify provider-dependent section hiding
                ProviderCatalog(
                    providerId = providerId,
                    heroItems = items,
                    ottPlatforms = emptyList(),
                    categories = listOf("4K HDR", "Action", "Horror"),
                    sections = listOf(
                        CatalogSection(
                            id = "rt-trending",
                            title = "Trending on Rtally",
                            items = items
                        )
                    )
                )
            }
        }
    }

    fun findById(mediaId: String): MediaSummary =
        allMedia.firstOrNull { it.id == mediaId } ?: allMedia.first()

    fun detailFor(mediaId: String, requestedProvider: ProviderId): MediaDetail {
        val summary = findById(mediaId).copy(providerId = requestedProvider)
        val isSeries = summary.kind == MediaKind.SERIES
        val recommendations = allMedia
            .filter { it.id != summary.id }
            .take(5)

        val overview = when (summary.id) {
            "mlbd-jailer-2" ->
                "When a dangerous syndicate threatens his family, retired jailer Tiger Muthuvel Pandian goes undercover as a driver to battle enemies from the shadows."
            "mlbd-resident-evil" ->
                "Inside an isolated quarantine sector, a tactical rescue unit uncovers a mutated biological outbreak and must fight through the night to survive."
            else ->
                "In a high-stakes race against impossible odds, unlikely allies confront hidden conspiracies and relentless danger across shifting alliances."
        }

        val infoFields = listOf(
            MovieInfoField("Status", summary.statusBadge.ifBlank { "Released" }),
            MovieInfoField("Release Info", summary.year.ifBlank { "2026" }),
            MovieInfoField("Runtime", summary.runtime.ifBlank { "2h 15m" }),
            MovieInfoField("Certification", summary.certification.ifBlank { "NR" }),
            MovieInfoField("Origin Country", if (summary.id.contains("jailer") || summary.id.contains("inkaar")) "IN" else "US"),
            MovieInfoField("Original Language", summary.languageTag.ifBlank { "EN" })
        )

        val downloads = listOf(
            DownloadSourceLink("dl-480", "Download [480p · 610 MB]", "480p", "610 MB"),
            DownloadSourceLink("dl-720h", "Download [720p HEVC · 1.2 GB]", "720p HEVC", "1.2 GB"),
            DownloadSourceLink("dl-720", "Download [720p · 2.1 GB]", "720p", "2.1 GB"),
            DownloadSourceLink("dl-1080", "Download [1080p · 3.6 GB]", "1080p", "3.6 GB"),
            DownloadSourceLink("dl-4k", "Download [4K-HD · 18.0 GB]", "4K-HD", "18.0 GB"),
            DownloadSourceLink("dl-best", "Download [Best Quality · 5.5 GB]", "Best", "5.5 GB"),
            DownloadSourceLink("sub-bn", "Bangla / Bangla Subtitle", "SUB", "120 KB", isSubtitle = true),
            DownloadSourceLink("sub-en", "English Subtitle", "SUB", "110 KB", isSubtitle = true)
        )

        val cast = listOf(
            CastMember("Nelson", "Director", 0xFF3F3F46),
            CastMember("Rajinikanth", "Muthuvel 'Tiger'", 0xFF52525B),
            CastMember("S. J. Suryah", "Bodhi Kalpak", 0xFF374151),
            CastMember("Suraj V.", "Dileep", 0xFF4B5563)
        )

        val seasons = if (isSeries) {
            listOf(
                SeasonGroup(
                    seasonNumber = 1,
                    title = "Season 1",
                    episodes = (1..6).map { ep ->
                        EpisodeItem(
                            number = ep,
                            title = "Episode $ep — Turning Point",
                            runtime = "54m",
                            isNew = ep >= 5,
                            downloads = listOf(
                                DownloadSourceLink("ep${ep}-720", "720p · 420 MB", "720p", "420 MB"),
                                DownloadSourceLink("ep${ep}-1080", "1080p · 890 MB", "1080p", "890 MB")
                            )
                        )
                    }
                ),
                SeasonGroup(
                    seasonNumber = 2,
                    title = "Season 2",
                    episodes = (1..3).map { ep ->
                        EpisodeItem(
                            number = ep,
                            title = "Episode $ep — Aftermath",
                            runtime = "58m",
                            isNew = ep == 3,
                            downloads = listOf(
                                DownloadSourceLink("s2ep${ep}-1080", "1080p · 940 MB", "1080p", "940 MB")
                            )
                        )
                    }
                )
            )
        } else {
            emptyList()
        }

        val screenshots = listOf(
            "Scene Preview 1 — Opening Sequence",
            "Scene Preview 2 — Confrontation",
            "Scene Preview 3 — Climax Frame"
        )

        return MediaDetail(
            summary = summary,
            overview = overview,
            screenshots = screenshots,
            infoFields = infoFields,
            sources = listOf(
                "${requestedProvider.displayName} Primary (1080p)",
                "${requestedProvider.displayName} Mirror CDN",
                "Direct Stream Server B"
            ),
            downloadLinks = downloads,
            cast = cast,
            seasons = seasons,
            recommendations = recommendations
        )
    }

    fun searchAcrossProviders(query: String): Map<ProviderId, List<MediaSummary>> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return emptyMap()
        return ProviderId.entries.associateWith { provider ->
            allMedia.filter {
                it.providerId == provider &&
                    (it.title.lowercase().contains(q) ||
                        it.subtitle.lowercase().contains(q) ||
                        it.genres.any { g -> g.lowercase().contains(q) })
            }
        }
    }

    val initialContinueWatching = listOf(
        ContinueWatchingEntry(
            media = allMedia[1],
            episodeLabel = null,
            progressFraction = 0.62f,
            remainingLabel = "1h 02m left"
        ),
        ContinueWatchingEntry(
            media = allMedia[4],
            episodeLabel = "S1 · E4",
            progressFraction = 0.44f,
            remainingLabel = "31m left"
        )
    )

    val initialHistory = listOf(
        VisitHistoryEntry(allMedia[1], "10m ago"),
        VisitHistoryEntry(allMedia[0], "1h ago"),
        VisitHistoryEntry(allMedia[6], "Yesterday")
    )
}
