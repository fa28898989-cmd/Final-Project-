package com.movielink.app.feature.settings

import android.os.StatFs
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.Coil
import com.movielink.app.BuildConfig
import com.movielink.app.core.designsystem.LocalMovieLinkColors
import com.movielink.app.core.designsystem.MovieLinkCard
import com.movielink.app.core.designsystem.MovieLinkRadius
import com.movielink.app.core.designsystem.PrimaryActionButton
import com.movielink.app.core.designsystem.SecondaryActionButton
import com.movielink.app.core.designsystem.SubtleHairlineDivider
import com.movielink.app.core.integrations.MetadataEnrichmentEngine
import com.movielink.app.core.state.BackupImportPreview
import com.movielink.app.core.state.BackupOperationResult
import com.movielink.app.core.state.BackupRestoreManager
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BackupRestoreSettingsContent(
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    val context = LocalContext.current

    var includeApiKeys by remember { mutableStateOf(false) }
    var lastResult by remember { mutableStateOf<BackupOperationResult?>(null) }
    var pendingPreview by remember { mutableStateOf<BackupImportPreview?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            lastResult = BackupRestoreManager.exportToUri(context, uri, includeApiKeys)
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val preview = BackupRestoreManager.previewFromUri(context, uri)
            if (preview.ok) {
                pendingPreview = preview
            } else {
                lastResult = BackupOperationResult(false, preview.message)
            }
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item(key = "backup_options") {
            MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                SettingSwitchRow(
                    title = "Include Integration API Keys in Export",
                    subtitle = "Disabled by default so shared backup files omit personal TMDB/OMDb/MDBList keys",
                    checked = includeApiKeys,
                    onCheckedChange = { includeApiKeys = it }
                )
            }
        }

        item(key = "backup_actions") {
            MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Configuration Backup (Schema v1)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    Text(
                        text = "Includes Appearance theme, Website Sources & mirrors, Ad Blocking rules, Playback, Downloads, Library settings, and Integrations.",
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                    PrimaryActionButton(
                        text = "Export Backup JSON",
                        icon = Icons.Rounded.FileUpload,
                        onClick = { exportLauncher.launch("movielink-backup-v1.json") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    SecondaryActionButton(
                        text = "Restore From Backup File",
                        icon = Icons.Rounded.FileDownload,
                        onClick = { importLauncher.launch(arrayOf("application/json", "*/*")) },
                        modifier = Modifier.fillMaxWidth()
                    )

                    lastResult?.let { res ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = if (res.ok) Icons.Rounded.CheckCircle else Icons.Rounded.ErrorOutline,
                                contentDescription = null,
                                tint = if (res.ok) colors.success else colors.danger,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = res.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (res.ok) colors.success else colors.danger
                            )
                        }
                    }
                }
            }
        }
    }

    pendingPreview?.let { preview ->
        val dateText = remember(preview.exportedAtMs) {
            if (preview.exportedAtMs > 0L) {
                SimpleDateFormat("MMM d, yyyy • HH:mm", Locale.getDefault())
                    .format(Date(preview.exportedAtMs))
            } else "Unknown date"
        }
        AlertDialog(
            onDismissRequest = { pendingPreview = null },
            containerColor = colors.surfaceElevated,
            title = {
                Text(
                    text = "Confirm Backup Restore",
                    color = colors.textPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Schema v${preview.schemaVersion} • Exported $dateText",
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.accent
                    )
                    Text(
                        text = "This will replace your current settings for:",
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                    preview.includedSections.forEach { section ->
                        Text(
                            text = "• $section",
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textPrimary
                        )
                    }
                    if (preview.includesApiKeys) {
                        Text(
                            text = "Note: This backup includes saved integration API keys.",
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.ratingGold
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        lastResult = BackupRestoreManager.applyPreview(preview)
                        pendingPreview = null
                    }
                ) {
                    Text("Restore Now", color = colors.accent, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingPreview = null }) {
                    Text("Cancel", color = colors.textSecondary)
                }
            }
        )
    }
}

@Composable
fun StorageSettingsContent(
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    val context = LocalContext.current
    var refreshTick by remember { mutableIntStateOf(0) }
    var statusText by remember { mutableStateOf<String?>(null) }

    val stats = remember(refreshTick) {
        val cacheBytes = directorySizeBytes(context.cacheDir)
        val dbBytes = context.getDatabasePath("movielink_library.db")?.takeIf { it.exists() }?.length() ?: 0L
        val stat = StatFs(context.filesDir.absolutePath)
        val freeBytes = stat.availableBytes
        Triple(cacheBytes, dbBytes, freeBytes)
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item(key = "storage_overview") {
            MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Storage,
                            contentDescription = null,
                            tint = colors.accent
                        )
                        Text(
                            text = "App Storage Breakdown",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                    StorageStatLine("Image & HTTP Cache", formatBytes(stats.first))
                    SubtleHairlineDivider()
                    StorageStatLine("Room Library Database", formatBytes(stats.second))
                    SubtleHairlineDivider()
                    StorageStatLine("Device Free Space", formatBytes(stats.third))
                }
            }
        }

        item(key = "storage_actions") {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                PrimaryActionButton(
                    text = "Clear Image & HTTP Cache",
                    icon = Icons.Rounded.DeleteOutline,
                    onClick = {
                        val before = stats.first
                        try {
                            Coil.imageLoader(context).memoryCache?.clear()
                            Coil.imageLoader(context).diskCache?.clear()
                        } catch (_: Exception) {
                        }
                        context.cacheDir.listFiles()?.forEach { it.deleteRecursively() }
                        MetadataEnrichmentEngine.clearCache()
                        refreshTick++
                        statusText = "Cleared ${formatBytes(before)} of cached artwork & temporary files."
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                statusText?.let { msg ->
                    Text(
                        text = msg,
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.success,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
internal fun StorageStatLine(label: String, value: String) {
    val colors = LocalMovieLinkColors.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = colors.textSecondary)
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = colors.textPrimary
        )
    }
}

@Composable
fun AboutSettingsContent(
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item(key = "about_app") {
            MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "MovieLink",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Black,
                        color = colors.textPrimary
                    )
                    Text(
                        text = "Version ${BuildConfig.VERSION_NAME} • Native Kotlin & Jetpack Compose",
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.accent
                    )
                    Text(
                        text = "Pure-black AMOLED modular media hub combining independent provider scrapers, built-in WebView request/popup ad blocking, Media3 ExoPlayer local & stream playback, Room history persistence, and optional metadata enrichment.",
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                }
            }
        }

        item(key = "about_stack") {
            MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Architecture & Capabilities",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    StorageStatLine("Playback Engine", "AndroidX Media3 ExoPlayer + HLS")
                    SubtleHairlineDivider()
                    StorageStatLine("Persistence", "Room Database + SharedPreferences")
                    SubtleHairlineDivider()
                    StorageStatLine("Networking & Parsing", "OkHttp + Jsoup + WebView CookieJar")
                    SubtleHairlineDivider()
                    StorageStatLine("External Integrations", "TMDB, OMDb, MDBList, Better Poster")
                    SubtleHairlineDivider()
                    StorageStatLine("App Advertisements", "None (Ad-Free + Built-in Blocker)")
                }
            }
        }
    }
}

private fun directorySizeBytes(dir: File?): Long {
    if (dir == null || !dir.exists()) return 0L
    if (dir.isFile) return dir.length()
    var sum = 0L
    dir.listFiles()?.forEach { child ->
        sum += directorySizeBytes(child)
    }
    return sum
}

private fun formatBytes(bytes: Long): String {
    if (bytes <= 0L) return "0 B"
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
        gb >= 1.0 -> String.format(Locale.US, "%.2f GB", gb)
        mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
        kb >= 1.0 -> String.format(Locale.US, "%.0f KB", kb)
        else -> "$bytes B"
    }
}
