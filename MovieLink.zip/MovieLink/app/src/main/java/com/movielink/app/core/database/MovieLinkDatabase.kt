package com.movielink.app.core.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        LibraryItemEntity::class,
        PlaybackProgressEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MovieLinkDatabase : RoomDatabase() {
    abstract fun libraryDao(): LibraryDao

    companion object {
        @Volatile
        private var instance: MovieLinkDatabase? = null

        fun getInstance(context: Context): MovieLinkDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    MovieLinkDatabase::class.java,
                    "movielink_library.db"
                ).fallbackToDestructiveMigration().build().also { instance = it }
            }
        }
    }
}
