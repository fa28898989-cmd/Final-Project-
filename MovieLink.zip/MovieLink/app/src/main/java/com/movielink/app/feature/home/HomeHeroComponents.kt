package com.movielink.app.feature.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import com.movielink.app.core.designsystem.EdgeToEdgeHeroScrim
import com.movielink.app.core.designsystem.LocalMovieLinkColors
import com.movielink.app.core.designsystem.MediaArtwork
import com.movielink.app.core.designsystem.MovieLinkRadius
import com.movielink.app.core.model.MediaKind
import com.movielink.app.core.model.MediaSummary
import kotlinx.coroutines.delay
import kotlin.math.absoluteValue

@Composable
fun CinematicHomeHero(
    items: List<MediaSummary>,
    heroHeight: Dp,
    onViewDetails: (MediaSummary) -> Unit,
    modifier: Modifier = Modifier
) {
    if (items.isEmpty()) return
    val colors = LocalMovieLinkColors.current
    val pagerState = rememberPagerState(pageCount = { items.size })

    LaunchedEffect(items, pagerState.isScrollInProgress) {
        if (items.size > 1 && !pagerState.isScrollInProgress) {
            delay(5000)
            val next = (pagerState.currentPage + 1) % items.size
            pagerState.animateScrollToPage(next)
        }
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(heroHeight)
        ) {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize()
            ) { page ->
                val item = items[page]
                EdgeToEdgeHeroScrim(
                    modifier = Modifier
                        .fillMaxSize()
                        .clickable { onViewDetails(item) }
                ) {
                    MediaArtwork(
                        media = item,
                        isBackdrop = true,
                        showEmbeddedTitle = false,
                        modifier = Modifier.fillMaxSize()
                    )

                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        val heroFallbackTitle: @Composable () -> Unit = {
                            if (item.titleLogoUrl.isBlank()) {
                                Text(
                                    text = item.title.uppercase(),
                                    color = Color.White,
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Black,
                                    textAlign = TextAlign.Center,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        if (item.titleLogoUrl.startsWith("http", ignoreCase = true)) {
                            SubcomposeAsyncImage(
                                model = item.titleLogoUrl,
                                contentDescription = item.title,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .fillMaxWidth(0.72f)
                                    .heightIn(max = 72.dp),
                                loading = { heroFallbackTitle() },
                                error = { heroFallbackTitle() }
                            )
                        } else {
                            heroFallbackTitle()
                        }

                        val kindLabel = if (item.kind == MediaKind.SERIES) "Series" else "Movie"
                        val primaryGenre = item.genres.firstOrNull().orEmpty()
                        val metaLine = listOf(kindLabel, primaryGenre, item.runtime, item.year)
                            .filter { it.isNotBlank() }
                            .joinToString("  •  ")
                        if (metaLine.isNotBlank()) {
                            Text(
                                text = metaLine,
                                style = MaterialTheme.typography.labelLarge,
                                color = Color.White.copy(alpha = 0.88f),
                                textAlign = TextAlign.Center
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (item.certification.isNotBlank() || item.statusBadge.isNotBlank()) {
                                val badgeText = listOf(item.certification, item.statusBadge.uppercase())
                                    .filter { it.isNotBlank() }
                                    .joinToString("  |  ")
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color.Black.copy(alpha = 0.45f))
                                        .border(1.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = badgeText,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color.White
                                    )
                                }
                            }

                            if (item.rating.isNotBlank()) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(Color(0xFFF5C518))
                                            .padding(horizontal = 5.dp, vertical = 1.dp)
                                    ) {
                                        Text(
                                            text = "IMDb",
                                            color = Color.Black,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                    Text(
                                        text = item.rating,
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }

                            if (item.languageTag.isNotBlank()) {
                                Text(
                                    text = "•  ${item.languageTag.take(10)}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White.copy(alpha = 0.85f)
                                )
                            }
                        }

                        Button(
                            onClick = { onViewDetails(item) },
                            shape = RoundedCornerShape(MovieLinkRadius.Pill),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = colors.primaryButtonBg,
                                contentColor = colors.primaryButtonContent
                            ),
                            contentPadding = PaddingValues(horizontal = 28.dp, vertical = 10.dp)
                        ) {
                            Text(
                                text = "View Details",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        if (items.size > 1) {
            Spacer(Modifier.height(6.dp))
            CarouselPageIndicator(
                count = items.size,
                currentIndex = pagerState.currentPage
            )
        }
    }
}

@Composable
fun PosterCarouselHomeHero(
    items: List<MediaSummary>,
    heroHeight: Dp,
    onViewDetails: (MediaSummary) -> Unit,
    modifier: Modifier = Modifier
) {
    if (items.isEmpty()) return
    val colors = LocalMovieLinkColors.current
    val pagerState = rememberPagerState(
        initialPage = if (items.size > 2) 1 else 0,
        pageCount = { items.size }
    )

    LaunchedEffect(items, pagerState.isScrollInProgress) {
        if (items.size > 1 && !pagerState.isScrollInProgress) {
            delay(5000)
            val next = (pagerState.currentPage + 1) % items.size
            pagerState.animateScrollToPage(next)
        }
    }

    val cardHeight = (heroHeight - 84.dp).coerceIn(260.dp, 440.dp)
    val cardWidth = cardHeight * 0.66f

    Column(
        modifier = modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(top = 62.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
            val clampedCardWidth = cardWidth.coerceAtMost(maxWidth - 96.dp)
            val horizontalPad = ((maxWidth - clampedCardWidth) / 2f).coerceAtLeast(32.dp)

            HorizontalPager(
                state = pagerState,
                contentPadding = PaddingValues(horizontal = horizontalPad),
                pageSpacing = 12.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(cardHeight + 12.dp)
            ) { page ->
                val item = items[page]
                val pageOffset = ((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction)
                    .absoluteValue
                    .coerceIn(0f, 1f)
                val scale = 0.85f + (1f - pageOffset) * 0.15f
                val alpha = 0.55f + (1f - pageOffset) * 0.45f

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            this.alpha = alpha
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .width(clampedCardWidth)
                            .aspectRatio(2f / 3f)
                            .clip(RoundedCornerShape(MovieLinkRadius.Lg))
                            .border(
                                width = 1.dp,
                                color = colors.borderSubtle,
                                shape = RoundedCornerShape(MovieLinkRadius.Lg)
                            )
                            .clickable { onViewDetails(item) }
                    ) {
                    MediaArtwork(
                        media = item,
                        isBackdrop = false,
                        showEmbeddedTitle = true,
                        modifier = Modifier.fillMaxSize()
                    )

                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    0f to Color.Transparent,
                                    0.45f to Color.Black.copy(alpha = 0.72f),
                                    1f to Color.Black.copy(alpha = 0.94f)
                                )
                            )
                            .padding(horizontal = 14.dp, vertical = 14.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                textAlign = TextAlign.Center,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val lang = item.languageTag.ifBlank { item.year }
                                if (lang.isNotBlank()) {
                                    Text(
                                        text = lang,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White.copy(alpha = 0.78f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                if (item.rating.isNotBlank()) {
                                    Text(
                                        text = "•",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White.copy(alpha = 0.6f)
                                    )
                                    Icon(
                                        imageVector = Icons.Rounded.Star,
                                        contentDescription = null,
                                        tint = colors.ratingGold,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Text(
                                        text = item.rating,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        }

        if (items.size > 1) {
            Spacer(Modifier.height(10.dp))
            CarouselPageIndicator(
                count = items.size,
                currentIndex = pagerState.currentPage
            )
        }
    }
}

@Composable
private fun CarouselPageIndicator(
    count: Int,
    currentIndex: Int
) {
    val colors = LocalMovieLinkColors.current
    Row(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(count) { index ->
            val selected = index == currentIndex
            Box(
                modifier = Modifier
                    .height(5.dp)
                    .width(if (selected) 22.dp else 5.dp)
                    .clip(CircleShape)
                    .background(
                        if (selected) colors.textPrimary
                        else colors.textSecondary.copy(alpha = 0.4f)
                    )
            )
        }
    }
}
