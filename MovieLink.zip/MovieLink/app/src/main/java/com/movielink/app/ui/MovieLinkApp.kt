package com.movielink.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.movielink.app.core.designsystem.LocalMovieLinkColors
import com.movielink.app.core.player.MovieLinkPlayerScreen
import com.movielink.app.feature.localplayer.LocalMediaViewModel
import com.movielink.app.navigation.MovieLinkNavHost
import com.movielink.app.navigation.TopLevelDestination

@Composable
fun MovieLinkApp(
    localMediaViewModel: LocalMediaViewModel = viewModel()
) {
    val navController = rememberNavController()
    val colors = LocalMovieLinkColors.current
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination
    val activePlayerRequest by localMediaViewModel.activePlayerRequest.collectAsStateWithLifecycle()

    val topLevelRoutes = remember { TopLevelDestination.entries.map { it.route }.toSet() }
    val showBottomBar = currentDestination?.route in topLevelRoutes

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .background(colors.background),
            containerColor = colors.background,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            bottomBar = {
                if (showBottomBar && activePlayerRequest == null) {
                    MovieLinkBottomBar(
                        destinations = TopLevelDestination.entries,
                        isSelected = { dest ->
                            currentDestination?.hierarchy?.any { it.route == dest.route } == true
                        },
                        onSelect = { dest ->
                            navController.navigate(dest.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = innerPadding.calculateBottomPadding())
            ) {
                MovieLinkNavHost(
                    navController = navController,
                    localMediaViewModel = localMediaViewModel
                )
            }
        }

        activePlayerRequest?.let { request ->
            MovieLinkPlayerScreen(
                request = request,
                onSaveProgress = { uri, title, pos, dur ->
                    localMediaViewModel.savePlaybackProgress(uri, title, pos, dur)
                },
                onClose = { localMediaViewModel.closePlayer() },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
private fun MovieLinkBottomBar(
    destinations: List<TopLevelDestination>,
    isSelected: (TopLevelDestination) -> Boolean,
    onSelect: (TopLevelDestination) -> Unit
) {
    val colors = LocalMovieLinkColors.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(colors.navBarBg)
            .navigationBarsPadding()
    ) {
        HorizontalDivider(
            thickness = 0.8.dp,
            color = colors.borderSubtle
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(62.dp)
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            destinations.forEach { destination ->
                val selected = isSelected(destination)
                val tint = if (selected) colors.navActive else colors.navInactive
                val interactionSource = remember { MutableInteractionSource() }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable(
                            interactionSource = interactionSource,
                            indication = null,
                            onClick = { onSelect(destination) }
                        )
                        .padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = if (selected) destination.selectedIcon else destination.unselectedIcon,
                        contentDescription = destination.label,
                        tint = tint,
                        modifier = Modifier.size(23.dp)
                    )
                    Spacer(Modifier.height(3.dp))
                    Text(
                        text = destination.label,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                        color = tint,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
