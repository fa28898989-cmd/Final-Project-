package com.movielink.app.feature.settings

import android.graphics.Color as AndroidColor
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.movielink.app.core.designsystem.LocalMovieLinkColors
import com.movielink.app.core.designsystem.MovieLinkRadius
import com.movielink.app.core.designsystem.PrimaryActionButton
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

@Composable
fun ColorWheelPickerDialog(
    title: String,
    initialColor: Color,
    onConfirm: (Color) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalMovieLinkColors.current
    val initialHsv = remember(initialColor) {
        FloatArray(3).also { AndroidColor.colorToHSV(initialColor.toArgb(), it) }
    }

    var hue by remember { mutableFloatStateOf(initialHsv[0]) }
    var saturation by remember { mutableFloatStateOf(initialHsv[1]) }
    var brightness by remember { mutableFloatStateOf(initialHsv[2]) }
    var hexInput by remember {
        mutableStateOf(String.format("#%06X", initialColor.toArgb() and 0xFFFFFF))
    }

    fun syncHex(h: Float, s: Float, v: Float) {
        val c = AndroidColor.HSVToColor(floatArrayOf(h, s, v))
        hexInput = String.format("#%06X", c and 0xFFFFFF)
    }

    val previewColor = remember(hue, saturation, brightness) {
        Color(AndroidColor.HSVToColor(floatArrayOf(hue, saturation, brightness)))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.surface,
        titleContentColor = colors.textPrimary,
        title = {
            Text(text = title, style = MaterialTheme.typography.titleLarge)
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Interactive Hue + Saturation Color Wheel
                HsvWheelCanvas(
                    hue = hue,
                    saturation = saturation,
                    brightness = brightness,
                    onPick = { newHue, newSat ->
                        hue = newHue
                        saturation = newSat
                        syncHex(newHue, newSat, brightness)
                    },
                    modifier = Modifier.size(190.dp)
                )

                // Saturation Slider
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Saturation", style = MaterialTheme.typography.labelMedium, color = colors.textSecondary)
                        Text("${(saturation * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = colors.textPrimary)
                    }
                    Slider(
                        value = saturation,
                        onValueChange = {
                            saturation = it
                            syncHex(hue, it, brightness)
                        },
                        colors = SliderDefaults.colors(thumbColor = previewColor, activeTrackColor = previewColor)
                    )
                }

                // Brightness / Value Slider
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Brightness", style = MaterialTheme.typography.labelMedium, color = colors.textSecondary)
                        Text("${(brightness * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = colors.textPrimary)
                    }
                    Slider(
                        value = brightness,
                        onValueChange = {
                            brightness = it
                            syncHex(hue, saturation, it)
                        },
                        colors = SliderDefaults.colors(thumbColor = previewColor, activeTrackColor = previewColor)
                    )
                }

                // Live Swatch + Hex Input
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(MovieLinkRadius.Sm))
                            .background(previewColor)
                            .border(1.dp, colors.borderStrong, RoundedCornerShape(MovieLinkRadius.Sm))
                    )
                    OutlinedTextField(
                        value = hexInput,
                        onValueChange = { raw ->
                            val clean = raw.uppercase().take(7)
                            hexInput = clean
                            if (Regex("^#[0-9A-F]{6}$").matches(clean)) {
                                val parsed = AndroidColor.parseColor(clean)
                                val hsv = FloatArray(3)
                                AndroidColor.colorToHSV(parsed, hsv)
                                hue = hsv[0]
                                saturation = hsv[1]
                                brightness = hsv[2]
                            }
                        },
                        singleLine = true,
                        label = { Text("Hex (#RRGGBB)") },
                        shape = RoundedCornerShape(MovieLinkRadius.Sm),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = colors.borderStrong,
                            unfocusedBorderColor = colors.borderSubtle,
                            focusedTextColor = colors.textPrimary,
                            unfocusedTextColor = colors.textPrimary
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onDismiss) {
                    Text("Cancel", color = colors.textSecondary)
                }
                Spacer(Modifier.width(6.dp))
                PrimaryActionButton(
                    text = "Apply",
                    onClick = { onConfirm(previewColor) }
                )
            }
        }
    )
}

@Composable
private fun HsvWheelCanvas(
    hue: Float,
    saturation: Float,
    brightness: Float,
    onPick: (Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val hueStops = remember {
        listOf(
            Color.Red, Color.Yellow, Color.Green, Color.Cyan,
            Color.Blue, Color.Magenta, Color.Red
        )
    }

    Canvas(
        modifier = modifier
            .clip(CircleShape)
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    fun emitOffset(pos: Offset) {
                        val cx = size.width / 2f
                        val cy = size.height / 2f
                        val r = minOf(cx, cy).coerceAtLeast(1f)
                        val dx = pos.x - cx
                        val dy = pos.y - cy
                        val dist = hypot(dx, dy).coerceAtMost(r)
                        val angle = ((atan2(dy, dx) * 180f / PI.toFloat()) + 360f) % 360f
                        onPick(angle, (dist / r).coerceIn(0f, 1f))
                    }
                    emitOffset(down.position)
                    drag(down.id) { change ->
                        change.consume()
                        emitOffset(change.position)
                    }
                }
            }
    ) {
        val radius = size.minDimension / 2f
        val center = Offset(size.width / 2f, size.height / 2f)

        drawCircle(
            brush = Brush.sweepGradient(hueStops, center),
            radius = radius,
            center = center
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White, Color.Transparent),
                center = center,
                radius = radius
            ),
            radius = radius,
            center = center
        )
        if (brightness < 1f) {
            drawCircle(
                color = Color.Black.copy(alpha = (1f - brightness).coerceIn(0f, 0.92f)),
                radius = radius,
                center = center
            )
        }

        val rad = Math.toRadians(hue.toDouble())
        val thumbOffset = Offset(
            x = center.x + (cos(rad) * saturation * radius).toFloat(),
            y = center.y + (sin(rad) * saturation * radius).toFloat()
        )
        drawCircle(
            color = Color.White,
            radius = 9.dp.toPx(),
            center = thumbOffset,
            style = Stroke(width = 2.5.dp.toPx())
        )
        drawCircle(
            color = Color.Black.copy(alpha = 0.55f),
            radius = 7.dp.toPx(),
            center = thumbOffset,
            style = Stroke(width = 1.dp.toPx())
        )
    }
}
