package com.movielink.app.feature.library

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BookmarkRemove
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.ViewList
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.movielink.app.core.designsystem.EmptyStateCard
import com.movielink.app.core.designsystem.FilterPill
import com.movielink.app.core.designsystem.LocalMovieLinkColors
import com.movielink.app.core.designsystem.MediaArtwork
import com.movielink.app.core.designsystem.MovieLinkCard
import com.movielink.app.core.designsystem.MovieLinkRadius
import com.movielink.app.core.designsystem.ScreenTitleHeader
import com.movielink.app.core.designsystem.SectionHeader
import com.movielink.app.core.model.ContinueWatchingEntry
import com.movielink.app.core.model.MediaSummary
import com.movielink.app.core.state.AppUiStateStore
import com.movielink.app.feature.home.CatalogPosterCard

private enum class LibraryTab {
    MY_LIST,
    VISIT_HISTORY
}

@Composable
fun LibraryScreen(
    onOpenDetails: (MediaSummary) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    val libraryState by AppUiStateStore.library.collectAsStateWithLifecycle()

    var activeTab by remember { mutableStateOf(LibraryTab.MY_LIST) }
    var isGridView by remember { mutableStateOf(true) }

    val savedItems = libraryState.watchlistItems

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background)
            .statusBarsPadding(),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item(key = "header") {
            Column {
                ScreenTitleHeader(
                    title = "Library",
                    trailing = {
                        IconButton(onClick = { isGridView = !isGridView }) {
                            Icon(
                                imageVector = if (isGridView) Icons.Rounded.GridView else Icons.Rounded.ViewList,
                                contentDescription = "Toggle grid or list view",
                                tint = colors.textSecondary
                            )
                        }
                    }
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FilterPill(
                        label = "My List (${savedItems.size})",
                        selected = activeTab == LibraryTab.MY_LIST,
                        onClick = { activeTab = LibraryTab.MY_LIST },
                        modifier = Modifier.weight(1f)
                    )
                    FilterPill(
                        label = "Visit History (${libraryState.visitHistory.size})",
                        selected = activeTab == LibraryTab.VISIT_HISTORY,
                        onClick = { activeTab = LibraryTab.VISIT_HISTORY },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Continue Watching + Resume Playback Strip
        if (libraryState.continueWatching.isNotEmpty()) {
            item(key = "continue_watching") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SectionHeader(title = "Continue Watching")
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(libraryState.continueWatching, key = { it.media.id }) { entry ->
                            ContinueWatchingCard(
                                entry = entry,
                                onClick = { onOpenDetails(entry.media) }
                            )
                        }
                    }
                }
            }
        }

        when (activeTab) {
            LibraryTab.MY_LIST -> {
                if (savedItems.isEmpty()) {
                    item(key = "my_list_empty") {
                        EmptyStateCard(
                            title = "Your library is empty",
                            description = "Saved titles will appear here after you tap Add to Watchlist on a details screen.",
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                } else if (isGridView) {
                    val rows = savedItems.chunked(3)
                    items(rows, key = { chunk -> chunk.joinToString { it.id } }) { rowItems ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            rowItems.forEach { media ->
                                CatalogPosterCard(
                                    media = media,
                                    showRatingBadge = true,
                                    onClick = { onOpenDetails(media) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            repeat(3 - rowItems.size) {
                                Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                } else {
                    items(savedItems, key = { it.id }) { media ->
                        LibraryListRow(
                            media = media,
                            metaText = listOf(media.providerId.displayName, media.year, media.qualityBadge)
                                .filter { it.isNotBlank() }
                                .joinToString(" • "),
                            onClick = { onOpenDetails(media) },
                            trailingIcon = Icons.Rounded.BookmarkRemove,
                            onTrailingClick = { AppUiStateStore.toggleWatchlist(media.id) }
                        )
                    }
                }
            }

            LibraryTab.VISIT_HISTORY -> {
                if (libraryState.visitHistory.isEmpty()) {
                    item(key = "history_empty") {
                        EmptyStateCard(
                            title = "No visit history yet",
                            description = "Titles you open from Home, Search, or Recommendations will appear here.",
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                } else {
                    item(key = "history_header") {
                        SectionHeader(
                            title = "Recent Activity",
                            actionLabel = "Clear",
                            onActionClick = { AppUiStateStore.clearHistory() }
                        )
                    }
                    items(libraryState.visitHistory, key = { it.media.id }) { item ->
                        LibraryListRow(
                            media = item.media,
                            metaText = "${item.media.providerId.displayName} • ${item.visitedAtLabel}",
                            onClick = { onOpenDetails(item.media) },
                            trailingIcon = Icons.Rounded.DeleteSweep,
                            onTrailingClick = { AppUiStateStore.removeHistoryItem(item.media.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ContinueWatchingCard(
    entry: ContinueWatchingEntry,
    onClick: () -> Unit
) {
    val colors = LocalMovieLinkColors.current
    MovieLinkCard(
        modifier = Modifier.width(210.dp),
        cornerRadius = MovieLinkRadius.Md,
        onClick = onClick
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(114.dp)
            ) {
                MediaArtwork(
                    media = entry.media,
                    isBackdrop = true,
                    showEmbeddedTitle = true,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.65f))
                        .border(1.dp, Color.White.copy(alpha = 0.45f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PlayArrow,
                        contentDescription = "Resume",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
                if (!entry.episodeLabel.isNullOrBlank()) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.Black.copy(alpha = 0.72f))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = entry.episodeLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White
                        )
                    }
                }
            }

            LinearProgressIndicator(
                progress = { entry.progressFraction.coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp),
                color = colors.accent,
                trackColor = colors.surfaceElevated
            )

            Column(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = entry.media.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Resume • ${entry.remainingLabel}",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
            }
        }
    }
}

@Composable
private fun LibraryListRow(
    media: MediaSummary,
    metaText: String,
    onClick: () -> Unit,
    trailingIcon: androidx.compose.ui.graphics.vector.ImageVector,
    onTrailingClick: () -> Unit
) {
    val colors = LocalMovieLinkColors.current
    MovieLinkCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        cornerRadius = MovieLinkRadius.Sm,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .width(54.dp)
                    .aspectRatio(2f / 3f)
                    .clip(RoundedCornerShape(MovieLinkRadius.Xs))
            ) {
                MediaArtwork(
                    media = media,
                    isBackdrop = false,
                    showEmbeddedTitle = true,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = media.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = metaText,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = onTrailingClick) {
                Icon(
                    imageVector = trailingIcon,
                    contentDescription = null,
                    tint = colors.textSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
