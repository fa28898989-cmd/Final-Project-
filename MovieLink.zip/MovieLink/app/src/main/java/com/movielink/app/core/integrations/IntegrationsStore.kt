package com.movielink.app.core.integrations

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONObject

data class IntegrationFieldsConfig(
    val posters: Boolean = true,
    val backdrops: Boolean = true,
    val titleLogos: Boolean = true,
    val ratings: Boolean = true,
    val overview: Boolean = true,
    val genres: Boolean = true,
    val releaseDates: Boolean = true,
    val runtime: Boolean = true,
    val cast: Boolean = true
)

data class IntegrationsSettings(
    val artworkEnrichmentEnabled: Boolean = false,
    val metadataEnrichmentEnabled: Boolean = false,
    val preferExternalOverWebsite: Boolean = false,
    val tmdbEnabled: Boolean = false,
    val tmdbApiKey: String = "",
    val omdbEnabled: Boolean = false,
    val omdbApiKey: String = "",
    val mdblistEnabled: Boolean = false,
    val mdblistApiKey: String = "",
    val betterPosterEnabled: Boolean = false,
    val betterPosterApiKey: String = "",
    val betterPosterBaseUrl: String = DEFAULT_BETTER_POSTER_URL,
    val fields: IntegrationFieldsConfig = IntegrationFieldsConfig()
) {
    val hasAnyMetadataSource: Boolean
        get() = (tmdbEnabled && tmdbApiKey.isNotBlank()) ||
            (omdbEnabled && omdbApiKey.isNotBlank()) ||
            (mdblistEnabled && mdblistApiKey.isNotBlank())

    val hasAnyArtworkSource: Boolean
        get() = (tmdbEnabled && tmdbApiKey.isNotBlank()) ||
            (omdbEnabled && omdbApiKey.isNotBlank()) ||
            (betterPosterEnabled && betterPosterApiKey.isNotBlank())

    companion object {
        const val DEFAULT_BETTER_POSTER_URL = "https://api.ratingposterdb.com"
    }
}

object IntegrationsStore {
    private const val PREFS_NAME = "movielink_integrations_v1"
    private const val KEY_JSON = "settings_json"

    private var prefs: SharedPreferences? = null

    private val _settings = MutableStateFlow(IntegrationsSettings())
    val settings: StateFlow<IntegrationsSettings> = _settings.asStateFlow()

    fun init(context: Context) {
        if (prefs != null) return
        val sp = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs = sp
        val raw = sp.getString(KEY_JSON, null)
        if (!raw.isNullOrBlank()) {
            _settings.value = decode(raw)
        }
    }

    fun update(transform: (IntegrationsSettings) -> IntegrationsSettings) {
        _settings.update { prev ->
            val next = transform(prev)
            persist(next)
            next
        }
    }

    fun updateFields(transform: (IntegrationFieldsConfig) -> IntegrationFieldsConfig) {
        update { it.copy(fields = transform(it.fields)) }
    }

    fun resetAll() {
        val fresh = IntegrationsSettings()
        _settings.value = fresh
        persist(fresh)
    }

    private fun persist(state: IntegrationsSettings) {
        val sp = prefs ?: return
        val f = state.fields
        val json = JSONObject().apply {
            put("artworkEnrichmentEnabled", state.artworkEnrichmentEnabled)
            put("metadataEnrichmentEnabled", state.metadataEnrichmentEnabled)
            put("preferExternalOverWebsite", state.preferExternalOverWebsite)
            put("tmdbEnabled", state.tmdbEnabled)
            put("tmdbApiKey", state.tmdbApiKey)
            put("omdbEnabled", state.omdbEnabled)
            put("omdbApiKey", state.omdbApiKey)
            put("mdblistEnabled", state.mdblistEnabled)
            put("mdblistApiKey", state.mdblistApiKey)
            put("betterPosterEnabled", state.betterPosterEnabled)
            put("betterPosterApiKey", state.betterPosterApiKey)
            put("betterPosterBaseUrl", state.betterPosterBaseUrl)
            put(
                "fields",
                JSONObject().apply {
                    put("posters", f.posters)
                    put("backdrops", f.backdrops)
                    put("titleLogos", f.titleLogos)
                    put("ratings", f.ratings)
                    put("overview", f.overview)
                    put("genres", f.genres)
                    put("releaseDates", f.releaseDates)
                    put("runtime", f.runtime)
                    put("cast", f.cast)
                }
            )
        }.toString()
        sp.edit().putString(KEY_JSON, json).apply()
    }

    private fun decode(raw: String): IntegrationsSettings {
        return try {
            val root = JSONObject(raw)
            val fObj = root.optJSONObject("fields")
            val fields = if (fObj != null) {
                IntegrationFieldsConfig(
                    posters = fObj.optBoolean("posters", true),
                    backdrops = fObj.optBoolean("backdrops", true),
                    titleLogos = fObj.optBoolean("titleLogos", true),
                    ratings = fObj.optBoolean("ratings", true),
                    overview = fObj.optBoolean("overview", true),
                    genres = fObj.optBoolean("genres", true),
                    releaseDates = fObj.optBoolean("releaseDates", true),
                    runtime = fObj.optBoolean("runtime", true),
                    cast = fObj.optBoolean("cast", true)
                )
            } else {
                IntegrationFieldsConfig()
            }
            IntegrationsSettings(
                artworkEnrichmentEnabled = root.optBoolean("artworkEnrichmentEnabled", false),
                metadataEnrichmentEnabled = root.optBoolean("metadataEnrichmentEnabled", false),
                preferExternalOverWebsite = root.optBoolean("preferExternalOverWebsite", false),
                tmdbEnabled = root.optBoolean("tmdbEnabled", false),
                tmdbApiKey = root.optString("tmdbApiKey", ""),
                omdbEnabled = root.optBoolean("omdbEnabled", false),
                omdbApiKey = root.optString("omdbApiKey", ""),
                mdblistEnabled = root.optBoolean("mdblistEnabled", false),
                mdblistApiKey = root.optString("mdblistApiKey", ""),
                betterPosterEnabled = root.optBoolean("betterPosterEnabled", false),
                betterPosterApiKey = root.optString("betterPosterApiKey", ""),
                betterPosterBaseUrl = root.optString(
                    "betterPosterBaseUrl",
                    IntegrationsSettings.DEFAULT_BETTER_POSTER_URL
                ).ifBlank { IntegrationsSettings.DEFAULT_BETTER_POSTER_URL },
                fields = fields
            )
        } catch (_: Exception) {
            IntegrationsSettings()
        }
    }

    fun exportBackupJson(includeApiKeys: Boolean): JSONObject {
        val s = _settings.value
        val f = s.fields
        return JSONObject().apply {
            put("artworkEnrichmentEnabled", s.artworkEnrichmentEnabled)
            put("metadataEnrichmentEnabled", s.metadataEnrichmentEnabled)
            put("preferExternalOverWebsite", s.preferExternalOverWebsite)
            put("tmdbEnabled", s.tmdbEnabled)
            put("omdbEnabled", s.omdbEnabled)
            put("mdblistEnabled", s.mdblistEnabled)
            put("betterPosterEnabled", s.betterPosterEnabled)
            put("betterPosterBaseUrl", s.betterPosterBaseUrl)
            if (includeApiKeys) {
                put("tmdbApiKey", s.tmdbApiKey)
                put("omdbApiKey", s.omdbApiKey)
                put("mdblistApiKey", s.mdblistApiKey)
                put("betterPosterApiKey", s.betterPosterApiKey)
            }
            put(
                "fields",
                JSONObject().apply {
                    put("posters", f.posters)
                    put("backdrops", f.backdrops)
                    put("titleLogos", f.titleLogos)
                    put("ratings", f.ratings)
                    put("overview", f.overview)
                    put("genres", f.genres)
                    put("releaseDates", f.releaseDates)
                    put("runtime", f.runtime)
                    put("cast", f.cast)
                }
            )
        }
    }

    fun importBackupJson(obj: JSONObject) {
        val cur = _settings.value
        val merged = decode(obj.toString()).let { imported ->
            imported.copy(
                tmdbApiKey = imported.tmdbApiKey.ifBlank { cur.tmdbApiKey },
                omdbApiKey = imported.omdbApiKey.ifBlank { cur.omdbApiKey },
                mdblistApiKey = imported.mdblistApiKey.ifBlank { cur.mdblistApiKey },
                betterPosterApiKey = imported.betterPosterApiKey.ifBlank { cur.betterPosterApiKey }
            )
        }
        _settings.value = merged
        persist(merged)
    }
}
