package com.movielink.app.feature.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.NetworkCheck
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.movielink.app.core.adblock.AdBlockStore
import com.movielink.app.core.adblock.AdBlockerEngine
import com.movielink.app.core.designsystem.EmptyStateCard
import com.movielink.app.core.designsystem.LocalMovieLinkColors
import com.movielink.app.core.designsystem.MovieLinkCard
import com.movielink.app.core.designsystem.MovieLinkRadius
import com.movielink.app.core.designsystem.PrimaryActionButton
import com.movielink.app.core.designsystem.SecondaryActionButton
import com.movielink.app.core.designsystem.SubtleHairlineDivider
import com.movielink.app.core.downloads.DownloadRouter
import com.movielink.app.core.integrations.IntegrationsStore
import com.movielink.app.core.model.ProviderId
import com.movielink.app.core.sources.MirrorProbeResult
import com.movielink.app.core.sources.ProviderHealthStatus
import com.movielink.app.core.sources.WebsiteSourceConfig
import com.movielink.app.core.sources.WebsiteSourcesRepository
import com.movielink.app.core.sources.WebsiteSourcesStore
import com.movielink.app.core.state.AppUiStateStore
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DiagnosticsSettingsContent(
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    val context = LocalContext.current
    val configs by WebsiteSourcesStore.configs.collectAsStateWithLifecycle()
    val probes by WebsiteSourcesStore.probeResults.collectAsStateWithLifecycle()
    val events by WebsiteSourcesStore.diagnostics.collectAsStateWithLifecycle()
    val adSettings by AdBlockStore.settings.collectAsStateWithLifecycle()
    val blockedCount by AdBlockerEngine.sessionBlockedCount.collectAsStateWithLifecycle()
    val integSettings by IntegrationsStore.settings.collectAsStateWithLifecycle()
    val libraryState by AppUiStateStore.library.collectAsStateWithLifecycle()
    val managers = remember { DownloadRouter.detectInstalledManagers(context) }
    val scope = rememberCoroutineScope()
    val timeFormatter = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item(key = "actions") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                PrimaryActionButton(
                    text = "Run Health Check",
                    icon = Icons.Rounded.NetworkCheck,
                    onClick = {
                        scope.launch { WebsiteSourcesRepository.probeAllEnabledProviders() }
                    },
                    modifier = Modifier.weight(1f)
                )
                SecondaryActionButton(
                    text = "Clear Log",
                    icon = Icons.Rounded.DeleteSweep,
                    onClick = { WebsiteSourcesStore.clearDiagnostics() },
                    modifier = Modifier.weight(0.7f)
                )
            }
        }

        item(key = "health_matrix") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Provider Health Summary",
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                    ProviderId.entries.forEachIndexed { index, provider ->
                        val cfg = configs[provider] ?: WebsiteSourceConfig(provider)
                        val probe = probes[provider] ?: MirrorProbeResult(url = cfg.activeBaseUrl)
                        val effectiveStatus = if (!cfg.enabled) ProviderHealthStatus.DISABLED else probe.status
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${provider.displayName} (${provider.shortLabel})",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = colors.textPrimary
                                )
                                Text(
                                    text = cfg.activeBaseUrl,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = colors.textSecondary
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = effectiveStatus.label,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = when (effectiveStatus) {
                                        ProviderHealthStatus.ONLINE -> Color(0xFF4ADE80)
                                        ProviderHealthStatus.UNREACHABLE -> colors.danger
                                        else -> colors.textSecondary
                                    }
                                )
                                if (probe.latencyMs > 0L) {
                                    Text(
                                        text = "${probe.latencyMs} ms" + (probe.httpCode?.let { " • HTTP $it" } ?: ""),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = colors.textTertiary
                                    )
                                }
                            }
                        }
                        if (index < ProviderId.entries.lastIndex) {
                            SubtleHairlineDivider(modifier = Modifier.padding(horizontal = 16.dp))
                        }
                    }
                }
            }
        }

        item(key = "runtime_subsystems") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Runtime Subsystems & Counters",
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        StorageStatLine(
                            label = "Ad Blocking",
                            value = if (adSettings.globalEnabled) {
                                "Active • $blockedCount blocked this session"
                            } else {
                                "Disabled"
                            }
                        )
                        SubtleHairlineDivider()
                        StorageStatLine(
                            label = "Metadata Enrichment",
                            value = if (integSettings.hasAnyMetadataSource || integSettings.hasAnyArtworkSource) {
                                "Configured"
                            } else {
                                "Website Data Only"
                            }
                        )
                        SubtleHairlineDivider()
                        StorageStatLine(
                            label = "Room Library Store",
                            value = "${libraryState.watchlistItems.size} list • ${libraryState.visitHistory.size} history • ${libraryState.continueWatching.size} resume"
                        )
                        SubtleHairlineDivider()
                        StorageStatLine(
                            label = "Download Managers",
                            value = buildList {
                                if (managers.has1dmOrIdm) add("1DM/IDM")
                                if (managers.hasAdm) add("ADM")
                            }.ifEmpty { listOf("System DownloadManager") }.joinToString(" • ")
                        )
                    }
                }
            }
        }

        item(key = "events_heading") {
            Text(
                text = "Recent Source Events (${events.size})",
                style = MaterialTheme.typography.titleSmall,
                color = colors.textSecondary,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
        }

        if (events.isEmpty()) {
            item(key = "empty_events") {
                EmptyStateCard(
                    title = "No diagnostics events recorded yet",
                    description = "Run a health check or switch mirrors in Website Sources to view live latency and redirect logs.",
                    icon = Icons.Rounded.NetworkCheck
                )
            }
        } else {
            items(events, key = { it.id }) { event ->
                MovieLinkCard(
                    cornerRadius = MovieLinkRadius.Sm,
                    borderColor = if (event.isError) colors.danger.copy(alpha = 0.4f) else colors.borderSubtle
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = event.providerId.displayName,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (event.isError) colors.danger else colors.accent
                            )
                            Text(
                                text = timeFormatter.format(Date(event.timestampMs)),
                                style = MaterialTheme.typography.labelSmall,
                                color = colors.textTertiary
                            )
                        }
                        Text(
                            text = event.message,
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textPrimary
                        )
                    }
                }
            }
        }

        item { Spacer(Modifier.height(10.dp)) }
    }
}
