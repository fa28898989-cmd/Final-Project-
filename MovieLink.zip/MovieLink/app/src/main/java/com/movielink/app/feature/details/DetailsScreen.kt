package com.movielink.app.feature.details

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.heightIn
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.SubcomposeAsyncImage
import com.movielink.app.core.designsystem.EdgeToEdgeHeroScrim
import com.movielink.app.core.designsystem.LocalMovieLinkColors
import com.movielink.app.core.designsystem.MediaArtwork
import com.movielink.app.core.designsystem.MovieLinkRadius
import com.movielink.app.core.designsystem.PrimaryActionButton
import com.movielink.app.core.designsystem.SecondaryActionButton
import com.movielink.app.core.downloads.DownloadRouter
import com.movielink.app.core.integrations.IntegrationsStore
import com.movielink.app.core.integrations.MetadataEnrichmentEngine
import com.movielink.app.core.model.MediaDetail
import com.movielink.app.core.model.MediaSummary
import com.movielink.app.core.model.ProviderId
import com.movielink.app.core.player.AdBlockedWebViewDialog
import com.movielink.app.core.sources.WebsiteSourcesRepository
import com.movielink.app.core.sources.providers.CloudflareChallengeException
import com.movielink.app.core.state.AppUiStateStore
import com.movielink.app.core.state.DownloadRouterMode
import com.movielink.app.core.state.UserPreferencesStore
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DetailsScreen(
    providerId: String,
    mediaId: String,
    onBack: () -> Unit,
    onOpenRelated: (MediaSummary) -> Unit,
    onPlayStreamUrl: (url: String, title: String) -> Unit = { _, _ -> },
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    val context = LocalContext.current
    val appearance by AppUiStateStore.appearance.collectAsStateWithLifecycle()
    val libraryState by AppUiStateStore.library.collectAsStateWithLifecycle()
    val integrationSettings by IntegrationsStore.settings.collectAsStateWithLifecycle()

    val provider = remember(providerId) { ProviderId.fromId(providerId) }
    var loadedDetail by remember(mediaId, provider) { mutableStateOf<MediaDetail?>(null) }
    var enrichedDetail by remember(mediaId, provider) { mutableStateOf<MediaDetail?>(null) }
    var showOriginalData by remember(mediaId, provider) { mutableStateOf(false) }
    var loadError by remember(mediaId, provider) { mutableStateOf<String?>(null) }
    var cloudflareChallengeUrl by remember(mediaId, provider) { mutableStateOf<String?>(null) }
    var showCloudflareDialog by remember { mutableStateOf(false) }
    var retryNonce by remember { mutableIntStateOf(0) }

    LaunchedEffect(mediaId, provider, retryNonce) {
        loadError = null
        cloudflareChallengeUrl = null
        WebsiteSourcesRepository.loadDetails(provider, mediaId)
            .onSuccess { result ->
                loadedDetail = result
                enrichedDetail = null
                showOriginalData = false
                AppUiStateStore.recordVisit(result.summary)
            }
            .onFailure { err ->
                if (err is CloudflareChallengeException) {
                    cloudflareChallengeUrl = err.challengeUrl
                    loadError = "Security verification is required to open this title on ${provider.displayName}."
                } else {
                    loadError = err.message ?: "Unable to load title details"
                }
            }
    }

    LaunchedEffect(loadedDetail, integrationSettings) {
        val base = loadedDetail ?: return@LaunchedEffect
        if (!integrationSettings.artworkEnrichmentEnabled && !integrationSettings.metadataEnrichmentEnabled) {
            enrichedDetail = null
            return@LaunchedEffect
        }
        val enriched = MetadataEnrichmentEngine.enrichDetail(base)
        enrichedDetail = enriched.takeIf { it.enrichedBy.isNotEmpty() }
    }

    if (showCloudflareDialog && cloudflareChallengeUrl != null) {
        AdBlockedWebViewDialog(
            initialUrl = cloudflareChallengeUrl!!,
            title = provider.displayName,
            providerId = provider,
            isCloudflareChallenge = true,
            onCloudflareSolved = {
                showCloudflareDialog = false
                cloudflareChallengeUrl = null
                retryNonce++
            },
            onDismiss = { showCloudflareDialog = false }
        )
    }

    val detail = if (!showOriginalData && enrichedDetail != null) enrichedDetail else loadedDetail
    if (detail == null) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(colors.background)
                .statusBarsPadding()
                .padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            if (loadError != null) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "${provider.displayName} Error",
                        style = MaterialTheme.typography.titleLarge,
                        color = colors.textPrimary
                    )
                    Text(
                        text = loadError!!,
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.textSecondary,
                        textAlign = TextAlign.Center
                    )
                    if (cloudflareChallengeUrl != null) {
                        PrimaryActionButton(
                            text = "Verify Security Check",
                            onClick = { showCloudflareDialog = true },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SecondaryActionButton(
                            text = "Back",
                            onClick = onBack,
                            modifier = Modifier.weight(1f)
                        )
                        if (cloudflareChallengeUrl != null) {
                            SecondaryActionButton(
                                text = "Retry",
                                onClick = { retryNonce++ },
                                modifier = Modifier.weight(1f)
                            )
                        } else {
                            PrimaryActionButton(
                                text = "Retry",
                                onClick = { retryNonce++ },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            } else {
                CircularProgressIndicator(color = colors.accent)
            }
        }
        return
    }

    val summary = detail.summary
    val isInWatchlist = summary.id in libraryState.watchlistIds
    val isWatched = summary.id in libraryState.watchedIds

    var selectedSource by remember(detail) { mutableStateOf(detail.sources.firstOrNull().orEmpty()) }
    var showSourcesMenu by remember { mutableStateOf(false) }
    var showScreenshotsModal by remember { mutableStateOf(false) }
    var webViewTarget by remember { mutableStateOf<Pair<String, String>?>(null) }
    var pendingDownloadTarget by remember { mutableStateOf<Pair<String, String>?>(null) }

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val openHttpOrDirect: (String, String) -> Unit = { url, title ->
        val clean = url.substringBefore('?').lowercase()
        val isDirectStream = clean.endsWith(".mp4") ||
            clean.endsWith(".m3u8") ||
            clean.endsWith(".mkv") ||
            clean.endsWith(".webm")
        if (isDirectStream) {
            onPlayStreamUrl(url, title)
        } else {
            webViewTarget = url to title
        }
    }

    val dispatchDownload: (String, String) -> Unit = { url, label ->
        val dlPrefs = UserPreferencesStore.state.value.downloads
        when (dlPrefs.routerMode) {
            DownloadRouterMode.ASK_EACH_TIME -> {
                pendingDownloadTarget = url to label
            }
            DownloadRouterMode.EXTERNAL_1DM -> {
                val res = DownloadRouter.sendTo1dmOrIdm(context, url, label)
                if (!res.launched && dlPrefs.fallbackToInAppResolver) {
                    webViewTarget = url to label
                }
                scope.launch { snackbarHostState.showSnackbar(res.message) }
            }
            DownloadRouterMode.EXTERNAL_ADM -> {
                val res = DownloadRouter.sendToAdm(context, url, label)
                if (!res.launched && dlPrefs.fallbackToInAppResolver) {
                    webViewTarget = url to label
                }
                scope.launch { snackbarHostState.showSnackbar(res.message) }
            }
            DownloadRouterMode.SYSTEM_DOWNLOADER -> {
                if (DownloadRouter.isLikelyDirectFile(url)) {
                    val res = DownloadRouter.enqueueSystemDownload(context, url, label)
                    scope.launch { snackbarHostState.showSnackbar(res.message) }
                } else {
                    webViewTarget = url to label
                }
            }
            DownloadRouterMode.IN_APP_BROWSER -> {
                webViewTarget = url to label
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = colors.background,
        snackbarHost = {
            SnackbarHost(
                hostState = snackbarHostState,
                modifier = Modifier.navigationBarsPadding()
            )
        }
    ) { _ ->
        val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(colors.background),
            contentPadding = PaddingValues(bottom = 36.dp + navBottom),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // 1. Full Cinematic Hero Artwork + Title Logo + Metadata
            item(key = "hero_header") {
                Column(modifier = Modifier.fillMaxWidth()) {
                    EdgeToEdgeHeroScrim(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(appearance.detailsHeroHeightDp.dp)
                    ) {
                        MediaArtwork(
                            media = summary,
                            isBackdrop = true,
                            showEmbeddedTitle = false,
                            modifier = Modifier.fillMaxSize()
                        )

                        IconButton(
                            onClick = onBack,
                            modifier = Modifier
                                .statusBarsPadding()
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.45f))
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }

                        // Stylized title logo / clearlogo artwork centered over bottom fade
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(horizontal = 24.dp, vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            val titleFallback: @Composable () -> Unit = {
                                Text(
                                    text = summary.title.uppercase(),
                                    color = Color.White,
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                            if (summary.titleLogoUrl.startsWith("http", ignoreCase = true)) {
                                SubcomposeAsyncImage(
                                    model = summary.titleLogoUrl,
                                    contentDescription = summary.title,
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier
                                        .fillMaxWidth(0.76f)
                                        .heightIn(max = 82.dp),
                                    loading = { titleFallback() },
                                    error = { titleFallback() }
                                )
                            } else {
                                titleFallback()
                            }
                        }
                    }

                    // Rating, year, runtime, certification & genres
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (summary.rating.isNotBlank()) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFFF5C518))
                                        .padding(horizontal = 5.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = "IMDb",
                                        color = Color.Black,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                                Text(
                                    text = summary.rating,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.textPrimary
                                )
                            }

                            val extraMeta = listOf(summary.year, summary.runtime, summary.certification)
                                .filter { it.isNotBlank() }
                            if (extraMeta.isNotEmpty()) {
                                Text(
                                    text = "•  " + extraMeta.joinToString("  •  "),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = colors.textSecondary
                                )
                            }
                        }

                        if (summary.genres.isNotEmpty()) {
                            Text(
                                text = summary.genres.joinToString(" / "),
                                style = MaterialTheme.typography.bodyMedium,
                                color = colors.textSecondary,
                                textAlign = TextAlign.Center
                            )
                        }

                        if (detail.externalRatings.isNotEmpty() || enrichedDetail != null) {
                            FlowRow(
                                modifier = Modifier.padding(top = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                detail.externalRatings.forEach { r ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(colors.surface)
                                            .border(1.dp, colors.borderSubtle, RoundedCornerShape(6.dp))
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Text(
                                            text = "${r.label} ${r.value}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = colors.textPrimary
                                        )
                                    }
                                }
                                enrichedDetail?.let { enriched ->
                                    val label = if (showOriginalData) {
                                        "Original (${provider.displayName}) • Use Enriched"
                                    } else {
                                        "Enriched (${enriched.enrichedBy.joinToString(", ")}) • View Original"
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(colors.surfaceElevated)
                                            .border(1.dp, colors.accent.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
                                            .clickable { showOriginalData = !showOriginalData }
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Text(
                                            text = label,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = colors.accent
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 2. Primary Play & Sources + Secondary Icon Actions
            item(key = "actions") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        PrimaryActionButton(
                            text = "Play",
                            icon = Icons.Rounded.PlayArrow,
                            onClick = {
                                AppUiStateStore.simulatePlay(summary)
                                val matchedLink = detail.downloadLinks.firstOrNull {
                                    it.label.equals(selectedSource, ignoreCase = true) ||
                                        it.quality.equals(selectedSource, ignoreCase = true) ||
                                        it.formatTag.equals(selectedSource, ignoreCase = true)
                                }
                                val targetUrl = listOfNotNull(
                                    matchedLink?.watchUrl?.takeIf { it.startsWith("http", true) },
                                    detail.watchEmbedUrl?.takeIf { it.startsWith("http", true) },
                                    matchedLink?.url?.takeIf { it.startsWith("http", true) },
                                    detail.downloadLinks.firstOrNull { it.watchUrl.isNotBlank() }?.watchUrl,
                                    detail.downloadLinks.firstOrNull { it.url.startsWith("http", true) }?.url,
                                    summary.sourceUrl.takeIf { it.startsWith("http", true) }
                                ).firstOrNull()
                                if (targetUrl != null) {
                                    openHttpOrDirect(targetUrl, summary.title)
                                } else {
                                    scope.launch {
                                        snackbarHostState.showSnackbar("Playing via $selectedSource (sample)")
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )

                        Box(modifier = Modifier.weight(1f)) {
                            SecondaryActionButton(
                                text = "Sources",
                                icon = Icons.Rounded.Layers,
                                onClick = { showSourcesMenu = true },
                                modifier = Modifier.fillMaxWidth()
                            )
                            DropdownMenu(
                                expanded = showSourcesMenu,
                                onDismissRequest = { showSourcesMenu = false },
                                modifier = Modifier.background(colors.surfaceElevated)
                            ) {
                                detail.sources.forEach { src ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                text = src,
                                                color = if (src == selectedSource) colors.accent else colors.textPrimary
                                            )
                                        },
                                        trailingIcon = {
                                            if (src == selectedSource) {
                                                Icon(
                                                    imageVector = Icons.Rounded.KeyboardArrowDown,
                                                    contentDescription = null,
                                                    tint = colors.accent
                                                )
                                            }
                                        },
                                        onClick = {
                                            selectedSource = src
                                            showSourcesMenu = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        DetailQuickAction(
                            icon = Icons.Rounded.Movie,
                            label = "Trailer",
                            active = false,
                            onClick = {
                                val tUrl = detail.trailerUrl
                                if (!tUrl.isNullOrBlank() && tUrl.startsWith("http", ignoreCase = true)) {
                                    try {
                                        context.startActivity(
                                            Intent(Intent.ACTION_VIEW, Uri.parse(tUrl)).apply {
                                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                            }
                                        )
                                    } catch (_: Exception) {
                                        webViewTarget = tUrl to "${summary.title} • Trailer"
                                    }
                                } else {
                                    scope.launch {
                                        snackbarHostState.showSnackbar("No trailer available on ${provider.displayName}")
                                    }
                                }
                            }
                        )
                        DetailQuickAction(
                            icon = if (isWatched) Icons.Rounded.Visibility else Icons.Outlined.Visibility,
                            label = if (isWatched) "Watched" else "Mark Watched",
                            active = isWatched,
                            onClick = { AppUiStateStore.toggleWatched(summary) }
                        )
                        DetailQuickAction(
                            icon = if (isInWatchlist) Icons.Rounded.Bookmark else Icons.Outlined.BookmarkBorder,
                            label = if (isInWatchlist) "In Watchlist" else "Add to Watchlist",
                            active = isInWatchlist,
                            onClick = { AppUiStateStore.toggleWatchlist(summary) }
                        )
                    }
                }
            }

            // 3. Overview / Plot
            if (detail.overview.isNotBlank()) {
                item(key = "overview") {
                    Text(
                        text = detail.overview,
                        style = MaterialTheme.typography.bodyLarge,
                        color = colors.textPrimary.copy(alpha = 0.9f),
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            }

            // 4. Screenshots immediately after Overview
            if (detail.screenshots.isNotEmpty()) {
                item(key = "screenshots") {
                    ScreenshotsPreviewCard(
                        summary = summary,
                        screenshotCount = detail.screenshots.size,
                        previewImageUrl = detail.screenshots.firstOrNull(),
                        onClick = { showScreenshotsModal = true }
                    )
                }
            }

            // 5. Movie Details key-value table
            if (detail.infoFields.isNotEmpty()) {
                item(key = "movie_details") {
                    MovieDetailsTableSection(fields = detail.infoFields)
                }
            }

            // 6. Seasons & Episodes (for Series)
            if (detail.seasons.isNotEmpty()) {
                item(key = "seasons") {
                    SeasonsAndEpisodesSection(
                        seasons = detail.seasons,
                        onPlayEpisode = { epLabel ->
                            AppUiStateStore.simulatePlay(summary, epLabel)
                            val epNum = epLabel.substringAfter("E", "").toIntOrNull()
                            val ep = detail.seasons
                                .flatMap { it.episodes }
                                .firstOrNull { it.number == epNum }
                            val epUrl = ep?.downloads?.firstOrNull()?.let { dl ->
                                dl.watchUrl?.takeIf { it.startsWith("http", true) }
                                    ?: dl.url.takeIf { it.startsWith("http", true) }
                            }
                            if (epUrl != null) {
                                openHttpOrDirect(epUrl, "${summary.title} • $epLabel")
                            } else {
                                scope.launch {
                                    snackbarHostState.showSnackbar("Playing $epLabel (sample)")
                                }
                            }
                        },
                        onDownloadEpisode = { dl ->
                            if (dl.url.startsWith("http", ignoreCase = true)) {
                                dispatchDownload(dl.url, "${summary.title} • ${dl.label}")
                            } else {
                                scope.launch {
                                    snackbarHostState.showSnackbar("Selected ${dl.label}")
                                }
                            }
                        }
                    )
                }
            }

            // 7. Download Links
            if (detail.downloadLinks.isNotEmpty()) {
                item(key = "downloads") {
                    DownloadLinksSection(
                        links = detail.downloadLinks,
                        onLinkClick = { link ->
                            if (link.url.startsWith("http", ignoreCase = true)) {
                                dispatchDownload(link.url, "${summary.title} • ${link.label}")
                            } else {
                                scope.launch {
                                    snackbarHostState.showSnackbar("Selected ${link.label} (${provider.displayName})")
                                }
                            }
                        }
                    )
                }
            }

            // 8. Cast
            if (detail.cast.isNotEmpty()) {
                item(key = "cast") {
                    CastRailSection(cast = detail.cast)
                }
            }

            // 9. More Like This
            if (detail.recommendations.isNotEmpty()) {
                item(key = "recommendations") {
                    MoreLikeThisSection(
                        items = detail.recommendations,
                        onMediaClick = onOpenRelated
                    )
                }
            }

            item { Spacer(Modifier.height(12.dp)) }
        }
    }

    if (showScreenshotsModal) {
        ScreenshotViewerDialog(
            summary = summary,
            screenshots = detail.screenshots,
            onDismiss = { showScreenshotsModal = false }
        )
    }

    webViewTarget?.let { (targetUrl, targetTitle) ->
        AdBlockedWebViewDialog(
            initialUrl = targetUrl,
            title = targetTitle,
            providerId = provider,
            isCloudflareChallenge = false,
            onPlayDirectVideoUrl = { directUrl ->
                onPlayStreamUrl(directUrl, targetTitle)
            },
            onDismiss = { webViewTarget = null }
        )
    }

    pendingDownloadTarget?.let { (dlUrl, dlTitle) ->
        val managers = remember(dlUrl) { DownloadRouter.detectInstalledManagers(context) }
        AlertDialog(
            onDismissRequest = { pendingDownloadTarget = null },
            containerColor = colors.surfaceElevated,
            title = {
                Text(
                    text = "Open Download With",
                    color = colors.textPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = dlTitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                    DownloadOptionRow(
                        title = if (managers.has1dmOrIdm) "1DM / IDM (Installed)" else "1DM / IDM",
                        subtitle = if (managers.has1dmOrIdm) "Send link directly to 1DM/IDM" else "Not detected on device",
                        onClick = {
                            pendingDownloadTarget = null
                            val res = DownloadRouter.sendTo1dmOrIdm(context, dlUrl, dlTitle)
                            scope.launch { snackbarHostState.showSnackbar(res.message) }
                        }
                    )
                    DownloadOptionRow(
                        title = if (managers.hasAdm) "ADM (Installed)" else "ADM",
                        subtitle = if (managers.hasAdm) "Send link directly to ADM" else "Not detected on device",
                        onClick = {
                            pendingDownloadTarget = null
                            val res = DownloadRouter.sendToAdm(context, dlUrl, dlTitle)
                            scope.launch { snackbarHostState.showSnackbar(res.message) }
                        }
                    )
                    if (DownloadRouter.isLikelyDirectFile(dlUrl)) {
                        DownloadOptionRow(
                            title = "Android Download Manager",
                            subtitle = "Queue direct file into Downloads folder",
                            onClick = {
                                pendingDownloadTarget = null
                                val res = DownloadRouter.enqueueSystemDownload(context, dlUrl, dlTitle)
                                scope.launch { snackbarHostState.showSnackbar(res.message) }
                            }
                        )
                    }
                    DownloadOptionRow(
                        title = "Ad-Blocked Resolver Browser",
                        subtitle = "Resolve protected hosts with built-in ad blocker",
                        onClick = {
                            pendingDownloadTarget = null
                            webViewTarget = dlUrl to dlTitle
                        }
                    )
                    DownloadOptionRow(
                        title = "Copy Link",
                        subtitle = "Copy download URL to clipboard",
                        onClick = {
                            pendingDownloadTarget = null
                            DownloadRouter.copyToClipboard(context, dlTitle, dlUrl)
                            scope.launch { snackbarHostState.showSnackbar("Download URL copied") }
                        }
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { pendingDownloadTarget = null }) {
                    Text("Close", color = colors.textSecondary)
                }
            }
        )
    }
}

@Composable
private fun DownloadOptionRow(
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    val colors = LocalMovieLinkColors.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(MovieLinkRadius.Sm))
            .background(colors.surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(title, style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
        Text(subtitle, style = MaterialTheme.typography.labelSmall, color = colors.textSecondary)
    }
}

@Composable
private fun DetailQuickAction(
    icon: ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit
) {
    val colors = LocalMovieLinkColors.current
    val tint = if (active) colors.accent else colors.textPrimary
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(MovieLinkRadius.Sm))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = tint,
            modifier = Modifier.size(22.dp)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = if (active) colors.accent else colors.textSecondary
        )
    }
}
