package com.movielink.app.core.player

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.movielink.app.core.designsystem.LocalMovieLinkColors
import com.movielink.app.core.localmedia.PlayerMediaRequest
import com.movielink.app.core.state.UserPreferencesStore
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.pow

@OptIn(UnstableApi::class)
@Composable
fun MovieLinkPlayerScreen(
    request: PlayerMediaRequest,
    onSaveProgress: (uri: String, title: String, positionMs: Long, durationMs: Long) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val lifecycleOwner = LocalLifecycleOwner.current
    val colors = LocalMovieLinkColors.current

    val audioManager = remember {
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }
    val maxVolume = remember { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    val userPrefs by UserPreferencesStore.state.collectAsStateWithLifecycle()
    val playbackPrefs = userPrefs.playback
    val seekStepMs = playbackPrefs.seekStepSeconds * 1000L

    var showControls by remember { mutableStateOf(true) }
    var isLocked by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(true) }
    var isBuffering by remember { mutableStateOf(true) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var positionMs by remember {
        mutableLongStateOf(if (playbackPrefs.resumePlaybackEnabled) request.resumePositionMs.coerceAtLeast(0L) else 0L)
    }
    var playbackSpeed by remember { mutableFloatStateOf(playbackPrefs.defaultSpeed) }
    var resizeModeIndex by remember { mutableIntStateOf(playbackPrefs.defaultResizeModeIndex) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    var audioTracks by remember { mutableStateOf<List<SelectableTrackOption>>(emptyList()) }
    var subtitleTracks by remember { mutableStateOf<List<SelectableTrackOption>>(emptyList()) }
    var subtitlesDisabled by remember { mutableStateOf(false) }

    var showSpeedDialog by remember { mutableStateOf(false) }
    var showAudioDialog by remember { mutableStateOf(false) }
    var showSubtitleDialog by remember { mutableStateOf(false) }
    val latestDurationMs by rememberUpdatedState(durationMs)

    // Gesture HUD state
    var brightnessLevel by remember { mutableFloatStateOf(0.65f) }
    var volumeLevel by remember {
        mutableFloatStateOf(
            audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVolume.toFloat()
        )
    }
    var activeHud by remember { mutableStateOf<String?>(null) }
    var seekPreviewTargetMs by remember { mutableLongStateOf(0L) }
    var seekPreviewDeltaMs by remember { mutableLongStateOf(0L) }

    val initialCutoutMode = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            activity?.window?.attributes?.layoutInDisplayCutoutMode
                ?: WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
        } else {
            0
        }
    }

    fun applyWindowBrightness(linear: Float?) {
        val window = activity?.window ?: return
        val lp = window.attributes
        lp.screenBrightness = if (linear == null) {
            WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        } else {
            linear.coerceIn(0.01f, 1.0f)
        }
        window.attributes = lp
    }

    LaunchedEffect(Unit) {
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
    }

    fun applyFullscreen(enable: Boolean) {
        val window = activity?.window ?: return
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (enable) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val lp = window.attributes
                lp.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                } else {
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
                window.attributes = lp
            }
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val lp = window.attributes
                lp.layoutInDisplayCutoutMode = initialCutoutMode
                window.attributes = lp
            }
            controller.show(WindowInsetsCompat.Type.systemBars())
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    val exoPlayer = remember(request.uri) {
        val renderersFactory = DefaultRenderersFactory(context)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
        val trackSelector = DefaultTrackSelector(context)
        val audioAttributes = AudioAttributes.Builder()
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .setUsage(C.USAGE_MEDIA)
            .build()

        ExoPlayer.Builder(context, renderersFactory)
            .setTrackSelector(trackSelector)
            .setAudioAttributes(audioAttributes, true)
            .build()
            .apply {
                setMediaItem(
                    PlaybackTrackUtils.buildMediaItem(request.uri, request.title)
                )
                playbackParameters = PlaybackParameters(playbackPrefs.defaultSpeed)
                if (playbackPrefs.resumePlaybackEnabled && request.resumePositionMs > 5_000L) {
                    seekTo(request.resumePositionMs)
                }
                prepare()
                playWhenReady = true
            }
    }

    val subtitlePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { subUri ->
        if (subUri != null) {
            val currentPos = exoPlayer.currentPosition.coerceAtLeast(0L)
            val mime = PlaybackTrackUtils.guessSubtitleMime(context, subUri)
            exoPlayer.setMediaItem(
                PlaybackTrackUtils.buildMediaItem(
                    uri = request.uri,
                    title = request.title,
                    externalSubtitleUri = subUri,
                    externalSubtitleMime = mime
                )
            )
            exoPlayer.seekTo(currentPos)
            exoPlayer.prepare()
            exoPlayer.playWhenReady = true
            subtitlesDisabled = false
        }
    }

    fun persistCurrentProgress() {
        val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
        val dur = exoPlayer.duration.coerceAtLeast(0L)
        if (dur > 0L || pos > 0L) {
            onSaveProgress(request.uri.toString(), request.title, pos, dur)
        }
    }

    DisposableEffect(Unit) {
        if (playbackPrefs.autoFullscreen) applyFullscreen(true)
        onDispose {
            persistCurrentProgress()
            applyWindowBrightness(null)
            if (playbackPrefs.autoFullscreen) applyFullscreen(false)
        }
    }

    DisposableEffect(lifecycleOwner, exoPlayer) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> {
                    persistCurrentProgress()
                    exoPlayer.pause()
                }
                Lifecycle.Event.ON_RESUME -> if (playbackPrefs.autoFullscreen) applyFullscreen(true)
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                isBuffering = playbackState == Player.STATE_BUFFERING
                val dur = exoPlayer.duration.coerceAtLeast(0L)
                if (dur > 0L) durationMs = dur
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onTracksChanged(tracks: Tracks) {
                audioTracks = PlaybackTrackUtils.extractTracks(tracks, C.TRACK_TYPE_AUDIO)
                subtitleTracks = PlaybackTrackUtils.extractTracks(tracks, C.TRACK_TYPE_TEXT)
                subtitlesDisabled = exoPlayer.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
            }

            override fun onPlayerError(error: PlaybackException) {
                errorMessage = "Playback failed (${error.errorCodeName}). Some MKV/AVI audio or video codecs may not be supported by this device's built-in decoders."
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    LaunchedEffect(exoPlayer) {
        var tick = 0
        while (true) {
            positionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
            val dur = exoPlayer.duration.coerceAtLeast(0L)
            if (dur > 0L) durationMs = dur
            tick++
            if (tick % 4 == 0 && isPlaying) {
                persistCurrentProgress()
            }
            delay(500)
        }
    }

    LaunchedEffect(showControls, isPlaying, isLocked) {
        if (showControls && isPlaying && !isLocked) {
            delay(3500)
            showControls = false
        }
    }

    LaunchedEffect(activeHud) {
        if (activeHud != null && activeHud != "seek") {
            delay(1100)
            activeHud = null
        }
    }

    BackHandler {
        persistCurrentProgress()
        onClose()
    }

    val resizeModes = listOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT to "Fit",
        AspectRatioFrameLayout.RESIZE_MODE_FILL to "Stretch",
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM to "Zoom"
    )
    val activeResize = resizeModes[resizeModeIndex % resizeModes.size]

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    keepScreenOn = true
                    resizeMode = activeResize.first
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { pv ->
                pv.resizeMode = activeResize.first
            }
        )

        // Tap & Gesture Overlay (Double-tap seek, Vertical Brightness/Volume, Horizontal Seek)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(isLocked, playbackPrefs.gesturesEnabled, seekStepMs) {
                    detectTapGestures(
                        onTap = {
                            showControls = !showControls
                        },
                        onDoubleTap = { offset ->
                            if (isLocked || !playbackPrefs.gesturesEnabled) return@detectTapGestures
                            val isLeft = offset.x < size.width / 2f
                            val delta = if (isLeft) -seekStepMs else seekStepMs
                            val target = (exoPlayer.currentPosition + delta)
                                .coerceIn(0L, latestDurationMs.coerceAtLeast(exoPlayer.currentPosition + seekStepMs))
                            exoPlayer.seekTo(target)
                            positionMs = target
                            seekPreviewTargetMs = target
                            seekPreviewDeltaMs = delta
                            activeHud = "seek"
                        }
                    )
                }
                .pointerInput(isLocked, playbackPrefs.gesturesEnabled) {
                    if (isLocked || !playbackPrefs.gesturesEnabled) return@pointerInput
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val startPos = down.position
                        var mode = "" // "bright", "vol", "seek"
                        var lastPos = startPos
                        val initialSeekBase = exoPlayer.currentPosition.coerceAtLeast(0L)
                        var currentTarget = initialSeekBase

                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull { it.id == down.id } ?: break
                            if (!change.pressed) {
                                if (mode == "seek") {
                                    exoPlayer.seekTo(currentTarget)
                                    positionMs = currentTarget
                                    activeHud = null
                                }
                                break
                            }
                            val totalDx = change.position.x - startPos.x
                            val totalDy = change.position.y - startPos.y
                            if (mode.isEmpty()) {
                                if (abs(totalDx) > 28f || abs(totalDy) > 28f) {
                                    mode = if (abs(totalDx) > abs(totalDy)) {
                                        "seek"
                                    } else if (startPos.x < size.width / 2f) {
                                        "bright"
                                    } else {
                                        "vol"
                                    }
                                }
                            }
                            if (mode.isNotEmpty()) {
                                change.consume()
                                val stepDy = change.position.y - lastPos.y
                                when (mode) {
                                    "bright" -> {
                                        val next = (brightnessLevel - (stepDy / size.height.toFloat()) * 1.3f)
                                            .coerceIn(0f, 1f)
                                        brightnessLevel = next
                                        applyWindowBrightness(next)
                                        activeHud = "bright"
                                    }
                                    "vol" -> {
                                        val next = (volumeLevel - (stepDy / size.height.toFloat()) * 1.3f)
                                            .coerceIn(0f, 1f)
                                        volumeLevel = next
                                        val volInt = (next * maxVolume).toInt().coerceIn(0, maxVolume)
                                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, volInt, 0)
                                        activeHud = "vol"
                                    }
                                    "seek" -> {
                                        val maxDur = latestDurationMs.coerceAtLeast(1L)
                                        val delta = ((totalDx / size.width.toFloat()) * 90_000f).toLong()
                                        currentTarget = (initialSeekBase + delta).coerceIn(0L, maxDur)
                                        seekPreviewTargetMs = currentTarget
                                        seekPreviewDeltaMs = currentTarget - initialSeekBase
                                        activeHud = "seek"
                                    }
                                }
                            }
                            lastPos = change.position
                        }
                    }
                }
        )

        if (isBuffering && errorMessage == null) {
            CircularProgressIndicator(
                color = colors.accent,
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(44.dp)
            )
        }

        // Gesture HUDs
        when (activeHud) {
            "bright" -> VerticalMeterHud(
                isBrightness = true,
                level = brightnessLevel,
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 24.dp)
            )
            "vol" -> VerticalMeterHud(
                isBrightness = false,
                level = volumeLevel,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 24.dp)
            )
            "seek" -> SeekPreviewHud(
                targetPositionMs = seekPreviewTargetMs,
                deltaMs = seekPreviewDeltaMs,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        if (showControls) {
            if (isLocked) {
                IconButton(
                    onClick = { isLocked = false },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 20.dp, end = 20.dp)
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.65f))
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Lock,
                        contentDescription = "Unlock player",
                        tint = colors.accent
                    )
                }
            } else {
                PlayerTopBar(
                    title = request.title,
                    subtitle = request.subtitle,
                    isLocked = false,
                    resizeLabel = activeResize.second,
                    onBack = {
                        persistCurrentProgress()
                        onClose()
                    },
                    onToggleLock = { isLocked = true },
                    onCycleResize = { resizeModeIndex++ },
                    modifier = Modifier.align(Alignment.TopCenter)
                )

                if (errorMessage == null && !isBuffering) {
                    PlayerCenterControls(
                        isPlaying = isPlaying,
                        onRewind = {
                            val target = (exoPlayer.currentPosition - seekStepMs).coerceAtLeast(0L)
                            exoPlayer.seekTo(target)
                            positionMs = target
                        },
                        onPlayPause = {
                            if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                        },
                        onForward = {
                            val maxDur = durationMs.coerceAtLeast(exoPlayer.currentPosition + seekStepMs)
                            val target = (exoPlayer.currentPosition + seekStepMs).coerceAtMost(maxDur)
                            exoPlayer.seekTo(target)
                            positionMs = target
                        },
                        modifier = Modifier.align(Alignment.Center)
                    )
                }

                PlayerBottomControls(
                    positionMs = positionMs,
                    durationMs = durationMs,
                    playbackSpeed = playbackSpeed,
                    audioTrackCount = audioTracks.size,
                    subtitleTrackCount = subtitleTracks.size,
                    onSeekTo = { target ->
                        exoPlayer.seekTo(target)
                        positionMs = target
                    },
                    onOpenSpeed = { showSpeedDialog = true },
                    onOpenAudio = { showAudioDialog = true },
                    onOpenSubtitles = { showSubtitleDialog = true },
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            }
        }

        errorMessage?.let { err ->
            PlaybackErrorOverlay(
                message = err,
                onOpenExternal = {
                    val intent = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(request.uri, "video/*")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    try {
                        context.startActivity(Intent.createChooser(intent, "Open video with"))
                    } catch (_: Exception) {
                    }
                },
                onClose = onClose,
                modifier = Modifier.align(Alignment.Center)
            )
        }
    }

    if (showSpeedDialog) {
        SpeedPickerDialog(
            currentSpeed = playbackSpeed,
            onSelectSpeed = { speed ->
                playbackSpeed = speed
                exoPlayer.playbackParameters = PlaybackParameters(speed)
            },
            onDismiss = { showSpeedDialog = false }
        )
    }

    if (showAudioDialog) {
        TrackPickerDialog(
            title = "Audio Track",
            tracks = audioTracks,
            allowDisable = false,
            isDisabled = false,
            onSelectTrack = { opt ->
                if (opt != null) PlaybackTrackUtils.selectAudioTrack(exoPlayer, opt)
            },
            onDismiss = { showAudioDialog = false }
        )
    }

    if (showSubtitleDialog) {
        TrackPickerDialog(
            title = "Subtitles",
            tracks = subtitleTracks,
            allowDisable = true,
            isDisabled = subtitlesDisabled,
            onSelectTrack = { opt ->
                PlaybackTrackUtils.selectSubtitleTrack(exoPlayer, opt)
                subtitlesDisabled = opt == null
            },
            onPickExternalSubtitle = {
                subtitlePickerLauncher.launch(arrayOf("*/*"))
            },
            onDismiss = { showSubtitleDialog = false }
        )
    }
}
