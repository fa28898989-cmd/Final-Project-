package com.movielink.app.feature.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.movielink.app.core.designsystem.LocalMovieLinkColors
import com.movielink.app.core.designsystem.MediaArtwork
import com.movielink.app.core.designsystem.MovieLinkRadius
import com.movielink.app.core.designsystem.SectionHeader
import com.movielink.app.core.model.CatalogSection
import com.movielink.app.core.model.MediaSummary
import com.movielink.app.core.model.OttPlatformItem
import com.movielink.app.core.model.ProviderId
import com.movielink.app.core.sources.WebsiteSourceConfig

@Composable
fun WatchByOttSection(
    platforms: List<OttPlatformItem>,
    selectedOttId: String?,
    onSelectOtt: (OttPlatformItem) -> Unit,
    modifier: Modifier = Modifier
) {
    if (platforms.isEmpty()) return
    val colors = LocalMovieLinkColors.current

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SectionHeader(title = "Watch by OTT")

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(platforms, key = { it.id }) { platform ->
                val isSelected = selectedOttId == platform.id
                val tileShape = RoundedCornerShape(16.dp)
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .width(66.dp)
                        .clickable { onSelectOtt(platform) }
                ) {
                    Box(
                        modifier = Modifier
                            .size(58.dp)
                            .clip(tileShape)
                            .background(Color(platform.brandColorHex))
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) colors.accent else colors.borderSubtle,
                                shape = tileShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = platform.shortCode,
                            color = Color(platform.contentColorHex),
                            fontWeight = FontWeight.Black,
                            fontSize = if (platform.shortCode.length <= 2) 22.sp else 11.sp,
                            lineHeight = 13.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                    Text(
                        text = platform.name,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) colors.textPrimary else colors.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun CatalogMediaRow(
    section: CatalogSection,
    onMediaClick: (MediaSummary) -> Unit,
    onViewAllClick: (CatalogSection) -> Unit,
    modifier: Modifier = Modifier
) {
    if (section.items.isEmpty()) return

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SectionHeader(
            title = section.title,
            actionLabel = if (section.hasViewAll) "View all" else null,
            onActionClick = if (section.hasViewAll) ({ onViewAllClick(section) }) else null
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(section.items, key = { "${section.id}_${it.id}" }) { media ->
                CatalogPosterCard(
                    media = media,
                    onClick = { onMediaClick(media) },
                    modifier = Modifier.width(114.dp)
                )
            }
        }
    }
}

@Composable
fun CatalogPosterCard(
    media: MediaSummary,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    showRatingBadge: Boolean = false
) {
    val colors = LocalMovieLinkColors.current
    Column(
        modifier = modifier.clickable(onClick = onClick),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
                .clip(RoundedCornerShape(MovieLinkRadius.Sm))
                .border(1.dp, colors.borderSubtle, RoundedCornerShape(MovieLinkRadius.Sm))
        ) {
            MediaArtwork(
                media = media,
                isBackdrop = false,
                showEmbeddedTitle = true,
                modifier = Modifier.fillMaxSize()
            )

            if (showRatingBadge && media.rating.isNotBlank()) {
                Row(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color.White.copy(alpha = 0.92f))
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Star,
                        contentDescription = null,
                        tint = Color(0xFFF59E0B),
                        modifier = Modifier.size(11.dp)
                    )
                    Text(
                        text = media.rating,
                        color = Color.Black,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else if (media.qualityBadge.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 6.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.Black.copy(alpha = 0.72f))
                        .border(0.8.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = media.qualityBadge,
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Text(
            text = media.title,
            style = MaterialTheme.typography.labelMedium,
            color = colors.textPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun CategoriesFilterDialog(
    categories: List<String>,
    selectedCategory: String?,
    onSelectCategory: (String?) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalMovieLinkColors.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.surface,
        titleContentColor = colors.textPrimary,
        title = {
            Text(
                text = "Categories",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                CategoryOptionRow(
                    label = "All Categories",
                    selected = selectedCategory == null,
                    onClick = {
                        onSelectCategory(null)
                        onDismiss()
                    }
                )
                categories.forEach { cat ->
                    CategoryOptionRow(
                        label = cat,
                        selected = selectedCategory == cat,
                        onClick = {
                            onSelectCategory(cat)
                            onDismiss()
                        }
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = colors.textSecondary)
            }
        }
    )
}

@Composable
fun ProviderSwitchDialog(
    activeProvider: ProviderId,
    configs: Map<ProviderId, WebsiteSourceConfig>,
    onSelectProvider: (ProviderId) -> Unit,
    onManageSources: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalMovieLinkColors.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.surface,
        titleContentColor = colors.textPrimary,
        title = {
            Text(
                text = "Home Content Source",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ProviderId.entries.forEach { provider ->
                    val cfg = configs[provider] ?: WebsiteSourceConfig(provider)
                    val selected = provider == activeProvider && cfg.enabled
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(MovieLinkRadius.Sm))
                            .background(if (selected) colors.surfaceElevated else Color.Transparent)
                            .border(
                                1.dp,
                                if (selected) colors.borderStrong else colors.borderSubtle,
                                RoundedCornerShape(MovieLinkRadius.Sm)
                            )
                            .clickable(enabled = cfg.enabled) {
                                onSelectProvider(provider)
                                onDismiss()
                            }
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${provider.displayName} (${provider.shortLabel})",
                                style = MaterialTheme.typography.titleSmall,
                                color = if (cfg.enabled) colors.textPrimary else colors.textTertiary
                            )
                            Text(
                                text = if (cfg.enabled) cfg.activeBaseUrl else "Disabled in Website Sources",
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        if (selected) {
                            Box(
                                modifier = Modifier
                                    .size(22.dp)
                                    .clip(CircleShape)
                                    .background(colors.primaryButtonBg),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Check,
                                    contentDescription = null,
                                    tint = colors.primaryButtonContent,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }
            }
        },
        dismissButton = {
            TextButton(
                onClick = {
                    onDismiss()
                    onManageSources()
                }
            ) {
                Text("Manage Sources", color = colors.accent)
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = colors.textSecondary)
            }
        }
    )
}

@Composable
private fun CategoryOptionRow(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val colors = LocalMovieLinkColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(MovieLinkRadius.Xs))
            .background(if (selected) colors.surfaceElevated else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            color = colors.textPrimary
        )
        if (selected) {
            Icon(
                imageVector = Icons.Rounded.Check,
                contentDescription = null,
                tint = colors.accent,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
fun SectionViewAllDialog(
    section: CatalogSection,
    onSelectMedia: (MediaSummary) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalMovieLinkColors.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.surface,
        titleContentColor = colors.textPrimary,
        title = {
            Text(
                text = section.title,
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                section.items.chunked(2).forEach { pair ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        pair.forEach { media ->
                            CatalogPosterCard(
                                media = media,
                                onClick = {
                                    onDismiss()
                                    onSelectMedia(media)
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (pair.size == 1) {
                            Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = colors.textSecondary)
            }
        }
    )
}
