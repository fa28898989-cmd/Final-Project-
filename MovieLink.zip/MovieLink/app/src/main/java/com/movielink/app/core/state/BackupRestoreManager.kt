package com.movielink.app.core.state

import android.content.Context
import android.net.Uri
import com.movielink.app.core.adblock.AdBlockStore
import com.movielink.app.core.integrations.IntegrationsStore
import com.movielink.app.core.integrations.MetadataEnrichmentEngine
import com.movielink.app.core.sources.WebsiteSourcesStore
import org.json.JSONObject

data class BackupOperationResult(
    val ok: Boolean,
    val message: String
)

data class BackupImportPreview(
    val ok: Boolean,
    val message: String,
    val schemaVersion: Int = 0,
    val exportedAtMs: Long = 0L,
    val includedSections: List<String> = emptyList(),
    val includesApiKeys: Boolean = false,
    internal val validatedRoot: JSONObject? = null
)

object BackupRestoreManager {

    private const val SCHEMA_APP_ID = "com.movielink.app"
    private const val SCHEMA_VERSION = 1

    fun buildBackupJson(includeApiKeys: Boolean): String {
        val root = JSONObject().apply {
            put("app", SCHEMA_APP_ID)
            put("schemaVersion", SCHEMA_VERSION)
            put("exportedAtMs", System.currentTimeMillis())
            put("appearance", AppUiStateStore.exportAppearanceJson())
            put("websiteSources", WebsiteSourcesStore.exportBackupJson())
            put("adBlocking", AdBlockStore.exportBackupJson())
            put("integrations", IntegrationsStore.exportBackupJson(includeApiKeys))
            put("userPreferences", UserPreferencesStore.state.value.toBackupJson())
        }
        return root.toString(2)
    }

    fun exportToUri(context: Context, uri: Uri, includeApiKeys: Boolean): BackupOperationResult {
        return try {
            val content = buildBackupJson(includeApiKeys)
            context.contentResolver.openOutputStream(uri)?.use { out ->
                out.write(content.toByteArray(Charsets.UTF_8))
                out.flush()
            } ?: return BackupOperationResult(false, "Unable to open output destination")
            BackupOperationResult(
                true,
                if (includeApiKeys) "Configuration + keys exported cleanly"
                else "Configuration exported cleanly (API keys excluded)"
            )
        } catch (e: Exception) {
            BackupOperationResult(false, "Export failed: ${e.message ?: "Unknown error"}")
        }
    }

    fun previewFromUri(context: Context, uri: Uri): BackupImportPreview {
        return try {
            val raw = context.contentResolver.openInputStream(uri)?.use { input ->
                input.bufferedReader(Charsets.UTF_8).readText()
            } ?: return BackupImportPreview(false, "Unable to read selected file")

            if (raw.length > 1_000_000) {
                return BackupImportPreview(false, "Backup file is unexpectedly large")
            }

            val root = JSONObject(raw)
            val appTag = root.optString("app")
            val version = root.optInt("schemaVersion", 0)
            if (appTag != SCHEMA_APP_ID || version != SCHEMA_VERSION) {
                return BackupImportPreview(
                    ok = false,
                    message = "Invalid backup format or unsupported schema version ($version)"
                )
            }

            val sections = buildList {
                if (root.optJSONObject("appearance") != null) add("Appearance & Hero Layout")
                if (root.optJSONObject("websiteSources") != null) add("Website Sources & Mirrors")
                if (root.optJSONObject("adBlocking") != null) add("Ad Blocking & Whitelist")
                if (root.optJSONObject("integrations") != null) add("Integrations Preferences")
                root.optJSONObject("userPreferences")?.let { pref ->
                    if (pref.optJSONObject("playback") != null) add("Playback Preferences")
                    if (pref.optJSONObject("downloads") != null) add("Download Manager Routing")
                    if (pref.optJSONObject("library") != null) add("Library Tracking Preferences")
                }
            }
            if (sections.isEmpty()) {
                return BackupImportPreview(false, "Backup file contains no recognized settings sections")
            }

            val integObj = root.optJSONObject("integrations")
            val hasKeys = integObj != null && (
                integObj.optString("tmdbApiKey").isNotBlank() ||
                    integObj.optString("omdbApiKey").isNotBlank() ||
                    integObj.optString("mdblistApiKey").isNotBlank()
                )

            BackupImportPreview(
                ok = true,
                message = "Backup validated (Schema v$version)",
                schemaVersion = version,
                exportedAtMs = root.optLong("exportedAtMs", 0L),
                includedSections = sections,
                includesApiKeys = hasKeys,
                validatedRoot = root
            )
        } catch (e: Exception) {
            BackupImportPreview(false, "Corrupted or invalid backup file: ${e.message ?: "Parse error"}")
        }
    }

    fun applyPreview(preview: BackupImportPreview): BackupOperationResult {
        val root = preview.validatedRoot
            ?: return BackupOperationResult(false, preview.message)
        return try {
            root.optJSONObject("appearance")?.let { AppUiStateStore.importAppearanceJson(it) }
            root.optJSONObject("websiteSources")?.let { WebsiteSourcesStore.importBackupJson(it) }
            root.optJSONObject("adBlocking")?.let { AdBlockStore.importBackupJson(it) }
            root.optJSONObject("integrations")?.let {
                IntegrationsStore.importBackupJson(it)
                MetadataEnrichmentEngine.clearCache()
            }
            root.optJSONObject("userPreferences")?.let { prefObj ->
                UserPreferencesStore.replaceAll(prefObj.toUserPreferencesState())
            }
            BackupOperationResult(true, "Restored ${preview.includedSections.size} settings sections")
        } catch (e: Exception) {
            BackupOperationResult(false, "Restore failed: ${e.message ?: "Unknown error"}")
        }
    }

    fun importFromUri(context: Context, uri: Uri): BackupOperationResult {
        val preview = previewFromUri(context, uri)
        return if (!preview.ok) {
            BackupOperationResult(false, preview.message)
        } else {
            applyPreview(preview)
        }
    }

    private fun UserPreferencesState.toBackupJson(): JSONObject {
        val p = playback
        val d = downloads
        val l = library
        return JSONObject().apply {
            put(
                "playback",
                JSONObject().apply {
                    put("defaultSpeed", p.defaultSpeed.toDouble())
                    put("seekStepSeconds", p.seekStepSeconds)
                    put("gesturesEnabled", p.gesturesEnabled)
                    put("autoFullscreen", p.autoFullscreen)
                    put("resumePlaybackEnabled", p.resumePlaybackEnabled)
                    put("defaultResizeModeIndex", p.defaultResizeModeIndex)
                    put("preferredSubtitleLanguage", p.preferredSubtitleLanguage)
                    put("preferredAudioLanguage", p.preferredAudioLanguage)
                }
            )
            put(
                "downloads",
                JSONObject().apply {
                    put("routerMode", d.routerMode.id)
                    put("fallbackToInAppResolver", d.fallbackToInAppResolver)
                }
            )
            put(
                "library",
                JSONObject().apply {
                    put("trackVisitHistory", l.trackVisitHistory)
                    put("trackContinueWatching", l.trackContinueWatching)
                    put("autoMarkWatchedThresholdPercent", l.autoMarkWatchedThresholdPercent)
                }
            )
        }
    }

    private fun JSONObject.toUserPreferencesState(): UserPreferencesState {
        val pObj = optJSONObject("playback")
        val dObj = optJSONObject("downloads")
        val lObj = optJSONObject("library")

        val playback = if (pObj != null) {
            PlaybackPreferences(
                defaultSpeed = pObj.optDouble("defaultSpeed", 1.0).toFloat().coerceIn(0.5f, 3.0f),
                seekStepSeconds = pObj.optInt("seekStepSeconds", 10).coerceIn(5, 60),
                gesturesEnabled = pObj.optBoolean("gesturesEnabled", true),
                autoFullscreen = pObj.optBoolean("autoFullscreen", true),
                resumePlaybackEnabled = pObj.optBoolean("resumePlaybackEnabled", true),
                defaultResizeModeIndex = pObj.optInt("defaultResizeModeIndex", 0).coerceIn(0, 2),
                preferredSubtitleLanguage = pObj.optString("preferredSubtitleLanguage", "English"),
                preferredAudioLanguage = pObj.optString("preferredAudioLanguage", "Original")
            )
        } else PlaybackPreferences()

        val modeId = dObj?.optString("routerMode", DownloadRouterMode.ASK_EACH_TIME.id)
        val mode = DownloadRouterMode.entries.firstOrNull { it.id == modeId }
            ?: DownloadRouterMode.ASK_EACH_TIME
        val downloads = DownloadPreferences(
            routerMode = mode,
            fallbackToInAppResolver = dObj?.optBoolean("fallbackToInAppResolver", true) ?: true
        )

        val library = if (lObj != null) {
            LibraryPreferences(
                trackVisitHistory = lObj.optBoolean("trackVisitHistory", true),
                trackContinueWatching = lObj.optBoolean("trackContinueWatching", true),
                autoMarkWatchedThresholdPercent = lObj.optInt("autoMarkWatchedThresholdPercent", 90).coerceIn(50, 99)
            )
        } else LibraryPreferences()

        return UserPreferencesState(playback = playback, downloads = downloads, library = library)
    }
}
