package com.movielink.app.core.designsystem

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

val LocalMovieLinkColors = staticCompositionLocalOf { MovieLinkColors() }

@Composable
fun MovieLinkTheme(
    backgroundColor: Color = MovieLinkColors.PureBlack,
    accentColor: Color = MovieLinkColors.DefaultAccent,
    content: @Composable () -> Unit
) {
    val palette = MovieLinkColors.create(
        backgroundColor = backgroundColor,
        accentColor = accentColor
    )

    val materialScheme = if (palette.isLightBackground) {
        lightColorScheme(
            primary = palette.accent,
            onPrimary = palette.onAccent,
            background = palette.background,
            onBackground = palette.textPrimary,
            surface = palette.surface,
            onSurface = palette.textPrimary,
            surfaceVariant = palette.surfaceElevated,
            onSurfaceVariant = palette.textSecondary,
            outline = palette.borderSubtle,
            error = palette.danger
        )
    } else {
        darkColorScheme(
            primary = palette.accent,
            onPrimary = palette.onAccent,
            background = palette.background,
            onBackground = palette.textPrimary,
            surface = palette.surface,
            onSurface = palette.textPrimary,
            surfaceVariant = palette.surfaceElevated,
            onSurfaceVariant = palette.textSecondary,
            outline = palette.borderSubtle,
            error = palette.danger
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = palette.isLightBackground
                controller.isAppearanceLightNavigationBars = palette.isLightBackground
            }
        }
    }

    CompositionLocalProvider(LocalMovieLinkColors provides palette) {
        MaterialTheme(
            colorScheme = materialScheme,
            typography = MovieLinkTypography,
            shapes = MovieLinkShapes,
            content = content
        )
    }
}
