package com.movielink.app.core.localmedia

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/**
 * Lightweight persistent store for local video resume positions and recently played order.
 */
class LocalPlaybackHistoryStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(
        "movielink_local_playback",
        Context.MODE_PRIVATE
    )

    private val _records = MutableStateFlow(loadAll())
    val records: StateFlow<List<LocalPlaybackRecord>> = _records.asStateFlow()

    fun getPositionFor(uriString: String): Long {
        val record = _records.value.firstOrNull { it.uriString == uriString } ?: return 0L
        // Restart from beginning if finished (>= 96%)
        return if (record.durationMs > 0L && record.progressFraction >= 0.96f) {
            0L
        } else {
            record.positionMs
        }
    }

    fun saveProgress(
        uriString: String,
        title: String,
        positionMs: Long,
        durationMs: Long
    ) {
        if (uriString.isBlank()) return
        val clampedPos = positionMs.coerceAtLeast(0L)
        val clampedDur = durationMs.coerceAtLeast(0L)
        val nextRecord = LocalPlaybackRecord(
            uriString = uriString,
            title = title.ifBlank { "Local Video" },
            positionMs = clampedPos,
            durationMs = clampedDur,
            lastPlayedAtMs = System.currentTimeMillis()
        )
        val updated = (listOf(nextRecord) + _records.value.filterNot { it.uriString == uriString })
            .take(50)
        _records.value = updated
        persist(updated)
    }

    fun removeRecord(uriString: String) {
        val updated = _records.value.filterNot { it.uriString == uriString }
        _records.value = updated
        persist(updated)
    }

    private fun loadAll(): List<LocalPlaybackRecord> {
        val raw = prefs.getString(KEY_RECORDS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val uri = obj.optString("uri")
                    if (uri.isBlank()) continue
                    add(
                        LocalPlaybackRecord(
                            uriString = uri,
                            title = obj.optString("title", "Local Video"),
                            positionMs = obj.optLong("pos", 0L),
                            durationMs = obj.optLong("dur", 0L),
                            lastPlayedAtMs = obj.optLong("ts", 0L)
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun persist(items: List<LocalPlaybackRecord>) {
        val arr = JSONArray()
        for (item in items) {
            arr.put(
                JSONObject().apply {
                    put("uri", item.uriString)
                    put("title", item.title)
                    put("pos", item.positionMs)
                    put("dur", item.durationMs)
                    put("ts", item.lastPlayedAtMs)
                }
            )
        }
        prefs.edit().putString(KEY_RECORDS, arr.toString()).apply()
    }

    companion object {
        private const val KEY_RECORDS = "playback_records_v1"
    }
}
