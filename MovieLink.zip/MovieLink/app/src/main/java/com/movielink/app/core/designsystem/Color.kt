package com.movielink.app.core.designsystem

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance

/**
 * Pure Black AMOLED (#000000) design tokens inspired by the Canva prototypes.
 * Supports future runtime customization of background and accent colors while
 * preserving contrast-safe foreground tokens.
 */
@Immutable
data class MovieLinkColors(
    val background: Color = PureBlack,
    val surface: Color = CharcoalSurface,
    val surfaceElevated: Color = CharcoalElevated,
    val surfaceSubtle: Color = CharcoalSubtle,
    val textPrimary: Color = WhitePrimary,
    val textSecondary: Color = MutedGrey,
    val textTertiary: Color = DimGrey,
    val borderSubtle: Color = SubtleBorder,
    val borderStrong: Color = StrongBorder,
    val accent: Color = DefaultAccent,
    val onAccent: Color = PureBlack,
    val primaryButtonBg: Color = WhitePrimary,
    val primaryButtonContent: Color = PureBlack,
    val ratingGold: Color = RatingAmber,
    val success: Color = EmeraldSuccess,
    val danger: Color = CoralDanger,
    val navBarBg: Color = NavBarBlack,
    val navActive: Color = WhitePrimary,
    val navInactive: Color = MutedGrey,
    val isLightBackground: Boolean = false
) {
    companion object {
        val PureBlack = Color(0xFF000000)
        val NavBarBlack = Color(0xF2050507)
        val CharcoalSurface = Color(0xFF111114)
        val CharcoalElevated = Color(0xFF18181D)
        val CharcoalSubtle = Color(0xFF0B0B0E)
        val WhitePrimary = Color(0xFFFFFFFF)
        val MutedGrey = Color(0xFF9CA3AF)
        val DimGrey = Color(0xFF6B7280)
        val SubtleBorder = Color(0x1FFFFFFF)
        val StrongBorder = Color(0x38FFFFFF)
        val DefaultAccent = Color(0xFFFFFFFF)
        val RatingAmber = Color(0xFFFACC15)
        val EmeraldSuccess = Color(0xFF34D399)
        val CoralDanger = Color(0xFFF87171)

        fun create(
            backgroundColor: Color = PureBlack,
            accentColor: Color = DefaultAccent
        ): MovieLinkColors {
            val isLight = backgroundColor.luminance() > 0.45f
            val onAccent = if (accentColor.luminance() > 0.45f) Color(0xFF09090B) else WhitePrimary
            return if (isLight) {
                MovieLinkColors(
                    background = backgroundColor,
                    surface = Color(0xFFF4F4F5),
                    surfaceElevated = Color(0xFFE4E4E7),
                    surfaceSubtle = Color(0xFFFAFAFA),
                    textPrimary = Color(0xFF09090B),
                    textSecondary = Color(0xFF52525B),
                    textTertiary = Color(0xFF71717A),
                    borderSubtle = Color(0x1A000000),
                    borderStrong = Color(0x33000000),
                    accent = accentColor,
                    onAccent = onAccent,
                    primaryButtonBg = Color(0xFF09090B),
                    primaryButtonContent = WhitePrimary,
                    navBarBg = backgroundColor.copy(alpha = 0.96f),
                    navActive = Color(0xFF09090B),
                    navInactive = Color(0xFF71717A),
                    isLightBackground = true
                )
            } else {
                val baseSurface = if (backgroundColor == PureBlack) {
                    CharcoalSurface
                } else {
                    blendOver(backgroundColor, WhitePrimary, 0.06f)
                }
                val elevatedSurface = if (backgroundColor == PureBlack) {
                    CharcoalElevated
                } else {
                    blendOver(backgroundColor, WhitePrimary, 0.11f)
                }
                MovieLinkColors(
                    background = backgroundColor,
                    surface = baseSurface,
                    surfaceElevated = elevatedSurface,
                    surfaceSubtle = blendOver(backgroundColor, WhitePrimary, 0.03f),
                    textPrimary = WhitePrimary,
                    textSecondary = MutedGrey,
                    textTertiary = DimGrey,
                    borderSubtle = SubtleBorder,
                    borderStrong = StrongBorder,
                    accent = accentColor,
                    onAccent = onAccent,
                    primaryButtonBg = WhitePrimary,
                    primaryButtonContent = PureBlack,
                    navBarBg = backgroundColor.copy(alpha = 0.95f),
                    navActive = WhitePrimary,
                    navInactive = MutedGrey,
                    isLightBackground = false
                )
            }
        }

        private fun blendOver(base: Color, overlay: Color, alpha: Float): Color {
            val inv = 1f - alpha
            return Color(
                red = base.red * inv + overlay.red * alpha,
                green = base.green * inv + overlay.green * alpha,
                blue = base.blue * inv + overlay.blue * alpha,
                alpha = 1f
            )
        }
    }
}
