package com.movielink.app

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import com.movielink.app.core.network.MovieLinkHttpClient

class MovieLinkApplication : Application(), ImageLoaderFactory {
    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .okHttpClient(MovieLinkHttpClient.client)
            .crossfade(true)
            .build()
    }
}
