package com.movielink.app.core.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.movielink.app.core.model.MediaKind
import com.movielink.app.core.model.MediaSummary
import com.movielink.app.core.model.ProviderId

@Entity(tableName = "library_items")
data class LibraryItemEntity(
    @PrimaryKey
    val mediaId: String,
    val providerId: String,
    val title: String,
    val subtitle: String,
    val year: String,
    val runtime: String,
    val rating: String,
    val certification: String,
    val statusBadge: String,
    val languageTag: String,
    val genresCsv: String,
    val kind: String,
    val posterUrl: String,
    val backdropUrl: String,
    val accentHex: Long,
    val secondaryHex: Long,
    val qualityBadge: String,
    val sourceUrl: String,
    val titleLogoUrl: String,
    val isInWatchlist: Boolean = false,
    val isWatched: Boolean = false,
    val lastVisitedAtMs: Long = 0L
) {
    fun toMediaSummary(): MediaSummary = MediaSummary(
        id = mediaId,
        providerId = ProviderId.fromId(providerId),
        title = title,
        subtitle = subtitle,
        year = year,
        runtime = runtime,
        rating = rating,
        certification = certification,
        statusBadge = statusBadge,
        languageTag = languageTag,
        genres = genresCsv.split("|").map { it.trim() }.filter { it.isNotBlank() },
        kind = if (kind == MediaKind.SERIES.name) MediaKind.SERIES else MediaKind.MOVIE,
        posterUrl = posterUrl,
        backdropUrl = backdropUrl,
        accentHex = accentHex,
        secondaryHex = secondaryHex,
        qualityBadge = qualityBadge,
        sourceUrl = sourceUrl,
        titleLogoUrl = titleLogoUrl
    )

    companion object {
        fun fromSummary(
            summary: MediaSummary,
            isInWatchlist: Boolean,
            isWatched: Boolean,
            lastVisitedAtMs: Long
        ): LibraryItemEntity = LibraryItemEntity(
            mediaId = summary.id,
            providerId = summary.providerId.id,
            title = summary.title,
            subtitle = summary.subtitle,
            year = summary.year,
            runtime = summary.runtime,
            rating = summary.rating,
            certification = summary.certification,
            statusBadge = summary.statusBadge,
            languageTag = summary.languageTag,
            genresCsv = summary.genres.joinToString("|"),
            kind = summary.kind.name,
            posterUrl = summary.posterUrl,
            backdropUrl = summary.backdropUrl,
            accentHex = summary.accentHex,
            secondaryHex = summary.secondaryHex,
            qualityBadge = summary.qualityBadge,
            sourceUrl = summary.sourceUrl,
            titleLogoUrl = summary.titleLogoUrl,
            isInWatchlist = isInWatchlist,
            isWatched = isWatched,
            lastVisitedAtMs = lastVisitedAtMs
        )
    }
}

@Entity(tableName = "playback_progress")
data class PlaybackProgressEntity(
    @PrimaryKey
    val mediaId: String,
    val providerId: String,
    val title: String,
    val posterUrl: String,
    val backdropUrl: String,
    val year: String,
    val episodeLabel: String?,
    val progressFraction: Float,
    val remainingLabel: String,
    val positionMs: Long,
    val durationMs: Long,
    val updatedAtMs: Long
) {
    fun toSummary(fallback: MediaSummary?): MediaSummary = fallback ?: MediaSummary(
        id = mediaId,
        providerId = ProviderId.fromId(providerId),
        title = title,
        year = year,
        posterUrl = posterUrl,
        backdropUrl = backdropUrl
    )
}
