package com.movielink.app.core.integrations

import com.movielink.app.core.model.CastMember
import com.movielink.app.core.model.MediaKind
import com.movielink.app.core.model.MovieInfoField
import com.movielink.app.core.network.MovieLinkHttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Request
import org.json.JSONObject
import java.util.Locale

data class IntegrationProbeResult(
    val ok: Boolean,
    val message: String,
    val latencyMs: Long = 0L
)

data class ExternalMetadataPayload(
    val sourceName: String,
    val tmdbId: String? = null,
    val imdbId: String? = null,
    val posterUrl: String = "",
    val backdropUrl: String = "",
    val titleLogoUrl: String = "",
    val overview: String = "",
    val genres: List<String> = emptyList(),
    val releaseDate: String = "",
    val year: String = "",
    val runtime: String = "",
    val certification: String = "",
    val primaryRating: String = "",
    val extraRatings: List<MovieInfoField> = emptyList(),
    val cast: List<CastMember> = emptyList(),
    val extraInfoFields: List<MovieInfoField> = emptyList()
)

object TmdbClient {
    private const val BASE = "https://api.themoviedb.org/3"
    private const val IMG_POSTER = "https://image.tmdb.org/t/p/w500"
    private const val IMG_BACKDROP = "https://image.tmdb.org/t/p/w1280"
    private const val IMG_LOGO = "https://image.tmdb.org/t/p/w500"
    private const val IMG_PROFILE = "https://image.tmdb.org/t/p/w185"

    private fun isV4Bearer(key: String): Boolean {
        val trimmed = key.trim()
        return trimmed.length > 45 && trimmed.contains('.')
    }

    private suspend fun getJson(url: String, apiKey: String): Pair<Int, JSONObject?> =
        withContext(Dispatchers.IO) {
            val trimmedKey = apiKey.trim()
            val urlBuilder = url.toHttpUrlOrNull()?.newBuilder()
                ?: return@withContext 0 to null
            if (!isV4Bearer(trimmedKey)) {
                urlBuilder.addQueryParameter("api_key", trimmedKey)
            }
            val reqBuilder = Request.Builder()
                .url(urlBuilder.build())
                .header("Accept", "application/json")
                .header("User-Agent", MovieLinkHttpClient.DEFAULT_USER_AGENT)
            if (isV4Bearer(trimmedKey)) {
                reqBuilder.header("Authorization", "Bearer $trimmedKey")
            }
            MovieLinkHttpClient.client.newCall(reqBuilder.build()).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                val json = try {
                    if (body.isNotBlank()) JSONObject(body) else null
                } catch (_: Exception) {
                    null
                }
                resp.code to json
            }
        }

    suspend fun testConnection(apiKey: String): IntegrationProbeResult {
        val key = apiKey.trim()
        if (key.isBlank()) return IntegrationProbeResult(false, "Enter a TMDB API key or v4 token first")
        val start = System.nanoTime()
        return try {
            val (code, json) = getJson("$BASE/configuration", key)
            val ms = ((System.nanoTime() - start) / 1_000_000L).coerceAtLeast(1L)
            if (code in 200..299 && json != null && json.has("images")) {
                IntegrationProbeResult(true, "TMDB connected (${ms}ms)", ms)
            } else {
                val msg = json?.optString("status_message")?.takeIf { it.isNotBlank() } ?: "HTTP $code"
                IntegrationProbeResult(false, "TMDB failed: $msg", ms)
            }
        } catch (e: Exception) {
            IntegrationProbeResult(false, e.message ?: "TMDB connection error")
        }
    }

    suspend fun lookup(
        apiKey: String,
        title: String,
        year: String,
        kind: MediaKind
    ): ExternalMetadataPayload? {
        val key = apiKey.trim()
        if (key.isBlank()) return null

        val cleanTitle = MetadataMatcher.cleanSearchTitle(title)
        if (cleanTitle.length < 2) return null
        val targetYear = MetadataMatcher.extractCleanYear(year.ifBlank { title })
        val mediaType = if (kind == MediaKind.SERIES) "tv" else "movie"

        val searchUrl = "$BASE/search/$mediaType".toHttpUrlOrNull()!!.newBuilder()
            .addQueryParameter("query", cleanTitle)
            .addQueryParameter("include_adult", "false")
            .apply {
                if (targetYear != null) {
                    val param = if (mediaType == "movie") "year" else "first_air_date_year"
                    addQueryParameter(param, targetYear.toString())
                }
            }
            .build()
            .toString()

        var (code, searchJson) = getJson(searchUrl, key)
        var results = searchJson?.optJSONArray("results")

        // Fallback search without year constraint if year-filtered search yields zero hits
        if ((code !in 200..299 || results == null || results.length() == 0) && targetYear != null) {
            val broadUrl = "$BASE/search/$mediaType".toHttpUrlOrNull()!!.newBuilder()
                .addQueryParameter("query", cleanTitle)
                .addQueryParameter("include_adult", "false")
                .build()
                .toString()
            val retry = getJson(broadUrl, key)
            code = retry.first
            searchJson = retry.second
            results = searchJson?.optJSONArray("results")
        }

        if (code !in 200..299 || results == null || results.length() == 0) return null

        var bestId: Int? = null
        var bestScore = 0f
        var bestHasYear = false
        val limit = minOf(results.length(), 8)
        for (i in 0 until limit) {
            val item = results.optJSONObject(i) ?: continue
            val candTitle = item.optString("title").ifBlank { item.optString("name") }
            val candOrig = item.optString("original_title").ifBlank { item.optString("original_name") }
            val dateStr = item.optString("release_date").ifBlank { item.optString("first_air_date") }
            val candYear = dateStr.take(4).toIntOrNull()
            val score = MetadataMatcher.scoreCandidate(
                queryTitle = title,
                queryYear = targetYear,
                candidateTitle = candTitle,
                candidateOriginalTitle = candOrig,
                candidateYear = candYear
            )
            if (score > bestScore) {
                bestScore = score
                bestId = item.optInt("id", -1).takeIf { it > 0 }
                bestHasYear = targetYear != null && candYear != null
            }
        }

        val tmdbId = bestId ?: return null
        if (!MetadataMatcher.isAcceptableMatch(bestScore, bestHasYear)) return null

        val detailUrl = "$BASE/$mediaType/$tmdbId".toHttpUrlOrNull()!!.newBuilder()
            .addQueryParameter("append_to_response", "credits,images,external_ids")
            .addQueryParameter("include_image_language", "en,null")
            .build()
            .toString()

        val (detCode, detJson) = getJson(detailUrl, key)
        if (detCode !in 200..299 || detJson == null) return null

        val posterPath = detJson.optString("poster_path")
        val backdropPath = detJson.optString("backdrop_path")
        val posterUrl = if (posterPath.startsWith("/")) "$IMG_POSTER$posterPath" else ""
        val backdropUrl = if (backdropPath.startsWith("/")) "$IMG_BACKDROP$backdropPath" else ""

        val logosArr = detJson.optJSONObject("images")?.optJSONArray("logos")
        var titleLogoUrl = ""
        if (logosArr != null && logosArr.length() > 0) {
            for (i in 0 until logosArr.length()) {
                val logoObj = logosArr.optJSONObject(i) ?: continue
                val filePath = logoObj.optString("file_path")
                if (filePath.startsWith("/") && !filePath.endsWith(".svg", ignoreCase = true)) {
                    titleLogoUrl = "$IMG_LOGO$filePath"
                    break
                }
            }
        }

        val releaseDate = detJson.optString("release_date")
            .ifBlank { detJson.optString("first_air_date") }
        val resolvedYear = releaseDate.take(4)

        val runtimeMin = when {
            detJson.optInt("runtime", 0) > 0 -> detJson.optInt("runtime")
            else -> detJson.optJSONArray("episode_run_time")?.optInt(0, 0) ?: 0
        }
        val runtimeText = if (runtimeMin > 0) {
            val h = runtimeMin / 60
            val m = runtimeMin % 60
            if (h > 0) "${h}h ${m}m" else "${m}m"
        } else {
            ""
        }

        val genresArr = detJson.optJSONArray("genres")
        val genres = buildList {
            if (genresArr != null) {
                for (i in 0 until genresArr.length()) {
                    val gName = genresArr.optJSONObject(i)?.optString("name")?.trim().orEmpty()
                    if (gName.isNotBlank()) add(gName)
                }
            }
        }

        val voteAvg = detJson.optDouble("vote_average", 0.0)
        val voteText = if (voteAvg > 0.0) String.format(Locale.US, "%.1f", voteAvg) else ""
        val imdbId = detJson.optJSONObject("external_ids")?.optString("imdb_id")
            ?.takeIf { it.startsWith("tt") }
            ?: detJson.optString("imdb_id").takeIf { it.startsWith("tt") }

        val castArr = detJson.optJSONObject("credits")?.optJSONArray("cast")
        val palette = listOf(0xFF1F2937L, 0xFF312E81L, 0xFF0F766EL, 0xFF7C2D12L, 0xFF3F3F46L)
        val cast = buildList {
            if (castArr != null) {
                val maxCast = minOf(castArr.length(), 15)
                for (i in 0 until maxCast) {
                    val c = castArr.optJSONObject(i) ?: continue
                    val name = c.optString("name").trim()
                    if (name.isBlank()) continue
                    val role = c.optString("character").trim().ifBlank { "Cast" }
                    val profile = c.optString("profile_path")
                    val profileUrl = if (profile.startsWith("/")) "$IMG_PROFILE$profile" else ""
                    add(
                        CastMember(
                            name = name,
                            role = role,
                            avatarColorHex = palette[i % palette.size],
                            profileImageUrl = profileUrl
                        )
                    )
                }
            }
        }

        val extraRatings = buildList {
            if (voteText.isNotBlank()) add(MovieInfoField("TMDB", "$voteText / 10"))
        }

        val infoFields = buildList {
            if (releaseDate.isNotBlank()) add(MovieInfoField("Release Date", releaseDate))
            if (runtimeText.isNotBlank()) add(MovieInfoField("Runtime", runtimeText))
            val spokenArr = detJson.optJSONArray("spoken_languages")
            if (spokenArr != null && spokenArr.length() > 0) {
                val langs = (0 until minOf(spokenArr.length(), 3))
                    .mapNotNull { spokenArr.optJSONObject(it)?.optString("english_name")?.takeIf { n -> n.isNotBlank() } }
                if (langs.isNotEmpty()) {
                    add(MovieInfoField("Spoken Audio", langs.joinToString(", ")))
                }
            }
        }

        return ExternalMetadataPayload(
            sourceName = "TMDB",
            tmdbId = tmdbId.toString(),
            imdbId = imdbId,
            posterUrl = posterUrl,
            backdropUrl = backdropUrl,
            titleLogoUrl = titleLogoUrl,
            overview = detJson.optString("overview").trim(),
            genres = genres,
            releaseDate = releaseDate,
            year = resolvedYear,
            runtime = runtimeText,
            primaryRating = voteText,
            extraRatings = extraRatings,
            cast = cast,
            extraInfoFields = infoFields
        )
    }
}

object OmdbClient {
    private const val BASE = "https://www.omdbapi.com/"

    suspend fun testConnection(apiKey: String): IntegrationProbeResult = withContext(Dispatchers.IO) {
        val key = apiKey.trim()
        if (key.isBlank()) return@withContext IntegrationProbeResult(false, "Enter an OMDb API key first")
        val start = System.nanoTime()
        try {
            val url = BASE.toHttpUrlOrNull()!!.newBuilder()
                .addQueryParameter("apikey", key)
                .addQueryParameter("i", "tt0111161")
                .build()
            val req = Request.Builder()
                .url(url)
                .header("Accept", "application/json")
                .build()
            MovieLinkHttpClient.client.newCall(req).execute().use { resp ->
                val ms = ((System.nanoTime() - start) / 1_000_000L).coerceAtLeast(1L)
                val json = try {
                    JSONObject(resp.body?.string().orEmpty())
                } catch (_: Exception) {
                    null
                }
                if (resp.isSuccessful && json?.optString("Response") == "True") {
                    IntegrationProbeResult(true, "OMDb connected (${ms}ms)", ms)
                } else {
                    val err = json?.optString("Error")?.takeIf { it.isNotBlank() } ?: "HTTP ${resp.code}"
                    IntegrationProbeResult(false, "OMDb failed: $err", ms)
                }
            }
        } catch (e: Exception) {
            IntegrationProbeResult(false, e.message ?: "OMDb connection error")
        }
    }

    suspend fun lookup(
        apiKey: String,
        imdbId: String?,
        title: String,
        year: String,
        kind: MediaKind
    ): ExternalMetadataPayload? = withContext(Dispatchers.IO) {
        val key = apiKey.trim()
        if (key.isBlank()) return@withContext null

        val cleanTitle = MetadataMatcher.cleanSearchTitle(title)
        val targetYear = MetadataMatcher.extractCleanYear(year.ifBlank { title })
        val builder = BASE.toHttpUrlOrNull()!!.newBuilder()
            .addQueryParameter("apikey", key)
            .addQueryParameter("plot", "short")

        if (!imdbId.isNullOrBlank() && imdbId.startsWith("tt")) {
            builder.addQueryParameter("i", imdbId)
        } else {
            if (cleanTitle.length < 2) return@withContext null
            builder.addQueryParameter("t", cleanTitle)
            builder.addQueryParameter("type", if (kind == MediaKind.SERIES) "series" else "movie")
            if (targetYear != null) {
                builder.addQueryParameter("y", targetYear.toString())
            }
        }

        val req = Request.Builder().url(builder.build()).header("Accept", "application/json").build()
        val json = try {
            MovieLinkHttpClient.client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use null
                JSONObject(resp.body?.string().orEmpty())
            }
        } catch (_: Exception) {
            null
        } ?: return@withContext null

        if (json.optString("Response") != "True") return@withContext null

        // If looked up by title without IMDb ID, verify strict match confidence
        val resolvedTitle = json.optString("Title")
        val resolvedYear = json.optString("Year").take(4)
        if (imdbId.isNullOrBlank()) {
            val candYear = resolvedYear.toIntOrNull()
            val score = MetadataMatcher.scoreCandidate(
                queryTitle = title,
                queryYear = targetYear,
                candidateTitle = resolvedTitle,
                candidateOriginalTitle = null,
                candidateYear = candYear
            )
            if (!MetadataMatcher.isAcceptableMatch(score, targetYear != null && candYear != null)) {
                return@withContext null
            }
        }

        val poster = json.optString("Poster").takeIf { it.startsWith("http") }.orEmpty()
        val plot = json.optString("Plot").takeIf { it != "N/A" }.orEmpty()
        val genres = json.optString("Genre")
            .takeIf { it != "N/A" }
            ?.split(",")
            ?.map { it.trim() }
            ?.filter { it.isNotBlank() }
            .orEmpty()
        val runtime = json.optString("Runtime").takeIf { it != "N/A" }.orEmpty()
        val released = json.optString("Released").takeIf { it != "N/A" }.orEmpty()
        val rated = json.optString("Rated").takeIf { it != "N/A" }.orEmpty()
        val imdbRating = json.optString("imdbRating").takeIf { it != "N/A" }.orEmpty()
        val director = json.optString("Director").takeIf { it != "N/A" }.orEmpty()
        val actors = json.optString("Actors")
            .takeIf { it != "N/A" }
            ?.split(",")
            ?.mapIndexedNotNull { idx, actor ->
                val n = actor.trim()
                if (n.isBlank()) null
                else CastMember(name = n, role = "Cast", avatarColorHex = 0xFF27272AL)
            }
            .orEmpty()

        val ratingsArr = json.optJSONArray("Ratings")
        val extraRatings = buildList {
            if (imdbRating.isNotBlank()) add(MovieInfoField("IMDb", imdbRating))
            if (ratingsArr != null) {
                for (i in 0 until ratingsArr.length()) {
                    val r = ratingsArr.optJSONObject(i) ?: continue
                    val src = r.optString("Source")
                    val value = r.optString("Value")
                    when {
                        src.contains("Rotten Tomatoes", true) -> add(MovieInfoField("Rotten Tomatoes", value))
                        src.contains("Metacritic", true) -> add(MovieInfoField("Metacritic", value))
                    }
                }
            }
        }

        val extraFields = buildList {
            if (director.isNotBlank()) add(MovieInfoField("Director", director))
            if (released.isNotBlank()) add(MovieInfoField("Release Date", released))
            if (runtime.isNotBlank()) add(MovieInfoField("Runtime", runtime))
            if (rated.isNotBlank()) add(MovieInfoField("Rated", rated))
        }

        ExternalMetadataPayload(
            sourceName = "OMDb",
            imdbId = json.optString("imdbID").takeIf { it.startsWith("tt") } ?: imdbId,
            posterUrl = poster,
            overview = plot,
            genres = genres,
            releaseDate = released,
            year = resolvedYear,
            runtime = runtime,
            certification = rated,
            primaryRating = imdbRating,
            extraRatings = extraRatings,
            cast = actors,
            extraInfoFields = extraFields
        )
    }
}

object MdblistClient {
    private const val BASE = "https://api.mdblist.com"

    suspend fun testConnection(apiKey: String): IntegrationProbeResult = withContext(Dispatchers.IO) {
        val key = apiKey.trim()
        if (key.isBlank()) return@withContext IntegrationProbeResult(false, "Enter an MDBList API key first")
        val start = System.nanoTime()
        try {
            val url = "$BASE/user".toHttpUrlOrNull()!!.newBuilder()
                .addQueryParameter("apikey", key)
                .build()
            val req = Request.Builder().url(url).header("Accept", "application/json").build()
            MovieLinkHttpClient.client.newCall(req).execute().use { resp ->
                val ms = ((System.nanoTime() - start) / 1_000_000L).coerceAtLeast(1L)
                val body = resp.body?.string().orEmpty()
                if (resp.isSuccessful && body.contains("{")) {
                    IntegrationProbeResult(true, "MDBList connected (${ms}ms)", ms)
                } else {
                    IntegrationProbeResult(false, "MDBList failed: HTTP ${resp.code}", ms)
                }
            }
        } catch (e: Exception) {
            IntegrationProbeResult(false, e.message ?: "MDBList connection error")
        }
    }

    suspend fun lookup(
        apiKey: String,
        imdbId: String?,
        tmdbId: String?,
        title: String,
        year: String,
        kind: MediaKind
    ): ExternalMetadataPayload? = withContext(Dispatchers.IO) {
        val key = apiKey.trim()
        if (key.isBlank()) return@withContext null

        val typeSlug = if (kind == MediaKind.SERIES) "show" else "movie"
        val url = when {
            !imdbId.isNullOrBlank() -> "$BASE/imdb/$imdbId".toHttpUrlOrNull()!!.newBuilder()
                .addQueryParameter("apikey", key)
                .build()
            !tmdbId.isNullOrBlank() -> "$BASE/tmdb/$typeSlug/$tmdbId".toHttpUrlOrNull()!!.newBuilder()
                .addQueryParameter("apikey", key)
                .build()
            else -> {
                val clean = MetadataMatcher.cleanSearchTitle(title)
                if (clean.length < 2) return@withContext null
                "$BASE/".toHttpUrlOrNull()!!.newBuilder()
                    .addQueryParameter("apikey", key)
                    .addQueryParameter("s", clean)
                    .apply {
                        val y = MetadataMatcher.extractCleanYear(year.ifBlank { title })
                        if (y != null) addQueryParameter("y", y.toString())
                    }
                    .build()
            }
        }

        val req = Request.Builder().url(url).header("Accept", "application/json").build()
        val json = try {
            MovieLinkHttpClient.client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use null
                JSONObject(resp.body?.string().orEmpty())
            }
        } catch (_: Exception) {
            null
        } ?: return@withContext null

        val obj = if (json.has("search")) {
            val arr = json.optJSONArray("search") ?: return@withContext null
            if (arr.length() == 0) return@withContext null
            arr.optJSONObject(0) ?: return@withContext null
        } else {
            json
        }

        val resTitle = obj.optString("title")
        val targetYear = MetadataMatcher.extractCleanYear(year.ifBlank { title })
        val candYear = obj.optInt("year", 0).takeIf { it > 1900 }
        if (imdbId.isNullOrBlank() && tmdbId.isNullOrBlank()) {
            val score = MetadataMatcher.scoreCandidate(title, targetYear, resTitle, null, candYear)
            if (!MetadataMatcher.isAcceptableMatch(score, targetYear != null && candYear != null)) {
                return@withContext null
            }
        }

        val ratingsArr = obj.optJSONArray("ratings")
        val ratings = buildList {
            val scoreVal = obj.optInt("score", 0)
            if (scoreVal > 0) add(MovieInfoField("MDBList", "$scoreVal%"))
            if (ratingsArr != null) {
                for (i in 0 until ratingsArr.length()) {
                    val r = ratingsArr.optJSONObject(i) ?: continue
                    val src = r.optString("source")
                    val valNum = r.opt("value")?.toString()?.takeIf { it != "null" && it.isNotBlank() } ?: continue
                    when (src.lowercase(Locale.US)) {
                        "imdb" -> add(MovieInfoField("IMDb", valNum))
                        "tomatoes" -> add(MovieInfoField("Rotten Tomatoes", "$valNum%"))
                        "metacritic" -> add(MovieInfoField("Metacritic", valNum))
                        "tmdb" -> add(MovieInfoField("TMDB", valNum))
                    }
                }
            }
        }

        val poster = obj.optString("poster").takeIf { it.startsWith("http") }.orEmpty()
        val backdrop = obj.optString("backdrop").takeIf { it.startsWith("http") }.orEmpty()
        val overview = obj.optString("description").trim()
        val cert = obj.optString("certification").trim()
        val runtimeVal = obj.optInt("runtime", 0)
        val runtimeStr = if (runtimeVal > 0) "${runtimeVal}m" else ""

        ExternalMetadataPayload(
            sourceName = "MDBList",
            imdbId = obj.optJSONObject("ids")?.optString("imdb")?.takeIf { it.startsWith("tt") } ?: imdbId,
            tmdbId = obj.optJSONObject("ids")?.optString("tmdb")?.takeIf { it.isNotBlank() } ?: tmdbId,
            posterUrl = poster,
            backdropUrl = backdrop,
            overview = overview,
            year = candYear?.toString().orEmpty(),
            runtime = runtimeStr,
            certification = cert,
            extraRatings = ratings
        )
    }
}

object BetterPosterResolver {
    fun buildPosterUrl(
        baseUrl: String,
        apiKey: String,
        imdbId: String?,
        tmdbId: String?,
        kind: MediaKind
    ): String {
        val key = apiKey.trim()
        val cleanBase = baseUrl.trim().trimEnd('/')
        if (key.isBlank() || cleanBase.isBlank()) return ""
        return when {
            !imdbId.isNullOrBlank() && imdbId.startsWith("tt") ->
                "$cleanBase/$key/imdb/poster-default/$imdbId.jpg"
            !tmdbId.isNullOrBlank() -> {
                val prefix = if (kind == MediaKind.SERIES) "series" else "movie"
                "$cleanBase/$key/tmdb/poster-default/$prefix-$tmdbId.jpg"
            }
            else -> ""
        }
    }

    suspend fun testConnection(baseUrl: String, apiKey: String): IntegrationProbeResult =
        withContext(Dispatchers.IO) {
            val testUrl = buildPosterUrl(
                baseUrl = baseUrl,
                apiKey = apiKey,
                imdbId = "tt0111161",
                tmdbId = null,
                kind = MediaKind.MOVIE
            )
            if (testUrl.isBlank()) {
                return@withContext IntegrationProbeResult(false, "Enter endpoint & API key first")
            }
            val start = System.nanoTime()
            try {
                val req = Request.Builder().url(testUrl).head().build()
                MovieLinkHttpClient.client.newCall(req).execute().use { resp ->
                    val ms = ((System.nanoTime() - start) / 1_000_000L).coerceAtLeast(1L)
                    if (resp.isSuccessful) {
                        IntegrationProbeResult(true, "Better Poster endpoint verified (${ms}ms)", ms)
                    } else {
                        IntegrationProbeResult(false, "Endpoint returned HTTP ${resp.code}", ms)
                    }
                }
            } catch (e: Exception) {
                IntegrationProbeResult(false, e.message ?: "Better Poster check failed")
            }
        }
}
