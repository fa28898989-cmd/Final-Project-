package com.movielink.app.core.adblock

import android.net.Uri
import com.movielink.app.core.model.ProviderId
import com.movielink.app.core.sources.WebsiteSourcesStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * High-speed domain, pop-up, and ad-redirect request blocker shared across
 * WebView resolvers and HTML link/iframe extraction.
 */
object AdBlockerEngine {

    private val counter = AtomicInteger(0)
    private val seq = AtomicLong(1L)

    private val _sessionBlockedCount = MutableStateFlow(0)
    val sessionBlockedCount: StateFlow<Int> = _sessionBlockedCount.asStateFlow()

    private val _recentBlocked = MutableStateFlow<List<BlockedRequestEvent>>(emptyList())
    val recentBlocked: StateFlow<List<BlockedRequestEvent>> = _recentBlocked.asStateFlow()

    private val adDomains = hashSetOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "google-analytics.com", "googletagmanager.com", "googletagservices.com", "2mdn.net",
        "popads.net", "popcash.net", "propellerads.com", "propellerclick.com", "exoclick.com",
        "exosrv.com", "exdynsrv.com", "juicyads.com", "trafficjunky.com", "trafficfactory.biz",
        "adsterra.com", "highperformanceformat.com", "effectivegatecpm.com", "profitablecpmrate.com",
        "profitablegatecpm.com", "highcpmgate.com", "adcash.com", "clickadu.com", "hilltopads.net",
        "hilltopads.com", "onclickads.net", "onclkds.com", "a-ads.com", "adnxs.com", "taboola.com",
        "outbrain.com", "mgid.com", "revcontent.com", "bidvertiser.com", "ad-maven.com",
        "admaven.com", "richads.com", "monetag.com", "pushame.com", "pushails.com", "notifpush.com",
        "adskeeper.com", "adspyglass.com", "ero-advertising.com", "tsyndicate.com", "ads.yahoo.com",
        "histats.com", "mc.yandex.ru", "adform.net", "criteo.com", "pubmatic.com", "rubiconproject.com",
        "openx.net", "smaato.net", "yllix.com", "kdmzu.com", "realsrv.com", "syndication.realsrv.com",
        "bongacams.com", "stripchat.com", "chaturbate.com", "livejasmin.com", "adtng.com",
        "clksite.com", "tzegilo.com", "acscdn.com", "wpadmngr.com", "pemsrv.com"
    )

    private val adUrlPatterns = listOf(
        "popunder", "/adserver", "adsbygoogle", "/pop.js", "/popup.js",
        "/banner_ads", "/prebid", "/vast.xml", "/vpaid", "clickunder"
    )

    private val domainCache = ConcurrentHashMap<String, Boolean>()

    fun shouldBlockUrl(
        rawUrl: String,
        providerId: ProviderId? = null
    ): Boolean {
        val uri = try {
            Uri.parse(rawUrl)
        } catch (_: Exception) {
            return false
        }
        return shouldBlockUri(uri, providerId)
    }

    fun shouldBlockUri(
        uri: Uri,
        providerId: ProviderId? = null
    ): Boolean {
        if (!AdBlockStore.isAdBlockActiveFor(providerId)) return false
        val host = uri.host?.lowercase(Locale.US)?.removePrefix("www.") ?: return false

        val settings = AdBlockStore.settings.value

        // Never block active provider host/mirrors
        if (isInternalProviderHost(host, providerId)) return false

        // Respect explicit whitelist
        if (hostMatchesSet(host, settings.allowedDomains)) return false

        // Custom user blocked domain
        if (hostMatchesSet(host, settings.customBlockedDomains)) {
            recordBlocked(providerId, host, "Custom block rule")
            return true
        }

        // Known ad/tracker network host
        if (domainCache.getOrPut(host) { hostMatchesSet(host, adDomains) }) {
            recordBlocked(providerId, host, "Ad/tracker domain")
            return true
        }

        val full = uri.toString().lowercase(Locale.US)
        val matchedPattern = adUrlPatterns.firstOrNull { full.contains(it) }
        if (matchedPattern != null) {
            recordBlocked(providerId, host, "Ad script pattern ($matchedPattern)")
            return true
        }

        return false
    }

    fun clearSessionStats() {
        counter.set(0)
        _sessionBlockedCount.value = 0
        _recentBlocked.value = emptyList()
    }

    private fun isInternalProviderHost(host: String, providerId: ProviderId?): Boolean {
        val targets = if (providerId != null) {
            WebsiteSourcesStore.configFor(providerId).mirrors
        } else {
            WebsiteSourcesStore.configs.value.values.flatMap { it.mirrors }
        }
        return targets.any { mirror ->
            val mh = Uri.parse(mirror).host?.lowercase(Locale.US)?.removePrefix("www.") ?: return@any false
            host == mh || host.endsWith(".$mh")
        }
    }

    private fun hostMatchesSet(host: String, set: Set<String>): Boolean {
        if (set.isEmpty()) return false
        var cursor = host
        while (true) {
            if (cursor in set) return true
            val idx = cursor.indexOf('.')
            if (idx < 0) break
            cursor = cursor.substring(idx + 1)
        }
        return false
    }

    private fun recordBlocked(providerId: ProviderId?, host: String, reason: String) {
        _sessionBlockedCount.value = counter.incrementAndGet()
        val evt = BlockedRequestEvent(
            id = seq.getAndIncrement(),
            timestampMs = System.currentTimeMillis(),
            providerId = providerId,
            host = host,
            reason = reason
        )
        _recentBlocked.update { (listOf(evt) + it).take(40) }
    }
}
