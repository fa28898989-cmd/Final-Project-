package com.movielink.app.feature.details

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.SubcomposeAsyncImage
import com.movielink.app.core.designsystem.LocalMovieLinkColors
import com.movielink.app.core.designsystem.MediaArtwork
import com.movielink.app.core.designsystem.MovieLinkRadius
import com.movielink.app.core.model.MediaSummary

@Composable
fun ScreenshotViewerDialog(
    summary: MediaSummary,
    screenshots: List<String>,
    onDismiss: () -> Unit
) {
    if (screenshots.isEmpty()) return
    val pagerState = rememberPagerState(pageCount = { screenshots.size })
    val colors = LocalMovieLinkColors.current

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.96f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Screenshots (${pagerState.currentPage + 1}/${screenshots.size})",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White
                )
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.14f))
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = "Close",
                        tint = Color.White
                    )
                }
            }

            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .align(Alignment.Center)
                    .fillMaxWidth()
            ) { index ->
                val entry = screenshots[index]
                val isHttpUrl = entry.startsWith("http://", ignoreCase = true) ||
                    entry.startsWith("https://", ignoreCase = true)

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 9f)
                            .clip(RoundedCornerShape(MovieLinkRadius.Md))
                            .background(Color(0xFF0E0E12)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isHttpUrl) {
                            SubcomposeAsyncImage(
                                model = entry,
                                contentDescription = "${summary.title} screenshot ${index + 1}",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize(),
                                loading = {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        CircularProgressIndicator(color = colors.accent)
                                    }
                                },
                                error = {
                                    MediaArtwork(
                                        media = summary,
                                        isBackdrop = true,
                                        showEmbeddedTitle = false,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            )
                        } else {
                            MediaArtwork(
                                media = summary,
                                isBackdrop = true,
                                showEmbeddedTitle = false,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                    Text(
                        text = if (isHttpUrl) "${summary.title} • Frame ${index + 1}" else entry,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.8f)
                    )
                }
            }
        }
    }
}
