package com.movielink.app.feature.search

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.movielink.app.core.designsystem.EmptyStateCard
import com.movielink.app.core.designsystem.FilterPill
import com.movielink.app.core.designsystem.LocalMovieLinkColors
import com.movielink.app.core.designsystem.MediaArtwork
import com.movielink.app.core.designsystem.MovieLinkCard
import com.movielink.app.core.designsystem.MovieLinkRadius
import com.movielink.app.core.designsystem.ScreenTitleHeader
import com.movielink.app.core.model.MediaSummary
import com.movielink.app.core.model.ProviderId
import com.movielink.app.core.model.ProviderSearchState
import com.movielink.app.core.player.AdBlockedWebViewDialog
import com.movielink.app.core.sources.WebsiteSourceConfig
import com.movielink.app.core.sources.WebsiteSourcesRepository
import com.movielink.app.core.sources.WebsiteSourcesStore
import com.movielink.app.core.sources.providers.CloudflareChallengeException
import kotlinx.coroutines.launch
import kotlinx.coroutines.supervisorScope

@Composable
fun SearchScreen(
    onOpenDetails: (MediaSummary) -> Unit,
    onOpenWebsiteSources: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    val sourceConfigs by WebsiteSourcesStore.configs.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("inception") }
    var focusedProvider by remember { mutableStateOf<ProviderId?>(null) }
    var retryNonce by remember { mutableIntStateOf(0) }
    var cloudflareUrls by remember { mutableStateOf<Map<ProviderId, String>>(emptyMap()) }
    var activeChallenge by remember { mutableStateOf<Pair<ProviderId, String>?>(null) }

    var providerStates by remember {
        mutableStateOf<Map<ProviderId, ProviderSearchState>>(
            ProviderId.entries.associateWith { ProviderSearchState.Idle }
        )
    }

    LaunchedEffect(query, sourceConfigs, retryNonce) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) {
            providerStates = ProviderId.entries.associateWith { ProviderSearchState.Idle }
            cloudflareUrls = emptyMap()
            return@LaunchedEffect
        }

        providerStates = ProviderId.entries.associateWith { pid ->
            if (sourceConfigs[pid]?.enabled == false) {
                ProviderSearchState.Error("Disabled in Website Sources")
            } else {
                ProviderSearchState.Loading
            }
        }

        supervisorScope {
            ProviderId.entries.forEach { pid ->
                if (sourceConfigs[pid]?.enabled == false) return@forEach
                launch {
                    val state = WebsiteSourcesRepository.searchProvider(pid, trimmed).fold(
                        onSuccess = { items ->
                            cloudflareUrls = cloudflareUrls - pid
                            ProviderSearchState.Success(items)
                        },
                        onFailure = { err ->
                            if (err is CloudflareChallengeException) {
                                cloudflareUrls = cloudflareUrls + (pid to err.challengeUrl)
                                ProviderSearchState.Error("Security verification required for ${pid.displayName}")
                            } else {
                                cloudflareUrls = cloudflareUrls - pid
                                ProviderSearchState.Error(err.message ?: "Search failed")
                            }
                        }
                    )
                    providerStates = providerStates + (pid to state)
                }
            }
        }
    }

    val visibleProviders = if (focusedProvider != null) {
        listOf(focusedProvider!!)
    } else {
        ProviderId.entries
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background)
            .statusBarsPadding(),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item(key = "header") {
            Column {
                ScreenTitleHeader(title = "Search")

                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    placeholder = {
                        Text(
                            text = "Search across all 3 websites...",
                            color = colors.textSecondary
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = null,
                            tint = colors.textSecondary
                        )
                    },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Clear search",
                                    tint = colors.textSecondary
                                )
                            }
                        }
                    },
                    shape = RoundedCornerShape(MovieLinkRadius.Pill),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = colors.surface,
                        unfocusedContainerColor = colors.surface,
                        focusedBorderColor = colors.borderStrong,
                        unfocusedBorderColor = colors.borderSubtle,
                        focusedTextColor = colors.textPrimary,
                        unfocusedTextColor = colors.textPrimary,
                        cursorColor = colors.accent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                )
            }
        }

        // 3 Independent Provider Selector / Status Tiles (Ref Image 4)
        item(key = "provider_cards") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ProviderId.entries.forEach { provider ->
                    val cfg = sourceConfigs[provider] ?: WebsiteSourceConfig(provider)
                    val state = providerStates[provider] ?: ProviderSearchState.Idle
                    val selected = focusedProvider == provider
                    val statusLabel = when {
                        !cfg.enabled -> "Disabled"
                        state is ProviderSearchState.Idle -> provider.displayName
                        state is ProviderSearchState.Loading -> "Searching…"
                        state is ProviderSearchState.Success -> "${state.items.size} found"
                        state is ProviderSearchState.Error -> "Error"
                        else -> provider.displayName
                    }
                    MovieLinkCard(
                        modifier = Modifier.weight(1f),
                        cornerRadius = MovieLinkRadius.Md,
                        backgroundColor = if (selected) colors.surfaceElevated else colors.surface,
                        borderColor = if (selected) colors.borderStrong else colors.borderSubtle,
                        onClick = {
                            focusedProvider = if (selected) null else provider
                        }
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 18.dp, horizontal = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = provider.shortLabel,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                            Text(
                                text = statusLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (state is ProviderSearchState.Error) {
                                    colors.danger
                                } else {
                                    colors.textSecondary
                                },
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // Quick Search Prompts + Website Sources shortcut
        item(key = "quick_chips") {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(listOf("inception", "jailer", "dune", "action")) { term ->
                    FilterPill(
                        label = term,
                        selected = query.equals(term, ignoreCase = true),
                        onClick = { query = term }
                    )
                }
                item {
                    FilterPill(
                        label = "Sources",
                        selected = false,
                        onClick = onOpenWebsiteSources
                    )
                }
            }
        }

        if (query.trim().isEmpty()) {
            item(key = "idle_empty") {
                EmptyStateCard(
                    title = "Search 3 Providers Simultaneously",
                    description = "Enter a movie or series title above. Results load independently per website so one source failing never blocks the others.",
                    icon = Icons.Rounded.Search,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        } else {
            items(visibleProviders, key = { it.id }) { provider ->
                val cfg = sourceConfigs[provider] ?: WebsiteSourceConfig(provider)
                val state = providerStates[provider] ?: ProviderSearchState.Idle
                val challengeUrl = cloudflareUrls[provider]
                ProviderSearchSection(
                    provider = provider,
                    activeBaseUrl = cfg.activeBaseUrl,
                    isDisabled = !cfg.enabled,
                    hasCloudflareChallenge = challengeUrl != null,
                    query = query.trim(),
                    state = state,
                    onRetry = {
                        when {
                            !cfg.enabled -> onOpenWebsiteSources()
                            challengeUrl != null -> activeChallenge = provider to challengeUrl
                            else -> retryNonce++
                        }
                    },
                    onOpenDetails = onOpenDetails
                )
            }
        }
    }

    activeChallenge?.let { (pid, url) ->
        AdBlockedWebViewDialog(
            initialUrl = url,
            title = pid.displayName,
            providerId = pid,
            isCloudflareChallenge = true,
            onCloudflareSolved = {
                activeChallenge = null
                cloudflareUrls = cloudflareUrls - pid
                retryNonce++
            },
            onDismiss = { activeChallenge = null }
        )
    }
}

@Composable
private fun ProviderSearchSection(
    provider: ProviderId,
    activeBaseUrl: String,
    isDisabled: Boolean,
    hasCloudflareChallenge: Boolean,
    query: String,
    state: ProviderSearchState,
    onRetry: () -> Unit,
    onOpenDetails: (MediaSummary) -> Unit
) {
    val colors = LocalMovieLinkColors.current
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${provider.displayName}: $query",
                    style = MaterialTheme.typography.titleLarge,
                    color = colors.textPrimary
                )
                Text(
                    text = activeBaseUrl,
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.textTertiary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Text(
                text = provider.shortLabel,
                style = MaterialTheme.typography.labelSmall,
                color = colors.textSecondary
            )
        }

        when (state) {
            ProviderSearchState.Idle -> Unit

            ProviderSearchState.Loading -> {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = colors.accent
                    )
                    Text(
                        text = "Searching ${provider.displayName}…",
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.textSecondary
                    )
                }
            }

            is ProviderSearchState.Error -> {
                MovieLinkCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    borderColor = colors.danger.copy(alpha = 0.4f)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ErrorOutline,
                                contentDescription = null,
                                tint = colors.danger,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = state.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textSecondary
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        val actionLabel = when {
                            isDisabled -> "Enable"
                            hasCloudflareChallenge -> "Verify"
                            else -> "Retry"
                        }
                        Text(
                            text = actionLabel,
                            style = MaterialTheme.typography.labelLarge,
                            color = colors.textPrimary,
                            modifier = Modifier
                                .clip(RoundedCornerShape(MovieLinkRadius.Xs))
                                .clickable(onClick = onRetry)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            is ProviderSearchState.Success -> {
                if (state.items.isEmpty()) {
                    Text(
                        text = "No matches found on ${provider.displayName}.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.textSecondary,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                } else {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(state.items, key = { it.id }) { media ->
                            SearchResultPosterCard(
                                media = media,
                                onClick = { onOpenDetails(media) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchResultPosterCard(
    media: MediaSummary,
    onClick: () -> Unit
) {
    val colors = LocalMovieLinkColors.current
    Column(
        modifier = Modifier
            .width(154.dp)
            .clip(RoundedCornerShape(MovieLinkRadius.Md))
            .background(colors.surface)
            .border(1.dp, colors.borderSubtle, RoundedCornerShape(MovieLinkRadius.Md))
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
        ) {
            MediaArtwork(
                media = media,
                isBackdrop = false,
                showEmbeddedTitle = true,
                modifier = Modifier.fillMaxSize()
            )

            if (media.rating.isNotBlank()) {
                Row(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color.White.copy(alpha = 0.94f))
                        .padding(horizontal = 6.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Star,
                        contentDescription = null,
                        tint = Color(0xFFF59E0B),
                        modifier = Modifier.size(12.dp)
                    )
                    Text(
                        text = media.rating,
                        color = Color.Black,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (media.languageTag.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                0f to Color.Transparent,
                                1f to Color.Black.copy(alpha = 0.88f)
                            )
                        )
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = media.languageTag,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        Text(
            text = media.title,
            style = MaterialTheme.typography.titleSmall,
            color = colors.textPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp)
        )
    }
}
