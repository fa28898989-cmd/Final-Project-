package com.movielink.app.feature.settings

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.movielink.app.core.designsystem.FilterPill
import com.movielink.app.core.designsystem.LocalMovieLinkColors
import com.movielink.app.core.designsystem.MovieLinkCard
import com.movielink.app.core.designsystem.MovieLinkRadius
import com.movielink.app.core.designsystem.SubtleHairlineDivider
import com.movielink.app.core.downloads.DownloadRouter
import com.movielink.app.core.state.AppUiStateStore
import com.movielink.app.core.state.DownloadRouterMode
import com.movielink.app.core.state.UserPreferencesStore

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PlaybackSettingsContent(
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    val prefsState by UserPreferencesStore.state.collectAsStateWithLifecycle()
    val p = prefsState.playback

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item(key = "playback_speed_seek") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Player Defaults",
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Default Playback Speed",
                            style = MaterialTheme.typography.titleSmall,
                            color = colors.textPrimary
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { spd ->
                                FilterPill(
                                    label = "${spd}x",
                                    selected = p.defaultSpeed == spd,
                                    onClick = {
                                        UserPreferencesStore.updatePlayback { it.copy(defaultSpeed = spd) }
                                    }
                                )
                            }
                        }

                        SubtleHairlineDivider()

                        Text(
                            text = "Double-Tap & Control Seek Interval",
                            style = MaterialTheme.typography.titleSmall,
                            color = colors.textPrimary
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(5, 10, 15, 30).forEach { sec ->
                                FilterPill(
                                    label = "${sec}s",
                                    selected = p.seekStepSeconds == sec,
                                    onClick = {
                                        UserPreferencesStore.updatePlayback { it.copy(seekStepSeconds = sec) }
                                    }
                                )
                            }
                        }

                        SubtleHairlineDivider()

                        Text(
                            text = "Default Video Aspect Ratio",
                            style = MaterialTheme.typography.titleSmall,
                            color = colors.textPrimary
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(0 to "Fit", 1 to "Stretch", 2 to "Zoom").forEach { (idx, label) ->
                                FilterPill(
                                    label = label,
                                    selected = p.defaultResizeModeIndex == idx,
                                    onClick = {
                                        UserPreferencesStore.updatePlayback { it.copy(defaultResizeModeIndex = idx) }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        item(key = "playback_behaviors") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Gestures & Orientation",
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                    SettingSwitchRow(
                        title = "Touch Gestures (Brightness, Volume & Seek)",
                        subtitle = "Swipe vertically on left/right edges or horizontally to seek",
                        checked = p.gesturesEnabled,
                        onCheckedChange = { on ->
                            UserPreferencesStore.updatePlayback { it.copy(gesturesEnabled = on) }
                        }
                    )
                    SubtleHairlineDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    SettingSwitchRow(
                        title = "Auto-Landscape Fullscreen",
                        subtitle = "Enter immersive landscape mode automatically when opening the player",
                        checked = p.autoFullscreen,
                        onCheckedChange = { on ->
                            UserPreferencesStore.updatePlayback { it.copy(autoFullscreen = on) }
                        }
                    )
                    SubtleHairlineDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    SettingSwitchRow(
                        title = "Remember Playback Position",
                        subtitle = "Automatically resume from last saved position",
                        checked = p.resumePlaybackEnabled,
                        onCheckedChange = { on ->
                            UserPreferencesStore.updatePlayback { it.copy(resumePlaybackEnabled = on) }
                        }
                    )
                }
            }
        }

        item(key = "track_prefs") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Track Preferences",
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Preferred Subtitle Language",
                            style = MaterialTheme.typography.titleSmall,
                            color = colors.textPrimary
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("Off", "English", "Bengali", "Hindi").forEach { lang ->
                                FilterPill(
                                    label = lang,
                                    selected = p.preferredSubtitleLanguage == lang,
                                    onClick = {
                                        UserPreferencesStore.updatePlayback { it.copy(preferredSubtitleLanguage = lang) }
                                    }
                                )
                            }
                        }

                        SubtleHairlineDivider()

                        Text(
                            text = "Preferred Audio Language",
                            style = MaterialTheme.typography.titleSmall,
                            color = colors.textPrimary
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("Original", "English", "Bengali", "Hindi").forEach { lang ->
                                FilterPill(
                                    label = lang,
                                    selected = p.preferredAudioLanguage == lang,
                                    onClick = {
                                        UserPreferencesStore.updatePlayback { it.copy(preferredAudioLanguage = lang) }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DownloadsSettingsContent(
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    val context = LocalContext.current
    val prefsState by UserPreferencesStore.state.collectAsStateWithLifecycle()
    val d = prefsState.downloads
    val managers = remember { DownloadRouter.detectInstalledManagers(context) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item(key = "detected_managers") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Detected Download Managers",
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                    ManagerStatusRow(
                        name = "1DM / IDM",
                        installed = managers.has1dmOrIdm,
                        packageName = managers.idmPackage,
                        storeSearchQuery = "1DM download manager"
                    )
                    SubtleHairlineDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    ManagerStatusRow(
                        name = "ADM (Advanced Download Manager)",
                        installed = managers.hasAdm,
                        packageName = managers.admPackage,
                        storeSearchQuery = "ADM download manager"
                    )
                }
            }
        }

        item(key = "download_routing") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Default Download Routing",
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                    DownloadRouterMode.entries.forEachIndexed { index, mode ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    UserPreferencesStore.updateDownloads { it.copy(routerMode = mode) }
                                }
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = d.routerMode == mode,
                                onClick = {
                                    UserPreferencesStore.updateDownloads { it.copy(routerMode = mode) }
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = colors.accent)
                            )
                            Spacer(Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = mode.label,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = colors.textPrimary
                                )
                                Text(
                                    text = mode.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = colors.textSecondary
                                )
                            }
                        }
                        if (index < DownloadRouterMode.entries.lastIndex) {
                            SubtleHairlineDivider(modifier = Modifier.padding(start = 52.dp))
                        }
                    }
                }
            }
        }

        item(key = "dl_fallback") {
            MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                SettingSwitchRow(
                    title = "Fall back to Ad-Blocked Browser",
                    subtitle = "If an external manager is missing or link requires verification",
                    checked = d.fallbackToInAppResolver,
                    onCheckedChange = { on ->
                        UserPreferencesStore.updateDownloads { it.copy(fallbackToInAppResolver = on) }
                    }
                )
            }
        }
    }
}

@Composable
private fun ManagerStatusRow(
    name: String,
    installed: Boolean,
    packageName: String?,
    storeSearchQuery: String
) {
    val colors = LocalMovieLinkColors.current
    val context = LocalContext.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Rounded.Download,
            contentDescription = null,
            tint = if (installed) colors.success else colors.textSecondary,
            modifier = Modifier.size(20.dp)
        )
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(name, style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
            Text(
                text = if (installed) "Installed ($packageName)" else "Not detected on device",
                style = MaterialTheme.typography.bodySmall,
                color = if (installed) colors.success else colors.textSecondary
            )
        }
        if (!installed) {
            TextButton(
                onClick = {
                    val uri = Uri.parse("market://search?q=${Uri.encode(storeSearchQuery)}")
                    try {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW, uri).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                        )
                    } catch (_: Exception) {
                    }
                }
            ) {
                Text("Find App", color = colors.accent)
            }
        }
    }
}

@Composable
fun LibrarySettingsContent(
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    val prefsState by UserPreferencesStore.state.collectAsStateWithLifecycle()
    val lib = prefsState.library
    val libraryState by AppUiStateStore.library.collectAsStateWithLifecycle()

    var pendingClearTarget by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item(key = "library_tracking") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "History & Room Tracking",
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                    SettingSwitchRow(
                        title = "Track Visit History",
                        subtitle = "Record opened movies & series locally in Room database",
                        checked = lib.trackVisitHistory,
                        onCheckedChange = { on ->
                            UserPreferencesStore.updateLibrary { it.copy(trackVisitHistory = on) }
                        }
                    )
                    SubtleHairlineDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    SettingSwitchRow(
                        title = "Track Continue Watching",
                        subtitle = "Save resume timestamps and progress bars across sessions",
                        checked = lib.trackContinueWatching,
                        onCheckedChange = { on ->
                            UserPreferencesStore.updateLibrary { it.copy(trackContinueWatching = on) }
                        }
                    )
                    SubtleHairlineDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Auto-Mark Watched Threshold: ${lib.autoMarkWatchedThresholdPercent}%",
                            style = MaterialTheme.typography.titleSmall,
                            color = colors.textPrimary
                        )
                        Slider(
                            value = lib.autoMarkWatchedThresholdPercent.toFloat(),
                            onValueChange = { v ->
                                UserPreferencesStore.updateLibrary {
                                    it.copy(autoMarkWatchedThresholdPercent = v.toInt().coerceIn(50, 99))
                                }
                            },
                            valueRange = 50f..99f,
                            colors = SliderDefaults.colors(
                                thumbColor = colors.accent,
                                activeTrackColor = colors.accent
                            )
                        )
                    }
                }
            }
        }

        item(key = "library_cleanup") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Saved Data (${libraryState.watchlistItems.size} List • ${libraryState.visitHistory.size} History • ${libraryState.continueWatching.size} Resume)",
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                    CleanupActionRow(
                        title = "Clear Visit History",
                        subtitle = "${libraryState.visitHistory.size} stored entries",
                        onClick = { pendingClearTarget = "history" }
                    )
                    SubtleHairlineDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    CleanupActionRow(
                        title = "Clear Continue Watching",
                        subtitle = "${libraryState.continueWatching.size} saved playback states",
                        onClick = { pendingClearTarget = "continue" }
                    )
                    SubtleHairlineDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    CleanupActionRow(
                        title = "Clear My List (Watchlist)",
                        subtitle = "${libraryState.watchlistItems.size} saved titles",
                        onClick = { pendingClearTarget = "watchlist" }
                    )
                }
            }
        }
    }

    pendingClearTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { pendingClearTarget = null },
            containerColor = colors.surfaceElevated,
            title = { Text("Confirm Clear", color = colors.textPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    text = when (target) {
                        "history" -> "Remove all entries from your local Visit History?"
                        "continue" -> "Reset all Continue Watching playback progress?"
                        else -> "Remove all saved titles from My List?"
                    },
                    color = colors.textSecondary
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        when (target) {
                            "history" -> AppUiStateStore.clearHistory()
                            "continue" -> AppUiStateStore.clearContinueWatching()
                            else -> AppUiStateStore.clearWatchlist()
                        }
                        pendingClearTarget = null
                    }
                ) {
                    Text("Clear", color = colors.danger)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingClearTarget = null }) {
                    Text("Cancel", color = colors.textSecondary)
                }
            }
        )
    }
}

@Composable
private fun CleanupActionRow(
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    val colors = LocalMovieLinkColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Rounded.DeleteOutline,
            contentDescription = null,
            tint = colors.danger,
            modifier = Modifier.size(20.dp)
        )
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
        }
    }
}

@Composable
internal fun SettingSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val colors = LocalMovieLinkColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = colors.onAccent,
                checkedTrackColor = colors.accent
            )
        )
    }
}

