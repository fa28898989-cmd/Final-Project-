package com.movielink.app.core.state

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONObject

enum class DownloadRouterMode(val id: String, val label: String, val description: String) {
    ASK_EACH_TIME("ask", "Ask Each Time", "Choose between 1DM/IDM, ADM, System or In-App"),
    EXTERNAL_1DM("1dm", "1DM / IDM", "Send links directly to 1DM or IDM downloader"),
    EXTERNAL_ADM("adm", "ADM", "Send links directly to Advanced Download Manager"),
    SYSTEM_DOWNLOADER("system", "Android System", "Queue direct file links via system DownloadManager"),
    IN_APP_BROWSER("in_app", "Ad-Blocked Browser", "Always open links inside the ad-blocked resolver")
}

data class PlaybackPreferences(
    val defaultSpeed: Float = 1.0f,
    val seekStepSeconds: Int = 10,
    val gesturesEnabled: Boolean = true,
    val autoFullscreen: Boolean = true,
    val resumePlaybackEnabled: Boolean = true,
    val defaultResizeModeIndex: Int = 0,
    val preferredSubtitleLanguage: String = "English",
    val preferredAudioLanguage: String = "Original"
)

data class DownloadPreferences(
    val routerMode: DownloadRouterMode = DownloadRouterMode.ASK_EACH_TIME,
    val fallbackToInAppResolver: Boolean = true
)

data class LibraryPreferences(
    val trackVisitHistory: Boolean = true,
    val trackContinueWatching: Boolean = true,
    val autoMarkWatchedThresholdPercent: Int = 90
)

data class UserPreferencesState(
    val playback: PlaybackPreferences = PlaybackPreferences(),
    val downloads: DownloadPreferences = DownloadPreferences(),
    val library: LibraryPreferences = LibraryPreferences()
)

object UserPreferencesStore {
    private const val PREFS_NAME = "movielink_user_prefs_v1"
    private const val KEY_JSON = "prefs_json"

    private var prefs: SharedPreferences? = null

    private val _state = MutableStateFlow(UserPreferencesState())
    val state: StateFlow<UserPreferencesState> = _state.asStateFlow()

    fun init(context: Context) {
        if (prefs != null) return
        val sp = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs = sp
        val raw = sp.getString(KEY_JSON, null)
        if (!raw.isNullOrBlank()) {
            _state.value = decode(raw)
        }
    }

    fun updatePlayback(transform: (PlaybackPreferences) -> PlaybackPreferences) {
        _state.update { prev ->
            val next = prev.copy(playback = transform(prev.playback))
            persist(next)
            next
        }
    }

    fun updateDownloads(transform: (DownloadPreferences) -> DownloadPreferences) {
        _state.update { prev ->
            val next = prev.copy(downloads = transform(prev.downloads))
            persist(next)
            next
        }
    }

    fun updateLibrary(transform: (LibraryPreferences) -> LibraryPreferences) {
        _state.update { prev ->
            val next = prev.copy(library = transform(prev.library))
            persist(next)
            next
        }
    }

    fun replaceAll(newState: UserPreferencesState) {
        _state.value = newState
        persist(newState)
    }

    private fun persist(value: UserPreferencesState) {
        val sp = prefs ?: return
        val p = value.playback
        val d = value.downloads
        val l = value.library
        val json = JSONObject().apply {
            put(
                "playback",
                JSONObject().apply {
                    put("defaultSpeed", p.defaultSpeed.toDouble())
                    put("seekStepSeconds", p.seekStepSeconds)
                    put("gesturesEnabled", p.gesturesEnabled)
                    put("autoFullscreen", p.autoFullscreen)
                    put("resumePlaybackEnabled", p.resumePlaybackEnabled)
                    put("defaultResizeModeIndex", p.defaultResizeModeIndex)
                    put("preferredSubtitleLanguage", p.preferredSubtitleLanguage)
                    put("preferredAudioLanguage", p.preferredAudioLanguage)
                }
            )
            put(
                "downloads",
                JSONObject().apply {
                    put("routerMode", d.routerMode.id)
                    put("fallbackToInAppResolver", d.fallbackToInAppResolver)
                }
            )
            put(
                "library",
                JSONObject().apply {
                    put("trackVisitHistory", l.trackVisitHistory)
                    put("trackContinueWatching", l.trackContinueWatching)
                    put("autoMarkWatchedThresholdPercent", l.autoMarkWatchedThresholdPercent)
                }
            )
        }.toString()
        sp.edit().putString(KEY_JSON, json).apply()
    }

    private fun decode(raw: String): UserPreferencesState {
        return try {
            val root = JSONObject(raw)
            val pObj = root.optJSONObject("playback")
            val dObj = root.optJSONObject("downloads")
            val lObj = root.optJSONObject("library")

            val playback = if (pObj != null) {
                PlaybackPreferences(
                    defaultSpeed = pObj.optDouble("defaultSpeed", 1.0).toFloat().coerceIn(0.5f, 3.0f),
                    seekStepSeconds = pObj.optInt("seekStepSeconds", 10).coerceIn(5, 60),
                    gesturesEnabled = pObj.optBoolean("gesturesEnabled", true),
                    autoFullscreen = pObj.optBoolean("autoFullscreen", true),
                    resumePlaybackEnabled = pObj.optBoolean("resumePlaybackEnabled", true),
                    defaultResizeModeIndex = pObj.optInt("defaultResizeModeIndex", 0).coerceIn(0, 2),
                    preferredSubtitleLanguage = pObj.optString("preferredSubtitleLanguage", "English"),
                    preferredAudioLanguage = pObj.optString("preferredAudioLanguage", "Original")
                )
            } else PlaybackPreferences()

            val modeId = dObj?.optString("routerMode", DownloadRouterMode.ASK_EACH_TIME.id)
            val mode = DownloadRouterMode.entries.firstOrNull { it.id == modeId }
                ?: DownloadRouterMode.ASK_EACH_TIME
            val downloads = DownloadPreferences(
                routerMode = mode,
                fallbackToInAppResolver = dObj?.optBoolean("fallbackToInAppResolver", true) ?: true
            )

            val library = if (lObj != null) {
                LibraryPreferences(
                    trackVisitHistory = lObj.optBoolean("trackVisitHistory", true),
                    trackContinueWatching = lObj.optBoolean("trackContinueWatching", true),
                    autoMarkWatchedThresholdPercent = lObj.optInt("autoMarkWatchedThresholdPercent", 90).coerceIn(50, 99)
                )
            } else LibraryPreferences()

            UserPreferencesState(playback = playback, downloads = downloads, library = library)
        } catch (_: Exception) {
            UserPreferencesState()
        }
    }
}
