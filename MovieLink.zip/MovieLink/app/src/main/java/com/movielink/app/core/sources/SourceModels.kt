package com.movielink.app.core.sources

import com.movielink.app.core.model.ProviderId

enum class ProviderHealthStatus(val label: String) {
    UNKNOWN("Not Checked"),
    CHECKING("Checking…"),
    ONLINE("Reachable"),
    UNREACHABLE("Unreachable"),
    DISABLED("Disabled")
}

data class ProviderCapabilities(
    val supportsHomeCatalog: Boolean = true,
    val supportsOttFilter: Boolean = false,
    val supportsSeries: Boolean = true,
    val supportsDownloads: Boolean = true,
    val supportsDirectStreams: Boolean = false
) {
    fun badgeLabels(): List<String> = buildList {
        if (supportsHomeCatalog) add("Catalog")
        if (supportsOttFilter) add("OTT")
        if (supportsSeries) add("Series")
        if (supportsDownloads) add("Downloads")
        if (supportsDirectStreams) add("Streams")
    }
}

data class MirrorProbeResult(
    val url: String,
    val resolvedUrl: String = url,
    val status: ProviderHealthStatus = ProviderHealthStatus.UNKNOWN,
    val httpCode: Int? = null,
    val latencyMs: Long = 0L,
    val message: String = "",
    val checkedAtMs: Long = 0L
)

data class WebsiteSourceConfig(
    val providerId: ProviderId,
    val enabled: Boolean = true,
    val activeBaseUrl: String = providerId.defaultBaseUrl,
    val mirrors: List<String> = defaultMirrorsFor(providerId),
    val customUserAgent: String = "",
    val timeoutSeconds: Int = 12,
    val adBlockEnabled: Boolean = true
)

data class ProviderDiagnosticsEvent(
    val id: Long,
    val timestampMs: Long,
    val providerId: ProviderId,
    val isError: Boolean,
    val message: String
)

fun normalizeProviderUrl(raw: String): String? {
    val trimmed = raw.trim()
    if (trimmed.isEmpty()) return null
    val withScheme = if (trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true)) {
        trimmed
    } else {
        "https://$trimmed"
    }
    return try {
        val parsed = java.net.URI(withScheme)
        val scheme = parsed.scheme?.lowercase()
        val host = parsed.host
        if ((scheme != "http" && scheme != "https") || host.isNullOrBlank()) {
            null
        } else {
            val base = withScheme.substringBefore('#').substringBefore('?')
            if (base.endsWith("/")) base else "$base/"
        }
    } catch (_: Exception) {
        null
    }
}

fun defaultMirrorsFor(providerId: ProviderId): List<String> = when (providerId) {
    ProviderId.MOVIELINKBD -> listOf(
        "https://movielinkbd.tv/",
        "https://movielinkbd.lol/"
    )
    ProviderId.CINEFREAK -> listOf(
        "https://cinefreak.net/",
        "https://cinefreak.bid/"
    )
    ProviderId.RTALLY -> listOf(
        "https://rtally.lol/",
        "https://rtally.fun/"
    )
}
