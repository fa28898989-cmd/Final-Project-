package com.movielink.app.core.designsystem

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

object MovieLinkRadius {
    val Xs = 8.dp
    val Sm = 12.dp
    val Md = 16.dp
    val Lg = 20.dp
    val Pill = 999.dp
}

val MovieLinkShapes = Shapes(
    extraSmall = RoundedCornerShape(MovieLinkRadius.Xs),
    small = RoundedCornerShape(MovieLinkRadius.Sm),
    medium = RoundedCornerShape(MovieLinkRadius.Md),
    large = RoundedCornerShape(MovieLinkRadius.Lg),
    extraLarge = RoundedCornerShape(24.dp)
)
