package com.movielink.app.core.sources.providers

import android.net.Uri
import com.movielink.app.core.adblock.AdBlockerEngine
import com.movielink.app.core.model.CastMember
import com.movielink.app.core.model.CatalogSection
import com.movielink.app.core.model.DownloadSourceLink
import com.movielink.app.core.model.EpisodeItem
import com.movielink.app.core.model.MediaDetail
import com.movielink.app.core.model.MediaKind
import com.movielink.app.core.model.MediaSummary
import com.movielink.app.core.model.MovieInfoField
import com.movielink.app.core.model.OttPlatformItem
import com.movielink.app.core.model.ProviderCatalog
import com.movielink.app.core.model.ProviderId
import com.movielink.app.core.model.SeasonGroup
import com.movielink.app.core.network.MovieLinkHttpClient
import com.movielink.app.core.sources.MediaSourceProvider
import com.movielink.app.core.sources.ProviderCapabilities
import com.movielink.app.core.sources.WebsiteSourcesStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLEncoder

/**
 * Website 1 — MovieLinkBD live Jsoup/OkHttp provider with LCG token decoding & AdBlock filtering.
 */
class MovieLinkBDProvider : MediaSourceProvider {
    override val providerId: ProviderId = ProviderId.MOVIELINKBD

    override val capabilities = ProviderCapabilities(
        supportsHomeCatalog = true,
        supportsOttFilter = true,
        supportsSeries = true,
        supportsDownloads = true,
        supportsDirectStreams = true
    )

    override suspend fun fetchHomeCatalog(baseUrl: String): Result<ProviderCatalog> = withContext(Dispatchers.IO) {
        runCatching {
            val cfg = WebsiteSourcesStore.configFor(providerId)
            val fetch = MovieLinkHttpClient.fetchHtml(baseUrl, providerId, cfg.timeoutSeconds, cfg.customUserAgent)
            val doc = Jsoup.parse(fetch.html, fetch.finalUrl)
            parseCatalogDocument(doc, fetch.finalUrl)
        }
    }

    override suspend fun search(baseUrl: String, query: String): Result<List<MediaSummary>> = withContext(Dispatchers.IO) {
        runCatching {
            val cfg = WebsiteSourcesStore.configFor(providerId)
            val encoded = URLEncoder.encode(query.trim(), "UTF-8")
            val searchUrl = "${baseUrl.trimEnd('/')}/search?q=$encoded"
            val fetch = MovieLinkHttpClient.fetchHtml(searchUrl, providerId, cfg.timeoutSeconds, cfg.customUserAgent)
            val doc = Jsoup.parse(fetch.html, fetch.finalUrl)
            doc.select(".movie-card")
                .mapNotNull { parseMovieCard(it, fetch.finalUrl) }
                .distinctBy { it.id }
        }
    }

    override suspend fun fetchDetails(baseUrl: String, mediaId: String): Result<MediaDetail> = withContext(Dispatchers.IO) {
        runCatching {
            val cfg = WebsiteSourcesStore.configFor(providerId)
            val targetUrl = if (mediaId.startsWith("http", true)) {
                mediaId
            } else {
                ProviderParsingUtils.resolveUrl(baseUrl, mediaId)
            }
            val fetch = MovieLinkHttpClient.fetchHtml(targetUrl, providerId, cfg.timeoutSeconds, cfg.customUserAgent)
            val doc = Jsoup.parse(fetch.html, fetch.finalUrl)
            parseDetailDocument(doc, fetch.finalUrl)
        }
    }

    private fun parseCatalogDocument(doc: Document, finalUrl: String): ProviderCatalog {
        val sections = mutableListOf<CatalogSection>()
        val seenKeys = hashSetOf<String>()

        doc.select(".movie-cards-container").forEachIndexed { idx, container ->
            val cards = container.select(".movie-card")
                .mapNotNull { parseMovieCard(it, finalUrl) }
                .distinctBy { it.id }
            if (cards.isEmpty()) return@forEachIndexed

            val rawHeading = findSectionHeading(container)?.text()?.trim().orEmpty()
            val title = BanglaUiNormalizer.normalizeUiText(rawHeading)
                .ifBlank { if (sections.isEmpty()) "Recently Updated" else "More Titles" }
            val key = "${title.lowercase()}:${cards.first().id}"
            if (seenKeys.add(key)) {
                sections.add(CatalogSection(id = "mlbd_sec_$idx", title = title, items = cards))
            }
        }

        doc.select("section.mlbd-rail-section").forEachIndexed { idx, rail ->
            val cards = rail.select(".mlbd-rail .movie-card, .movie-card")
                .mapNotNull { parseMovieCard(it, finalUrl) }
                .distinctBy { it.id }
            if (cards.isEmpty()) return@forEachIndexed

            val rawTitle = rail.selectFirst(".mlbd-rail-title")?.text()?.trim()
                ?: rail.attr("aria-label").trim()
            val cleanTitle = BanglaUiNormalizer.normalizeUiText(rawTitle).ifBlank { "Featured" }
            if (cleanTitle.contains("18+", true) || cleanTitle.contains("adult", true)) return@forEachIndexed
            val key = "${cleanTitle.lowercase()}:${cards.first().id}"
            if (seenKeys.add(key)) {
                sections.add(CatalogSection(id = "mlbd_rail_$idx", title = cleanTitle, items = cards))
            }
        }

        if (sections.isEmpty()) {
            val fallback = doc.select(".movie-card")
                .mapNotNull { parseMovieCard(it, finalUrl) }
                .distinctBy { it.id }
            if (fallback.isNotEmpty()) {
                sections.add(CatalogSection(id = "mlbd_all", title = "Latest Releases", items = fallback))
            }
        }

        val ottPlatforms = extractOttPlatforms(doc)
        val categories = extractCategories(doc, finalUrl)
        val heroItems = sections.firstOrNull()?.items?.take(8).orEmpty()

        return ProviderCatalog(
            providerId = providerId,
            heroItems = heroItems,
            ottPlatforms = ottPlatforms,
            categories = categories,
            sections = sections
        )
    }

    private fun parseMovieCard(card: Element, baseUrl: String): MediaSummary? {
        val anchor = card.selectFirst("a[href*=/movie/], a[href*=/series/], a[href*=/drama/], a[href*=/anime/], a[href]")
            ?: return null
        val absUrl = ProviderParsingUtils.resolveUrl(baseUrl, anchor.attr("href"))
        if (absUrl.isBlank() || AdBlockerEngine.shouldBlockUrl(absUrl, providerId)) return null

        val img = card.selectFirst("img")
        val rawTitle = card.selectFirst(".title, .movie-title, h3, h4")?.text()?.trim()
            ?.takeIf { it.isNotEmpty() }
            ?: img?.attr("alt")?.trim()
            ?: anchor.attr("title").trim()
        if (rawTitle.isBlank()) return null

        val (cleanTitle, year) = ProviderParsingUtils.cleanTitleYearSplit(rawTitle)

        val dataSrc = img?.attr("data-src")?.trim().orEmpty()
        val src = img?.attr("src")?.trim().orEmpty()
        val posterRaw = when {
            dataSrc.isNotEmpty() && !dataSrc.startsWith("data:") && !dataSrc.contains("mlbd_load") -> dataSrc
            src.isNotEmpty() && !src.startsWith("data:") && !src.contains("mlbd_load") -> src
            else -> ""
        }
        val posterUrl = if (posterRaw.isNotEmpty()) ProviderParsingUtils.resolveUrl(baseUrl, posterRaw) else ""

        val quality = card.select(".badge-group .badge, .quality")
            .map { it.text().trim() }
            .firstOrNull { txt ->
                txt.isNotBlank() && !txt.equals("PINNED", true) && !txt.equals("FEATURED", true)
            }
            .orEmpty()
        val language = BanglaUiNormalizer.normalizeUiText(card.selectFirst(".language")?.text().orEmpty())
        val typeRaw = card.selectFirst(".type")?.text().orEmpty()
        val isSeries = typeRaw.contains("series", true) || absUrl.contains("/series/", true)

        return MediaSummary(
            id = absUrl,
            providerId = providerId,
            title = cleanTitle,
            year = year,
            languageTag = language,
            kind = if (isSeries) MediaKind.SERIES else MediaKind.MOVIE,
            posterUrl = posterUrl,
            backdropUrl = posterUrl,
            qualityBadge = quality,
            sourceUrl = absUrl
        )
    }

    private fun extractOttPlatforms(doc: Document): List<OttPlatformItem> {
        val bar = doc.selectFirst(".mlbd-ottbar") ?: return emptyList()
        return bar.select("a.mlbd-ott-item[href]").mapNotNull { a ->
            val name = a.selectFirst(".mlbd-ott-lbl")?.text()?.trim()
                ?.ifBlank { a.attr("title").trim() }
                .orEmpty()
            if (name.isBlank()) return@mapNotNull null
            val styleAttr = a.attr("style")
            val hexStr = Regex("""--oc\s*:\s*(#[0-9a-fA-F]{3,8})""").find(styleAttr)?.groupValues?.getOrNull(1)
            val color = ProviderParsingUtils.parseHexColor(hexStr, 0xFF1E293B)
            ProviderParsingUtils.buildOttItem(
                id = name.lowercase().replace(" ", "_"),
                name = name,
                shortCode = name.take(2).uppercase(),
                brandColorHex = color
            )
        }.distinctBy { it.id }
    }

    private fun extractCategories(doc: Document, baseUrl: String): List<String> {
        val out = linkedSetOf<String>()
        doc.select("a[href]").forEach { a ->
            val abs = ProviderParsingUtils.resolveUrl(baseUrl, a.attr("href"))
            if (abs.isBlank()) return@forEach
            val path = Uri.parse(abs).path.orEmpty()
            val match = path.startsWith("/genre/") || path.startsWith("/language/") ||
                path.startsWith("/category/") || path.startsWith("/collection/")
            if (!match) return@forEach
            val clean = BanglaUiNormalizer.normalizeUiText(a.text().trim())
                .replace(Regex("""\s+\d+\s+titles$""", RegexOption.IGNORE_CASE), "")
                .trim()
            if (clean.isNotBlank() && clean.length <= 28 && !BanglaUiNormalizer.isClutterText(clean)) {
                out.add(clean)
            }
        }
        return out.take(24)
    }

    private fun findSectionHeading(container: Element): Element? {
        var prev = container.previousElementSibling()
        var steps = 0
        while (prev != null && steps < 4) {
            val h = prev.selectFirst("h1, h2, h3, h4, .section-title, .mlbd-sec-title")
                ?: if (prev.tagName().matches(Regex("h[1-4]"))) prev else null
            if (h != null && h.text().isNotBlank() && !BanglaUiNormalizer.isClutterText(h.text())) return h
            prev = prev.previousElementSibling()
            steps++
        }
        return null
    }

    private fun parseDetailDocument(doc: Document, finalUrl: String): MediaDetail {
        val rawTitle = doc.selectFirst(".movie-info-view h1, h1")?.text()?.trim()
            ?: doc.title().substringBefore("—").substringBefore("|").trim()
        val (cleanTitle, year) = ProviderParsingUtils.cleanTitleYearSplit(rawTitle)

        val posterEl = doc.selectFirst(".movie-poster img, .poster-img, .image-container img, meta[property=og:image]")
        val posterRaw = when {
            posterEl == null -> ""
            posterEl.tagName() == "meta" -> posterEl.attr("content")
            posterEl.attr("data-src").isNotBlank() && !posterEl.attr("data-src").contains("mlbd_load") ->
                posterEl.attr("data-src")
            else -> posterEl.attr("src")
        }
        val posterUrl = if (posterRaw.isNotBlank() && !posterRaw.startsWith("data:")) {
            ProviderParsingUtils.resolveUrl(finalUrl, posterRaw)
        } else ""

        var isSeries = finalUrl.contains("/series/", true)
        var langVal = ""
        var qualVal = ""
        val extraInfoFields = mutableListOf<MovieInfoField>()
        doc.select("ul.flex-container li.flex-item").forEach { li ->
            val bold = li.selectFirst("b")?.text()?.trim().orEmpty()
            val full = li.text().trim()
            val key = full.removeSuffix(bold).trim().removeSuffix(":")
            val cleanVal = BanglaUiNormalizer.normalizeUiText(bold)
            if (key.isNotBlank() && cleanVal.isNotBlank()) {
                extraInfoFields.add(MovieInfoField(key, cleanVal))
            }
            when {
                key.contains("type", true) && cleanVal.contains("series", true) -> isSeries = true
                key.contains("lang", true) -> langVal = cleanVal
                key.contains("qual", true) -> qualVal = cleanVal
            }
        }

        val storyline = BanglaUiNormalizer.normalizeUiText(
            doc.selectFirst(".storyline-box .story-text, .storyline-box p")?.text().orEmpty()
        )
        val screenshots = doc.select(".screenshot-wrapper img").mapNotNull { img ->
            val d = img.attr("data-src").trim()
            val s = img.attr("src").trim()
            val u = if (d.isNotEmpty() && !d.contains("mlbd_load")) d else s
            if (u.isNotEmpty() && !u.startsWith("data:") && !u.contains("mlbd_load")) {
                ProviderParsingUtils.resolveUrl(finalUrl, u)
            } else null
        }.distinct()

        val cast = doc.select(".mlbd-cast__p").mapNotNull { el ->
            val name = el.selectFirst("b")?.text()?.trim().orEmpty()
            if (name.isBlank()) return@mapNotNull null
            val role = el.selectFirst("small")?.text()?.trim().orEmpty()
            CastMember(name = name, role = role, avatarColorHex = 0xFF1E293B)
        }

        val epBySeason = linkedMapOf<Int, MutableList<EpisodeItem>>()
        doc.select("#mlbdEpisodeDownloadGrid .ep-card").forEach { card ->
            val seasonNum = card.attr("data-season-number").trim().toIntOrNull() ?: 1
            val epNum = card.attr("data-episode-number").trim().toIntOrNull() ?: 1
            val epTitleRaw = card.selectFirst(".mlbd-episode-title, h5, h4")?.ownText()?.trim().orEmpty()
            val epTitle = BanglaUiNormalizer.normalizeUiText(epTitleRaw)
                .ifBlank { "Episode $epNum" }
            val isNew = card.selectFirst(".mlbd-ep-flag.is-new") != null
            val epLinks = extractDownloads(card.select("a[data-dl], a.btn-user"), finalUrl)
            if (epLinks.isNotEmpty()) {
                epBySeason.getOrPut(seasonNum) { mutableListOf() }.add(
                    EpisodeItem(
                        number = epNum,
                        title = epTitle,
                        runtime = "",
                        isNew = isNew,
                        downloads = epLinks
                    )
                )
            }
        }
        val seasons = epBySeason.entries.sortedBy { it.key }.map { (seasonNum, eps) ->
            SeasonGroup(
                seasonNumber = seasonNum,
                title = "Season $seasonNum",
                episodes = eps.sortedBy { it.number }
            )
        }

        val zipDownloads = extractDownloads(
            doc.select("#mlbdSeasonZipDownloads a[data-dl], #mlbdZipDownloadGrid a[data-dl]"),
            finalUrl,
            markZip = true
        )
        val mainAnchors = doc.select("a[data-dl], a.btn-dark.btn-user").filter { el ->
            el.parents().none { p ->
                p.id() == "mlbdEpisodeDownloadGrid" ||
                    p.id() == "mlbdSeasonZipDownloads" ||
                    p.id() == "mlbdZipDownloadGrid"
            }
        }
        val downloadLinks = extractDownloads(mainAnchors, finalUrl) + zipDownloads

        val watchSrc = doc.selectFirst("iframe#mlbdHdFrame, iframe[src*=/p/]")?.attr("src")?.trim()
        val watchEmbedUrl = watchSrc?.takeIf { it.isNotBlank() }
            ?.let { ProviderParsingUtils.resolveUrl(finalUrl, it) }
            ?.takeUnless { AdBlockerEngine.shouldBlockUrl(it, providerId) }

        val trailerYt = doc.selectFirst("[data-mlbd-trailer]")?.attr("data-mlbd-trailer")?.trim()
            ?.takeIf { it.isNotBlank() }
        val trailerUrl = trailerYt?.let { "https://www.youtube.com/watch?v=$it" }

        val related = doc.select(".movie-card")
            .mapNotNull { parseMovieCard(it, finalUrl) }
            .filterNot { it.id == finalUrl }
            .distinctBy { it.id }
            .take(12)

        val summary = MediaSummary(
            id = finalUrl,
            providerId = providerId,
            title = cleanTitle,
            year = year,
            languageTag = langVal,
            kind = if (isSeries || seasons.isNotEmpty()) MediaKind.SERIES else MediaKind.MOVIE,
            posterUrl = posterUrl,
            backdropUrl = screenshots.firstOrNull() ?: posterUrl,
            qualityBadge = qualVal,
            sourceUrl = finalUrl
        )

        val sources = buildList {
            if (watchEmbedUrl != null) add("Web Player (${providerId.displayName})")
            if (downloadLinks.isNotEmpty()) add("Direct Downloads (${downloadLinks.size})")
        }.ifEmpty { listOf("Website Page") }

        return MediaDetail(
            summary = summary,
            overview = storyline,
            screenshots = screenshots,
            infoFields = extraInfoFields,
            sources = sources,
            downloadLinks = downloadLinks,
            cast = cast,
            seasons = seasons,
            recommendations = related,
            trailerLabel = if (trailerUrl != null) "Watch Trailer" else "Official Trailer",
            watchEmbedUrl = watchEmbedUrl,
            trailerUrl = trailerUrl
        )
    }

    private fun extractDownloads(
        elements: List<Element>,
        baseUrl: String,
        markZip: Boolean = false
    ): List<DownloadSourceLink> {
        val out = mutableListOf<DownloadSourceLink>()
        val seen = hashSetOf<String>()
        elements.forEachIndexed { idx, a ->
            val dataDl = a.attr("data-dl").trim()
            val decoded = if (dataDl.isNotEmpty()) {
                val ds = a.attr("data-ds").trim()
                val dr = a.attr("data-dr").trim().toIntOrNull() ?: 0
                ProviderParsingUtils.decodeToken(dataDl, ds, dr)
            } else {
                a.attr("href").trim().takeIf { it.isNotEmpty() && it != "#" }
            }
            if (decoded.isNullOrBlank()) return@forEachIndexed
            val abs = ProviderParsingUtils.resolveUrl(baseUrl, decoded)
            if (abs.isBlank() || AdBlockerEngine.shouldBlockUrl(abs, providerId)) return@forEachIndexed
            val rawLabel = a.text().trim().replace(Regex("""\s+"""), " ")
            if (BanglaUiNormalizer.isClutterText(rawLabel)) return@forEachIndexed
            val label = BanglaUiNormalizer.normalizeUiText(rawLabel).ifBlank { "Download Link" }
            if (seen.add("$label|$abs")) {
                val quality = Regex("""(2160p|4K|1080p|720p|480p|360p)""", RegexOption.IGNORE_CASE)
                    .find(label)?.groupValues?.getOrNull(1)?.uppercase() ?: "HD"
                val size = Regex("""\[([^\]]*(?:MB|GB)[^\]]*)]""", RegexOption.IGNORE_CASE)
                    .find(label)?.groupValues?.getOrNull(1).orEmpty()
                out.add(
                    DownloadSourceLink(
                        id = "mlbd_dl_$idx",
                        label = label,
                        quality = quality,
                        size = size,
                        url = abs,
                        isZip = markZip || label.contains("zip", true)
                    )
                )
            }
        }
        return out
    }
}
