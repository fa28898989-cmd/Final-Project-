package com.movielink.app.feature.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.movielink.app.core.designsystem.FilterPill
import com.movielink.app.core.designsystem.LocalMovieLinkColors
import com.movielink.app.core.designsystem.MovieLinkCard
import com.movielink.app.core.designsystem.MovieLinkRadius
import com.movielink.app.core.designsystem.SecondaryActionButton
import com.movielink.app.core.designsystem.SubtleHairlineDivider
import com.movielink.app.core.model.HomeHeroStyle
import com.movielink.app.core.state.AppUiStateStore

private enum class WheelTarget {
    BACKGROUND,
    ACCENT
}

@Composable
fun AppearanceSettingsContent(
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    val appearance by AppUiStateStore.appearance.collectAsStateWithLifecycle()
    var wheelTarget by remember { mutableStateOf<WheelTarget?>(null) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Live Theme Preview Card
        item(key = "live_preview") {
            MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Live Preview",
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.textSecondary
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Pure Black AMOLED",
                                style = MaterialTheme.typography.titleMedium,
                                color = colors.textPrimary
                            )
                            Text(
                                text = "Bg ${AppUiStateStore.colorToHex(appearance.backgroundColor)} • Accent ${AppUiStateStore.colorToHex(appearance.accentColor)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textSecondary
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(MovieLinkRadius.Pill))
                                .background(colors.accent)
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "Accent",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = colors.onAccent
                            )
                        }
                    }
                }
            }
        }

        // Background & Accent Color Pickers
        item(key = "colors") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Theme Colors",
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                    ColorPickerRow(
                        title = "Background Color",
                        subtitle = AppUiStateStore.colorToHex(appearance.backgroundColor),
                        swatchColor = appearance.backgroundColor,
                        onEdit = { wheelTarget = WheelTarget.BACKGROUND }
                    )
                    SubtleHairlineDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    ColorPickerRow(
                        title = "App Accent Color",
                        subtitle = AppUiStateStore.colorToHex(appearance.accentColor),
                        swatchColor = appearance.accentColor,
                        onEdit = { wheelTarget = WheelTarget.ACCENT }
                    )
                }
            }
        }

        // Home Hero Style & Adjustable Sizes
        item(key = "hero") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Hero Layout & Sizing",
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                MovieLinkCard(cornerRadius = MovieLinkRadius.Md) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "Home Hero Style",
                            style = MaterialTheme.typography.titleSmall,
                            color = colors.textPrimary
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            HomeHeroStyle.entries.forEach { style ->
                                FilterPill(
                                    label = style.label,
                                    selected = appearance.heroStyle == style,
                                    onClick = { AppUiStateStore.setHeroStyle(style) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        SubtleHairlineDivider()

                        HeroHeightSlider(
                            label = "Home Hero Size",
                            valueDp = appearance.homeHeroHeightDp,
                            range = 340f..560f,
                            onChange = { next ->
                                AppUiStateStore.updateAppearance { it.copy(homeHeroHeightDp = next) }
                            }
                        )

                        HeroHeightSlider(
                            label = "Details Hero Size",
                            valueDp = appearance.detailsHeroHeightDp,
                            range = 280f..500f,
                            onChange = { next ->
                                AppUiStateStore.updateAppearance { it.copy(detailsHeroHeightDp = next) }
                            }
                        )
                    }
                }
            }
        }

        // Reset to Pure Black Default
        item(key = "reset") {
            SecondaryActionButton(
                text = "Reset Appearance to Default",
                onClick = { AppUiStateStore.resetAppearance() },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
        }
    }

    wheelTarget?.let { target ->
        val initial = when (target) {
            WheelTarget.BACKGROUND -> appearance.backgroundColor
            WheelTarget.ACCENT -> appearance.accentColor
        }
        ColorWheelPickerDialog(
            title = if (target == WheelTarget.BACKGROUND) "Choose Background Color" else "Choose Accent Color",
            initialColor = initial,
            onConfirm = { chosen ->
                AppUiStateStore.updateAppearance { current ->
                    when (target) {
                        WheelTarget.BACKGROUND -> current.copy(backgroundColor = chosen)
                        WheelTarget.ACCENT -> current.copy(accentColor = chosen)
                    }
                }
                wheelTarget = null
            },
            onDismiss = { wheelTarget = null }
        )
    }
}

@Composable
private fun ColorPickerRow(
    title: String,
    subtitle: String,
    swatchColor: Color,
    onEdit: () -> Unit
) {
    val colors = LocalMovieLinkColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onEdit)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = colors.textPrimary
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary
            )
        }
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(swatchColor)
                    .border(1.dp, colors.borderStrong, CircleShape)
            )
            Button(
                onClick = onEdit,
                shape = RoundedCornerShape(MovieLinkRadius.Pill),
                colors = ButtonDefaults.buttonColors(
                    containerColor = colors.surfaceElevated,
                    contentColor = colors.textPrimary
                ),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text("Customize", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
private fun HeroHeightSlider(
    label: String,
    valueDp: Int,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Int) -> Unit
) {
    val colors = LocalMovieLinkColors.current
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.bodyMedium, color = colors.textPrimary)
            Text("${valueDp} dp", style = MaterialTheme.typography.labelLarge, color = colors.accent)
        }
        Slider(
            value = valueDp.toFloat(),
            onValueChange = { onChange(it.toInt()) },
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = colors.accent,
                activeTrackColor = colors.accent,
                inactiveTrackColor = colors.surfaceElevated
            )
        )
    }
}
