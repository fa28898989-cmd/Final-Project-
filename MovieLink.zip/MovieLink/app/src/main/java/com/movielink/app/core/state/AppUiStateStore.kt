package com.movielink.app.core.state

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.movielink.app.core.database.LibraryDao
import com.movielink.app.core.database.LibraryItemEntity
import com.movielink.app.core.database.MovieLinkDatabase
import com.movielink.app.core.database.PlaybackProgressEntity
import com.movielink.app.core.designsystem.MovieLinkColors
import com.movielink.app.core.model.ContinueWatchingEntry
import com.movielink.app.core.model.HomeHeroStyle
import com.movielink.app.core.model.MediaSummary
import com.movielink.app.core.model.ProviderId
import com.movielink.app.core.model.VisitHistoryEntry
import com.movielink.app.core.sources.WebsiteSourcesStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

data class AppearanceSettings(
    val backgroundColor: Color = MovieLinkColors.PureBlack,
    val accentColor: Color = MovieLinkColors.DefaultAccent,
    val heroStyle: HomeHeroStyle = HomeHeroStyle.CINEMATIC,
    val homeHeroHeightDp: Int = 460,
    val detailsHeroHeightDp: Int = 390,
    val activeHomeProvider: ProviderId = ProviderId.MOVIELINKBD
)

data class LibraryState(
    val watchlistIds: Set<String> = emptySet(),
    val watchlistItems: List<MediaSummary> = emptyList(),
    val watchedIds: Set<String> = emptySet(),
    val continueWatching: List<ContinueWatchingEntry> = emptyList(),
    val visitHistory: List<VisitHistoryEntry> = emptyList()
)

/**
 * Persistent application state store backed by SharedPreferences (Appearance) and
 * Room Database (Watchlist, Watched states, Visit History, and Playback Progress).
 */
object AppUiStateStore {
    private const val APPEARANCE_PREFS = "movielink_appearance_v1"
    private const val KEY_APPEARANCE_JSON = "appearance_json"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var appearancePrefs: SharedPreferences? = null
    private var libraryDao: LibraryDao? = null

    private val summaryCache = ConcurrentHashMap<String, MediaSummary>()

    private val _appearance = MutableStateFlow(AppearanceSettings())
    val appearance: StateFlow<AppearanceSettings> = _appearance.asStateFlow()

    private val _library = MutableStateFlow(LibraryState())
    val library: StateFlow<LibraryState> = _library.asStateFlow()

    fun init(context: Context) {
        if (libraryDao != null) return
        val appCtx = context.applicationContext

        val sp = appCtx.getSharedPreferences(APPEARANCE_PREFS, Context.MODE_PRIVATE)
        appearancePrefs = sp
        sp.getString(KEY_APPEARANCE_JSON, null)?.let { raw ->
            val restored = decodeAppearance(raw)
            _appearance.value = restored
            WebsiteSourcesStore.setActiveHomeProvider(restored.activeHomeProvider)
        }

        val dao = MovieLinkDatabase.getInstance(appCtx).libraryDao()
        libraryDao = dao

        scope.launch {
            combine(
                dao.observeAllLibraryItems(),
                dao.observeContinueWatching()
            ) { items, progressList ->
                val byId = items.associateBy { it.mediaId }
                byId.values.forEach { summaryCache[it.mediaId] = it.toMediaSummary() }

                val watchlistEntities = items.filter { it.isInWatchlist }
                val watchedIds = items.filter { it.isWatched }.map { it.mediaId }.toSet()
                val history = items
                    .filter { it.lastVisitedAtMs > 0L }
                    .sortedByDescending { it.lastVisitedAtMs }
                    .take(60)
                    .map { entity ->
                        VisitHistoryEntry(
                            media = entity.toMediaSummary(),
                            visitedAtLabel = formatRelativeTime(entity.lastVisitedAtMs)
                        )
                    }
                val continueList = progressList
                    .take(20)
                    .map { p ->
                        ContinueWatchingEntry(
                            media = p.toSummary(byId[p.mediaId]?.toMediaSummary()),
                            episodeLabel = p.episodeLabel,
                            progressFraction = p.progressFraction.coerceIn(0f, 1f),
                            remainingLabel = p.remainingLabel
                        )
                    }

                LibraryState(
                    watchlistIds = watchlistEntities.map { it.mediaId }.toSet(),
                    watchlistItems = watchlistEntities
                        .sortedByDescending { it.lastVisitedAtMs }
                        .map { it.toMediaSummary() },
                    watchedIds = watchedIds,
                    continueWatching = continueList,
                    visitHistory = history
                )
            }.collect { next ->
                _library.value = next
            }
        }
    }

    fun updateAppearance(transform: (AppearanceSettings) -> AppearanceSettings) {
        _appearance.update { prev ->
            val next = transform(prev)
            persistAppearance(next)
            next
        }
    }

    fun resetAppearance() {
        val fresh = AppearanceSettings()
        _appearance.value = fresh
        persistAppearance(fresh)
    }

    fun setHomeProvider(providerId: ProviderId) {
        WebsiteSourcesStore.setActiveHomeProvider(providerId)
        updateAppearance { it.copy(activeHomeProvider = providerId) }
    }

    fun setHeroStyle(style: HomeHeroStyle) {
        updateAppearance { it.copy(heroStyle = style) }
    }

    fun toggleWatchlist(media: MediaSummary) {
        summaryCache[media.id] = media
        val dao = libraryDao ?: return
        scope.launch {
            val existing = dao.findItemById(media.id)
            val nextSaved = !(existing?.isInWatchlist ?: false)
            val entity = LibraryItemEntity.fromSummary(
                summary = media,
                isInWatchlist = nextSaved,
                isWatched = existing?.isWatched ?: false,
                lastVisitedAtMs = existing?.lastVisitedAtMs ?: System.currentTimeMillis()
            )
            dao.upsertLibraryItem(entity)
            dao.pruneOrphanedItems()
        }
    }

    fun toggleWatchlist(mediaId: String) {
        val cached = summaryCache[mediaId] ?: _library.value.watchlistItems.firstOrNull { it.id == mediaId }
            ?: _library.value.visitHistory.firstOrNull { it.media.id == mediaId }?.media
        if (cached != null) {
            toggleWatchlist(cached)
            return
        }
        val dao = libraryDao ?: return
        scope.launch {
            dao.removeFromWatchlist(mediaId)
            dao.pruneOrphanedItems()
        }
    }

    fun toggleWatched(media: MediaSummary) {
        summaryCache[media.id] = media
        val dao = libraryDao ?: return
        scope.launch {
            val existing = dao.findItemById(media.id)
            val nextWatched = !(existing?.isWatched ?: false)
            val entity = LibraryItemEntity.fromSummary(
                summary = media,
                isInWatchlist = existing?.isInWatchlist ?: false,
                isWatched = nextWatched,
                lastVisitedAtMs = existing?.lastVisitedAtMs ?: System.currentTimeMillis()
            )
            dao.upsertLibraryItem(entity)
            dao.pruneOrphanedItems()
        }
    }

    fun toggleWatched(mediaId: String) {
        val cached = summaryCache[mediaId] ?: _library.value.watchlistItems.firstOrNull { it.id == mediaId }
            ?: _library.value.visitHistory.firstOrNull { it.media.id == mediaId }?.media
        if (cached != null) {
            toggleWatched(cached)
        }
    }

    fun recordVisit(media: MediaSummary) {
        summaryCache[media.id] = media
        if (!UserPreferencesStore.state.value.library.trackVisitHistory) return
        val dao = libraryDao ?: return
        scope.launch {
            val existing = dao.findItemById(media.id)
            val entity = LibraryItemEntity.fromSummary(
                summary = media,
                isInWatchlist = existing?.isInWatchlist ?: false,
                isWatched = existing?.isWatched ?: false,
                lastVisitedAtMs = System.currentTimeMillis()
            )
            dao.upsertLibraryItem(entity)
        }
    }

    fun simulatePlay(media: MediaSummary, episodeLabel: String? = null) {
        recordPlaybackProgress(
            media = media,
            episodeLabel = episodeLabel,
            positionMs = 180_000L,
            durationMs = 5_400_000L
        )
    }

    fun recordPlaybackProgress(
        media: MediaSummary,
        episodeLabel: String? = null,
        positionMs: Long,
        durationMs: Long
    ) {
        summaryCache[media.id] = media
        val libPrefs = UserPreferencesStore.state.value.library
        if (!libPrefs.trackContinueWatching) return
        val dao = libraryDao ?: return

        val fraction = if (durationMs > 0L) {
            (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0.02f, 1f)
        } else {
            0.15f
        }
        val remainingMin = if (durationMs > positionMs) {
            ((durationMs - positionMs) / 60_000L).coerceAtLeast(1L)
        } else 0L
        val remainingText = if (remainingMin > 0) "${remainingMin}m left" else "In progress"

        scope.launch {
            dao.upsertPlaybackProgress(
                PlaybackProgressEntity(
                    mediaId = media.id,
                    providerId = media.providerId.id,
                    title = media.title,
                    posterUrl = media.posterUrl,
                    backdropUrl = media.backdropUrl,
                    year = media.year,
                    episodeLabel = episodeLabel,
                    progressFraction = fraction,
                    remainingLabel = remainingText,
                    positionMs = positionMs,
                    durationMs = durationMs,
                    updatedAtMs = System.currentTimeMillis()
                )
            )
            if (fraction * 100f >= libPrefs.autoMarkWatchedThresholdPercent) {
                val existing = dao.findItemById(media.id)
                dao.upsertLibraryItem(
                    LibraryItemEntity.fromSummary(
                        summary = media,
                        isInWatchlist = existing?.isInWatchlist ?: false,
                        isWatched = true,
                        lastVisitedAtMs = existing?.lastVisitedAtMs ?: System.currentTimeMillis()
                    )
                )
            }
        }
    }

    fun removeHistoryItem(mediaId: String) {
        val dao = libraryDao ?: return
        scope.launch {
            dao.clearVisitTimestamp(mediaId)
            dao.pruneOrphanedItems()
        }
    }

    fun clearHistory() {
        val dao = libraryDao ?: return
        scope.launch {
            dao.clearAllVisitTimestamps()
            dao.pruneOrphanedItems()
        }
    }

    fun clearWatchlist() {
        val dao = libraryDao ?: return
        scope.launch {
            dao.clearWatchlist()
            dao.pruneOrphanedItems()
        }
    }

    fun clearContinueWatching() {
        val dao = libraryDao ?: return
        scope.launch {
            dao.clearContinueWatching()
        }
    }

    fun colorToHex(color: Color): String {
        val rgb = color.toArgb() and 0xFFFFFF
        return String.format("#%06X", rgb)
    }

    fun exportAppearanceJson(): JSONObject {
        val a = _appearance.value
        return JSONObject().apply {
            put("backgroundColorArgb", a.backgroundColor.toArgb())
            put("accentColorArgb", a.accentColor.toArgb())
            put("heroStyle", a.heroStyle.id)
            put("homeHeroHeightDp", a.homeHeroHeightDp)
            put("detailsHeroHeightDp", a.detailsHeroHeightDp)
            put("activeHomeProvider", a.activeHomeProvider.id)
        }
    }

    fun importAppearanceJson(obj: JSONObject) {
        val heroStyle = HomeHeroStyle.entries.firstOrNull { it.id == obj.optString("heroStyle") }
            ?: HomeHeroStyle.CINEMATIC
        val provider = ProviderId.fromId(obj.optString("activeHomeProvider", ProviderId.MOVIELINKBD.id))
        val restored = AppearanceSettings(
            backgroundColor = Color(obj.optInt("backgroundColorArgb", MovieLinkColors.PureBlack.toArgb())),
            accentColor = Color(obj.optInt("accentColorArgb", MovieLinkColors.DefaultAccent.toArgb())),
            heroStyle = heroStyle,
            homeHeroHeightDp = obj.optInt("homeHeroHeightDp", 460).coerceIn(320, 580),
            detailsHeroHeightDp = obj.optInt("detailsHeroHeightDp", 390).coerceIn(280, 520),
            activeHomeProvider = provider
        )
        _appearance.value = restored
        WebsiteSourcesStore.setActiveHomeProvider(provider)
        persistAppearance(restored)
    }

    private fun persistAppearance(settings: AppearanceSettings) {
        val sp = appearancePrefs ?: return
        val json = JSONObject().apply {
            put("backgroundColorArgb", settings.backgroundColor.toArgb())
            put("accentColorArgb", settings.accentColor.toArgb())
            put("heroStyle", settings.heroStyle.id)
            put("homeHeroHeightDp", settings.homeHeroHeightDp)
            put("detailsHeroHeightDp", settings.detailsHeroHeightDp)
            put("activeHomeProvider", settings.activeHomeProvider.id)
        }.toString()
        sp.edit().putString(KEY_APPEARANCE_JSON, json).apply()
    }

    private fun decodeAppearance(raw: String): AppearanceSettings {
        return try {
            val obj = JSONObject(raw)
            val heroStyle = HomeHeroStyle.entries.firstOrNull { it.id == obj.optString("heroStyle") }
                ?: HomeHeroStyle.CINEMATIC
            val provider = ProviderId.fromId(obj.optString("activeHomeProvider", ProviderId.MOVIELINKBD.id))
            AppearanceSettings(
                backgroundColor = Color(obj.optInt("backgroundColorArgb", MovieLinkColors.PureBlack.toArgb())),
                accentColor = Color(obj.optInt("accentColorArgb", MovieLinkColors.DefaultAccent.toArgb())),
                heroStyle = heroStyle,
                homeHeroHeightDp = obj.optInt("homeHeroHeightDp", 460).coerceIn(320, 580),
                detailsHeroHeightDp = obj.optInt("detailsHeroHeightDp", 390).coerceIn(280, 520),
                activeHomeProvider = provider
            )
        } catch (_: Exception) {
            AppearanceSettings()
        }
    }

    private fun formatRelativeTime(timestampMs: Long): String {
        val diff = (System.currentTimeMillis() - timestampMs).coerceAtLeast(0L)
        val minutes = diff / 60_000L
        val hours = minutes / 60L
        val days = hours / 24L
        return when {
            minutes < 2 -> "Just now"
            minutes < 60 -> "${minutes}m ago"
            hours < 24 -> "${hours}h ago"
            days < 7 -> "${days}d ago"
            else -> "${days / 7}w ago"
        }
    }
}
