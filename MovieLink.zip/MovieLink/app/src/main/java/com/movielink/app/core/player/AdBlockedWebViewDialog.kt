package com.movielink.app.core.player

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Message
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.OpenInBrowser
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.movielink.app.core.adblock.AdBlockStore
import com.movielink.app.core.adblock.AdBlockerEngine
import com.movielink.app.core.designsystem.LocalMovieLinkColors
import com.movielink.app.core.model.ProviderId
import com.movielink.app.core.network.MovieLinkCookieJar
import com.movielink.app.core.network.MovieLinkHttpClient
import java.io.ByteArrayInputStream

/**
 * Ad-blocked in-app WebView used both for solving Cloudflare challenges cleanly
 * and for ad-protected stream / download link resolution.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun AdBlockedWebViewDialog(
    initialUrl: String,
    title: String,
    providerId: ProviderId,
    isCloudflareChallenge: Boolean = false,
    onCloudflareSolved: () -> Unit = {},
    onPlayDirectVideoUrl: ((String) -> Unit)? = null,
    onDismiss: () -> Unit
) {
    val colors = LocalMovieLinkColors.current
    val context = LocalContext.current
    val blockedCount by AdBlockerEngine.sessionBlockedCount.collectAsStateWithLifecycle()

    var progress by remember { mutableIntStateOf(0) }
    var currentUrl by remember { mutableStateOf(initialUrl) }
    var detectedVideoUrl by remember { mutableStateOf<String?>(null) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var cfNotified by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(colors.background)
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(colors.surface)
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close", tint = colors.textPrimary)
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 6.dp)
                ) {
                    Text(
                        text = if (isCloudflareChallenge) "Security Check (${providerId.displayName})" else title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Shield,
                            contentDescription = null,
                            tint = colors.accent,
                            modifier = Modifier.height(12.dp)
                        )
                        Text(
                            text = "$blockedCount blocked • ${currentUrl.removePrefix("https://").removePrefix("http://")}",
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                val playable = detectedVideoUrl ?: currentUrl.takeIf { isLikelyVideoUrl(it) }
                if (playable != null && onPlayDirectVideoUrl != null) {
                    IconButton(
                        onClick = {
                            onDismiss()
                            onPlayDirectVideoUrl(playable)
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PlayCircle,
                            contentDescription = "Open in Native Player",
                            tint = colors.accent
                        )
                    }
                }

                IconButton(onClick = { webViewRef?.reload() }) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Reload", tint = colors.textPrimary)
                }

                IconButton(
                    onClick = {
                        try {
                            context.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse(currentUrl)).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                            )
                        } catch (_: Exception) {
                        }
                    }
                ) {
                    Icon(Icons.Rounded.OpenInBrowser, contentDescription = "Open in Browser", tint = colors.textPrimary)
                }
            }

            if (progress in 1..99) {
                LinearProgressIndicator(
                    progress = { progress / 100f },
                    color = colors.accent,
                    trackColor = colors.surface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                )
            }

            Box(modifier = Modifier.fillMaxSize()) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            setBackgroundColor(colors.background.toArgb())
                            CookieManager.getInstance().setAcceptCookie(true)
                            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                cacheMode = WebSettings.LOAD_DEFAULT
                                mediaPlaybackRequiresUserGesture = false
                                javaScriptCanOpenWindowsAutomatically = false
                                setSupportMultipleWindows(true)
                                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                                userAgentString = MovieLinkHttpClient.DEFAULT_USER_AGENT
                            }

                            webChromeClient = object : WebChromeClient() {
                                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                    progress = newProgress
                                }

                                override fun onCreateWindow(
                                    view: WebView?,
                                    isDialog: Boolean,
                                    isUserGesture: Boolean,
                                    resultMsg: Message?
                                ): Boolean {
                                    // Block ad popups by refusing new windows when popup blocker is active
                                    val blockPopups = AdBlockStore.settings.value.let {
                                        it.globalEnabled && it.blockPopups
                                    }
                                    return !blockPopups
                                }
                            }

                            webViewClient = object : WebViewClient() {
                                override fun shouldInterceptRequest(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): WebResourceResponse? {
                                    val reqUri = request?.url ?: return null
                                    if (!isCloudflareChallenge && AdBlockerEngine.shouldBlockUri(reqUri, providerId)) {
                                        return WebResourceResponse(
                                            "text/plain",
                                            "utf-8",
                                            ByteArrayInputStream(ByteArray(0))
                                        )
                                    }
                                    return null
                                }

                                override fun shouldOverrideUrlLoading(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): Boolean {
                                    val reqUri = request?.url ?: return false
                                    val scheme = reqUri.scheme?.lowercase()
                                    if (scheme != "http" && scheme != "https") {
                                        return true
                                    }
                                    if (!isCloudflareChallenge && AdBlockerEngine.shouldBlockUri(reqUri, providerId)) {
                                        return true
                                    }
                                    val raw = reqUri.toString()
                                    if (isLikelyVideoUrl(raw)) {
                                        detectedVideoUrl = raw
                                    }
                                    return false
                                }

                                override fun onLoadResource(view: WebView?, url: String?) {
                                    if (url != null && isLikelyVideoUrl(url)) {
                                        detectedVideoUrl = url
                                    }
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    super.onPageFinished(view, url)
                                    if (!url.isNullOrBlank()) {
                                        currentUrl = url
                                    }
                                    CookieManager.getInstance().flush()
                                    if (isCloudflareChallenge && !cfNotified) {
                                        val checkUrl = url ?: initialUrl
                                        if (MovieLinkCookieJar.hasCloudflareClearance(checkUrl)) {
                                            cfNotified = true
                                            onCloudflareSolved()
                                        }
                                    }
                                }
                            }

                            webViewRef = this
                            loadUrl(initialUrl)
                        }
                    }
                )
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            webViewRef?.stopLoading()
            webViewRef?.destroy()
            webViewRef = null
        }
    }
}

private fun isLikelyVideoUrl(url: String): Boolean {
    val clean = url.substringBefore('?').lowercase()
    return clean.endsWith(".mp4") ||
        clean.endsWith(".m3u8") ||
        clean.endsWith(".mkv") ||
        clean.endsWith(".webm")
}
