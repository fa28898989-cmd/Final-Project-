package com.movielink.app.core.integrations

import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Sanitizes website release titles (quality tags, audio labels, year suffixes) and
 * scores external metadata candidates strictly to avoid false matches.
 */
object MetadataMatcher {

    private val stripBracketed = Regex("""[\[\(\{][^\]\)\}]{2,48}[\]\)\}]""")
    private val stripTags = Regex(
        """\b(480p|720p|1080p|2160p|4k|uhd|hdr|web-?dl|webrip|bluray|brrip|hdrip|dvdrip|hdts|camrip|x264|x265|hevc|10bit|aac|ddp?5\.?1|dual\s*audio|multi\s*audio|hindi\s*dubbed|bangla\s*sub|esub|hc|season\s*\d+|s\d{1,2}e?\d{0,2}|complete\s*series)\b""",
        RegexOption.IGNORE_CASE
    )
    private val trailingYear = Regex("""\b(19\d{2}|20\d{2})\b""")

    fun cleanSearchTitle(rawTitle: String): String {
        var text = rawTitle
            .replace(stripBracketed, " ")
            .replace(stripTags, " ")
            .replace(trailingYear, " ")
            .replace("—", " ")
            .replace("–", " ")
            .replace("|", " ")
            .replace(":", " ")
            .replace(Regex("""\s+"""), " ")
            .trim()
        // If aggressive stripping cleared everything (e.g. a movie literally titled "2012" or "1917"),
        // fall back to basic bracket stripping.
        if (text.length < 2) {
            text = rawTitle
                .replace(stripBracketed, " ")
                .replace(Regex("""\s+"""), " ")
                .trim()
        }
        return text
    }

    fun extractCleanYear(raw: String): Int? {
        val m = trailingYear.find(raw) ?: return null
        return m.groupValues[1].toIntOrNull()
    }

    /**
     * Computes a [0f, 1f] match confidence score between a source title/year and a candidate.
     * Returns < 0.72f if year mismatch is >= 2 years or titles diverge significantly.
     */
    fun scoreCandidate(
        queryTitle: String,
        queryYear: Int?,
        candidateTitle: String,
        candidateOriginalTitle: String?,
        candidateYear: Int?
    ): Float {
        val cleanQuery = normalizeForCompare(cleanSearchTitle(queryTitle))
        if (cleanQuery.isBlank()) return 0f

        val simPrimary = titleSimilarity(cleanQuery, normalizeForCompare(candidateTitle))
        val simOriginal = candidateOriginalTitle
            ?.takeIf { it.isNotBlank() }
            ?.let { titleSimilarity(cleanQuery, normalizeForCompare(it)) }
            ?: 0f
        val baseTitleSim = max(simPrimary, simOriginal)

        if (baseTitleSim < 0.52f) return baseTitleSim * 0.6f

        if (queryYear != null && candidateYear != null) {
            val diff = abs(queryYear - candidateYear)
            return when {
                diff == 0 -> (baseTitleSim * 0.85f + 0.15f).coerceAtMost(1f)
                diff == 1 -> (baseTitleSim * 0.82f + 0.10f).coerceAtMost(1f)
                else -> (baseTitleSim * 0.45f) // Reject obvious year mismatch
            }
        }
        return baseTitleSim * 0.92f
    }

    fun isAcceptableMatch(score: Float, hasYearMatch: Boolean): Boolean {
        return if (hasYearMatch) score >= 0.70f else score >= 0.82f
    }

    private fun normalizeForCompare(value: String): String {
        return value
            .lowercase(Locale.US)
            .replace(Regex("""[^\p{L}\p{N}\s]"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()
    }

    private fun titleSimilarity(a: String, b: String): Float {
        if (a.isBlank() || b.isBlank()) return 0f
        if (a == b) return 1f

        val levDist = levenshtein(a, b)
        val maxLen = max(a.length, b.length).coerceAtLeast(1)
        val charSim = 1f - (levDist.toFloat() / maxLen.toFloat())

        val tokensA = a.split(" ").filter { it.isNotBlank() }.toSet()
        val tokensB = b.split(" ").filter { it.isNotBlank() }.toSet()
        val intersection = tokensA.intersect(tokensB).size
        val union = tokensA.union(tokensB).size.coerceAtLeast(1)
        val jaccard = intersection.toFloat() / union.toFloat()

        return max(charSim, (charSim * 0.55f + jaccard * 0.45f))
    }

    private fun levenshtein(lhs: String, rhs: String): Int {
        val m = lhs.length
        val n = rhs.length
        var prev = IntArray(n + 1) { it }
        var curr = IntArray(n + 1)
        for (i in 1..m) {
            curr[0] = i
            for (j in 1..n) {
                val cost = if (lhs[i - 1] == rhs[j - 1]) 0 else 1
                curr[j] = min(
                    min(curr[j - 1] + 1, prev[j] + 1),
                    prev[j - 1] + cost
                )
            }
            val tmp = prev
            prev = curr
            curr = tmp
        }
        return prev[n]
    }
}
