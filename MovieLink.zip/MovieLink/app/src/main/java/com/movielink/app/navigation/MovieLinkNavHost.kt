package com.movielink.app.navigation

import android.net.Uri
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.movielink.app.core.model.MediaSummary
import com.movielink.app.feature.details.DetailsScreen
import com.movielink.app.feature.home.HomeScreen
import com.movielink.app.feature.library.LibraryScreen
import com.movielink.app.feature.localplayer.LocalMediaViewModel
import com.movielink.app.feature.localplayer.LocalPlayerScreen
import com.movielink.app.feature.search.SearchScreen
import com.movielink.app.feature.settings.SettingsScreen
import com.movielink.app.feature.settings.SettingsSection
import com.movielink.app.feature.settings.SettingsSectionDetailScreen

@Composable
fun MovieLinkNavHost(
    navController: NavHostController,
    localMediaViewModel: LocalMediaViewModel,
    modifier: Modifier = Modifier
) {
    val openDetails: (MediaSummary) -> Unit = { media ->
        navController.navigate(MovieLinkRoutes.details(media.providerId.id, media.id))
    }
    val openWebsiteSources: () -> Unit = {
        navController.navigate(MovieLinkRoutes.settingsSection(SettingsSection.WEBSITE_SOURCES.id))
    }

    NavHost(
        navController = navController,
        startDestination = TopLevelDestination.HOME.route,
        modifier = modifier,
        enterTransition = { fadeIn(animationSpec = tween(160)) },
        exitTransition = { fadeOut(animationSpec = tween(120)) },
        popEnterTransition = { EnterTransition.None },
        popExitTransition = { ExitTransition.None }
    ) {
        composable(TopLevelDestination.HOME.route) {
            HomeScreen(
                onOpenDetails = openDetails,
                onOpenWebsiteSources = openWebsiteSources
            )
        }

        composable(TopLevelDestination.SEARCH.route) {
            SearchScreen(
                onOpenDetails = openDetails,
                onOpenWebsiteSources = openWebsiteSources
            )
        }

        composable(TopLevelDestination.LIBRARY.route) {
            LibraryScreen(onOpenDetails = openDetails)
        }

        composable(TopLevelDestination.LOCAL_PLAYER.route) {
            LocalPlayerScreen(viewModel = localMediaViewModel)
        }

        composable(TopLevelDestination.SETTINGS.route) {
            SettingsScreen(
                onOpenSection = { section ->
                    navController.navigate(MovieLinkRoutes.settingsSection(section.id))
                }
            )
        }

        composable(
            route = MovieLinkRoutes.DETAILS,
            arguments = listOf(
                navArgument("providerId") { type = NavType.StringType },
                navArgument("mediaId") { type = NavType.StringType }
            )
        ) { entry ->
            val providerId = entry.arguments?.getString("providerId").orEmpty()
            val mediaId = Uri.decode(entry.arguments?.getString("mediaId").orEmpty())
            DetailsScreen(
                providerId = providerId,
                mediaId = mediaId,
                onBack = { navController.popBackStack() },
                onOpenRelated = openDetails,
                onPlayStreamUrl = { url, title ->
                    localMediaViewModel.playStreamUrl(url, title)
                }
            )
        }

        composable(
            route = MovieLinkRoutes.SETTINGS_SECTION,
            arguments = listOf(
                navArgument("sectionId") { type = NavType.StringType }
            )
        ) { entry ->
            val sectionId = entry.arguments?.getString("sectionId").orEmpty()
            SettingsSectionDetailScreen(
                sectionId = sectionId,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
