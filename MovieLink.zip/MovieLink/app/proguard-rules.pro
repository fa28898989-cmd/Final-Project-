# MovieLink Release R8 / ProGuard Hardening Rules
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod,RuntimeVisibleAnnotations
-dontwarn kotlin.reflect.**

# Keep MovieLink Room database, entities, DAOs, and core models
-keep class com.movielink.app.core.database.** { *; }
-keep class com.movielink.app.core.model.** { *; }
-keepclassmembers class * extends androidx.room.RoomDatabase {
    void <init>();
}

# OkHttp & Okio
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**

# Jsoup HTML parser
-keeppackagenames org.jsoup.nodes
-dontwarn org.jsoup.**

# AndroidX Media3 ExoPlayer & HLS
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Coil image loader
-keep class coil.** { *; }
-dontwarn coil.**
