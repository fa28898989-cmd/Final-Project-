package com.personal.movielink

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.text.format.DateUtils
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

private val Context.movieLinkDataStore by preferencesDataStore(name = "movielink_datastore")

class AppSettingsStore(private val context: Context) {
    private val sp = context.getSharedPreferences("movielink_prefs", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _settings = MutableStateFlow(readFromPrefsSync())
    val settings: StateFlow<UserSettings> = _settings.asStateFlow()

    private val _history = MutableStateFlow(readHistorySync())
    val history: StateFlow<List<HistoryItem>> = _history.asStateFlow()

    private val _myList = MutableStateFlow(readMyListSync())
    val myList: StateFlow<List<MyListItem>> = _myList.asStateFlow()

    private val _playbackProgress = MutableStateFlow(readPlaybackProgressSync())
    val playbackProgress: StateFlow<List<PlaybackProgressItem>> = _playbackProgress.asStateFlow()

    private val _watchedUrls = MutableStateFlow(readWatchedUrlsSync())
    val watchedUrls: StateFlow<Set<String>> = _watchedUrls.asStateFlow()

    init {
        scope.launch {
            val prefs = context.movieLinkDataStore.data.first()
            if (prefs.asMap().isNotEmpty()) {
                val synced = UserSettings(
                    mirrorUrl = Config.normalizeUrl(prefs[KEY_MIRROR_URL] ?: _settings.value.mirrorUrl),
                    resumeLastPage = prefs[KEY_RESUME_LAST] ?: _settings.value.resumeLastPage,
                    lastVisitedUrl = prefs[KEY_LAST_URL] ?: _settings.value.lastVisitedUrl,
                    downloaderMode = Config.DownloaderMode.fromId(prefs[KEY_DOWNLOADER_MODE] ?: _settings.value.downloaderMode.id),
                    videoActionMode = Config.VideoActionMode.fromId(prefs[KEY_VIDEO_MODE] ?: _settings.value.videoActionMode.id),
                    hideVideoProgressBar = prefs[KEY_HIDE_VIDEO_BAR] ?: _settings.value.hideVideoProgressBar,
                    playerBrightnessSync = prefs[KEY_PLAYER_BRIGHTNESS] ?: _settings.value.playerBrightnessSync,
                    desktopMode = prefs[KEY_DESKTOP_MODE] ?: _settings.value.desktopMode,
                    adBlockEnabled = prefs[KEY_ADBLOCK_ENABLED] ?: _settings.value.adBlockEnabled,
                    sitePolishEnabled = prefs[KEY_SITE_POLISH] ?: _settings.value.sitePolishEnabled,
                    showContinueWatching = prefs[KEY_SHOW_CONTINUE_WATCHING] ?: _settings.value.showContinueWatching,
                    showOttSection = prefs[KEY_SHOW_OTT] ?: _settings.value.showOttSection,
                    floatingNavBar = prefs[KEY_FLOATING_NAV] ?: _settings.value.floatingNavBar,
                    floatingNavHeightDp = prefs[KEY_FLOATING_HEIGHT] ?: _settings.value.floatingNavHeightDp,
                    floatingNavWidthPercent = prefs[KEY_FLOATING_WIDTH] ?: _settings.value.floatingNavWidthPercent,
                    floatingNavSpacingDp = prefs[KEY_FLOATING_SPACING] ?: _settings.value.floatingNavSpacingDp,
                    floatingNavIconSpacingDp = prefs[KEY_FLOATING_ICON_SPACING] ?: _settings.value.floatingNavIconSpacingDp,
                    floatingNavAlphaPercent = prefs[KEY_FLOATING_ALPHA] ?: _settings.value.floatingNavAlphaPercent,
                    floatingNavColorHex = prefs[KEY_FLOATING_COLOR] ?: _settings.value.floatingNavColorHex,
                    normalNavHeightDp = prefs[KEY_NORMAL_HEIGHT] ?: _settings.value.normalNavHeightDp,
                    normalNavWidthPercent = prefs[KEY_NORMAL_WIDTH] ?: _settings.value.normalNavWidthPercent,
                    normalNavSpacingDp = prefs[KEY_NORMAL_SPACING] ?: _settings.value.normalNavSpacingDp,
                    normalNavIconSpacingDp = prefs[KEY_NORMAL_ICON_SPACING] ?: _settings.value.normalNavIconSpacingDp,
                    normalNavAlphaPercent = prefs[KEY_NORMAL_ALPHA] ?: _settings.value.normalNavAlphaPercent,
                    normalNavColorHex = prefs[KEY_NORMAL_COLOR] ?: _settings.value.normalNavColorHex,
                    navBarIconIds = prefs[KEY_NAV_ICONS]?.let { parseKeySet(it) }?.ifEmpty { null }
                        ?: _settings.value.navBarIconIds,
                    appLogoStyle = Config.AppLogoStyle.fromId(
                        prefs[KEY_APP_LOGO_STYLE] ?: _settings.value.appLogoStyle.id
                    ),
                    detailBoxEnabled = prefs[KEY_DETAIL_BOX_ENABLED] ?: _settings.value.detailBoxEnabled,
                    detailBoxStyle = Config.DetailBoxStyle.fromId(prefs[KEY_DETAIL_BOX_STYLE] ?: _settings.value.detailBoxStyle.id),
                    detailBoxOpacityPercent = prefs[KEY_DETAIL_BOX_OPACITY] ?: _settings.value.detailBoxOpacityPercent,
                    detailBoxSizePercent = prefs[KEY_DETAIL_BOX_SIZE] ?: _settings.value.detailBoxSizePercent,
                    detailBoxColorHex = prefs[KEY_DETAIL_BOX_COLOR] ?: _settings.value.detailBoxColorHex,
                    bgPresetId = prefs[KEY_BG_PRESET] ?: _settings.value.bgPresetId,
                    customBgHex = prefs[KEY_CUSTOM_BG_HEX] ?: _settings.value.customBgHex,
                    themePresetId = prefs[KEY_THEME_PRESET] ?: _settings.value.themePresetId,
                    customThemeHex = prefs[KEY_CUSTOM_THEME_HEX] ?: _settings.value.customThemeHex,
                    customBlockedDomains = parseDomains(prefs[KEY_CUSTOM_BLOCKED] ?: ""),
                    customAllowedDomains = parseDomains(prefs[KEY_CUSTOM_ALLOWED] ?: ""),
                    showLocalPlayerTab = prefs[KEY_SHOW_LOCAL_TAB] ?: _settings.value.showLocalPlayerTab,
                    movieLinkHeroEnabled = prefs[KEY_ML_HERO] ?: _settings.value.movieLinkHeroEnabled,
                    movieLinkSearchEnabled = prefs[KEY_ML_SEARCH] ?: _settings.value.movieLinkSearchEnabled,
                    movieLinkWatchOnlineEnabled = prefs[KEY_ML_WATCH_ONLINE] ?: _settings.value.movieLinkWatchOnlineEnabled,
                    heroSourceKey = prefs[KEY_HERO_SOURCE_KEY] ?: _settings.value.heroSourceKey,
                    heroSourceKeys = parseKeySet(prefs[KEY_HERO_SOURCE_KEYS] ?: "").ifEmpty {
                        _settings.value.heroSourceKeys
                    },
                    heroAutoRotate = prefs[KEY_HERO_AUTO_ROTATE] ?: _settings.value.heroAutoRotate,
                    continueWatchingLayout = Config.ContinueWatchingLayout.fromId(
                        prefs[KEY_CONTINUE_WATCHING_LAYOUT] ?: _settings.value.continueWatchingLayout.id
                    ),
                    heroLayoutStyle = Config.HeroLayoutStyle.fromId(
                        prefs[KEY_HERO_LAYOUT_STYLE] ?: _settings.value.heroLayoutStyle.id
                    ),
                    heroSizePercent = (prefs[KEY_HERO_SIZE_PERCENT] ?: _settings.value.heroSizePercent).coerceIn(75, 130),
                    detailHeroSizePercent = (prefs[KEY_DETAIL_HERO_SIZE_PERCENT] ?: _settings.value.detailHeroSizePercent).coerceIn(75, 130),
                    tmdbMetadataEnabled = prefs[KEY_TMDB_ENABLED] ?: _settings.value.tmdbMetadataEnabled,
                    tmdbApiKey = prefs[KEY_TMDB_API_KEY] ?: _settings.value.tmdbApiKey,
                    mdbListEnabled = prefs[KEY_MDBLIST_ENABLED] ?: _settings.value.mdbListEnabled,
                    mdbListApiKey = prefs[KEY_MDBLIST_API_KEY] ?: _settings.value.mdbListApiKey,
                    betterPosterProvider = Config.BetterPosterProvider.fromId(
                        prefs[KEY_BETTER_POSTER_PROVIDER] ?: _settings.value.betterPosterProvider.id
                    ),
                    rpdbApiKey = prefs[KEY_RPDB_API_KEY] ?: _settings.value.rpdbApiKey,
                    betterPosterCustomTemplate = prefs[KEY_BETTER_POSTER_CUSTOM]
                        ?: _settings.value.betterPosterCustomTemplate,
                    betterPosterOnCards = prefs[KEY_BETTER_POSTER_CARDS] ?: _settings.value.betterPosterOnCards
                )
                _settings.value = synced
            }
        }
    }

    fun startupUrl(): String {
        val s = _settings.value
        val last = s.lastVisitedUrl
        return if (s.resumeLastPage && !last.isNullOrBlank()) last else s.mirrorUrl
    }

    fun updateSettings(transform: (UserSettings) -> UserSettings) {
        val prev = _settings.value
        val updated = transform(prev).let {
            it.copy(mirrorUrl = Config.normalizeUrl(it.mirrorUrl))
        }
        _settings.value = updated
        persistSync(updated)
        if (updated.appLogoStyle != prev.appLogoStyle) {
            applyLauncherLogoAlias(context, updated.appLogoStyle)
        }
        scope.launch {
            context.movieLinkDataStore.edit { p ->
                p[KEY_MIRROR_URL] = updated.mirrorUrl
                p[KEY_RESUME_LAST] = updated.resumeLastPage
                if (updated.lastVisitedUrl != null) p[KEY_LAST_URL] = updated.lastVisitedUrl else p.remove(KEY_LAST_URL)
                p[KEY_DOWNLOADER_MODE] = updated.downloaderMode.id
                p[KEY_VIDEO_MODE] = updated.videoActionMode.id
                p[KEY_HIDE_VIDEO_BAR] = updated.hideVideoProgressBar
                p[KEY_PLAYER_BRIGHTNESS] = updated.playerBrightnessSync
                p[KEY_DESKTOP_MODE] = updated.desktopMode
                p[KEY_ADBLOCK_ENABLED] = updated.adBlockEnabled
                p[KEY_SITE_POLISH] = updated.sitePolishEnabled
                p[KEY_SHOW_CONTINUE_WATCHING] = updated.showContinueWatching
                p[KEY_SHOW_OTT] = updated.showOttSection
                p[KEY_FLOATING_NAV] = updated.floatingNavBar
                p[KEY_FLOATING_HEIGHT] = updated.floatingNavHeightDp
                p[KEY_FLOATING_WIDTH] = updated.floatingNavWidthPercent
                p[KEY_FLOATING_SPACING] = updated.floatingNavSpacingDp
                p[KEY_FLOATING_ICON_SPACING] = updated.floatingNavIconSpacingDp
                p[KEY_FLOATING_ALPHA] = updated.floatingNavAlphaPercent
                if (updated.floatingNavColorHex != null) p[KEY_FLOATING_COLOR] = updated.floatingNavColorHex else p.remove(KEY_FLOATING_COLOR)
                p[KEY_NORMAL_HEIGHT] = updated.normalNavHeightDp
                p[KEY_NORMAL_WIDTH] = updated.normalNavWidthPercent
                p[KEY_NORMAL_SPACING] = updated.normalNavSpacingDp
                p[KEY_NORMAL_ICON_SPACING] = updated.normalNavIconSpacingDp
                p[KEY_NORMAL_ALPHA] = updated.normalNavAlphaPercent
                if (updated.normalNavColorHex != null) p[KEY_NORMAL_COLOR] = updated.normalNavColorHex else p.remove(KEY_NORMAL_COLOR)
                p[KEY_NAV_ICONS] = updated.navBarIconIds.sorted().joinToString("\n")
                p[KEY_APP_LOGO_STYLE] = updated.appLogoStyle.id
                p[KEY_DETAIL_BOX_ENABLED] = updated.detailBoxEnabled
                p[KEY_DETAIL_BOX_STYLE] = updated.detailBoxStyle.id
                p[KEY_DETAIL_BOX_OPACITY] = updated.detailBoxOpacityPercent
                p[KEY_DETAIL_BOX_SIZE] = updated.detailBoxSizePercent
                p[KEY_DETAIL_BOX_COLOR] = updated.detailBoxColorHex
                p[KEY_BG_PRESET] = updated.bgPresetId
                if (updated.customBgHex != null) p[KEY_CUSTOM_BG_HEX] = updated.customBgHex else p.remove(KEY_CUSTOM_BG_HEX)
                p[KEY_THEME_PRESET] = updated.themePresetId
                if (updated.customThemeHex != null) p[KEY_CUSTOM_THEME_HEX] = updated.customThemeHex else p.remove(KEY_CUSTOM_THEME_HEX)
                p[KEY_CUSTOM_BLOCKED] = updated.customBlockedDomains.sorted().joinToString("\n")
                p[KEY_CUSTOM_ALLOWED] = updated.customAllowedDomains.sorted().joinToString("\n")
                p[KEY_SHOW_LOCAL_TAB] = updated.showLocalPlayerTab
                p[KEY_ML_HERO] = updated.movieLinkHeroEnabled
                p[KEY_ML_SEARCH] = updated.movieLinkSearchEnabled
                p[KEY_ML_WATCH_ONLINE] = updated.movieLinkWatchOnlineEnabled
                if (updated.heroSourceKey != null) p[KEY_HERO_SOURCE_KEY] = updated.heroSourceKey else p.remove(KEY_HERO_SOURCE_KEY)
                p[KEY_HERO_SOURCE_KEYS] = updated.heroSourceKeys.sorted().joinToString("\n")
                p[KEY_HERO_AUTO_ROTATE] = updated.heroAutoRotate
                p[KEY_CONTINUE_WATCHING_LAYOUT] = updated.continueWatchingLayout.id
                p[KEY_HERO_LAYOUT_STYLE] = updated.heroLayoutStyle.id
                p[KEY_HERO_SIZE_PERCENT] = updated.heroSizePercent.coerceIn(75, 130)
                p[KEY_DETAIL_HERO_SIZE_PERCENT] = updated.detailHeroSizePercent.coerceIn(75, 130)
                p[KEY_TMDB_ENABLED] = updated.tmdbMetadataEnabled
                p[KEY_TMDB_API_KEY] = updated.tmdbApiKey
                p[KEY_MDBLIST_ENABLED] = updated.mdbListEnabled
                p[KEY_MDBLIST_API_KEY] = updated.mdbListApiKey
                p[KEY_BETTER_POSTER_PROVIDER] = updated.betterPosterProvider.id
                p[KEY_RPDB_API_KEY] = updated.rpdbApiKey
                p[KEY_BETTER_POSTER_CUSTOM] = updated.betterPosterCustomTemplate
                p[KEY_BETTER_POSTER_CARDS] = updated.betterPosterOnCards
            }
        }
    }

    fun setCustomDomainsRaw(blockedRaw: String, allowedRaw: String) {
        updateSettings {
            it.copy(
                customBlockedDomains = parseDomains(blockedRaw),
                customAllowedDomains = parseDomains(allowedRaw)
            )
        }
    }

    fun recordHistory(title: String?, url: String, posterUrl: String = "") {
        if (url.isBlank() || url.startsWith("data:") || url == "about:blank") return
        val cleanTitle = title?.trim()?.takeIf { it.isNotEmpty() } ?: url
        val next = _history.value
            .filterNot { it.url == url }
            .toMutableList()
            .apply { add(0, HistoryItem(cleanTitle, url, posterUrl, System.currentTimeMillis())) }
            .take(MAX_HISTORY)

        _history.value = next
        val arr = JSONArray()
        for (item in next) {
            arr.put(JSONObject().apply {
                put("title", item.title)
                put("url", item.url)
                put("poster", item.posterUrl)
                put("ts", item.timestamp)
            })
        }
        sp.edit().putString("history_json", arr.toString()).apply()
        updateSettings { it.copy(lastVisitedUrl = url) }
    }

    fun clearHistory() {
        _history.value = emptyList()
        sp.edit().remove("history_json").remove("last_url").apply()
        updateSettings { it.copy(lastVisitedUrl = null) }
    }

    fun toggleMyList(item: MyListItem): Boolean {
        val current = _myList.value
        val exists = current.any { it.url == item.url }
        val next = if (exists) {
            current.filterNot { it.url == item.url }
        } else {
            listOf(item) + current
        }
        saveMyList(next)
        return !exists
    }

    fun removeFromMyList(url: String) {
        saveMyList(_myList.value.filterNot { it.url == url })
    }

    fun isInMyList(url: String): Boolean = _myList.value.any { it.url == url }

    fun toggleWatched(url: String): Boolean {
        val clean = url.trim().trimEnd('/')
        if (clean.isEmpty()) return false
        val current = _watchedUrls.value
        val nowWatched = clean !in current
        val next = if (nowWatched) current + clean else current - clean
        _watchedUrls.value = next
        val arr = JSONArray()
        next.forEach { arr.put(it) }
        sp.edit().putString("watched_urls_json", arr.toString()).apply()
        return nowWatched
    }

    fun isWatched(url: String): Boolean {
        val clean = url.trim().trimEnd('/')
        return clean.isNotEmpty() && clean in _watchedUrls.value
    }

    private fun saveMyList(items: List<MyListItem>) {
        _myList.value = items
        val arr = JSONArray()
        for (item in items) {
            arr.put(JSONObject().apply {
                put("url", item.url)
                put("title", item.title)
                put("poster", item.posterUrl)
                put("type", item.type)
                put("quality", item.quality)
                put("language", item.language)
                put("ts", item.addedAt)
            })
        }
        sp.edit().putString("mylist_json", arr.toString()).apply()
    }

    fun getLastHeroLeadKey(): String? =
        sp.getString("last_hero_lead_key", null)?.trim()?.takeIf { it.isNotEmpty() }

    fun setLastHeroLeadKey(key: String) {
        if (key.isBlank()) return
        if (sp.getString("last_hero_lead_key", null) != key) {
            sp.edit().putString("last_hero_lead_key", key).apply()
        }
    }

    fun getPlaybackPositionMs(mediaKey: String): Long {
        if (mediaKey.isBlank()) return 0L
        return _playbackProgress.value.firstOrNull { it.mediaKey == mediaKey }?.positionMs ?: 0L
    }

    fun savePlaybackProgress(item: PlaybackProgressItem) {
        if (item.mediaKey.isBlank()) return
        val nearEnd = item.durationMs > 60_000L &&
            (item.positionMs.toDouble() / item.durationMs.toDouble() >= 0.95 ||
                (item.durationMs - item.positionMs) <= 20_000L)
        if (nearEnd) {
            removePlaybackProgress(item.mediaKey)
            return
        }
        if (item.positionMs < 5_000L) return

        val next = _playbackProgress.value
            .filterNot { it.mediaKey == item.mediaKey }
            .toMutableList()
            .apply { add(0, item.copy(updatedAt = System.currentTimeMillis())) }
            .take(MAX_PROGRESS_ITEMS)
        persistPlaybackProgress(next)
    }

    fun removePlaybackProgress(mediaKey: String) {
        if (mediaKey.isBlank()) return
        val next = _playbackProgress.value.filterNot { it.mediaKey == mediaKey }
        if (next.size != _playbackProgress.value.size) {
            persistPlaybackProgress(next)
        }
    }

    private fun persistPlaybackProgress(items: List<PlaybackProgressItem>) {
        _playbackProgress.value = items
        val arr = JSONArray()
        for (item in items) {
            arr.put(JSONObject().apply {
                put("key", item.mediaKey)
                put("title", item.title)
                put("subtitle", item.subtitle)
                put("poster", item.posterUrl)
                put("streamUrl", item.streamUrl)
                put("refererUrl", item.refererUrl)
                put("sourceType", item.sourceType)
                put("contentType", item.contentType)
                put("quality", item.quality)
                put("headers", JSONObject(item.requestHeaders))
                if (!item.mimeTypeHint.isNullOrBlank()) put("mimeHint", item.mimeTypeHint)
                put("sourceLabel", item.sourceLabel)
                put("pos", item.positionMs)
                put("dur", item.durationMs)
                put("embed", item.isEmbedPage)
                put("ts", item.updatedAt)
            })
        }
        sp.edit().putString("playback_progress_json", arr.toString()).apply()
    }

    private fun readFromPrefsSync(): UserSettings {
        return UserSettings(
            mirrorUrl = Config.normalizeUrl(sp.getString("mirror_url", Config.DEFAULT_HOME_URL) ?: Config.DEFAULT_HOME_URL),
            resumeLastPage = sp.getBoolean("resume_last_page", false),
            lastVisitedUrl = sp.getString("last_url", null),
            downloaderMode = Config.DownloaderMode.fromId(sp.getString("downloader_mode", Config.DownloaderMode.AUTO.id)),
            videoActionMode = Config.VideoActionMode.fromId(sp.getString("video_action_mode", Config.VideoActionMode.DOWNLOAD.id)),
            hideVideoProgressBar = sp.getBoolean("hide_video_progress_bar", true),
            playerBrightnessSync = sp.getBoolean("player_brightness_sync", true),
            desktopMode = sp.getBoolean("desktop_mode", false),
            adBlockEnabled = sp.getBoolean("adblock_enabled", true),
            sitePolishEnabled = sp.getBoolean("site_polish_enabled", true),
            showContinueWatching = sp.getBoolean("show_continue_watching", true),
            showOttSection = sp.getBoolean("show_ott_section", true),
            floatingNavBar = sp.getBoolean("floating_nav_bar", false),
            floatingNavHeightDp = sp.getInt("floating_nav_height", 56),
            floatingNavWidthPercent = sp.getInt("floating_nav_width", 90),
            floatingNavSpacingDp = sp.getInt("floating_nav_spacing", 14),
            floatingNavIconSpacingDp = sp.getInt("floating_nav_icon_spacing", 8),
            floatingNavAlphaPercent = sp.getInt("floating_nav_alpha", 90),
            floatingNavColorHex = sp.getString("floating_nav_color", null),
            normalNavHeightDp = sp.getInt("normal_nav_height", 60),
            normalNavWidthPercent = sp.getInt("normal_nav_width", 92),
            normalNavSpacingDp = sp.getInt("normal_nav_spacing", 4),
            normalNavIconSpacingDp = sp.getInt("normal_nav_icon_spacing", 8),
            normalNavAlphaPercent = sp.getInt("normal_nav_alpha", 96),
            normalNavColorHex = sp.getString("normal_nav_color", null),
            navBarIconIds = parseKeySet(sp.getString("nav_bar_icons", "") ?: "").ifEmpty {
                val showLocal = sp.getBoolean("show_local_player_tab", true)
                if (showLocal) Config.NavBarIcon.DEFAULT_IDS else Config.NavBarIcon.DEFAULT_IDS - Config.NavBarIcon.LOCAL.id
            },
            appLogoStyle = Config.AppLogoStyle.fromId(
                sp.getString("app_logo_style", Config.AppLogoStyle.ECLIPSE.id)
            ),
            detailBoxEnabled = sp.getBoolean("detail_box_enabled", true),
            detailBoxStyle = Config.DetailBoxStyle.fromId(sp.getString("detail_box_style", Config.DetailBoxStyle.ROUNDED.id)),
            detailBoxOpacityPercent = sp.getInt("detail_box_opacity", 85),
            detailBoxSizePercent = sp.getInt("detail_box_size", 100),
            detailBoxColorHex = sp.getString("detail_box_color", "#71717A") ?: "#71717A",
            bgPresetId = sp.getString("bg_preset", Config.BgPreset.BLACK.id) ?: Config.BgPreset.BLACK.id,
            customBgHex = sp.getString("custom_bg_hex", null),
            themePresetId = sp.getString("theme_preset", Config.ThemePreset.BLACK.id) ?: Config.ThemePreset.BLACK.id,
            customThemeHex = sp.getString("custom_theme_hex", null),
            customBlockedDomains = parseDomains(sp.getString("custom_blocked", "") ?: ""),
            customAllowedDomains = parseDomains(sp.getString("custom_allowed", "") ?: ""),
            showLocalPlayerTab = sp.getBoolean("show_local_player_tab", true),
            movieLinkHeroEnabled = sp.getBoolean("movielink_hero_enabled", true),
            movieLinkSearchEnabled = sp.getBoolean("movielink_search_enabled", true),
            movieLinkWatchOnlineEnabled = sp.getBoolean("movielink_watch_online_enabled", true),
            heroSourceKey = sp.getString("hero_source_key", null),
            heroSourceKeys = parseKeySet(sp.getString("hero_source_keys", "") ?: ""),
            heroAutoRotate = sp.getBoolean("hero_auto_rotate", false),
            continueWatchingLayout = Config.ContinueWatchingLayout.fromId(
                sp.getString("continue_watching_layout", Config.ContinueWatchingLayout.VERTICAL.id)
            ),
            heroLayoutStyle = Config.HeroLayoutStyle.fromId(
                sp.getString("hero_layout_style", Config.HeroLayoutStyle.CAROUSEL.id)
            ),
            heroSizePercent = sp.getInt("hero_size_percent", 100).coerceIn(75, 130),
            detailHeroSizePercent = sp.getInt("detail_hero_size_percent", 100).coerceIn(75, 130),
            tmdbMetadataEnabled = sp.getBoolean("tmdb_metadata_enabled", false),
            tmdbApiKey = sp.getString("tmdb_api_key", "") ?: "",
            mdbListEnabled = sp.getBoolean("mdblist_enabled", false),
            mdbListApiKey = sp.getString("mdblist_api_key", "") ?: "",
            betterPosterProvider = Config.BetterPosterProvider.fromId(
                sp.getString("better_poster_provider", Config.BetterPosterProvider.NONE.id)
            ),
            rpdbApiKey = sp.getString("rpdb_api_key", "") ?: "",
            betterPosterCustomTemplate = sp.getString(
                "better_poster_custom_template",
                "https://btttr.cc/poster-a/imdb/poster-default/{imdb_id}.jpg"
            ) ?: "https://btttr.cc/poster-a/imdb/poster-default/{imdb_id}.jpg",
            betterPosterOnCards = sp.getBoolean("better_poster_on_cards", true)
        )
    }

    private fun persistSync(s: UserSettings) {
        sp.edit()
            .putString("mirror_url", s.mirrorUrl)
            .putBoolean("resume_last_page", s.resumeLastPage)
            .putString("last_url", s.lastVisitedUrl)
            .putString("downloader_mode", s.downloaderMode.id)
            .putString("video_action_mode", s.videoActionMode.id)
            .putBoolean("hide_video_progress_bar", s.hideVideoProgressBar)
            .putBoolean("player_brightness_sync", s.playerBrightnessSync)
            .putBoolean("desktop_mode", s.desktopMode)
            .putBoolean("adblock_enabled", s.adBlockEnabled)
            .putBoolean("site_polish_enabled", s.sitePolishEnabled)
            .putBoolean("show_continue_watching", s.showContinueWatching)
            .putBoolean("show_ott_section", s.showOttSection)
            .putBoolean("floating_nav_bar", s.floatingNavBar)
            .putInt("floating_nav_height", s.floatingNavHeightDp)
            .putInt("floating_nav_width", s.floatingNavWidthPercent)
            .putInt("floating_nav_spacing", s.floatingNavSpacingDp)
            .putInt("floating_nav_icon_spacing", s.floatingNavIconSpacingDp)
            .putInt("floating_nav_alpha", s.floatingNavAlphaPercent)
            .putString("floating_nav_color", s.floatingNavColorHex)
            .putInt("normal_nav_height", s.normalNavHeightDp)
            .putInt("normal_nav_width", s.normalNavWidthPercent)
            .putInt("normal_nav_spacing", s.normalNavSpacingDp)
            .putInt("normal_nav_icon_spacing", s.normalNavIconSpacingDp)
            .putInt("normal_nav_alpha", s.normalNavAlphaPercent)
            .putString("normal_nav_color", s.normalNavColorHex)
            .putString("nav_bar_icons", s.navBarIconIds.sorted().joinToString("\n"))
            .putString("app_logo_style", s.appLogoStyle.id)
            .putBoolean("detail_box_enabled", s.detailBoxEnabled)
            .putString("detail_box_style", s.detailBoxStyle.id)
            .putInt("detail_box_opacity", s.detailBoxOpacityPercent)
            .putInt("detail_box_size", s.detailBoxSizePercent)
            .putString("detail_box_color", s.detailBoxColorHex)
            .putString("bg_preset", s.bgPresetId)
            .putString("custom_bg_hex", s.customBgHex)
            .putString("theme_preset", s.themePresetId)
            .putString("custom_theme_hex", s.customThemeHex)
            .putString("custom_blocked", s.customBlockedDomains.sorted().joinToString("\n"))
            .putString("custom_allowed", s.customAllowedDomains.sorted().joinToString("\n"))
            .putBoolean("show_local_player_tab", s.showLocalPlayerTab)
            .putBoolean("movielink_hero_enabled", s.movieLinkHeroEnabled)
            .putBoolean("movielink_search_enabled", s.movieLinkSearchEnabled)
            .putBoolean("movielink_watch_online_enabled", s.movieLinkWatchOnlineEnabled)
            .putString("hero_source_key", s.heroSourceKey)
            .putString("hero_source_keys", s.heroSourceKeys.sorted().joinToString("\n"))
            .putBoolean("hero_auto_rotate", s.heroAutoRotate)
            .putString("continue_watching_layout", s.continueWatchingLayout.id)
            .putString("hero_layout_style", s.heroLayoutStyle.id)
            .putInt("hero_size_percent", s.heroSizePercent.coerceIn(75, 130))
            .putInt("detail_hero_size_percent", s.detailHeroSizePercent.coerceIn(75, 130))
            .putBoolean("tmdb_metadata_enabled", s.tmdbMetadataEnabled)
            .putString("tmdb_api_key", s.tmdbApiKey)
            .putBoolean("mdblist_enabled", s.mdbListEnabled)
            .putString("mdblist_api_key", s.mdbListApiKey)
            .putString("better_poster_provider", s.betterPosterProvider.id)
            .putString("rpdb_api_key", s.rpdbApiKey)
            .putString("better_poster_custom_template", s.betterPosterCustomTemplate)
            .putBoolean("better_poster_on_cards", s.betterPosterOnCards)
            .apply()
    }

    private fun readHistorySync(): List<HistoryItem> {
        val raw = sp.getString("history_json", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val url = obj.optString("url", "")
                    if (url.isNotEmpty()) {
                        add(
                            HistoryItem(
                                title = obj.optString("title", url),
                                url = url,
                                posterUrl = obj.optString("poster", ""),
                                timestamp = obj.optLong("ts", 0L)
                            )
                        )
                    }
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun readMyListSync(): List<MyListItem> {
        val raw = sp.getString("mylist_json", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val url = obj.optString("url", "")
                    if (url.isNotEmpty()) {
                        add(
                            MyListItem(
                                url = url,
                                title = obj.optString("title", url),
                                posterUrl = obj.optString("poster", ""),
                                type = obj.optString("type", "Title"),
                                quality = obj.optString("quality", "HD"),
                                language = obj.optString("language", "Multi"),
                                addedAt = obj.optLong("ts", 0L)
                            )
                        )
                    }
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun readPlaybackProgressSync(): List<PlaybackProgressItem> {
        val raw = sp.getString("playback_progress_json", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val key = obj.optString("key", "")
                    if (key.isNotEmpty()) {
                        val hdrObj = obj.optJSONObject("headers")
                        val hdrMap = linkedMapOf<String, String>()
                        if (hdrObj != null) {
                            val keys = hdrObj.keys()
                            while (keys.hasNext()) {
                                val hk = keys.next()
                                val hv = hdrObj.optString(hk, "")
                                if (hk.isNotBlank() && hv.isNotBlank()) hdrMap[hk] = hv
                            }
                        }
                        add(
                            PlaybackProgressItem(
                                mediaKey = key,
                                title = obj.optString("title", key),
                                subtitle = obj.optString("subtitle", ""),
                                posterUrl = obj.optString("poster", ""),
                                streamUrl = obj.optString("streamUrl", ""),
                                refererUrl = obj.optString("refererUrl", ""),
                                sourceType = obj.optString("sourceType", ""),
                                contentType = obj.optString("contentType", ""),
                                quality = obj.optString("quality", ""),
                                requestHeaders = hdrMap,
                                mimeTypeHint = obj.optString("mimeHint", "").takeIf { it.isNotBlank() },
                                sourceLabel = obj.optString("sourceLabel", ""),
                                positionMs = obj.optLong("pos", 0L),
                                durationMs = obj.optLong("dur", 0L),
                                isEmbedPage = obj.optBoolean("embed", false),
                                updatedAt = obj.optLong("ts", 0L)
                            )
                        )
                    }
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun readWatchedUrlsSync(): Set<String> {
        val raw = sp.getString("watched_urls_json", null) ?: return emptySet()
        return try {
            val arr = JSONArray(raw)
            buildSet {
                for (i in 0 until arr.length()) {
                    val u = arr.optString(i, "").trim().trimEnd('/')
                    if (u.isNotEmpty()) add(u)
                }
            }
        } catch (_: Exception) {
            emptySet()
        }
    }

    companion object {
        private const val MAX_HISTORY = 25
        private const val MAX_PROGRESS_ITEMS = 40

        private val KEY_MIRROR_URL = stringPreferencesKey("mirror_url")
        private val KEY_RESUME_LAST = booleanPreferencesKey("resume_last_page")
        private val KEY_LAST_URL = stringPreferencesKey("last_url")
        private val KEY_DOWNLOADER_MODE = stringPreferencesKey("downloader_mode")
        private val KEY_VIDEO_MODE = stringPreferencesKey("video_action_mode")
        private val KEY_HIDE_VIDEO_BAR = booleanPreferencesKey("hide_video_progress_bar")
        private val KEY_PLAYER_BRIGHTNESS = booleanPreferencesKey("player_brightness_sync")
        private val KEY_DESKTOP_MODE = booleanPreferencesKey("desktop_mode")
        private val KEY_ADBLOCK_ENABLED = booleanPreferencesKey("adblock_enabled")
        private val KEY_SITE_POLISH = booleanPreferencesKey("site_polish_enabled")
        private val KEY_SHOW_CONTINUE_WATCHING = booleanPreferencesKey("show_continue_watching")
        private val KEY_SHOW_OTT = booleanPreferencesKey("show_ott_section")
        private val KEY_FLOATING_NAV = booleanPreferencesKey("floating_nav_bar")
        private val KEY_FLOATING_HEIGHT = intPreferencesKey("floating_nav_height")
        private val KEY_FLOATING_WIDTH = intPreferencesKey("floating_nav_width")
        private val KEY_FLOATING_SPACING = intPreferencesKey("floating_nav_spacing")
        private val KEY_FLOATING_ICON_SPACING = intPreferencesKey("floating_nav_icon_spacing")
        private val KEY_FLOATING_ALPHA = intPreferencesKey("floating_nav_alpha")
        private val KEY_FLOATING_COLOR = stringPreferencesKey("floating_nav_color")
        private val KEY_NORMAL_HEIGHT = intPreferencesKey("normal_nav_height")
        private val KEY_NORMAL_WIDTH = intPreferencesKey("normal_nav_width")
        private val KEY_NORMAL_SPACING = intPreferencesKey("normal_nav_spacing")
        private val KEY_NORMAL_ICON_SPACING = intPreferencesKey("normal_nav_icon_spacing")
        private val KEY_NORMAL_ALPHA = intPreferencesKey("normal_nav_alpha")
        private val KEY_NORMAL_COLOR = stringPreferencesKey("normal_nav_color")
        private val KEY_NAV_ICONS = stringPreferencesKey("nav_bar_icons")
        private val KEY_APP_LOGO_STYLE = stringPreferencesKey("app_logo_style")
        private val KEY_DETAIL_BOX_ENABLED = booleanPreferencesKey("detail_box_enabled")
        private val KEY_DETAIL_BOX_STYLE = stringPreferencesKey("detail_box_style")
        private val KEY_DETAIL_BOX_OPACITY = intPreferencesKey("detail_box_opacity")
        private val KEY_DETAIL_BOX_SIZE = intPreferencesKey("detail_box_size")
        private val KEY_DETAIL_BOX_COLOR = stringPreferencesKey("detail_box_color")
        private val KEY_BG_PRESET = stringPreferencesKey("bg_preset")
        private val KEY_CUSTOM_BG_HEX = stringPreferencesKey("custom_bg_hex")
        private val KEY_THEME_PRESET = stringPreferencesKey("theme_preset")
        private val KEY_CUSTOM_THEME_HEX = stringPreferencesKey("custom_theme_hex")
        private val KEY_CUSTOM_BLOCKED = stringPreferencesKey("custom_blocked")
        private val KEY_CUSTOM_ALLOWED = stringPreferencesKey("custom_allowed")
        private val KEY_SHOW_LOCAL_TAB = booleanPreferencesKey("show_local_player_tab")
        private val KEY_ML_HERO = booleanPreferencesKey("movielink_hero_enabled")
        private val KEY_ML_SEARCH = booleanPreferencesKey("movielink_search_enabled")
        private val KEY_ML_WATCH_ONLINE = booleanPreferencesKey("movielink_watch_online_enabled")
        private val KEY_HERO_SOURCE_KEY = stringPreferencesKey("hero_source_key")
        private val KEY_HERO_SOURCE_KEYS = stringPreferencesKey("hero_source_keys")
        private val KEY_HERO_AUTO_ROTATE = booleanPreferencesKey("hero_auto_rotate")
        private val KEY_CONTINUE_WATCHING_LAYOUT = stringPreferencesKey("continue_watching_layout")
        private val KEY_HERO_LAYOUT_STYLE = stringPreferencesKey("hero_layout_style")
        private val KEY_HERO_SIZE_PERCENT = intPreferencesKey("hero_size_percent")
        private val KEY_DETAIL_HERO_SIZE_PERCENT = intPreferencesKey("detail_hero_size_percent")
        private val KEY_TMDB_ENABLED = booleanPreferencesKey("tmdb_metadata_enabled")
        private val KEY_TMDB_API_KEY = stringPreferencesKey("tmdb_api_key")
        private val KEY_MDBLIST_ENABLED = booleanPreferencesKey("mdblist_enabled")
        private val KEY_MDBLIST_API_KEY = stringPreferencesKey("mdblist_api_key")
        private val KEY_BETTER_POSTER_PROVIDER = stringPreferencesKey("better_poster_provider")
        private val KEY_RPDB_API_KEY = stringPreferencesKey("rpdb_api_key")
        private val KEY_BETTER_POSTER_CUSTOM = stringPreferencesKey("better_poster_custom_template")
        private val KEY_BETTER_POSTER_CARDS = booleanPreferencesKey("better_poster_on_cards")

        fun parseKeySet(raw: String): Set<String> =
            raw.split('\n', '\r')
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .toSet()

        fun parseDomains(raw: String): Set<String> =
            raw.split(',', '\n', '\r', ' ')
                .map {
                    it.trim().lowercase(Locale.US)
                        .removePrefix("https://")
                        .removePrefix("http://")
                        .substringBefore('/')
                }
                .filter { it.contains('.') && !it.contains(' ') }
                .toSet()

        fun applyLauncherLogoAlias(context: Context, style: Config.AppLogoStyle) {
            try {
                val pm = context.packageManager
                val pkg = context.packageName
                val eclipseAlias = ComponentName(pkg, "$pkg.LauncherEclipse")
                val wordmarkAlias = ComponentName(pkg, "$pkg.LauncherWordmark")
                val wantWordmark = style == Config.AppLogoStyle.WORDMARK
                val eclipseState = if (wantWordmark) {
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED
                } else {
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                }
                val wordmarkState = if (wantWordmark) {
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                } else {
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED
                }
                if (pm.getComponentEnabledSetting(eclipseAlias) != eclipseState) {
                    pm.setComponentEnabledSetting(eclipseAlias, eclipseState, PackageManager.DONT_KILL_APP)
                }
                if (pm.getComponentEnabledSetting(wordmarkAlias) != wordmarkState) {
                    pm.setComponentEnabledSetting(wordmarkAlias, wordmarkState, PackageManager.DONT_KILL_APP)
                }
            } catch (_: Throwable) {
            }
        }

        fun formatRelativeTime(timestamp: Long): String {
            if (timestamp <= 0L) return ""
            return DateUtils.getRelativeTimeSpanString(
                timestamp,
                System.currentTimeMillis(),
                DateUtils.MINUTE_IN_MILLIS
            ).toString()
        }
    }
}
