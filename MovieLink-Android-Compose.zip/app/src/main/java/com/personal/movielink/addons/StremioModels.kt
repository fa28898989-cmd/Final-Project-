package com.personal.movielink.addons

import org.json.JSONArray
import org.json.JSONObject

enum class AddonConnectionStatus(val label: String) {
    CONNECTED("Connected"),
    CONFIG_REQUIRED("Configuration Required"),
    UNREACHABLE("Unreachable"),
    DISABLED("Disabled")
}

data class StremioResourceSpec(
    val name: String,
    val types: List<String> = emptyList(),
    val idPrefixes: List<String> = emptyList()
)

data class StremioExtraSpec(
    val name: String,
    val isRequired: Boolean = false,
    val options: List<String> = emptyList(),
    val optionsLimit: Int = 1
)

data class StremioCatalogSpec(
    val type: String,
    val id: String,
    val name: String,
    val extra: List<StremioExtraSpec> = emptyList()
) {
    fun supportsSearch(): Boolean = extra.any { it.name.equals("search", ignoreCase = true) }
    fun requiresSearch(): Boolean = extra.any { it.name.equals("search", ignoreCase = true) && it.isRequired }
    fun supportsSkip(): Boolean = extra.any { it.name.equals("skip", ignoreCase = true) }
    fun genreOptions(): List<String> =
        extra.firstOrNull { it.name.equals("genre", ignoreCase = true) }?.options.orEmpty()
}

data class StremioBehaviorHints(
    val configurable: Boolean = false,
    val configurationRequired: Boolean = false
)

data class StremioManifest(
    val id: String,
    val version: String,
    val name: String,
    val description: String = "",
    val logo: String = "",
    val background: String = "",
    val types: List<String> = emptyList(),
    val resources: List<StremioResourceSpec> = emptyList(),
    val catalogs: List<StremioCatalogSpec> = emptyList(),
    val idPrefixes: List<String> = emptyList(),
    val behaviorHints: StremioBehaviorHints = StremioBehaviorHints()
) {
    fun resourceNames(): List<String> =
        resources.map { it.name }.distinct()

    fun supportsResource(resourceName: String, type: String? = null, itemId: String? = null): Boolean {
        val matchingSpecs = resources.filter { it.name.equals(resourceName, ignoreCase = true) }
        if (matchingSpecs.isEmpty()) return false

        return matchingSpecs.any { spec ->
            val effectiveTypes = if (spec.types.isNotEmpty()) spec.types else types
            val typeOk = type.isNullOrBlank() || effectiveTypes.isEmpty() ||
                effectiveTypes.any { it.equals(type, ignoreCase = true) }

            val effectivePrefixes = if (spec.idPrefixes.isNotEmpty()) spec.idPrefixes else idPrefixes
            val prefixOk = itemId.isNullOrBlank() || effectivePrefixes.isEmpty() ||
                effectivePrefixes.any { prefix -> itemId.startsWith(prefix, ignoreCase = true) }

            typeOk && prefixOk
        }
    }
}

data class InstalledAddon(
    val id: String,
    val manifestUrl: String,
    val baseUrl: String,
    val manifest: StremioManifest,
    val enabled: Boolean = true,
    val status: AddonConnectionStatus = AddonConnectionStatus.CONNECTED,
    val lastError: String? = null,
    val lastCheckedAt: Long = 0L
) {
    fun configureUrl(): String = "${baseUrl.trimEnd('/')}/configure"

    fun buildResourceUrl(vararg segments: String): String {
        val encodedPath = segments
            .filter { it.isNotBlank() }
            .joinToString("/") { android.net.Uri.encode(it) }
        val base = "${baseUrl.trimEnd('/')}/$encodedPath"
        val query = manifestUrl.substringAfter('?', "")
        return if (query.isNotBlank()) "$base?$query" else base
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("manifestUrl", manifestUrl)
        put("baseUrl", baseUrl)
        put("enabled", enabled)
        put("status", status.name)
        if (lastError != null) put("lastError", lastError)
        put("lastCheckedAt", lastCheckedAt)
        put("manifest", StremioManifestCodec.toJson(manifest))
    }

    companion object {
        fun fromJson(obj: JSONObject): InstalledAddon? {
            val manifestObj = obj.optJSONObject("manifest") ?: return null
            val manifest = StremioManifestCodec.fromJson(manifestObj) ?: return null
            val manifestUrl = obj.optString("manifestUrl", "").trim()
            val baseUrl = obj.optString("baseUrl", "").trim()
            if (manifestUrl.isBlank() || baseUrl.isBlank()) return null

            val statusName = obj.optString("status", AddonConnectionStatus.CONNECTED.name)
            val status = AddonConnectionStatus.entries.firstOrNull { it.name == statusName }
                ?: AddonConnectionStatus.CONNECTED
            val err = if (obj.has("lastError") && !obj.isNull("lastError")) {
                obj.optString("lastError", "").takeIf { it.isNotBlank() }
            } else {
                null
            }

            return InstalledAddon(
                id = obj.optString("id", manifest.id).ifBlank { manifest.id },
                manifestUrl = manifestUrl,
                baseUrl = baseUrl,
                manifest = manifest,
                enabled = obj.optBoolean("enabled", true),
                status = status,
                lastError = err,
                lastCheckedAt = obj.optLong("lastCheckedAt", 0L)
            )
        }
    }
}

enum class ContentProviderKind(val displayName: String) {
    MOVIELINK_BD("MovieLinkBD"),
    STREMIO_ADDON("Nuvio Addon")
}

data class UnifiedPosterItem(
    val provider: ContentProviderKind,
    val title: String,
    val posterUrl: String,
    val backdropUrl: String = "",
    val type: String = "",
    val yearOrRelease: String = "",
    val rating: String = "",
    val qualityOrBadge: String = "",
    val language: String = "",
    val description: String = "",
    val genres: List<String> = emptyList(),
    val movieLinkUrl: String? = null,
    val addonManifestUrl: String? = null,
    val addonName: String? = null,
    val stremioId: String? = null,
    val stremioType: String? = null,
    val logoUrl: String = "",
    val fallbackPosterUrl: String = ""
) {
    val stableKey: String
        get() = when (provider) {
            ContentProviderKind.MOVIELINK_BD -> "ml:${movieLinkUrl.orEmpty()}:$title"
            ContentProviderKind.STREMIO_ADDON ->
                "addon:${addonManifestUrl.orEmpty()}:${stremioType ?: type}:${stremioId.orEmpty()}"
        }

    fun toMediaCard(): com.personal.movielink.MediaCard = com.personal.movielink.MediaCard(
        title = title,
        url = movieLinkUrl.orEmpty(),
        posterUrl = posterUrl,
        quality = qualityOrBadge.ifBlank { rating.takeIf { it.isNotBlank() }?.let { "★ $it" }.orEmpty() },
        language = language.ifBlank { yearOrRelease },
        type = type.ifBlank { stremioType.orEmpty() },
        badge = if (provider == ContentProviderKind.STREMIO_ADDON) {
            yearOrRelease.ifBlank { type.replaceFirstChar { it.uppercase() } }
        } else {
            ""
        },
        fallbackPosterUrl = fallbackPosterUrl.ifBlank { backdropUrl }
    )

    companion object {
        fun fromMovieLink(card: com.personal.movielink.MediaCard): UnifiedPosterItem = UnifiedPosterItem(
            provider = ContentProviderKind.MOVIELINK_BD,
            title = card.title,
            posterUrl = card.posterUrl,
            type = card.type,
            qualityOrBadge = card.quality,
            language = card.language,
            movieLinkUrl = card.url,
            fallbackPosterUrl = card.fallbackPosterUrl
        )
    }
}

data class AddonCatalogDescriptor(
    val addon: InstalledAddon,
    val catalog: StremioCatalogSpec
) {
    val catalogKey: String
        get() = "${addon.manifestUrl}|${catalog.type}|${catalog.id}"
}

data class AddonCatalogPage(
    val addonManifestUrl: String,
    val addonName: String,
    val catalogSpec: StremioCatalogSpec,
    val items: List<UnifiedPosterItem>,
    val skip: Int = 0,
    val hasMore: Boolean = false,
    val nextSkip: Int = 0,
    val genreFilter: String? = null,
    val searchQuery: String? = null
)

object StremioManifestCodec {
    fun fromJson(obj: JSONObject): StremioManifest? {
        val id = obj.optString("id", "").trim()
        val name = obj.optString("name", "").trim()
        val version = obj.optString("version", "1.0.0").trim().ifBlank { "1.0.0" }
        if (id.isBlank() || name.isBlank()) return null

        val description = obj.optString("description", "").trim()
        val logo = obj.optString("logo", "").trim()
        val background = obj.optString("background", "").trim()
        val types = readStringArray(obj.optJSONArray("types"))
        val idPrefixes = readStringArray(obj.optJSONArray("idPrefixes"))

        val resources = mutableListOf<StremioResourceSpec>()
        val resArray = obj.optJSONArray("resources")
        if (resArray != null) {
            for (i in 0 until resArray.length()) {
                val item = resArray.opt(i)
                when (item) {
                    is String -> {
                        val clean = item.trim()
                        if (clean.isNotEmpty()) resources.add(StremioResourceSpec(name = clean))
                    }
                    is JSONObject -> {
                        val rName = item.optString("name", "").trim()
                        if (rName.isNotEmpty()) {
                            resources.add(
                                StremioResourceSpec(
                                    name = rName,
                                    types = readStringArray(item.optJSONArray("types")),
                                    idPrefixes = readStringArray(item.optJSONArray("idPrefixes"))
                                )
                            )
                        }
                    }
                }
            }
        }

        val catalogs = mutableListOf<StremioCatalogSpec>()
        val catArray = obj.optJSONArray("catalogs")
        if (catArray != null) {
            for (i in 0 until catArray.length()) {
                val cObj = catArray.optJSONObject(i) ?: continue
                val cType = cObj.optString("type", "").trim()
                val cId = cObj.optString("id", "").trim()
                val cName = cObj.optString("name", cId).trim().ifBlank { cId }
                if (cType.isBlank() || cId.isBlank()) continue

                val extras = mutableListOf<StremioExtraSpec>()
                val extraArr = cObj.optJSONArray("extra")
                if (extraArr != null) {
                    for (j in 0 until extraArr.length()) {
                        val eObj = extraArr.optJSONObject(j)
                        if (eObj != null) {
                            val eName = eObj.optString("name", "").trim()
                            if (eName.isNotEmpty()) {
                                extras.add(
                                    StremioExtraSpec(
                                        name = eName,
                                        isRequired = eObj.optBoolean("isRequired", false),
                                        options = readStringArray(eObj.optJSONArray("options")),
                                        optionsLimit = eObj.optInt("optionsLimit", 1).coerceAtLeast(1)
                                    )
                                )
                            }
                        }
                    }
                }

                // Support legacy extraSupported / extraRequired string arrays
                val legacySupported = readStringArray(cObj.optJSONArray("extraSupported"))
                val legacyRequired = readStringArray(cObj.optJSONArray("extraRequired")).toSet()
                for (nameKey in legacySupported) {
                    if (extras.none { it.name.equals(nameKey, ignoreCase = true) }) {
                        extras.add(
                            StremioExtraSpec(
                                name = nameKey,
                                isRequired = legacyRequired.any { it.equals(nameKey, ignoreCase = true) }
                            )
                        )
                    }
                }
                for (reqKey in legacyRequired) {
                    if (extras.none { it.name.equals(reqKey, ignoreCase = true) }) {
                        extras.add(StremioExtraSpec(name = reqKey, isRequired = true))
                    }
                }

                catalogs.add(
                    StremioCatalogSpec(
                        type = cType,
                        id = cId,
                        name = cName,
                        extra = extras
                    )
                )
            }
        }

        val bhObj = obj.optJSONObject("behaviorHints")
        val behaviorHints = StremioBehaviorHints(
            configurable = bhObj?.optBoolean("configurable", false) ?: false,
            configurationRequired = bhObj?.optBoolean("configurationRequired", false) ?: false
        )

        return StremioManifest(
            id = id,
            version = version,
            name = name,
            description = description,
            logo = logo,
            background = background,
            types = types,
            resources = resources,
            catalogs = catalogs,
            idPrefixes = idPrefixes,
            behaviorHints = behaviorHints
        )
    }

    fun toJson(m: StremioManifest): JSONObject = JSONObject().apply {
        put("id", m.id)
        put("version", m.version)
        put("name", m.name)
        put("description", m.description)
        put("logo", m.logo)
        put("background", m.background)
        put("types", JSONArray(m.types))
        put("idPrefixes", JSONArray(m.idPrefixes))
        put(
            "resources",
            JSONArray().apply {
                m.resources.forEach { r ->
                    put(
                        JSONObject().apply {
                            put("name", r.name)
                            put("types", JSONArray(r.types))
                            put("idPrefixes", JSONArray(r.idPrefixes))
                        }
                    )
                }
            }
        )
        put(
            "catalogs",
            JSONArray().apply {
                m.catalogs.forEach { c ->
                    put(
                        JSONObject().apply {
                            put("type", c.type)
                            put("id", c.id)
                            put("name", c.name)
                            put(
                                "extra",
                                JSONArray().apply {
                                    c.extra.forEach { e ->
                                        put(
                                            JSONObject().apply {
                                                put("name", e.name)
                                                put("isRequired", e.isRequired)
                                                put("options", JSONArray(e.options))
                                                put("optionsLimit", e.optionsLimit)
                                            }
                                        )
                                    }
                                }
                            )
                        }
                    )
                }
            }
        )
        put(
            "behaviorHints",
            JSONObject().apply {
                put("configurable", m.behaviorHints.configurable)
                put("configurationRequired", m.behaviorHints.configurationRequired)
            }
        )
    }

    private fun readStringArray(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        return buildList {
            for (i in 0 until arr.length()) {
                val v = arr.optString(i, "").trim()
                if (v.isNotEmpty()) add(v)
            }
        }
    }
}
