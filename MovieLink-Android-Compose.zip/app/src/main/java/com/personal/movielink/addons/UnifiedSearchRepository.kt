package com.personal.movielink.addons

data class AddonCatalogSearchGroup(
    val key: String,
    val addon: InstalledAddon,
    val catalog: StremioCatalogSpec,
    val items: List<UnifiedPosterItem> = emptyList(),
    val isLoading: Boolean = false,
    val isLoadingMore: Boolean = false,
    val hasMore: Boolean = false,
    val nextSkip: Int = 0,
    val error: String? = null
)

class UnifiedSearchRepository(
    private val catalogRepository: AddonCatalogRepository
) {
    fun discoverSearchableCatalogs(addons: List<InstalledAddon>): List<AddonCatalogDescriptor> {
        val seenKeys = HashSet<String>()
        return catalogRepository.availableSearchCatalogs(addons)
            .filter { desc ->
                seenKeys.add(desc.catalogKey)
            }
    }

    suspend fun searchAddonCatalog(
        descriptor: AddonCatalogDescriptor,
        query: String,
        skip: Int = 0,
        forceRefresh: Boolean = false
    ): Result<AddonCatalogPage> {
        return catalogRepository.fetchCatalog(
            addon = descriptor.addon,
            catalog = descriptor.catalog,
            skip = skip,
            searchQuery = query,
            forceRefresh = forceRefresh
        )
    }
}
