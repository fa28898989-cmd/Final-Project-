package com.personal.movielink

import androidx.compose.runtime.Immutable

@Immutable
data class MediaCard(
    val title: String,
    val url: String,
    val posterUrl: String,
    val quality: String = "",
    val language: String = "",
    val type: String = "",
    val badge: String = "",
    val fallbackPosterUrl: String = ""
)

@Immutable
data class CatalogSection(
    val title: String,
    val items: List<MediaCard>,
    val moreUrl: String? = null
)

@Immutable
data class CategoryChip(
    val label: String,
    val url: String
)

@Immutable
data class OttPlatform(
    val name: String,
    val url: String,
    val iconUrl: String,
    val newBadge: String = "",
    val accentHex: String = "#22D3EE"
)

@Immutable
data class CatalogPage(
    val url: String,
    val pageTitle: String,
    val sections: List<CatalogSection>,
    val categories: List<CategoryChip>,
    val ottPlatforms: List<OttPlatform> = emptyList(),
    val ottAllUrl: String? = null,
    val nextPageUrl: String? = null,
    val isSearchOrGrid: Boolean = false
)

@Immutable
data class CastMember(
    val name: String,
    val role: String,
    val avatarUrl: String,
    val profileUrl: String
)

@Immutable
data class DownloadOption(
    val label: String,
    val decodedUrl: String,
    val isZipPack: Boolean = false
)

@Immutable
data class EpisodeItem(
    val title: String,
    val seasonNumber: Int?,
    val episodeNumber: Int?,
    val isNew: Boolean,
    val downloads: List<DownloadOption>,
    val watchEmbedUrl: String? = null
)

@Immutable
data class ExternalRatingBadge(
    val source: String,
    val value: String
)

@Immutable
data class MediaDetail(
    val url: String,
    val title: String,
    val subtitle: String,
    val posterUrl: String,
    val type: String,
    val language: String,
    val quality: String,
    val scheduleText: String,
    val trailerYoutubeId: String?,
    val watchEmbedUrl: String?,
    val storyline: String,
    val extraInfoLines: List<String>,
    val cast: List<CastMember>,
    val screenshotUrls: List<String>,
    val downloadLinks: List<DownloadOption>,
    val episodes: List<EpisodeItem>,
    val seasonZipLinks: List<DownloadOption>,
    val relatedItems: List<MediaCard>,
    val communityRatingSummary: String? = null,
    val backdropUrl: String = "",
    val logoUrl: String = "",
    val externalRatings: List<ExternalRatingBadge> = emptyList(),
    val imdbId: String? = null,
    val genres: List<String> = emptyList(),
    val status: String = "",
    val releaseInfo: String = "",
    val runtime: String = "",
    val certification: String = "",
    val originCountry: String = "",
    val originalLanguage: String = ""
)

@Immutable
data class HistoryItem(
    val title: String,
    val url: String,
    val posterUrl: String = "",
    val timestamp: Long
)

@Immutable
data class MyListItem(
    val url: String,
    val title: String,
    val posterUrl: String,
    val type: String,
    val quality: String,
    val language: String,
    val addedAt: Long
)

@Immutable
data class UnifiedPosterItem(
    val stableKey: String,
    val title: String,
    val posterUrl: String = "",
    val fallbackPosterUrl: String = "",
    val backdropUrl: String = "",
    val logoUrl: String = "",
    val type: String = "Movie",
    val yearOrRelease: String = "",
    val rating: String = "",
    val qualityOrBadge: String = "",
    val language: String = "",
    val description: String = "",
    val genres: List<String> = emptyList(),
    val movieLinkUrl: String? = null,
    val imdbId: String? = null
) {
    fun toMediaCard(): MediaCard = MediaCard(
        title = title,
        url = movieLinkUrl ?: stableKey,
        posterUrl = posterUrl,
        quality = qualityOrBadge,
        language = language,
        type = type,
        badge = rating,
        fallbackPosterUrl = fallbackPosterUrl
    )

    companion object {
        fun fromMovieLink(card: MediaCard): UnifiedPosterItem = UnifiedPosterItem(
            stableKey = "ml:${card.url.trim().trimEnd('/')}",
            title = card.title,
            posterUrl = card.posterUrl,
            fallbackPosterUrl = card.fallbackPosterUrl,
            backdropUrl = "",
            logoUrl = "",
            type = card.type.ifBlank { "Movie" },
            yearOrRelease = "",
            rating = "",
            qualityOrBadge = card.quality.ifBlank { card.badge },
            language = card.language,
            movieLinkUrl = card.url
        )
    }
}

@Immutable
data class UserSettings(
    val mirrorUrl: String = Config.DEFAULT_HOME_URL,
    val resumeLastPage: Boolean = false,
    val lastVisitedUrl: String? = null,
    val downloaderMode: Config.DownloaderMode = Config.DownloaderMode.AUTO,
    val videoActionMode: Config.VideoActionMode = Config.VideoActionMode.DOWNLOAD,
    val hideVideoProgressBar: Boolean = true,
    val playerBrightnessSync: Boolean = true,
    val desktopMode: Boolean = false,
    val adBlockEnabled: Boolean = true,
    val sitePolishEnabled: Boolean = true,
    val showContinueWatching: Boolean = true,
    val showOttSection: Boolean = true,
    val floatingNavBar: Boolean = false,
    val floatingNavHeightDp: Int = 56,
    val floatingNavWidthPercent: Int = 90,
    val floatingNavSpacingDp: Int = 14,
    val floatingNavIconSpacingDp: Int = 8,
    val floatingNavAlphaPercent: Int = 90,
    val floatingNavColorHex: String? = null,
    val normalNavHeightDp: Int = 60,
    val normalNavWidthPercent: Int = 92,
    val normalNavSpacingDp: Int = 4,
    val normalNavIconSpacingDp: Int = 8,
    val normalNavAlphaPercent: Int = 96,
    val normalNavColorHex: String? = null,
    val navBarIconIds: Set<String> = Config.NavBarIcon.DEFAULT_IDS,
    val appLogoStyle: Config.AppLogoStyle = Config.AppLogoStyle.ECLIPSE,
    val detailBoxEnabled: Boolean = true,
    val detailBoxStyle: Config.DetailBoxStyle = Config.DetailBoxStyle.ROUNDED,
    val detailBoxOpacityPercent: Int = 85,
    val detailBoxSizePercent: Int = 100,
    val detailBoxColorHex: String = "#71717A",
    val bgPresetId: String = Config.BgPreset.BLACK.id,
    val customBgHex: String? = null,
    val themePresetId: String = Config.ThemePreset.BLACK.id,
    val customThemeHex: String? = null,
    val customBlockedDomains: Set<String> = emptySet(),
    val customAllowedDomains: Set<String> = emptySet(),
    val showLocalPlayerTab: Boolean = true,
    val movieLinkHeroEnabled: Boolean = true,
    val movieLinkSearchEnabled: Boolean = true,
    val movieLinkWatchOnlineEnabled: Boolean = true,
    val heroSourceKey: String? = null,
    val heroSourceKeys: Set<String> = emptySet(),
    val heroAutoRotate: Boolean = false,
    val continueWatchingLayout: Config.ContinueWatchingLayout = Config.ContinueWatchingLayout.VERTICAL,
    val heroLayoutStyle: Config.HeroLayoutStyle = Config.HeroLayoutStyle.CAROUSEL,
    val heroSizePercent: Int = 100,
    val detailHeroSizePercent: Int = 100,
    val tmdbMetadataEnabled: Boolean = false,
    val tmdbApiKey: String = "",
    val mdbListEnabled: Boolean = false,
    val mdbListApiKey: String = "",
    val betterPosterProvider: Config.BetterPosterProvider = Config.BetterPosterProvider.NONE,
    val rpdbApiKey: String = "",
    val betterPosterCustomTemplate: String = "https://btttr.cc/poster-a/imdb/poster-default/{imdb_id}.jpg",
    val betterPosterOnCards: Boolean = true
) {
    fun effectiveHeroSourceKeys(): Set<String> {
        val multi = heroSourceKeys.map { it.trim() }.filter { it.isNotEmpty() }.toSet()
        if (multi.isNotEmpty()) return multi
        val single = heroSourceKey?.trim()?.takeIf { it.isNotEmpty() }
        return if (single != null) setOf(single) else emptySet()
    }

    fun effectiveNavBarIcons(): Set<Config.NavBarIcon> {
        val resolved = navBarIconIds.mapNotNull { Config.NavBarIcon.fromId(it) }.toMutableSet()
        if (!showLocalPlayerTab) {
            resolved.remove(Config.NavBarIcon.LOCAL)
        }
        if (resolved.isEmpty()) {
            resolved.add(Config.NavBarIcon.HOME)
            resolved.add(Config.NavBarIcon.SEARCH)
        }
        return resolved
    }
}

@Immutable
data class PlaybackProgressItem(
    val mediaKey: String,
    val title: String,
    val subtitle: String = "",
    val posterUrl: String = "",
    val streamUrl: String = "",
    val refererUrl: String = "",
    val sourceType: String = "",
    val contentType: String = "",
    val quality: String = "",
    val requestHeaders: Map<String, String> = emptyMap(),
    val mimeTypeHint: String? = null,
    val sourceLabel: String = "",
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val isEmbedPage: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

@Immutable
data class PlayerSubtitleTrack(
    val id: String,
    val lang: String,
    val url: String,
    val mimeType: String? = null,
    val label: String? = null
)

@Immutable
data class PlayerLaunchRequest(
    val streamUrl: String,
    val title: String,
    val subtitle: String = "",
    val refererUrl: String,
    val isEmbedPage: Boolean = false,
    val requestHeaders: Map<String, String> = emptyMap(),
    val subtitles: List<PlayerSubtitleTrack> = emptyList(),
    val mimeTypeHint: String? = null,
    val sourceLabel: String = "",
    val mediaKey: String = "",
    val posterUrl: String = "",
    val contentType: String = "",
    val isLocalMedia: Boolean = false,
    val targetSeason: Int? = null,
    val targetEpisode: Int? = null,
    val targetEpisodeTitle: String = ""
)
