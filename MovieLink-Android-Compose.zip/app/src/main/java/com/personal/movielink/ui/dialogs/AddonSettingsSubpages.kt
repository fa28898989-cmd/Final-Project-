package com.personal.movielink.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.OpenInBrowser
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.personal.movielink.Config
import com.personal.movielink.DownloadAndPlayerRouter
import com.personal.movielink.UserSettings
import com.personal.movielink.addons.AddonConnectionStatus
import com.personal.movielink.addons.InstalledAddon
import com.personal.movielink.ui.theme.LocalMovieLinkPalette
import kotlinx.coroutines.launch

@Composable
fun ProvidersSettingsSubpage(
    settings: UserSettings,
    onUpdateSettings: ((UserSettings) -> UserSettings) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "Keep MovieLinkBD and Nuvio Stremio Addons controlled independently. All Nuvio features start OFF by default.",
            color = palette.textSecondary,
            fontSize = 12.sp,
            lineHeight = 17.sp
        )

        SubpageHeaderText("Nuvio / Stremio Addon Provider")
        SubpageToggleCard(
            title = "Enable Nuvio Addon Integration",
            subtitle = "Master switch for Stremio addon catalogues, hero, search, and streaming",
            checked = settings.nuvioIntegrationEnabled,
            onCheckedChange = { v -> onUpdateSettings { it.copy(nuvioIntegrationEnabled = v) } }
        )

        if (settings.nuvioIntegrationEnabled) {
            SubpageToggleCard(
                title = "Nuvio Home Catalogues",
                subtitle = "Allow selected addon catalogues in the combined Home feed",
                checked = settings.nuvioHomeCatalogsEnabled,
                onCheckedChange = { v -> onUpdateSettings { it.copy(nuvioHomeCatalogsEnabled = v) } }
            )
            SubpageToggleCard(
                title = "Nuvio Hero Content",
                subtitle = "Allow addon catalogues as the Home hero carousel source",
                checked = settings.nuvioHeroEnabled,
                onCheckedChange = { v -> onUpdateSettings { it.copy(nuvioHeroEnabled = v) } }
            )
        }

        Spacer(Modifier.height(4.dp))
        SubpageHeaderText("MovieLinkBD Provider")
        SubpageToggleCard(
            title = "MovieLinkBD Hero Content",
            subtitle = "Show website posters in the Home screen hero carousel",
            checked = settings.movieLinkHeroEnabled,
            onCheckedChange = { v -> onUpdateSettings { it.copy(movieLinkHeroEnabled = v) } }
        )
        SubpageToggleCard(
            title = "Show Watch by OTT Section",
            subtitle = "Displays OTT shortcuts below Continue Watching on Home",
            checked = settings.showOttSection,
            onCheckedChange = { v -> onUpdateSettings { it.copy(showOttSection = v) } }
        )
    }
}

@Composable
fun SearchAndStreamingSubpage(
    settings: UserSettings,
    onUpdateSettings: ((UserSettings) -> UserSettings) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SubpageHeaderText("Search Providers")
        SubpageToggleCard(
            title = "Enable MovieLinkBD Search",
            subtitle = "Queries the MovieLinkBD website when searching",
            checked = settings.movieLinkSearchEnabled,
            onCheckedChange = { v -> onUpdateSettings { it.copy(movieLinkSearchEnabled = v) } }
        )
        SubpageToggleCard(
            title = "Enable Nuvio Addon Search",
            subtitle = if (settings.nuvioIntegrationEnabled) {
                "Queries enabled Stremio addons that support search"
            } else {
                "Requires Nuvio Integration to be turned ON in Providers"
            },
            checked = settings.nuvioSearchEnabled,
            enabled = settings.nuvioIntegrationEnabled,
            onCheckedChange = { v -> onUpdateSettings { it.copy(nuvioSearchEnabled = v) } }
        )

        Spacer(Modifier.height(4.dp))
        SubpageHeaderText("Streaming Options")
        SubpageToggleCard(
            title = "Watch Online (MovieLinkBD)",
            subtitle = "Shows the existing Watch Online (Ad-Free) player button",
            checked = settings.movieLinkWatchOnlineEnabled,
            onCheckedChange = { v -> onUpdateSettings { it.copy(movieLinkWatchOnlineEnabled = v) } }
        )
        SubpageToggleCard(
            title = "Watch from Addons (Nuvio)",
            subtitle = if (settings.nuvioIntegrationEnabled) {
                "Enables the dedicated Addon Sources screen for addon playback"
            } else {
                "Requires Nuvio Integration to be turned ON in Providers"
            },
            checked = settings.watchFromAddonsEnabled,
            enabled = settings.nuvioIntegrationEnabled,
            onCheckedChange = { v -> onUpdateSettings { it.copy(watchFromAddonsEnabled = v) } }
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(palette.altBg)
                .padding(12.dp)
        ) {
            Text(
                text = "Downloads stay strictly managed by MovieLinkBD's existing downloader system (1DM+/1DM/ADM/Built-in).",
                color = palette.textSecondary,
                fontSize = 11.5.sp,
                lineHeight = 16.sp
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddonManagerSubpage(
    settings: UserSettings,
    addons: List<InstalledAddon>,
    isBusy: Boolean,
    onUpdateSettings: ((UserSettings) -> UserSettings) -> Unit,
    onInstallAddon: suspend (String) -> Result<InstalledAddon>,
    onToggleAddon: (String, Boolean) -> Unit,
    onRefreshAddon: suspend (String) -> Result<InstalledAddon>,
    onRefreshAllAddons: () -> Unit,
    onRemoveAddon: (String) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var manifestUrlInput by remember { mutableStateOf("") }
    var statusBanner by remember { mutableStateOf<Pair<Boolean, String>?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (!settings.nuvioIntegrationEnabled) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(palette.boxBg)
                    .border(1.dp, palette.boxBorder.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                    Text(
                        text = "Nuvio Integration is OFF",
                        color = palette.textPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "You can install addons now, then enable Nuvio in Providers when ready.",
                        color = palette.textSecondary,
                        fontSize = 11.5.sp
                    )
                }
                Button(
                    onClick = { onUpdateSettings { it.copy(nuvioIntegrationEnabled = true) } },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = palette.fg,
                        contentColor = palette.onAccent
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Enable", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        SubpageHeaderText("Install Stremio Addon")
        OutlinedTextField(
            value = manifestUrlInput,
            onValueChange = { manifestUrlInput = it },
            singleLine = true,
            label = { Text("Addon Manifest URL (https://.../manifest.json)", fontSize = 12.sp) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = palette.fg,
                unfocusedBorderColor = palette.border.copy(alpha = 0.5f),
                focusedTextColor = palette.textPrimary,
                unfocusedTextColor = palette.textPrimary
            ),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                enabled = !isBusy && manifestUrlInput.isNotBlank(),
                onClick = {
                    val raw = manifestUrlInput.trim()
                    statusBanner = null
                    scope.launch {
                        val res = onInstallAddon(raw)
                        res.fold(
                            onSuccess = { installed ->
                                manifestUrlInput = ""
                                statusBanner = true to "Installed ${installed.manifest.name} (v${installed.manifest.version})"
                            },
                            onFailure = { err ->
                                statusBanner = false to (err.message ?: "Failed to install addon")
                            }
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = palette.fg,
                    contentColor = palette.onAccent
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                if (isBusy) {
                    CircularProgressIndicator(
                        color = palette.onAccent,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                }
                Text("Install Addon", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
            }

            if (addons.isNotEmpty()) {
                OutlinedButton(
                    enabled = !isBusy,
                    onClick = {
                        statusBanner = null
                        onRefreshAllAddons()
                    },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        Icons.Rounded.Refresh,
                        contentDescription = "Refresh all addons",
                        tint = palette.textPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text("Refresh All", color = palette.textPrimary, fontSize = 12.sp)
                }
            }
        }

        statusBanner?.let { (ok, msg) ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (ok) Color(0x1F22C55E) else Color(0x26EF4444))
                    .border(
                        1.dp,
                        if (ok) Color(0xFF22C55E) else Color(0xFFEF4444),
                        RoundedCornerShape(10.dp)
                    )
                    .padding(10.dp)
            ) {
                Text(
                    text = msg,
                    color = if (ok) Color(0xFF4ADE80) else Color(0xFFFCA5A5),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(Modifier.height(4.dp))
        SubpageHeaderText("Installed Addons (${addons.size})")

        if (addons.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(palette.altBg)
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(
                        imageVector = Icons.Rounded.Extension,
                        contentDescription = null,
                        tint = palette.textSecondary,
                        modifier = Modifier.size(26.dp)
                    )
                    Text(
                        text = "No Stremio addons installed yet.",
                        color = palette.textPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Paste a valid Stremio manifest.json URL above to install external catalogues, metadata, streams, or subtitles.",
                        color = palette.textSecondary,
                        fontSize = 11.5.sp
                    )
                }
            }
        } else {
            addons.forEach { addon ->
                val statusColor = when (addon.status) {
                    AddonConnectionStatus.CONNECTED -> Color(0xFF4ADE80)
                    AddonConnectionStatus.CONFIG_REQUIRED -> Color(0xFFFBBF24)
                    AddonConnectionStatus.UNREACHABLE -> Color(0xFFF87171)
                    AddonConnectionStatus.DISABLED -> palette.textSecondary
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(palette.altBg)
                        .border(1.dp, palette.boxBorder.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = addon.manifest.name,
                                    color = palette.textPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "v${addon.manifest.version}",
                                    color = palette.textSecondary,
                                    fontSize = 11.sp
                                )
                            }
                            Text(
                                text = addon.status.label,
                                color = statusColor,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Switch(
                            checked = addon.enabled,
                            onCheckedChange = { checked -> onToggleAddon(addon.manifestUrl, checked) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = palette.onAccent,
                                checkedTrackColor = palette.fg
                            )
                        )
                    }

                    if (addon.manifest.description.isNotBlank()) {
                        Text(
                            text = addon.manifest.description,
                            color = palette.textSecondary,
                            fontSize = 11.5.sp,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Supported resources & types summary
                    val resNames = addon.manifest.resourceNames()
                    val types = addon.manifest.types
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        resNames.forEach { res ->
                            AddonTagChip(label = "res: $res", highlight = true)
                        }
                        types.forEach { t ->
                            AddonTagChip(label = t, highlight = false)
                        }
                        if (addon.manifest.catalogs.isNotEmpty()) {
                            AddonTagChip(
                                label = "${addon.manifest.catalogs.size} catalog${if (addon.manifest.catalogs.size == 1) "" else "s"}",
                                highlight = false
                            )
                        }
                    }

                    if (addon.lastError != null) {
                        Text(
                            text = "Last error: ${addon.lastError}",
                            color = Color(0xFFFCA5A5),
                            fontSize = 11.sp
                        )
                    }

                    if (addon.manifest.behaviorHints.configurationRequired || addon.manifest.behaviorHints.configurable) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(palette.cardBg)
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (addon.manifest.behaviorHints.configurationRequired) {
                                    "Configuration required before use"
                                } else {
                                    "Supports external configuration"
                                },
                                color = if (addon.manifest.behaviorHints.configurationRequired) {
                                    Color(0xFFFBBF24)
                                } else {
                                    palette.textSecondary
                                },
                                fontSize = 11.sp,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedButton(
                                onClick = {
                                    DownloadAndPlayerRouter.openExternal(context, addon.configureUrl())
                                },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(
                                    Icons.Rounded.OpenInBrowser,
                                    contentDescription = null,
                                    tint = palette.fg,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(Modifier.width(4.dp))
                                Text("Configure", color = palette.fg, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            enabled = !isBusy,
                            onClick = {
                                scope.launch {
                                    val res = onRefreshAddon(addon.manifestUrl)
                                    res.fold(
                                        onSuccess = {
                                            statusBanner = true to "Refreshed ${it.manifest.name}"
                                        },
                                        onFailure = { e ->
                                            statusBanner = false to "${addon.manifest.name}: ${e.message ?: "Refresh failed"}"
                                        }
                                    )
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Refresh,
                                contentDescription = "Refresh manifest",
                                tint = palette.fg,
                                modifier = Modifier.size(19.dp)
                            )
                        }
                        IconButton(onClick = { onRemoveAddon(addon.manifestUrl) }) {
                            Icon(
                                imageVector = Icons.Rounded.Delete,
                                contentDescription = "Remove addon",
                                tint = Color(0xFFF87171),
                                modifier = Modifier.size(19.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AddonTagChip(label: String, highlight: Boolean) {
    val palette = LocalMovieLinkPalette.current
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (highlight) palette.boxBg else palette.cardBg)
            .border(
                1.dp,
                if (highlight) palette.boxBorder.copy(alpha = 0.65f) else palette.border.copy(alpha = 0.35f),
                RoundedCornerShape(6.dp)
            )
            .padding(horizontal = 7.dp, vertical = 3.dp)
    ) {
        Text(
            text = label,
            color = if (highlight) palette.fg else palette.textSecondary,
            fontSize = 10.5.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun SubpageHeaderText(title: String) {
    val palette = LocalMovieLinkPalette.current
    Text(
        text = title,
        color = palette.fg,
        fontSize = 13.5.sp,
        fontWeight = FontWeight.ExtraBold
    )
}

@Composable
private fun SubpageToggleCard(
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.altBg)
            .clickable(enabled = enabled) { onCheckedChange(!checked) }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
            Text(
                text = title,
                color = if (enabled) palette.textPrimary else palette.textSecondary,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = subtitle,
                color = palette.textSecondary,
                fontSize = 11.5.sp,
                lineHeight = 15.sp
            )
        }
        Switch(
            checked = checked,
            enabled = enabled,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = palette.onAccent,
                checkedTrackColor = palette.fg
            )
        )
    }
}

@Composable
fun MetadataIntegrationsSubpage(
    settings: UserSettings,
    onUpdateSettings: ((UserSettings) -> UserSettings) -> Unit,
    onTestMetadataIntegration: suspend (
        kind: String,
        tmdbKey: String,
        mdbKey: String,
        bpProvider: Config.BetterPosterProvider,
        rpdbKey: String,
        customTemplate: String
    ) -> Result<String>
) {
    val palette = LocalMovieLinkPalette.current
    val scope = rememberCoroutineScope()

    var tmdbKeyInput by remember(settings.tmdbApiKey) { mutableStateOf(settings.tmdbApiKey) }
    var mdbKeyInput by remember(settings.mdbListApiKey) { mutableStateOf(settings.mdbListApiKey) }
    var rpdbKeyInput by remember(settings.rpdbApiKey) { mutableStateOf(settings.rpdbApiKey) }
    var customTemplateInput by remember(settings.betterPosterCustomTemplate) {
        mutableStateOf(settings.betterPosterCustomTemplate)
    }

    var testingKind by remember { mutableStateOf<String?>(null) }
    var statusBanner by remember { mutableStateOf<Pair<Boolean, String>?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            text = "All metadata integrations are optional and default to OFF. Existing MovieLinkBD and Stremio addon feeds continue working normally without keys.",
            color = palette.textSecondary,
            fontSize = 12.sp,
            lineHeight = 17.sp
        )

        statusBanner?.let { (ok, msg) ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (ok) Color(0x1F22C55E) else Color(0x26EF4444))
                    .border(
                        1.dp,
                        if (ok) Color(0xFF22C55E) else Color(0xFFEF4444),
                        RoundedCornerShape(10.dp)
                    )
                    .padding(10.dp)
            ) {
                Text(
                    text = msg,
                    color = if (ok) Color(0xFF4ADE80) else Color(0xFFFCA5A5),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // 1. TMDB
        SubpageHeaderText("TMDB (The Movie Database)")
        SubpageToggleCard(
            title = "Enable TMDB Metadata Enrichment",
            subtitle = "Fills missing synopses, backdrops, cast photos, genres, and TMDB scores on detail screens",
            checked = settings.tmdbMetadataEnabled,
            onCheckedChange = { v -> onUpdateSettings { it.copy(tmdbMetadataEnabled = v) } }
        )
        OutlinedTextField(
            value = tmdbKeyInput,
            onValueChange = { tmdbKeyInput = it },
            singleLine = true,
            label = { Text("TMDB API Key (v3) or Read Access Token (v4)", fontSize = 12.sp) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = palette.fg,
                unfocusedBorderColor = palette.border.copy(alpha = 0.5f),
                focusedTextColor = palette.textPrimary,
                unfocusedTextColor = palette.textPrimary
            ),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    val trimmed = tmdbKeyInput.trim()
                    onUpdateSettings { it.copy(tmdbApiKey = trimmed) }
                    statusBanner = true to "Saved TMDB key"
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = palette.fg,
                    contentColor = palette.onAccent
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text("Save Key", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            OutlinedButton(
                enabled = testingKind == null,
                onClick = {
                    val trimmed = tmdbKeyInput.trim()
                    onUpdateSettings { it.copy(tmdbApiKey = trimmed) }
                    testingKind = "tmdb"
                    statusBanner = null
                    scope.launch {
                        val res = onTestMetadataIntegration(
                            "tmdb",
                            trimmed,
                            mdbKeyInput.trim(),
                            settings.betterPosterProvider,
                            rpdbKeyInput.trim(),
                            customTemplateInput.trim()
                        )
                        res.fold(
                            onSuccess = { statusBanner = true to it },
                            onFailure = { statusBanner = false to (it.message ?: "TMDB connection failed") }
                        )
                        testingKind = null
                    }
                },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = if (testingKind == "tmdb") "Testing…" else "Test TMDB",
                    color = palette.textPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // 2. MDBD / MDBList
        SubpageHeaderText("MDBD / MDBList (Multi-Source Ratings)")
        SubpageToggleCard(
            title = "Enable MDBD (MDBList) Ratings",
            subtitle = "Fetches IMDb, Rotten Tomatoes, Metacritic, Trakt & Letterboxd ratings via api.mdblist.com",
            checked = settings.mdbListEnabled,
            onCheckedChange = { v -> onUpdateSettings { it.copy(mdbListEnabled = v) } }
        )
        OutlinedTextField(
            value = mdbKeyInput,
            onValueChange = { mdbKeyInput = it },
            singleLine = true,
            label = { Text("MDBList API Key", fontSize = 12.sp) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = palette.fg,
                unfocusedBorderColor = palette.border.copy(alpha = 0.5f),
                focusedTextColor = palette.textPrimary,
                unfocusedTextColor = palette.textPrimary
            ),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    val trimmed = mdbKeyInput.trim()
                    onUpdateSettings { it.copy(mdbListApiKey = trimmed) }
                    statusBanner = true to "Saved MDBD / MDBList key"
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = palette.fg,
                    contentColor = palette.onAccent
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text("Save Key", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            OutlinedButton(
                enabled = testingKind == null,
                onClick = {
                    val trimmed = mdbKeyInput.trim()
                    onUpdateSettings { it.copy(mdbListApiKey = trimmed) }
                    testingKind = "mdblist"
                    statusBanner = null
                    scope.launch {
                        val res = onTestMetadataIntegration(
                            "mdblist",
                            tmdbKeyInput.trim(),
                            trimmed,
                            settings.betterPosterProvider,
                            rpdbKeyInput.trim(),
                            customTemplateInput.trim()
                        )
                        res.fold(
                            onSuccess = { statusBanner = true to it },
                            onFailure = { statusBanner = false to (it.message ?: "MDBList connection failed") }
                        )
                        testingKind = null
                    }
                },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = if (testingKind == "mdblist") "Testing…" else "Test MDBD",
                    color = palette.textPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // 3. Better Poster
        SubpageHeaderText("Better Poster Artwork")
        Text(
            text = "Enhances IMDb-backed addon posters with crisp rating badges or custom artwork proxies (btttr.cc / RPDB).",
            color = palette.textSecondary,
            fontSize = 11.5.sp,
            lineHeight = 16.sp
        )

        Config.BetterPosterProvider.entries.forEach { provider ->
            val selected = settings.betterPosterProvider == provider
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (selected) palette.boxBg else palette.altBg)
                    .border(
                        width = 1.dp,
                        color = if (selected) palette.boxBorder else Color.Transparent,
                        shape = RoundedCornerShape(10.dp)
                    )
                    .clickable {
                        onUpdateSettings { it.copy(betterPosterProvider = provider) }
                    }
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = provider.label,
                    color = palette.textPrimary,
                    fontSize = 12.5.sp,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                )
                if (selected) {
                    Text("Active", color = palette.fg, fontSize = 11.5.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
        }

        if (settings.betterPosterProvider == Config.BetterPosterProvider.RPDB) {
            OutlinedTextField(
                value = rpdbKeyInput,
                onValueChange = { rpdbKeyInput = it },
                singleLine = true,
                label = { Text("RPDB API Key (e.g. t0-free-rpdb or paid key)", fontSize = 12.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = palette.fg,
                    unfocusedBorderColor = palette.border.copy(alpha = 0.5f),
                    focusedTextColor = palette.textPrimary,
                    unfocusedTextColor = palette.textPrimary
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    val trimmed = rpdbKeyInput.trim()
                    onUpdateSettings { it.copy(rpdbApiKey = trimmed) }
                    statusBanner = true to "Saved RPDB key"
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = palette.fg,
                    contentColor = palette.onAccent
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save RPDB Key", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        if (settings.betterPosterProvider == Config.BetterPosterProvider.CUSTOM) {
            OutlinedTextField(
                value = customTemplateInput,
                onValueChange = { customTemplateInput = it },
                singleLine = true,
                label = { Text("Custom Template ({imdb_id}, {type})", fontSize = 12.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = palette.fg,
                    unfocusedBorderColor = palette.border.copy(alpha = 0.5f),
                    focusedTextColor = palette.textPrimary,
                    unfocusedTextColor = palette.textPrimary
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    val trimmed = customTemplateInput.trim()
                    onUpdateSettings { it.copy(betterPosterCustomTemplate = trimmed) }
                    statusBanner = true to "Saved Custom Poster Template"
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = palette.fg,
                    contentColor = palette.onAccent
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save Template", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        if (settings.betterPosterProvider != Config.BetterPosterProvider.NONE) {
            SubpageToggleCard(
                title = "Apply Better Poster on Home & Search Cards",
                subtitle = "Updates posters in Home rails, Search, and Addon grids for IMDb-backed items",
                checked = settings.betterPosterOnCards,
                onCheckedChange = { v -> onUpdateSettings { it.copy(betterPosterOnCards = v) } }
            )

            OutlinedButton(
                enabled = testingKind == null,
                onClick = {
                    onUpdateSettings {
                        it.copy(
                            rpdbApiKey = rpdbKeyInput.trim(),
                            betterPosterCustomTemplate = customTemplateInput.trim()
                        )
                    }
                    testingKind = "better_poster"
                    statusBanner = null
                    scope.launch {
                        val res = onTestMetadataIntegration(
                            "better_poster",
                            tmdbKeyInput.trim(),
                            mdbKeyInput.trim(),
                            settings.betterPosterProvider,
                            rpdbKeyInput.trim(),
                            customTemplateInput.trim()
                        )
                        res.fold(
                            onSuccess = { statusBanner = true to it },
                            onFailure = { statusBanner = false to (it.message ?: "Better Poster check failed") }
                        )
                        testingKind = null
                    }
                },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = if (testingKind == "better_poster") "Verifying…" else "Verify Better Poster Endpoint",
                    color = palette.fg,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
