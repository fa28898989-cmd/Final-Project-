package com.personal.movielink.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DragHandle
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.personal.movielink.UserSettings
import com.personal.movielink.addons.ContentProviderKind
import com.personal.movielink.addons.UnifiedHomeCatalogEntry
import com.personal.movielink.ui.theme.LocalMovieLinkPalette

@Composable
fun HomeCatalogManagerSubpage(
    settings: UserSettings,
    entries: List<UnifiedHomeCatalogEntry>,
    onUpdateSettings: ((UserSettings) -> UserSettings) -> Unit,
    onToggleCatalog: (String, Boolean) -> Unit,
    onMoveCatalog: (Int, Int) -> Unit,
    onRemoveEntry: (String) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val currentEntries by rememberUpdatedState(entries)
    val itemHeightsPx = remember { mutableStateMapOf<String, Int>() }
    var draggingKey by remember { mutableStateOf<String?>(null) }
    var dragOffsetY by remember { mutableFloatStateOf(0f) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "Manage and reorder both MovieLinkBD and Nuvio addon catalogues together in one list. Drag the handle (≡) or use arrows to change Home order.",
            color = palette.textSecondary,
            fontSize = 12.sp,
            lineHeight = 17.sp
        )

        if (!settings.nuvioIntegrationEnabled || !settings.nuvioHomeCatalogsEnabled) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(palette.boxBg)
                    .border(1.dp, palette.boxBorder.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                    Text(
                        text = "Nuvio Home Catalogues are OFF",
                        color = palette.textPrimary,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Addon sections can be arranged now and will appear on Home once enabled.",
                        color = palette.textSecondary,
                        fontSize = 11.sp
                    )
                }
                Button(
                    onClick = {
                        onUpdateSettings {
                            it.copy(
                                nuvioIntegrationEnabled = true,
                                nuvioHomeCatalogsEnabled = true
                            )
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = palette.fg,
                        contentColor = palette.onAccent
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Enable", fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                }
            }
        }

        val enabledMl = entries.count { it.provider == ContentProviderKind.MOVIELINK_BD && !it.key.startsWith("ml:cat:") && it.movieLinkCategoryUrl == null && it.enabled && it.isAvailable }
        val enabledCats = entries.count { (it.key.startsWith("ml:cat:") || it.movieLinkCategoryUrl != null) && it.enabled && it.isAvailable }
        val enabledAddon = entries.count { it.provider == ContentProviderKind.STREMIO_ADDON && it.enabled && it.isAvailable }
        Text(
            text = "Unified Feed Order (${entries.size} total · $enabledMl Home · $enabledCats Categories · $enabledAddon Nuvio active)",
            color = palette.fg,
            fontSize = 13.sp,
            fontWeight = FontWeight.ExtraBold
        )

        if (entries.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(palette.altBg)
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Open the Home screen once or install a Stremio addon to populate catalogues here.",
                    color = palette.textSecondary,
                    fontSize = 12.sp
                )
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                entries.forEachIndexed { index, entry ->
                    key(entry.key) {
                        val isDragging = draggingKey == entry.key
                        val isCategory = entry.key.startsWith("ml:cat:") || entry.movieLinkCategoryUrl != null
                        val isMovieLink = entry.provider == ContentProviderKind.MOVIELINK_BD
                        val providerLabel = when {
                            isCategory -> "Category · MovieLinkBD"
                            isMovieLink -> "MovieLinkBD"
                            else -> "Nuvio · ${entry.addonName ?: "Addon"}"
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .zIndex(if (isDragging) 1f else 0f)
                                .graphicsLayer {
                                    translationY = if (isDragging) dragOffsetY else 0f
                                    scaleX = if (isDragging) 1.015f else 1f
                                    scaleY = if (isDragging) 1.015f else 1f
                                }
                                .onSizeChanged { size ->
                                    itemHeightsPx[entry.key] = size.height
                                }
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isDragging) palette.cardBg else palette.altBg)
                                .border(
                                    width = if (isDragging) 1.5.dp else 1.dp,
                                    color = if (isDragging) {
                                        palette.fg
                                    } else {
                                        palette.boxBorder.copy(alpha = if (entry.enabled) 0.55f else 0.25f)
                                    },
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { onToggleCatalog(entry.key, !entry.enabled) }
                                .padding(horizontal = 8.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            // Drag handle
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(palette.cardBg)
                                    .pointerInput(entry.key) {
                                        detectVerticalDragGestures(
                                            onDragStart = {
                                                draggingKey = entry.key
                                                dragOffsetY = 0f
                                            },
                                            onDragEnd = {
                                                draggingKey = null
                                                dragOffsetY = 0f
                                            },
                                            onDragCancel = {
                                                draggingKey = null
                                                dragOffsetY = 0f
                                            },
                                            onVerticalDrag = { change, dragAmount ->
                                                change.consume()
                                                dragOffsetY += dragAmount
                                                val listSnapshot = currentEntries
                                                val currIdx = listSnapshot.indexOfFirst { it.key == entry.key }
                                                if (currIdx >= 0) {
                                                    val selfHeight = (itemHeightsPx[entry.key] ?: 140).coerceAtLeast(80)
                                                    val stepPx = selfHeight + 16f
                                                    if (dragOffsetY > stepPx * 0.55f && currIdx < listSnapshot.lastIndex) {
                                                        val targetIdx = currIdx + 1
                                                        onMoveCatalog(currIdx, targetIdx)
                                                        dragOffsetY -= stepPx
                                                    } else if (dragOffsetY < -stepPx * 0.55f && currIdx > 0) {
                                                        val targetIdx = currIdx - 1
                                                        onMoveCatalog(currIdx, targetIdx)
                                                        dragOffsetY += stepPx
                                                    }
                                                }
                                            }
                                        )
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.DragHandle,
                                    contentDescription = "Drag to reorder",
                                    tint = if (isDragging) palette.fg else palette.textSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "${index + 1}.",
                                        color = palette.textSecondary,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = entry.title,
                                        color = if (entry.isAvailable) palette.textPrimary else palette.textSecondary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Spacer(Modifier.height(3.dp))

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(5.dp))
                                            .background(if (isMovieLink) palette.boxBg else palette.cardBg)
                                            .border(
                                                1.dp,
                                                if (isMovieLink) palette.boxBorder.copy(alpha = 0.6f) else palette.fg.copy(alpha = 0.5f),
                                                RoundedCornerShape(5.dp)
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = providerLabel,
                                            color = if (isMovieLink) palette.textPrimary else palette.fg,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }

                                    if (!entry.addonCatalogType.isNullOrBlank()) {
                                        Text(
                                            text = entry.addonCatalogType,
                                            color = palette.textSecondary,
                                            fontSize = 10.sp
                                        )
                                    }

                                    if (!entry.isAvailable && !entry.availabilityNote.isNullOrBlank()) {
                                        Text(
                                            text = entry.availabilityNote,
                                            color = Color(0xFFFBBF24),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }

                            // Compact up/down arrows for accessible one-tap reordering
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Rounded.KeyboardArrowUp,
                                    contentDescription = "Move up",
                                    tint = if (index > 0) palette.textSecondary else palette.textSecondary.copy(alpha = 0.25f),
                                    modifier = Modifier
                                        .size(20.dp)
                                        .clickable(enabled = index > 0) {
                                            onMoveCatalog(index, index - 1)
                                        }
                                )
                                Icon(
                                    imageVector = Icons.Rounded.KeyboardArrowDown,
                                    contentDescription = "Move down",
                                    tint = if (index < entries.lastIndex) palette.textSecondary else palette.textSecondary.copy(alpha = 0.25f),
                                    modifier = Modifier
                                        .size(20.dp)
                                        .clickable(enabled = index < entries.lastIndex) {
                                            onMoveCatalog(index, index + 1)
                                        }
                                )
                            }

                            if (!entry.isAvailable && entry.provider == ContentProviderKind.STREMIO_ADDON) {
                                IconButton(
                                    onClick = { onRemoveEntry(entry.key) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Delete,
                                        contentDescription = "Remove unavailable entry",
                                        tint = Color(0xFFF87171),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }

                            Switch(
                                checked = entry.enabled,
                                onCheckedChange = { checked -> onToggleCatalog(entry.key, checked) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = palette.onAccent,
                                    checkedTrackColor = palette.fg
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
