package com.personal.movielink.ui.dialogs

import android.annotation.SuppressLint
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.ByteArrayInputStream
import java.net.URLEncoder
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.OpenInBrowser
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.graphics.ColorUtils
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.personal.movielink.AppSettingsStore
import com.personal.movielink.Config
import com.personal.movielink.DownloadAndPlayerRouter
import com.personal.movielink.HeroSourceOption
import com.personal.movielink.HistoryItem
import com.personal.movielink.MyListItem
import com.personal.movielink.UnifiedHomeCatalogEntry
import com.personal.movielink.UserSettings
import com.personal.movielink.ui.components.ColorWheelDialog
import com.personal.movielink.ui.theme.LocalMovieLinkPalette
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.roundToInt

private enum class SettingsCategory(
    val tabLabel: String,
    val title: String,
    val subtitle: String,
    val keywords: String
) {
    HERO(
        tabLabel = "Hero",
        title = "Hero",
        subtitle = "Customize Home carousel layout, banner scale, auto-rotation, and hero sources.",
        keywords = "hero carousel coverflow spotlight banner size rotation sources categories movielinkbd"
    ),
    APPEARANCE(
        tabLabel = "Appearance",
        title = "Appearance",
        subtitle = "Customize background colors, theme accent, detail boxes, and navigation bar.",
        keywords = "appearance background theme accent color wheel detail box opacity size normal floating nav bar navigation transparency width height icon spacing icons"
    ),
    HOME_SCREEN(
        tabLabel = "Home Screen",
        title = "Home Screen",
        subtitle = "Control Continue Watching, OTT shortcuts, startup page, and bottom tabs.",
        keywords = "home screen continue watching layout vertical horizontal ott section local media player resume startup"
    ),
    CATALOGUES(
        tabLabel = "Catalogues",
        title = "Catalogues",
        subtitle = "Enable, disable, and drag-reorder Home screen sections and categories.",
        keywords = "catalogues catalog order reorder sections categories movielinkbd home feed"
    ),
    PLAYER(
        tabLabel = "Player",
        title = "Player & Downloader",
        subtitle = "Configure stream playback, fullscreen controls, search, and downloader mode.",
        keywords = "player video link downloader hide bottom progress bar fullscreen brightness watch online details search local file"
    ),
    METADATA(
        tabLabel = "Metadata",
        title = "Metadata & Posters",
        subtitle = "Optional TMDB artwork, MDBList ratings, and Better Poster providers.",
        keywords = "metadata tmdb api key mdblist ratings rpdb better poster custom template"
    ),
    NETWORK_ADS(
        tabLabel = "Network & Ads",
        title = "Network & Ad-Blocker",
        subtitle = "Manage active mirror URL, English UI polish, user-agent, and domain blocklists.",
        keywords = "network mirror url ad blocker blocked allowed domains popup tracker english ui desktop user agent"
    )
}

@Composable
fun SettingsScreen(
    settings: UserSettings,
    unifiedHomeCatalogs: List<UnifiedHomeCatalogEntry>,
    heroSources: List<HeroSourceOption>,
    currentUrl: String,
    sessionBlockedCountFlow: StateFlow<Int>,
    onUpdateSettings: ((UserSettings) -> UserSettings) -> Unit,
    onReloadHome: (String) -> Unit,
    onOpenCurrentUrlInPlayer: (String) -> Unit,
    onPlayLocalVideo: () -> Unit,
    onSaveCustomDomains: (String, String) -> Unit,
    onToggleHomeCatalog: (String, Boolean) -> Unit,
    onMoveHomeCatalog: (Int, Int) -> Unit,
    onTestMetadataIntegration: suspend (
        kind: String,
        tmdbKey: String,
        mdbKey: String,
        bpProvider: Config.BetterPosterProvider,
        rpdbKey: String,
        customTemplate: String
    ) -> Result<String> = { _, _, _, _, _, _ -> Result.failure(UnsupportedOperationException()) },
    onBack: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val sessionBlockedCount by sessionBlockedCountFlow.collectAsStateWithLifecycle()

    var selectedCategory by remember { mutableStateOf(SettingsCategory.HERO) }
    var isSearching by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    var mirrorInput by remember(settings.mirrorUrl) { mutableStateOf(settings.mirrorUrl) }
    var showBgWheel by remember { mutableStateOf(false) }
    var showThemeWheel by remember { mutableStateOf(false) }
    var showNormalNavWheel by remember { mutableStateOf(false) }
    var showFloatingNavWheel by remember { mutableStateOf(false) }
    var showDetailBoxWheel by remember { mutableStateOf(false) }
    var showDomainsDialog by remember { mutableStateOf(false) }

    val pillActiveBg = if (!palette.isLightBg) Color(0xFFF4F4F5) else Color(0xFF18181B)
    val pillActiveFg = if (!palette.isLightBg) Color(0xFF0A0D12) else Color.White
    val groupCardBg = if (!palette.isLightBg) Color(0xFF12141A) else palette.cardBg
    val pageBackgroundBrush = remember(palette.pageBg, palette.isLightBg) {
        if (!palette.isLightBg) {
            Brush.verticalGradient(
                0f to Color(0xFF141B2D).copy(alpha = 0.72f),
                0.28f to palette.pageBg,
                1f to palette.pageBg
            )
        } else {
            Brush.verticalGradient(listOf(palette.pageBg, palette.pageBg))
        }
    }

    val cleanQuery = searchQuery.trim().lowercase()
    val matchingCategories = remember(cleanQuery) {
        if (cleanQuery.isEmpty()) {
            listOf(selectedCategory)
        } else {
            SettingsCategory.entries.filter { cat ->
                cat.tabLabel.lowercase().contains(cleanQuery) ||
                    cat.title.lowercase().contains(cleanQuery) ||
                    cat.subtitle.lowercase().contains(cleanQuery) ||
                    cat.keywords.contains(cleanQuery)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(pageBackgroundBrush)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Top Header Bar: "< Back" on left, Search icon on right
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable(onClick = onBack)
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.ChevronLeft,
                    contentDescription = "Back",
                    tint = palette.textPrimary,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = "Back",
                    color = palette.textPrimary,
                    fontSize = 15.5.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            IconButton(
                onClick = {
                    if (isSearching) {
                        searchQuery = ""
                        isSearching = false
                    } else {
                        isSearching = true
                    }
                }
            ) {
                Icon(
                    imageVector = if (isSearching) Icons.Rounded.Close else Icons.Rounded.Search,
                    contentDescription = if (isSearching) "Close search" else "Search settings",
                    tint = palette.textPrimary,
                    modifier = Modifier.size(23.dp)
                )
            }
        }

        if (isSearching) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                singleLine = true,
                placeholder = {
                    Text(
                        text = "Search Hero, Appearance, Player, Catalogues...",
                        color = palette.textSecondary,
                        fontSize = 13.5.sp
                    )
                },
                leadingIcon = {
                    Icon(Icons.Rounded.Search, contentDescription = null, tint = palette.fg)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Clear", tint = palette.textSecondary)
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = groupCardBg,
                    unfocusedContainerColor = groupCardBg,
                    focusedBorderColor = palette.fg,
                    unfocusedBorderColor = palette.border.copy(alpha = 0.35f),
                    focusedTextColor = palette.textPrimary,
                    unfocusedTextColor = palette.textPrimary
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            )
            Spacer(Modifier.height(6.dp))
        }

        // Top side-by-side horizontally scrollable category bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SettingsCategory.entries.forEach { category ->
                val isSelected = cleanQuery.isEmpty() && selectedCategory == category
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(if (isSelected) pillActiveBg else Color.Transparent)
                        .clickable {
                            searchQuery = ""
                            isSearching = false
                            selectedCategory = category
                        }
                        .padding(
                            horizontal = if (isSelected) 18.dp else 12.dp,
                            vertical = 9.dp
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = category.tabLabel,
                        color = if (isSelected) pillActiveFg else palette.textSecondary,
                        fontSize = 14.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                        maxLines = 1
                    )
                }
            }
        }

        // Scrollable Settings Body
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            if (cleanQuery.isNotEmpty() && matchingCategories.isEmpty()) {
                SettingsGroupCard(cardBg = groupCardBg) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "No matching settings",
                            color = palette.textPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "Try searching for Hero, Theme, Floating bar, Continue Watching, Player, Mirror, or Metadata.",
                            color = palette.textSecondary,
                            fontSize = 13.sp,
                            lineHeight = 19.sp
                        )
                    }
                }
            } else {
                val categoriesToRender = if (cleanQuery.isEmpty()) {
                    listOf(selectedCategory)
                } else {
                    matchingCategories
                }

                categoriesToRender.forEach { cat ->
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = cat.title,
                                color = palette.textPrimary,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = cat.subtitle,
                                color = palette.textSecondary,
                                fontSize = 13.5.sp,
                                lineHeight = 19.sp
                            )
                        }

                        when (cat) {
                            SettingsCategory.HERO -> {
                                HeroSettingsSubpage(
                                    settings = settings,
                                    heroSources = heroSources,
                                    onUpdateSettings = onUpdateSettings
                                )
                            }

                            SettingsCategory.APPEARANCE -> {
                                // 1. Background Color
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        SettingsSubSectionTitle("Background Color")
                                        TextButton(onClick = { showBgWheel = true }) {
                                            Text(
                                                text = if (settings.bgPresetId == "custom") "Color Wheel (Custom)" else "Color Wheel",
                                                color = palette.fg,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.5.sp
                                            )
                                        }
                                    }
                                    SettingsGroupCard(cardBg = groupCardBg) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            val bgRows = Config.BgPreset.entries.chunked(4)
                                            bgRows.forEach { row ->
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    row.forEach { preset ->
                                                        val selected = settings.bgPresetId == preset.id
                                                        Box(
                                                            modifier = Modifier
                                                                .weight(1f)
                                                                .clip(RoundedCornerShape(10.dp))
                                                                .background(Color(android.graphics.Color.parseColor(preset.pageHex)))
                                                                .border(
                                                                    width = if (selected) 2.dp else 1.dp,
                                                                    color = if (selected) palette.fg else Color(0xFF3F3F46),
                                                                    shape = RoundedCornerShape(10.dp)
                                                                )
                                                                .clickable {
                                                                    onUpdateSettings { it.copy(bgPresetId = preset.id) }
                                                                }
                                                                .padding(vertical = 10.dp),
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            Text(
                                                                text = preset.label,
                                                                color = Color.White,
                                                                fontSize = 11.5.sp,
                                                                fontWeight = FontWeight.Bold
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                // 2. Theme Accent Color
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        SettingsSubSectionTitle("Theme Accent Color")
                                        TextButton(onClick = { showThemeWheel = true }) {
                                            Text(
                                                text = if (settings.themePresetId == "custom") "Color Wheel (Custom)" else "Color Wheel",
                                                color = palette.fg,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.5.sp
                                            )
                                        }
                                    }
                                    SettingsGroupCard(cardBg = groupCardBg) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            val themeRows = Config.ThemePreset.entries.chunked(3)
                                            themeRows.forEach { row ->
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    row.forEach { preset ->
                                                        val selected = settings.themePresetId == preset.id
                                                        val accentInt = android.graphics.Color.parseColor(preset.accentHex)
                                                        val borderInt = android.graphics.Color.parseColor(preset.borderHex)
                                                        val darkText = selected && ColorUtils.calculateLuminance(accentInt) > 0.42
                                                        Box(
                                                            modifier = Modifier
                                                                .weight(1f)
                                                                .clip(RoundedCornerShape(10.dp))
                                                                .background(if (selected) Color(accentInt) else palette.altBg)
                                                                .border(
                                                                    width = if (selected) 2.dp else 1.5.dp,
                                                                    color = if (preset == Config.ThemePreset.BLACK && selected) Color(0xFF71717A) else Color(borderInt),
                                                                    shape = RoundedCornerShape(10.dp)
                                                                )
                                                                .clickable {
                                                                    onUpdateSettings { it.copy(themePresetId = preset.id) }
                                                                }
                                                                .padding(vertical = 10.dp),
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            Text(
                                                                text = preset.label,
                                                                color = if (darkText) Color(0xFF0A0D12) else palette.textPrimary,
                                                                fontSize = 11.5.sp,
                                                                fontWeight = FontWeight.Bold
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                // 3. Navigation Bar (Normal & Floating)
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    SettingsSubSectionTitle("Navigation Bar")
                                    SettingsGroupCard(cardBg = groupCardBg) {
                                        val editingFloating = settings.floatingNavBar
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            Text(
                                                text = "Navigation Bar Style",
                                                color = palette.textPrimary,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                listOf(false to "Normal", true to "Floating").forEach { (isFloating, label) ->
                                                    val isSelected = editingFloating == isFloating
                                                    Box(
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .clip(RoundedCornerShape(10.dp))
                                                            .background(if (isSelected) palette.fg else palette.altBg)
                                                            .border(
                                                                width = 1.2.dp,
                                                                color = if (isSelected) palette.fg else palette.border.copy(alpha = 0.4f),
                                                                shape = RoundedCornerShape(10.dp)
                                                            )
                                                            .clickable {
                                                                onUpdateSettings { it.copy(floatingNavBar = isFloating) }
                                                            }
                                                            .padding(vertical = 10.dp),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Text(
                                                            text = label,
                                                            color = if (isSelected) palette.onAccent else palette.textPrimary,
                                                            fontSize = 12.5.sp,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                }
                                            }

                                            HorizontalDivider(color = palette.border.copy(alpha = 0.16f))

                                            val activeHeight = if (editingFloating) settings.floatingNavHeightDp else settings.normalNavHeightDp
                                            val activeWidth = if (editingFloating) settings.floatingNavWidthPercent else settings.normalNavWidthPercent
                                            val activeSpacing = if (editingFloating) settings.floatingNavSpacingDp else settings.normalNavSpacingDp
                                            val activeIconSpacing = if (editingFloating) settings.floatingNavIconSpacingDp else settings.normalNavIconSpacingDp
                                            val activeAlpha = if (editingFloating) settings.floatingNavAlphaPercent else settings.normalNavAlphaPercent
                                            val activeColorHex = if (editingFloating) settings.floatingNavColorHex else settings.normalNavColorHex

                                            FloatingSliderRow(
                                                label = "Bar Height",
                                                valueLabel = "$activeHeight dp",
                                                value = activeHeight.toFloat(),
                                                range = if (editingFloating) 44f..80f else 46f..80f,
                                                onValueChange = { v ->
                                                    val rounded = v.roundToInt()
                                                    onUpdateSettings {
                                                        if (editingFloating) it.copy(floatingNavHeightDp = rounded)
                                                        else it.copy(normalNavHeightDp = rounded)
                                                    }
                                                }
                                            )
                                            FloatingSliderRow(
                                                label = "Bar Width",
                                                valueLabel = "$activeWidth%",
                                                value = activeWidth.toFloat(),
                                                range = if (editingFloating) 62f..96f else 68f..100f,
                                                onValueChange = { v ->
                                                    val rounded = v.roundToInt()
                                                    onUpdateSettings {
                                                        if (editingFloating) it.copy(floatingNavWidthPercent = rounded)
                                                        else it.copy(normalNavWidthPercent = rounded)
                                                    }
                                                }
                                            )
                                            FloatingSliderRow(
                                                label = "Bottom Spacing",
                                                valueLabel = "$activeSpacing dp",
                                                value = activeSpacing.toFloat(),
                                                range = if (editingFloating) 4f..36f else 0f..36f,
                                                onValueChange = { v ->
                                                    val rounded = v.roundToInt()
                                                    onUpdateSettings {
                                                        if (editingFloating) it.copy(floatingNavSpacingDp = rounded)
                                                        else it.copy(normalNavSpacingDp = rounded)
                                                    }
                                                }
                                            )
                                            FloatingSliderRow(
                                                label = "Icons Spacing",
                                                valueLabel = "$activeIconSpacing dp",
                                                value = activeIconSpacing.toFloat(),
                                                range = 0f..28f,
                                                onValueChange = { v ->
                                                    val rounded = v.roundToInt()
                                                    onUpdateSettings {
                                                        if (editingFloating) it.copy(floatingNavIconSpacingDp = rounded)
                                                        else it.copy(normalNavIconSpacingDp = rounded)
                                                    }
                                                }
                                            )
                                            FloatingSliderRow(
                                                label = "Transparency (Opacity)",
                                                valueLabel = "$activeAlpha%",
                                                value = activeAlpha.toFloat(),
                                                range = 20f..100f,
                                                onValueChange = { v ->
                                                    val rounded = v.roundToInt()
                                                    onUpdateSettings {
                                                        if (editingFloating) it.copy(floatingNavAlphaPercent = rounded)
                                                        else it.copy(normalNavAlphaPercent = rounded)
                                                    }
                                                }
                                            )

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = if (editingFloating) "Floating Bar Color" else "Normal Bar Color",
                                                    color = palette.textPrimary,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                TextButton(
                                                    onClick = {
                                                        if (editingFloating) showFloatingNavWheel = true
                                                        else showNormalNavWheel = true
                                                    }
                                                ) {
                                                    Text(
                                                        text = if (activeColorHex != null) "Color Wheel ($activeColorHex)" else "Color Wheel",
                                                        color = palette.fg,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 12.sp
                                                    )
                                                }
                                            }
                                            val navSwatches = remember {
                                                listOf(
                                                    null to "Auto",
                                                    "#000000" to "Black",
                                                    "#141418" to "Dark",
                                                    "#0F172A" to "Navy",
                                                    "#1E1B4B" to "Indigo",
                                                    "#064E3B" to "Emerald",
                                                    "#FFFFFF" to "Light"
                                                )
                                            }
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                navSwatches.forEach { (hex, label) ->
                                                    val isSelected = activeColorHex.equals(hex, ignoreCase = true) ||
                                                        (hex == null && activeColorHex == null)
                                                    val swatchColor = if (hex == null) {
                                                        palette.pageBg
                                                    } else {
                                                        Color(android.graphics.Color.parseColor(hex))
                                                    }
                                                    Box(
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .height(30.dp)
                                                            .clip(RoundedCornerShape(8.dp))
                                                            .background(swatchColor)
                                                            .border(
                                                                width = if (isSelected) 2.dp else 1.dp,
                                                                color = if (isSelected) palette.fg else palette.border.copy(alpha = 0.55f),
                                                                shape = RoundedCornerShape(8.dp)
                                                            )
                                                            .clickable {
                                                                onUpdateSettings {
                                                                    if (editingFloating) it.copy(floatingNavColorHex = hex)
                                                                    else it.copy(normalNavColorHex = hex)
                                                                }
                                                            },
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        if (hex == null) {
                                                            Text(
                                                                text = label,
                                                                color = palette.textPrimary,
                                                                fontSize = 9.5.sp,
                                                                fontWeight = FontWeight.Bold
                                                            )
                                                        }
                                                    }
                                                }
                                            }

                                            HorizontalDivider(color = palette.border.copy(alpha = 0.16f))

                                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                                Text(
                                                    text = "Navigation Icons",
                                                    color = palette.textPrimary,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                Text(
                                                    text = "Choose which icons appear on both Normal and Floating bars",
                                                    color = palette.textSecondary,
                                                    fontSize = 11.5.sp
                                                )
                                                val enabledSet = settings.effectiveNavBarIcons()
                                                @OptIn(ExperimentalLayoutApi::class)
                                                FlowRow(
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Config.NavBarIcon.DEFAULT_ORDER.forEach { navIcon ->
                                                        val active = navIcon in enabledSet
                                                        Box(
                                                            modifier = Modifier
                                                                .clip(RoundedCornerShape(10.dp))
                                                                .background(if (active) palette.fg else palette.altBg)
                                                                .border(
                                                                    width = 1.dp,
                                                                    color = if (active) palette.fg else palette.border.copy(alpha = 0.4f),
                                                                    shape = RoundedCornerShape(10.dp)
                                                                )
                                                                .clickable {
                                                                    val next = enabledSet.toMutableSet()
                                                                    if (active) {
                                                                        if (next.size > 2) next.remove(navIcon)
                                                                    } else {
                                                                        next.add(navIcon)
                                                                    }
                                                                    onUpdateSettings { cur ->
                                                                        cur.copy(
                                                                            navBarIconIds = next.map { it.id }.toSet(),
                                                                            showLocalPlayerTab = Config.NavBarIcon.LOCAL in next
                                                                        )
                                                                    }
                                                                }
                                                                .padding(horizontal = 12.dp, vertical = 7.dp)
                                                        ) {
                                                            Text(
                                                                text = navIcon.label,
                                                                color = if (active) palette.onAccent else palette.textPrimary,
                                                                fontSize = 12.sp,
                                                                fontWeight = FontWeight.Bold
                                                            )
                                                        }
                                                    }
                                                }
                                            }

                                            OutlinedButton(
                                                onClick = {
                                                    onUpdateSettings {
                                                        if (editingFloating) {
                                                            it.copy(
                                                                floatingNavHeightDp = 56,
                                                                floatingNavWidthPercent = 90,
                                                                floatingNavSpacingDp = 14,
                                                                floatingNavIconSpacingDp = 8,
                                                                floatingNavAlphaPercent = 90,
                                                                floatingNavColorHex = null
                                                            )
                                                        } else {
                                                            it.copy(
                                                                normalNavHeightDp = 60,
                                                                normalNavWidthPercent = 92,
                                                                normalNavSpacingDp = 12,
                                                                normalNavIconSpacingDp = 8,
                                                                normalNavAlphaPercent = 96,
                                                                normalNavColorHex = null
                                                            )
                                                        }
                                                    }
                                                },
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Text(
                                                    text = if (editingFloating) "Reset Floating Bar Defaults" else "Reset Normal Bar Defaults",
                                                    color = palette.textPrimary,
                                                    fontSize = 12.sp
                                                )
                                            }
                                        }
                                    }
                                }

                                // 4. Movie / Series Screen Boxes
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    SettingsSubSectionTitle("Movie / Series Screen Boxes")
                                    SettingsGroupCard(cardBg = groupCardBg) {
                                        SettingsToggleRow(
                                            title = "Show info & action boxes",
                                            subtitle = "When off, hides Type/Language/Quality/Trailer/My List boxes while keeping layout alignment",
                                            checked = settings.detailBoxEnabled,
                                            onCheckedChange = { v -> onUpdateSettings { it.copy(detailBoxEnabled = v) } }
                                        )
                                        if (settings.detailBoxEnabled) {
                                            HorizontalDivider(color = palette.border.copy(alpha = 0.16f))
                                            Column(
                                                modifier = Modifier.padding(14.dp),
                                                verticalArrangement = Arrangement.spacedBy(10.dp)
                                            ) {
                                                Text(
                                                    text = "Box Style",
                                                    color = palette.textPrimary,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Config.DetailBoxStyle.entries.forEach { style ->
                                                        val isSelected = settings.detailBoxStyle == style
                                                        val chipShape = when (style) {
                                                            Config.DetailBoxStyle.SQUARE -> RoundedCornerShape(0.dp)
                                                            Config.DetailBoxStyle.CIRCLE -> RoundedCornerShape(50)
                                                            Config.DetailBoxStyle.ROUNDED -> RoundedCornerShape(10.dp)
                                                        }
                                                        Box(
                                                            modifier = Modifier
                                                                .weight(1f)
                                                                .clip(chipShape)
                                                                .background(if (isSelected) palette.fg else palette.altBg)
                                                                .border(
                                                                    width = 1.2.dp,
                                                                    color = if (isSelected) palette.fg else palette.border.copy(alpha = 0.45f),
                                                                    shape = chipShape
                                                                )
                                                                .clickable {
                                                                    onUpdateSettings { it.copy(detailBoxStyle = style) }
                                                                }
                                                                .padding(vertical = 9.dp),
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            Text(
                                                                text = style.label,
                                                                color = if (isSelected) palette.onAccent else palette.textPrimary,
                                                                fontSize = 11.5.sp,
                                                                fontWeight = FontWeight.Bold
                                                            )
                                                        }
                                                    }
                                                }
                                                FloatingSliderRow(
                                                    label = "Box Opacity",
                                                    valueLabel = "${settings.detailBoxOpacityPercent}%",
                                                    value = settings.detailBoxOpacityPercent.toFloat(),
                                                    range = 0f..100f,
                                                    onValueChange = { v ->
                                                        onUpdateSettings { it.copy(detailBoxOpacityPercent = v.roundToInt()) }
                                                    }
                                                )
                                                FloatingSliderRow(
                                                    label = "Box Size",
                                                    valueLabel = "${settings.detailBoxSizePercent}%",
                                                    value = settings.detailBoxSizePercent.toFloat(),
                                                    range = 75f..130f,
                                                    onValueChange = { v ->
                                                        onUpdateSettings { it.copy(detailBoxSizePercent = v.roundToInt()) }
                                                    }
                                                )
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = "Box Color (${settings.detailBoxColorHex})",
                                                        color = palette.textPrimary,
                                                        fontSize = 13.sp,
                                                        fontWeight = FontWeight.SemiBold
                                                    )
                                                    TextButton(onClick = { showDetailBoxWheel = true }) {
                                                        Text(
                                                            text = "Color Wheel",
                                                            color = palette.fg,
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 12.sp
                                                        )
                                                    }
                                                }
                                                val boxSwatches = remember {
                                                    listOf(
                                                        "#000000" to "Black",
                                                        "#71717A" to "Grey",
                                                        "#E4E4E7" to "White",
                                                        "#22D3EE" to "Cyan",
                                                        "#3B82F6" to "Blue",
                                                        "#22C55E" to "Green",
                                                        "#EF4444" to "Red",
                                                        "#A855F7" to "Purple",
                                                        "#F59E0B" to "Amber"
                                                    )
                                                }
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                                                ) {
                                                    boxSwatches.forEach { (hex, _) ->
                                                        val isSelected = settings.detailBoxColorHex.equals(hex, ignoreCase = true)
                                                        val isBlackSwatch = hex == "#000000"
                                                        Box(
                                                            modifier = Modifier
                                                                .weight(1f)
                                                                .height(28.dp)
                                                                .clip(RoundedCornerShape(8.dp))
                                                                .background(Color(android.graphics.Color.parseColor(hex)))
                                                                .border(
                                                                    width = if (isSelected) 2.dp else 1.dp,
                                                                    color = when {
                                                                        isSelected -> palette.textPrimary
                                                                        isBlackSwatch -> Color(0xFF3F3F46)
                                                                        else -> Color.Transparent
                                                                    },
                                                                    shape = RoundedCornerShape(8.dp)
                                                                )
                                                                .clickable {
                                                                    onUpdateSettings { it.copy(detailBoxColorHex = hex) }
                                                                }
                                                        )
                                                    }
                                                }
                                                OutlinedButton(
                                                    onClick = {
                                                        onUpdateSettings {
                                                            it.copy(
                                                                detailBoxEnabled = true,
                                                                detailBoxStyle = Config.DetailBoxStyle.ROUNDED,
                                                                detailBoxOpacityPercent = 85,
                                                                detailBoxSizePercent = 100,
                                                                detailBoxColorHex = "#71717A"
                                                            )
                                                        }
                                                    },
                                                    shape = RoundedCornerShape(10.dp),
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Text("Reset Boxes Defaults", color = palette.textPrimary, fontSize = 12.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            SettingsCategory.HOME_SCREEN -> {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    SettingsSubSectionTitle("Home Feed Sections")
                                    SettingsGroupCard(cardBg = groupCardBg) {
                                        SettingsToggleRow(
                                            title = "Show Continue Watching section",
                                            subtitle = "Displays recent unfinished playback items at the top of Home",
                                            checked = settings.showContinueWatching,
                                            onCheckedChange = { v -> onUpdateSettings { it.copy(showContinueWatching = v) } }
                                        )
                                        if (settings.showContinueWatching) {
                                            HorizontalDivider(color = palette.border.copy(alpha = 0.16f))
                                            Column(
                                                modifier = Modifier.padding(14.dp),
                                                verticalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Text(
                                                    text = "Continue Watching Layout",
                                                    color = palette.textPrimary,
                                                    fontSize = 13.5.sp,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                Text(
                                                    text = "Switch between portrait poster cards and wide horizontal cards",
                                                    color = palette.textSecondary,
                                                    fontSize = 11.5.sp
                                                )
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Config.ContinueWatchingLayout.entries.forEach { layoutMode ->
                                                        val isSelected = settings.continueWatchingLayout == layoutMode
                                                        Box(
                                                            modifier = Modifier
                                                                .weight(1f)
                                                                .clip(RoundedCornerShape(10.dp))
                                                                .background(if (isSelected) palette.fg else palette.altBg)
                                                                .border(
                                                                    1.dp,
                                                                    if (isSelected) palette.fg else palette.border.copy(alpha = 0.35f),
                                                                    RoundedCornerShape(10.dp)
                                                                )
                                                                .clickable {
                                                                    onUpdateSettings { it.copy(continueWatchingLayout = layoutMode) }
                                                                }
                                                                .padding(vertical = 9.dp),
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            Text(
                                                                text = layoutMode.label,
                                                                color = if (isSelected) palette.onAccent else palette.textPrimary,
                                                                fontSize = 12.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                maxLines = 1,
                                                                overflow = TextOverflow.Ellipsis
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        HorizontalDivider(color = palette.border.copy(alpha = 0.16f))
                                        SettingsToggleRow(
                                            title = "Show Watch by OTT section",
                                            subtitle = "Displays OTT platform shortcuts below Continue Watching on Home",
                                            checked = settings.showOttSection,
                                            onCheckedChange = { v -> onUpdateSettings { it.copy(showOttSection = v) } }
                                        )
                                        HorizontalDivider(color = palette.border.copy(alpha = 0.16f))
                                        SettingsToggleRow(
                                            title = "Show local media player tab in bottom bar",
                                            subtitle = "Adds a local video file picker shortcut tab to the navigation bar",
                                            checked = settings.showLocalPlayerTab,
                                            onCheckedChange = { v ->
                                                onUpdateSettings { cur ->
                                                    val nextIds = if (v) {
                                                        cur.navBarIconIds + Config.NavBarIcon.LOCAL.id
                                                    } else {
                                                        cur.navBarIconIds - Config.NavBarIcon.LOCAL.id
                                                    }
                                                    cur.copy(showLocalPlayerTab = v, navBarIconIds = nextIds)
                                                }
                                            }
                                        )
                                    }
                                }

                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    SettingsSubSectionTitle("Startup Behavior")
                                    SettingsGroupCard(cardBg = groupCardBg) {
                                        SettingsToggleRow(
                                            title = "Resume last visited page on startup",
                                            subtitle = "Reopens the last movie, series, or page when launching the app",
                                            checked = settings.resumeLastPage,
                                            onCheckedChange = { v -> onUpdateSettings { it.copy(resumeLastPage = v) } }
                                        )
                                    }
                                }
                            }

                            SettingsCategory.CATALOGUES -> {
                                HomeCatalogManagerSubpage(
                                    entries = unifiedHomeCatalogs,
                                    onToggleCatalog = onToggleHomeCatalog,
                                    onMoveCatalog = onMoveHomeCatalog
                                )
                            }

                            SettingsCategory.PLAYER -> {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    SettingsSubSectionTitle("Playback & Link Routing")
                                    SettingsGroupCard(cardBg = groupCardBg) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Text("Downloader Mode", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = palette.textSecondary)
                                            Config.DownloaderMode.entries.forEach { mode ->
                                                RadioChoiceRow(
                                                    label = mode.label,
                                                    selected = settings.downloaderMode == mode,
                                                    onClick = { onUpdateSettings { it.copy(downloaderMode = mode) } }
                                                )
                                            }
                                            Spacer(Modifier.height(4.dp))
                                            Text("Video Link Behavior", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = palette.textSecondary)
                                            Config.VideoActionMode.entries.forEach { mode ->
                                                RadioChoiceRow(
                                                    label = mode.label,
                                                    selected = settings.videoActionMode == mode,
                                                    onClick = { onUpdateSettings { it.copy(videoActionMode = mode) } }
                                                )
                                            }
                                        }
                                    }
                                }

                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    SettingsSubSectionTitle("Video Controls & Quick Actions")
                                    SettingsGroupCard(cardBg = groupCardBg) {
                                        SettingsToggleRow(
                                            title = "Hide bottom progress bar in fullscreen",
                                            subtitle = "Removes persistent bottom seek bar in fullscreen landscape",
                                            checked = settings.hideVideoProgressBar,
                                            onCheckedChange = { v -> onUpdateSettings { it.copy(hideVideoProgressBar = v) } }
                                        )
                                        HorizontalDivider(color = palette.border.copy(alpha = 0.16f))
                                        SettingsToggleRow(
                                            title = "Left-edge brightness controls screen",
                                            subtitle = "Smoothly adjusts window brightness in fullscreen only (volume untouched)",
                                            checked = settings.playerBrightnessSync,
                                            onCheckedChange = { v -> onUpdateSettings { it.copy(playerBrightnessSync = v) } }
                                        )
                                        HorizontalDivider(color = palette.border.copy(alpha = 0.16f))
                                        SettingsToggleRow(
                                            title = "Show Watch Online button on details",
                                            subtitle = "Displays embedded player launch button on MovieLinkBD details",
                                            checked = settings.movieLinkWatchOnlineEnabled,
                                            onCheckedChange = { v -> onUpdateSettings { it.copy(movieLinkWatchOnlineEnabled = v) } }
                                        )
                                        HorizontalDivider(color = palette.border.copy(alpha = 0.16f))
                                        SettingsToggleRow(
                                            title = "Enable MovieLinkBD search",
                                            subtitle = "Queries the active MovieLinkBD mirror when using the Search tab",
                                            checked = settings.movieLinkSearchEnabled,
                                            onCheckedChange = { v -> onUpdateSettings { it.copy(movieLinkSearchEnabled = v) } }
                                        )
                                        HorizontalDivider(color = palette.border.copy(alpha = 0.16f))
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            OutlinedButton(
                                                onClick = {
                                                    onBack()
                                                    onOpenCurrentUrlInPlayer(currentUrl)
                                                },
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Text("Open current URL in video player", color = palette.fg, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                                            }
                                            OutlinedButton(
                                                onClick = {
                                                    onBack()
                                                    onPlayLocalVideo()
                                                },
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Text("Play Local Video File (MP4 / MKV / HLS)", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                                            }
                                        }
                                    }
                                }
                            }

                            SettingsCategory.METADATA -> {
                                MetadataIntegrationsSubpage(
                                    settings = settings,
                                    onUpdateSettings = onUpdateSettings,
                                    onTestMetadataIntegration = onTestMetadataIntegration
                                )
                            }

                            SettingsCategory.NETWORK_ADS -> {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    SettingsSubSectionTitle("Active Mirror")
                                    SettingsGroupCard(cardBg = groupCardBg) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            OutlinedTextField(
                                                value = mirrorInput,
                                                onValueChange = { mirrorInput = it },
                                                singleLine = true,
                                                label = { Text("Active Mirror URL", fontSize = 12.sp) },
                                                colors = OutlinedTextFieldDefaults.colors(
                                                    focusedBorderColor = palette.fg,
                                                    unfocusedBorderColor = palette.border.copy(alpha = 0.5f),
                                                    focusedTextColor = palette.textPrimary,
                                                    unfocusedTextColor = palette.textPrimary
                                                ),
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            )
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                Button(
                                                    onClick = {
                                                        val norm = Config.normalizeUrl(mirrorInput)
                                                        mirrorInput = norm
                                                        onUpdateSettings { it.copy(mirrorUrl = norm) }
                                                        onReloadHome(norm)
                                                        onBack()
                                                    },
                                                    colors = ButtonDefaults.buttonColors(
                                                        containerColor = palette.fg,
                                                        contentColor = palette.onAccent
                                                    ),
                                                    shape = RoundedCornerShape(10.dp),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Text("Save & Reload", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                                                }
                                                OutlinedButton(
                                                    onClick = {
                                                        mirrorInput = Config.DEFAULT_HOME_URL
                                                        onUpdateSettings { it.copy(mirrorUrl = Config.DEFAULT_HOME_URL) }
                                                        onReloadHome(Config.DEFAULT_HOME_URL)
                                                    },
                                                    shape = RoundedCornerShape(10.dp)
                                                ) {
                                                    Text("Reset to default", color = palette.textPrimary, fontSize = 12.5.sp)
                                                }
                                            }
                                        }
                                    }
                                }

                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    SettingsSubSectionTitle(
                                        if (settings.adBlockEnabled) {
                                            "Clean UI & Ad-Blocker ($sessionBlockedCount blocked)"
                                        } else {
                                            "Clean UI & Ad-Blocker (Paused)"
                                        }
                                    )
                                    SettingsGroupCard(cardBg = groupCardBg) {
                                        SettingsToggleRow(
                                            title = "English UI & clean movie boxes",
                                            subtitle = "Translates Bangla labels & numerals, aligns detail boxes, hides site clutter",
                                            checked = settings.sitePolishEnabled,
                                            onCheckedChange = { v -> onUpdateSettings { it.copy(sitePolishEnabled = v) } }
                                        )
                                        HorizontalDivider(color = palette.border.copy(alpha = 0.16f))
                                        SettingsToggleRow(
                                            title = "Ad, popup & tracker blocker",
                                            subtitle = "Blocks ad networks & popups across catalog, ExoPlayer, and WebView",
                                            checked = settings.adBlockEnabled,
                                            onCheckedChange = { v -> onUpdateSettings { it.copy(adBlockEnabled = v) } }
                                        )
                                        HorizontalDivider(color = palette.border.copy(alpha = 0.16f))
                                        SettingsToggleRow(
                                            title = "Desktop User-Agent",
                                            subtitle = "Uses desktop Chrome headers for catalog & fallback WebView",
                                            checked = settings.desktopMode,
                                            onCheckedChange = { v -> onUpdateSettings { it.copy(desktopMode = v) } }
                                        )
                                        HorizontalDivider(color = palette.border.copy(alpha = 0.16f))
                                        Box(modifier = Modifier.padding(14.dp)) {
                                            OutlinedButton(
                                                onClick = { showDomainsDialog = true },
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Text(
                                                    text = "Manage Blocked (${settings.customBlockedDomains.size}) & Allowed (${settings.customAllowedDomains.size}) Domains",
                                                    color = palette.textPrimary,
                                                    fontSize = 12.5.sp,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
        }
    }

    if (showBgWheel) {
        val currentBgHex = Config.resolveBg(settings.bgPresetId, settings.customBgHex).pageHex
        ColorWheelDialog(
            title = "Custom Background Color",
            initialHex = currentBgHex,
            minBrightness = 0.0f,
            onDismiss = { showBgWheel = false },
            onConfirm = { hex ->
                onUpdateSettings { it.copy(bgPresetId = "custom", customBgHex = hex) }
                showBgWheel = false
            }
        )
    }

    if (showThemeWheel) {
        val currentThemeHex = Config.resolveTheme(settings.themePresetId, settings.customThemeHex).accentHex
        ColorWheelDialog(
            title = "Custom Theme & Box Color",
            initialHex = currentThemeHex,
            minBrightness = 0.15f,
            onDismiss = { showThemeWheel = false },
            onConfirm = { hex ->
                onUpdateSettings { it.copy(themePresetId = "custom", customThemeHex = hex) }
                showThemeWheel = false
            }
        )
    }

    if (showNormalNavWheel) {
        val initialNormalHex = settings.normalNavColorHex
            ?: Config.resolveBg(settings.bgPresetId, settings.customBgHex).pageHex
        ColorWheelDialog(
            title = "Normal Bar Color",
            initialHex = initialNormalHex,
            minBrightness = 0.0f,
            onDismiss = { showNormalNavWheel = false },
            onConfirm = { hex ->
                onUpdateSettings { it.copy(normalNavColorHex = hex) }
                showNormalNavWheel = false
            }
        )
    }

    if (showFloatingNavWheel) {
        val initialNavHex = settings.floatingNavColorHex
            ?: Config.resolveBg(settings.bgPresetId, settings.customBgHex).pageHex
        ColorWheelDialog(
            title = "Floating Bar Color",
            initialHex = initialNavHex,
            minBrightness = 0.0f,
            onDismiss = { showFloatingNavWheel = false },
            onConfirm = { hex ->
                onUpdateSettings { it.copy(floatingNavColorHex = hex) }
                showFloatingNavWheel = false
            }
        )
    }

    if (showDetailBoxWheel) {
        ColorWheelDialog(
            title = "Detail Boxes Color",
            initialHex = settings.detailBoxColorHex,
            minBrightness = 0.05f,
            onDismiss = { showDetailBoxWheel = false },
            onConfirm = { hex ->
                onUpdateSettings { it.copy(detailBoxColorHex = hex) }
                showDetailBoxWheel = false
            }
        )
    }

    if (showDomainsDialog) {
        DomainRulesDialog(
            blockedDomains = settings.customBlockedDomains,
            allowedDomains = settings.customAllowedDomains,
            onDismiss = { showDomainsDialog = false },
            onSave = { blocked, allowed ->
                onSaveCustomDomains(blocked, allowed)
                showDomainsDialog = false
            }
        )
    }
}

@Composable
private fun SettingsGroupCard(
    cardBg: Color,
    content: @Composable ColumnScope.() -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(cardBg)
            .border(1.dp, palette.border.copy(alpha = 0.24f), RoundedCornerShape(16.dp)),
        content = content
    )
}

@Composable
private fun SettingsSubSectionTitle(title: String) {
    val palette = LocalMovieLinkPalette.current
    Text(
        text = title,
        color = palette.textPrimary,
        fontSize = 17.sp,
        fontWeight = FontWeight.Bold
    )
}

@Composable
private fun FloatingSliderRow(
    label: String,
    valueLabel: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = label, color = palette.textPrimary, fontSize = 12.5.sp, fontWeight = FontWeight.Medium)
            Text(text = valueLabel, color = palette.fg, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = palette.fg,
                activeTrackColor = palette.fg,
                inactiveTrackColor = palette.border.copy(alpha = 0.35f)
            )
        )
    }
}

@Composable
private fun SettingsToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(text = title, color = palette.textPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(2.dp))
            Text(text = subtitle, color = palette.textSecondary, fontSize = 12.sp, lineHeight = 16.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = palette.onAccent,
                checkedTrackColor = palette.fg
            )
        )
    }
}

@Composable
private fun RadioChoiceRow(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) palette.boxBg else palette.altBg)
            .border(
                width = 1.dp,
                color = if (selected) palette.boxBorder else Color.Transparent,
                shape = RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            color = palette.textPrimary,
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
        )
        if (selected) {
            Text("Active", color = palette.fg, fontSize = 11.5.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}

@Composable
fun DomainRulesDialog(
    blockedDomains: Set<String>,
    allowedDomains: Set<String>,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    var blockedRaw by remember { mutableStateOf(blockedDomains.sorted().joinToString("\n")) }
    var allowedRaw by remember { mutableStateOf(allowedDomains.sorted().joinToString("\n")) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.cardBg,
        titleContentColor = palette.textPrimary,
        title = { Text("Domain Rules", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Enter one domain per line (e.g. doubleclick.net).",
                    fontSize = 12.sp,
                    color = palette.textSecondary
                )
                OutlinedTextField(
                    value = blockedRaw,
                    onValueChange = { blockedRaw = it },
                    label = { Text("Custom Blocked Domains") },
                    minLines = 3,
                    maxLines = 5,
                    textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = palette.fg,
                        focusedTextColor = palette.textPrimary,
                        unfocusedTextColor = palette.textPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = allowedRaw,
                    onValueChange = { allowedRaw = it },
                    label = { Text("Allowed / Bypass Domains") },
                    minLines = 3,
                    maxLines = 5,
                    textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = palette.fg,
                        focusedTextColor = palette.textPrimary,
                        unfocusedTextColor = palette.textPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(blockedRaw, allowedRaw) }) {
                Text("Save", color = palette.fg, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = palette.textSecondary)
            }
        }
    )
}

@Composable
fun HistoryDialog(
    items: List<HistoryItem>,
    onSelect: (HistoryItem) -> Unit,
    onClear: () -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.cardBg,
        titleContentColor = palette.textPrimary,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Visit History (${items.size}/25)", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                if (items.isNotEmpty()) {
                    TextButton(onClick = onClear) {
                        Text("Clear", color = palette.fg, fontSize = 12.5.sp)
                    }
                }
            }
        },
        text = {
            if (items.isEmpty()) {
                Text("No recent visits yet.", color = palette.textSecondary, fontSize = 13.5.sp)
            } else {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 380.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(items, key = { it.url }) { item ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(palette.altBg)
                                .clickable {
                                    onSelect(item)
                                    onDismiss()
                                }
                                .padding(10.dp)
                        ) {
                            Text(
                                text = item.title,
                                color = palette.textPrimary,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${item.url.removePrefix("https://")} · ${AppSettingsStore.formatRelativeTime(item.timestamp)}",
                                color = palette.textSecondary,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = palette.fg, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun MyListDialog(
    items: List<MyListItem>,
    onSelect: (MyListItem) -> Unit,
    onRemove: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.cardBg,
        titleContentColor = palette.textPrimary,
        title = { Text("My List (${items.size})", fontWeight = FontWeight.Bold, fontSize = 17.sp) },
        text = {
            if (items.isEmpty()) {
                Text(
                    text = "Tap ＋ My List on any movie or series to save it here.",
                    color = palette.textSecondary,
                    fontSize = 13.5.sp
                )
            } else {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 380.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(items, key = { it.url }) { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(palette.altBg)
                                .clickable {
                                    onSelect(item)
                                    onDismiss()
                                }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.title,
                                    color = palette.textPrimary,
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${item.type} · ${item.language} · ${item.quality}",
                                    color = palette.textSecondary,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(onClick = { onRemove(item.url) }) {
                                Icon(
                                    Icons.Rounded.Delete,
                                    contentDescription = "Remove",
                                    tint = palette.textSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = palette.fg, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun TrailerDialog(
    youtubeId: String,
    title: String,
    embedOrigin: String = Config.DEFAULT_HOME_URL,
    onDismiss: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val context = LocalContext.current
    val cleanYoutubeId = remember(youtubeId) {
        val raw = youtubeId.trim()
        Regex("""(?:youtu\.be/|youtube\.com/(?:watch\?.*v=|embed/|shorts/|live/)|youtube-nocookie\.com/embed/)([A-Za-z0-9_-]{11})""")
            .find(raw)?.groupValues?.getOrNull(1)
            ?: raw.replace(Regex("""[^A-Za-z0-9_-]"""), "")
    }
    val cleanOrigin = remember(embedOrigin) {
        val parsed = runCatching { android.net.Uri.parse(embedOrigin.trim()) }.getOrNull()
        val scheme = parsed?.scheme?.takeIf { it == "https" || it == "http" } ?: "https"
        val host = parsed?.host?.takeIf { it.isNotBlank() } ?: "movielinkbd.tv"
        "$scheme://$host"
    }
    val wrapperUrl = remember(cleanOrigin, cleanYoutubeId) {
        "$cleanOrigin/__ml_trailer__/$cleanYoutubeId"
    }
    val encodedOrigin = remember(cleanOrigin) {
        URLEncoder.encode(cleanOrigin, "UTF-8")
    }
    val watchUrl = "https://www.youtube.com/watch?v=$cleanYoutubeId"
    val mobileWatchUrl = "https://m.youtube.com/watch?v=$cleanYoutubeId"
    val iframeHtml = remember(cleanYoutubeId, encodedOrigin) {
        val embedSrc = "https://www.youtube.com/embed/$cleanYoutubeId?autoplay=1&playsinline=1&rel=0&modestbranding=1&enablejsapi=1&origin=$encodedOrigin&widget_referrer=$encodedOrigin"
        """
            <!DOCTYPE html>
            <html>
              <head>
                <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
                <meta name="referrer" content="strict-origin-when-cross-origin">
                <style>
                  html, body {
                    margin: 0;
                    padding: 0;
                    width: 100%;
                    height: 100%;
                    background: #000;
                    overflow: hidden;
                  }
                  iframe {
                    border: 0;
                    width: 100%;
                    height: 100%;
                    display: block;
                  }
                </style>
              </head>
              <body>
                <iframe
                  id="ytframe"
                  src="$embedSrc"
                  referrerpolicy="strict-origin-when-cross-origin"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen"
                  allowfullscreen>
                </iframe>
                <script>
                  (function() {
                    var notified = false;
                    var frame = document.getElementById('ytframe');
                    function notifyListening() {
                      try {
                        if (frame && frame.contentWindow) {
                          frame.contentWindow.postMessage(JSON.stringify({event:'listening',id:1}), '*');
                        }
                      } catch (e) {}
                    }
                    if (frame) {
                      frame.addEventListener('load', function() {
                        notifyListening();
                        setTimeout(notifyListening, 500);
                        setTimeout(notifyListening, 1500);
                      });
                    }
                    window.addEventListener('message', function(e) {
                      try {
                        if (typeof e.data !== 'string') return;
                        var payload = JSON.parse(e.data);
                        if (payload && payload.event === 'onError' && !notified) {
                          notified = true;
                          if (window.AndroidTrailerBridge && window.AndroidTrailerBridge.onEmbedError) {
                            window.AndroidTrailerBridge.onEmbedError(Number(payload.info || 152));
                          }
                        }
                      } catch (err) {}
                    });
                  })();
                </script>
              </body>
            </html>
        """.trimIndent()
    }
    var webRef by remember { mutableStateOf<WebView?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.Black)
                .border(1.5.dp, palette.boxBorder, RoundedCornerShape(16.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(palette.cardBg)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Trailer — $title",
                    color = palette.textPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = {
                    DownloadAndPlayerRouter.openExternal(context, watchUrl)
                }) {
                    Icon(Icons.Rounded.OpenInBrowser, contentDescription = "Open in YouTube", tint = palette.fg)
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close", tint = palette.textPrimary)
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            setBackgroundColor(android.graphics.Color.BLACK)
                            CookieManager.getInstance().setAcceptCookie(true)
                            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                mediaPlaybackRequiresUserGesture = false
                                useWideViewPort = true
                                loadWithOverviewMode = true
                                allowContentAccess = true
                                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                            }
                            var fallbackWatchMode = false
                            addJavascriptInterface(
                                object {
                                    @JavascriptInterface
                                    fun onEmbedError(@Suppress("UNUSED_PARAMETER") code: Int) {
                                        post {
                                            if (!fallbackWatchMode) {
                                                fallbackWatchMode = true
                                                loadUrl(mobileWatchUrl)
                                            }
                                        }
                                    }
                                },
                                "AndroidTrailerBridge"
                            )
                            webViewClient = object : WebViewClient() {
                                override fun shouldInterceptRequest(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): WebResourceResponse? {
                                    if (request?.url?.toString() == wrapperUrl) {
                                        return WebResourceResponse(
                                            "text/html",
                                            "UTF-8",
                                            200,
                                            "OK",
                                            mapOf(
                                                "Cache-Control" to "no-store",
                                                "Referrer-Policy" to "strict-origin-when-cross-origin"
                                            ),
                                            ByteArrayInputStream(iframeHtml.toByteArray(Charsets.UTF_8))
                                        )
                                    }
                                    return super.shouldInterceptRequest(view, request)
                                }

                                override fun shouldOverrideUrlLoading(
                                    view: WebView,
                                    request: WebResourceRequest
                                ): Boolean {
                                    val url = request.url.toString()
                                    val host = request.url.host.orEmpty().lowercase()
                                    if (url == wrapperUrl || !request.isForMainFrame) {
                                        return false
                                    }
                                    if (host.contains("youtube.com") || host.contains("youtube-nocookie.com") || host.contains("youtu.be") || host.contains("googlevideo.com") || host.contains("google.com")) {
                                        if (!fallbackWatchMode && request.hasGesture() && url.contains("/watch") && !url.contains("/embed/")) {
                                            DownloadAndPlayerRouter.openExternal(context, url)
                                            return true
                                        }
                                        return false
                                    }
                                    DownloadAndPlayerRouter.openExternal(context, url)
                                    return true
                                }
                            }
                            webChromeClient = WebChromeClient()
                            loadUrl(wrapperUrl)
                            webRef = this
                        }
                    }
                )
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            webRef?.removeJavascriptInterface("AndroidTrailerBridge")
            webRef?.stopLoading()
            webRef?.destroy()
            webRef = null
        }
    }
}
