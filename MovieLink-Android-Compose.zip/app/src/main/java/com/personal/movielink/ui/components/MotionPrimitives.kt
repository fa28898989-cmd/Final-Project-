package com.personal.movielink.ui.components

import android.app.Activity
import android.content.Context
import android.database.ContentObserver
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Display
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.personal.movielink.Config
import com.personal.movielink.ui.theme.LocalMovieLinkPalette
import kotlin.math.abs
import kotlin.math.roundToInt

val LocalReduceMotion = staticCompositionLocalOf { false }

private fun readReduceMotionEnabled(context: Context): Boolean {
    return try {
        val cr = context.contentResolver
        val animScale = Settings.Global.getFloat(cr, Settings.Global.ANIMATOR_DURATION_SCALE, 1f)
        val transScale = Settings.Global.getFloat(cr, Settings.Global.WINDOW_ANIMATION_SCALE, 1f)
        animScale == 0f || transScale == 0f
    } catch (_: Throwable) {
        false
    }
}

@Composable
fun rememberReduceMotionEnabled(): Boolean {
    val context = LocalContext.current
    var reduceMotion by remember(context) { mutableStateOf(readReduceMotionEnabled(context)) }

    DisposableEffect(context) {
        val handler = Handler(Looper.getMainLooper())
        val observer = object : ContentObserver(handler) {
            override fun onChange(selfChange: Boolean) {
                reduceMotion = readReduceMotionEnabled(context)
            }
        }
        val cr = context.contentResolver
        runCatching {
            cr.registerContentObserver(
                Settings.Global.getUriFor(Settings.Global.ANIMATOR_DURATION_SCALE),
                false,
                observer
            )
            cr.registerContentObserver(
                Settings.Global.getUriFor(Settings.Global.WINDOW_ANIMATION_SCALE),
                false,
                observer
            )
        }
        onDispose {
            runCatching { cr.unregisterContentObserver(observer) }
        }
    }
    return reduceMotion
}

private fun currentActivityDisplay(activity: Activity): Display? {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        activity.display
    } else {
        @Suppress("DEPRECATION")
        activity.windowManager?.defaultDisplay
    }
}

fun applyPreferredRefreshRate(activity: Activity?, mode: Config.RefreshRateMode) {
    val window = activity?.window ?: return
    val targetHz = mode.targetHz
    val targetModeId = if (targetHz == null) {
        0
    } else {
        val display = currentActivityDisplay(activity)
        val activeMode = display?.mode
        val supported = display?.supportedModes?.toList().orEmpty()
        val sameResModes = if (activeMode != null) {
            supported.filter {
                it.physicalWidth == activeMode.physicalWidth &&
                    it.physicalHeight == activeMode.physicalHeight
            }.ifEmpty { supported }
        } else {
            supported
        }
        sameResModes.minByOrNull { abs(it.refreshRate - targetHz) }?.modeId ?: 0
    }

    val lp = window.attributes
    @Suppress("DEPRECATION")
    val legacyRateDiffers = lp.preferredRefreshRate != 0f
    if (lp.preferredDisplayModeId != targetModeId || legacyRateDiffers) {
        lp.preferredDisplayModeId = targetModeId
        @Suppress("DEPRECATION")
        lp.preferredRefreshRate = 0f
        window.attributes = lp
    }
}

@Composable
fun rememberSupportedRefreshRates(): List<Int> {
    val context = LocalContext.current
    val activity = context as? Activity
    fun readRates(): List<Int> {
        val display = if (activity != null) {
            currentActivityDisplay(activity)
        } else {
            val dm = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
            dm?.getDisplay(Display.DEFAULT_DISPLAY)
        }
        val active = display?.mode
        val modes = display?.supportedModes?.toList().orEmpty()
        val sameRes = if (active != null) {
            modes.filter {
                it.physicalWidth == active.physicalWidth && it.physicalHeight == active.physicalHeight
            }.ifEmpty { modes }
        } else {
            modes
        }
        return sameRes
            .map { it.refreshRate.roundToInt() }
            .filter { it > 0 }
            .distinct()
            .sorted()
    }

    var rates by remember(context) { mutableStateOf(readRates()) }
    DisposableEffect(context) {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
        val listener = object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(displayId: Int) {
                rates = readRates()
            }
            override fun onDisplayRemoved(displayId: Int) {
                rates = readRates()
            }
            override fun onDisplayChanged(displayId: Int) {
                rates = readRates()
            }
        }
        dm?.registerDisplayListener(listener, Handler(Looper.getMainLooper()))
        onDispose {
            dm?.unregisterDisplayListener(listener)
        }
    }
    return rates
}

@Composable
fun DisplayRefreshRateEffect(mode: Config.RefreshRateMode) {
    val context = LocalContext.current
    val activity = context as? Activity
    val lifecycleOwner = LocalLifecycleOwner.current

    LaunchedEffect(activity, mode) {
        applyPreferredRefreshRate(activity, mode)
    }

    DisposableEffect(activity, lifecycleOwner, mode) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                applyPreferredRefreshRate(activity, mode)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }
}

fun Modifier.pressScale(
    interactionSource: MutableInteractionSource,
    pressedScale: Float = 0.96f,
    enabled: Boolean = true
): Modifier = composed {
    if (!enabled || LocalReduceMotion.current) return@composed this
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) pressedScale else 1f,
        animationSpec = spring(dampingRatio = 0.8f, stiffness = 620f),
        label = "press_scale"
    )
    this.graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}

@Composable
fun SkeletonBox(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(10.dp)
) {
    val palette = LocalMovieLinkPalette.current
    val reduceMotion = LocalReduceMotion.current

    if (reduceMotion) {
        Box(
            modifier = modifier
                .clip(shape)
                .background(palette.altBg)
        )
        return
    }

    val transition = rememberInfiniteTransition(label = "skeleton_pulse")
    val progress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1050, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "skeleton_alpha"
    )
    val baseColor = palette.altBg
    val highlightColor = palette.cardBg.copy(alpha = 0.9f)
    val animatedColor = androidx.compose.ui.graphics.lerp(baseColor, highlightColor, progress * 0.72f)

    Box(
        modifier = modifier
            .clip(shape)
            .background(animatedColor)
    )
}

@Composable
fun PosterRailSkeletonRow(
    cardCount: Int = 5,
    cardWidth: Dp = 118.dp,
    modifier: Modifier = Modifier
) {
    LazyRow(
        modifier = modifier.fillMaxWidth(),
        userScrollEnabled = false,
        contentPadding = PaddingValues(horizontal = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(cardCount) {
            Column(
                modifier = Modifier.width(cardWidth),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                SkeletonBox(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(2f / 2.8f),
                    shape = RoundedCornerShape(10.dp)
                )
                SkeletonBox(
                    modifier = Modifier
                        .fillMaxWidth(0.84f)
                        .height(11.dp),
                    shape = RoundedCornerShape(4.dp)
                )
                SkeletonBox(
                    modifier = Modifier
                        .fillMaxWidth(0.55f)
                        .height(10.dp),
                    shape = RoundedCornerShape(4.dp)
                )
            }
        }
    }
}

@Composable
fun CatalogLoadingSkeleton(
    heroLayoutStyle: Config.HeroLayoutStyle,
    heroSizePercent: Int,
    bottomPadding: Dp
) {
    val statusTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val heroScale = heroSizePercent.coerceIn(75, 130) / 100f

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(
                top = if (heroLayoutStyle == Config.HeroLayoutStyle.SPOTLIGHT) 0.dp else statusTop + 10.dp,
                bottom = bottomPadding
            ),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        if (heroLayoutStyle == Config.HeroLayoutStyle.SPOTLIGHT) {
            SkeletonBox(
                modifier = Modifier
                    .fillMaxWidth()
                    .height((360f * heroScale).dp.coerceIn(260.dp, 500.dp)),
                shape = RoundedCornerShape(0.dp)
            )
        } else {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SkeletonBox(
                    modifier = Modifier
                        .width((196f * heroScale).dp.coerceIn(144.dp, 260.dp))
                        .aspectRatio(0.68f),
                    shape = RoundedCornerShape(16.dp)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SkeletonBox(modifier = Modifier.width(22.dp).height(6.dp), shape = CircleShape)
                    repeat(3) {
                        SkeletonBox(modifier = Modifier.width(6.dp).height(6.dp), shape = CircleShape)
                    }
                }
            }
        }

        repeat(2) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SkeletonBox(
                    modifier = Modifier
                        .padding(horizontal = 14.dp)
                        .width(142.dp)
                        .height(18.dp),
                    shape = RoundedCornerShape(6.dp)
                )
                PosterRailSkeletonRow()
            }
        }
    }
}

@Composable
fun SearchLoadingSkeletonGrid(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        repeat(3) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                repeat(2) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        SkeletonBox(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(2f / 2.8f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        SkeletonBox(
                            modifier = Modifier
                                .fillMaxWidth(0.82f)
                                .height(13.dp),
                            shape = RoundedCornerShape(4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DetailLoadingSkeleton(
    heroHeight: Dp
) {
    val palette = LocalMovieLinkPalette.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.pageBg),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(heroHeight)
        ) {
            SkeletonBox(
                modifier = Modifier.fillMaxSize(),
                shape = RoundedCornerShape(0.dp)
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(140.dp)
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                palette.pageBg.copy(alpha = 0f),
                                palette.pageBg.copy(alpha = 0.72f),
                                palette.pageBg
                            )
                        )
                    )
            )
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 24.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SkeletonBox(
                    modifier = Modifier
                        .width(210.dp)
                        .height(26.dp),
                    shape = RoundedCornerShape(8.dp)
                )
                SkeletonBox(
                    modifier = Modifier
                        .width(150.dp)
                        .height(14.dp),
                    shape = RoundedCornerShape(6.dp)
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SkeletonBox(
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(15.dp)
            )
            SkeletonBox(
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(15.dp)
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            repeat(3) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    SkeletonBox(modifier = Modifier.width(24.dp).height(24.dp), shape = CircleShape)
                    SkeletonBox(modifier = Modifier.width(62.dp).height(10.dp), shape = RoundedCornerShape(4.dp))
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SkeletonBox(modifier = Modifier.fillMaxWidth().height(13.dp), shape = RoundedCornerShape(4.dp))
            SkeletonBox(modifier = Modifier.fillMaxWidth(0.92f).height(13.dp), shape = RoundedCornerShape(4.dp))
            SkeletonBox(modifier = Modifier.fillMaxWidth(0.68f).height(13.dp), shape = RoundedCornerShape(4.dp))
            Spacer(Modifier.height(4.dp))
            SkeletonBox(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f),
                shape = RoundedCornerShape(12.dp)
            )
        }
    }
}
