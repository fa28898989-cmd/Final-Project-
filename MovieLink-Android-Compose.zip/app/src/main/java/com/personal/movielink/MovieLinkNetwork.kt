package com.personal.movielink

import android.content.Context
import android.net.Uri
import android.webkit.CookieManager
import coil.ImageLoader
import coil.disk.DiskCache
import coil.memory.MemoryCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Cache
import okhttp3.ConnectionPool
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.Dispatcher
import okhttp3.HttpUrl
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.io.File
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class CloudflareRequiredException(val url: String) : IOException("Cloudflare verification required for $url")

object MovieLinkNetwork {
    private class WebViewCookieJar : CookieJar {
        private val cm: CookieManager by lazy { CookieManager.getInstance() }

        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
            val urlStr = url.toString()
            for (cookie in cookies) {
                cm.setCookie(urlStr, cookie.toString())
            }
            cm.flush()
        }

        override fun loadForRequest(url: HttpUrl): List<Cookie> {
            val raw = cm.getCookie(url.toString()) ?: return emptyList()
            return raw.split(";")
                .mapNotNull { part ->
                    val trimmed = part.trim()
                    val eq = trimmed.indexOf('=')
                    if (eq <= 0) return@mapNotNull null
                    val name = trimmed.substring(0, eq).trim()
                    val value = trimmed.substring(eq + 1).trim()
                    Cookie.Builder()
                        .name(name)
                        .value(value)
                        .domain(url.host)
                        .path("/")
                        .build()
                }
        }
    }

    private class CloudflareDns : okhttp3.Dns {
        private val client by lazy {
            OkHttpClient.Builder()
                .connectTimeout(4, TimeUnit.SECONDS)
                .readTimeout(4, TimeUnit.SECONDS)
                .build()
        }

        override fun lookup(hostname: String): List<java.net.InetAddress> {
            return try {
                val url = "https://cloudflare-dns.com/dns-query?name=$hostname&type=A"
                val req = Request.Builder()
                    .url(url)
                    .header("Accept", "application/dns-json")
                    .build()
                client.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val body = resp.body?.string().orEmpty()
                        val json = org.json.JSONObject(body)
                        val answers = json.optJSONArray("Answer")
                        val addrs = mutableListOf<java.net.InetAddress>()
                        if (answers != null) {
                            for (i in 0 until answers.length()) {
                                val ans = answers.getJSONObject(i)
                                if (ans.optInt("type") == 1) {
                                    val data = ans.optString("data")
                                    if (data.isNotBlank()) {
                                        runCatching { addrs.add(java.net.InetAddress.getByName(data)) }
                                    }
                                }
                            }
                        }
                        if (addrs.isNotEmpty()) return addrs
                    }
                }
                okhttp3.Dns.SYSTEM.lookup(hostname)
            } catch (_: Exception) {
                okhttp3.Dns.SYSTEM.lookup(hostname)
            }
        }
    }

    fun buildHttpClient(settingsProvider: () -> UserSettings): OkHttpClient {
        val blockerInterceptor = Interceptor { chain ->
            val req = chain.request()
            val settings = settingsProvider()
            val uri = Uri.parse(req.url.toString())
            if (AdBlocker.shouldBlock(uri, settings)) {
                return@Interceptor Response.Builder()
                    .request(req)
                    .protocol(Protocol.HTTP_1_1)
                    .code(204)
                    .message("Blocked by MovieLink AdBlocker")
                    .body(ByteArray(0).toResponseBody(null))
                    .build()
            }
            val ua = if (settings.desktopMode) Config.DESKTOP_USER_AGENT else Config.MOBILE_USER_AGENT
            val nextReq = req.newBuilder()
                .header("User-Agent", ua)
                .header("Accept-Language", "en-US,en;q=0.9")
                .build()
            chain.proceed(nextReq)
        }

        return OkHttpClient.Builder()
            .dns(CloudflareDns())
            .cookieJar(WebViewCookieJar())
            .connectionPool(ConnectionPool(12, 5, TimeUnit.MINUTES))
            .addInterceptor(blockerInterceptor)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(18, TimeUnit.SECONDS)
            .build()
    }

    /**
     * Dedicated HTTP client for direct Stremio/Nuvio addon streams and progressive/HLS media.
     * - Preserves caller/proxyHeaders headers verbatim (never overwrites custom User-Agent).
     * - Does not inject MovieLinkBD WebView cookies or run site AdBlocker against stream CDNs.
     */
    fun buildStreamHttpClient(settingsProvider: () -> UserSettings): OkHttpClient {
        val streamHeaderInterceptor = Interceptor { chain ->
            val req = chain.request()
            val builder = req.newBuilder()
            if (req.header("User-Agent").isNullOrBlank()) {
                val ua = if (settingsProvider().desktopMode) {
                    Config.DESKTOP_USER_AGENT
                } else {
                    Config.MOBILE_USER_AGENT
                }
                builder.header("User-Agent", ua)
            }
            if (req.header("Accept-Language").isNullOrBlank()) {
                builder.header("Accept-Language", "en-US,en;q=0.9")
            }
            chain.proceed(builder.build())
        }

        return OkHttpClient.Builder()
            .dns(CloudflareDns())
            .cookieJar(CookieJar.NO_COOKIES)
            .connectionPool(ConnectionPool(12, 5, TimeUnit.MINUTES))
            .addInterceptor(streamHeaderInterceptor)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    fun buildImageLoader(
        context: Context,
        settingsProvider: (() -> UserSettings)? = null
    ): ImageLoader {
        // R2 poster/screenshot host serves all artwork from one domain; lift OkHttp's default 5/host cap
        val dispatcher = Dispatcher().apply {
            maxRequests = 64
            maxRequestsPerHost = 24
        }
        val httpCacheDir = File(context.cacheDir, "http_image_cache")
        val imageClient = OkHttpClient.Builder()
            .dns(CloudflareDns())
            .cookieJar(WebViewCookieJar())
            .dispatcher(dispatcher)
            .connectionPool(ConnectionPool(16, 5, TimeUnit.MINUTES))
            .cache(Cache(httpCacheDir, 80L * 1024L * 1024L))
            .addInterceptor { chain ->
                val orig = chain.request()
                val mirrorUrl = settingsProvider?.invoke()?.mirrorUrl ?: Config.DEFAULT_HOME_URL
                val isInternalHost = Config.isInternal(orig.url.host, mirrorUrl)
                val reqBuilder = orig.newBuilder()
                    .header("User-Agent", Config.MOBILE_USER_AGENT)
                if (orig.header("Accept").isNullOrBlank()) {
                    reqBuilder.header("Accept", "image/webp,image/png,image/jpeg,*/*;q=0.8")
                }
                if (isInternalHost) {
                    reqBuilder.header("Referer", mirrorUrl)
                } else {
                    reqBuilder
                        .removeHeader("Referer")
                        .header("Referrer-Policy", "no-referrer")
                }
                chain.proceed(reqBuilder.build())
            }
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .build()

        return ImageLoader.Builder(context)
            .okHttpClient(imageClient)
            .memoryCache {
                MemoryCache.Builder(context)
                    .maxSizePercent(0.25)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(File(context.cacheDir, "coil_image_cache"))
                    .maxSizeBytes(150L * 1024L * 1024L)
                    .build()
            }
            .allowRgb565(true)
            .respectCacheHeaders(false)
            .crossfade(150)
            .build()
    }
}

class MovieLinkRepository(
    private val httpClient: OkHttpClient,
    private val settingsProvider: () -> UserSettings
) {
    @Volatile
    private var resolvedMirrorBaseUrl: String? = null

    @Volatile
    private var resolvedForConfiguredMirror: String? = null

    private val redirectProbeClient: OkHttpClient by lazy {
        httpClient.newBuilder()
            .followRedirects(false)
            .followSslRedirects(false)
            .build()
    }

    private fun isRedirectorHost(host: String?): Boolean {
        val h = host?.lowercase()?.trim().orEmpty()
        if (h.isEmpty()) return true
        return h == "movielinkbd.at" ||
            h.endsWith(".movielinkbd.at") ||
            h == "movielinkbd.com"
    }

    private fun originOf(url: String): String? {
        val uri = Uri.parse(url)
        val authority = uri.authority?.takeIf { it.isNotBlank() } ?: return null
        val host = uri.host?.lowercase().orEmpty()
        val rawScheme = uri.scheme?.lowercase().orEmpty().ifBlank { "https" }
        val scheme = if (rawScheme == "http" && host.contains("movielink")) "https" else rawScheme
        return "$scheme://$authority"
    }

    private fun recordResolvedOrigin(url: String, configuredMirror: String) {
        val uri = Uri.parse(url)
        val host = uri.host
        if (!isRedirectorHost(host) && Config.isInternal(host, configuredMirror)) {
            val origin = originOf(url)
            if (!origin.isNullOrBlank()) {
                resolvedForConfiguredMirror = configuredMirror.trimEnd('/')
                resolvedMirrorBaseUrl = origin
            }
        }
    }

    private fun resolveActiveSearchBase(configuredMirror: String): String {
        val cleanMirror = configuredMirror.trimEnd('/')
        if (resolvedForConfiguredMirror != cleanMirror) {
            resolvedMirrorBaseUrl = null
            resolvedForConfiguredMirror = cleanMirror
        }
        val cached = resolvedMirrorBaseUrl
        if (!cached.isNullOrBlank() && !isRedirectorHost(Uri.parse(cached).host)) {
            return cached
        }

        // Probe root "/" without following /search redirects so redirector CDN caches cannot rewrite the query
        var probeUrl = "$cleanMirror/"
        for (hop in 0 until 4) {
            val host = Uri.parse(probeUrl).host
            if (!isRedirectorHost(host)) {
                val origin = originOf(probeUrl)
                if (!origin.isNullOrBlank()) {
                    resolvedMirrorBaseUrl = origin
                    return origin
                }
                break
            }
            val req = Request.Builder()
                .url(probeUrl)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Cache-Control", "no-cache")
                .build()
            val location = runCatching {
                redirectProbeClient.newCall(req).execute().use { resp ->
                    if (resp.code in 300..399) resp.header("Location") else null
                }
            }.getOrNull()?.trim()
            if (location.isNullOrBlank()) break
            val nextUrl = LinkDecoder.resolveUrl(probeUrl, location)
            if (nextUrl == probeUrl) break
            probeUrl = nextUrl
        }
        return originOf(probeUrl) ?: originOf(cleanMirror) ?: cleanMirror
    }

    private fun buildMismatchedSearchRetryUrl(
        landedUrl: String,
        expectedQuery: String,
        encodedQuery: String,
        configuredMirror: String
    ): String? {
        val uri = Uri.parse(landedUrl)
        val path = uri.path.orEmpty()
        if (!path.contains("/search", ignoreCase = true)) return null
        val returnedQuery = uri.getQueryParameter("q")?.trim().orEmpty()
        val normExpected = expectedQuery.replace(Regex("""\s+"""), " ").trim()
        val normReturned = returnedQuery.replace(Regex("""\s+"""), " ").trim()
        if (normReturned.isEmpty() || normReturned.equals(normExpected, ignoreCase = true)) {
            return null
        }
        val host = uri.host
        if (isRedirectorHost(host) || !Config.isInternal(host, configuredMirror)) return null
        val origin = originOf(landedUrl) ?: return null
        resolvedForConfiguredMirror = configuredMirror.trimEnd('/')
        resolvedMirrorBaseUrl = origin
        return "$origin/search?q=$encodedQuery"
    }

    suspend fun fetchCatalogPage(url: String): CatalogPage = withContext(Dispatchers.IO) {
        val settings = settingsProvider()
        val normalized = Config.normalizeUrl(url)
        val (finalUrl, html) = fetchHtml(normalized)
        parseCatalogDocument(finalUrl, html, settings)
    }

    suspend fun searchCatalog(query: String): CatalogPage = withContext(Dispatchers.IO) {
        val settings = settingsProvider()
        val trimmedQuery = query.trim()
        val encoded = URLEncoder.encode(trimmedQuery, "UTF-8")
        val activeBase = resolveActiveSearchBase(settings.mirrorUrl).trimEnd('/')
        val searchUrl = "$activeBase/search?q=$encoded"
        val (finalUrl, html) = try {
            fetchHtml(searchUrl)
        } catch (cf: CloudflareRequiredException) {
            val cfRetry = buildMismatchedSearchRetryUrl(cf.url, trimmedQuery, encoded, settings.mirrorUrl)
            if (cfRetry != null && cfRetry != cf.url) {
                fetchHtml(cfRetry)
            } else {
                throw cf
            }
        }
        val retryAfterRedirect = buildMismatchedSearchRetryUrl(finalUrl, trimmedQuery, encoded, settings.mirrorUrl)
        val (resolvedUrl, resolvedHtml) = if (retryAfterRedirect != null && retryAfterRedirect != finalUrl) {
            fetchHtml(retryAfterRedirect)
        } else {
            finalUrl to html
        }
        parseCatalogDocument(resolvedUrl, resolvedHtml, settings, forceGrid = true, customTitle = "Search: $trimmedQuery")
    }

    suspend fun fetchDetail(url: String): MediaDetail = withContext(Dispatchers.IO) {
        val settings = settingsProvider()
        val (finalUrl, html) = fetchHtml(url)
        parseDetailDocument(finalUrl, html, settings)
    }

    private fun fetchHtml(url: String): Pair<String, String> {
        val configuredMirror = settingsProvider().mirrorUrl
        val isSearch = url.contains("/search?", ignoreCase = true) || url.contains("?s=", ignoreCase = true)
        val reqBuilder = Request.Builder()
            .url(url)
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
        if (isSearch) {
            reqBuilder
                .header("Cache-Control", "no-cache")
                .header("Pragma", "no-cache")
        }

        httpClient.newCall(reqBuilder.build()).execute().use { resp ->
            val finalUrl = resp.request.url.toString()
            val body = resp.body?.string().orEmpty()
            recordResolvedOrigin(finalUrl, configuredMirror)
            val cfHeader = resp.header("cf-mitigated")
            if (resp.code in listOf(403, 503) ||
                cfHeader.equals("challenge", ignoreCase = true) ||
                looksLikeCloudflareChallenge(body)
            ) {
                throw CloudflareRequiredException(finalUrl)
            }
            if (!resp.isSuccessful && body.isBlank()) {
                throw IOException("HTTP ${resp.code} while loading $finalUrl")
            }
            return finalUrl to body
        }
    }

    private fun looksLikeCloudflareChallenge(html: String): Boolean {
        if (html.length > 35_000) return false
        val lower = html.lowercase()
        return lower.contains("cf-browser-verification") ||
            lower.contains("challenge-platform") ||
            (lower.contains("just a moment") && lower.contains("cloudflare"))
    }

    private fun parseCatalogDocument(
        finalUrl: String,
        html: String,
        settings: UserSettings,
        forceGrid: Boolean = false,
        customTitle: String? = null
    ): CatalogPage {
        val doc = Jsoup.parse(html, finalUrl)
        val polish = settings.sitePolishEnabled
        val categories = extractCategories(doc, finalUrl, settings)

        val sections = mutableListOf<CatalogSection>()
        val seenSectionKeys = hashSetOf<String>()

        // 1. Primary .movie-cards-container (Recently Updated on Home, or grid on category/search pages)
        val containers = doc.select(".movie-cards-container")
        for (container in containers) {
            val cards = container.select(".movie-card").mapNotNull { parseMovieCard(it, finalUrl, polish) }
                .distinctBy { it.url }
            if (cards.isEmpty()) continue

            val headingEl = findSectionHeading(container)
            val rawHeading = headingEl?.text()?.trim().orEmpty()
            val cleanHeading = cleanSectionTitle(BanglaTranslator.translateUi(rawHeading, polish))
                .ifBlank { if (sections.isEmpty()) "Recently Updated" else "More Titles" }

            val moreHref = headingEl?.parent()?.selectFirst("a[href]")?.absUrl("href")
                ?.takeIf { it.isNotBlank() && !it.contains("/movie/") && !it.contains("/series/") }

            val key = "${cleanHeading.lowercase()}:${cards.first().url}"
            if (seenSectionKeys.add(key)) {
                sections.add(CatalogSection(cleanHeading, cards, moreHref))
            }
        }

        // 2. Homepage horizontal rail sections (.mlbd-rail-section: Top 10, New & Popular, Movies, Series, etc.)
        val railSections = doc.select("section.mlbd-rail-section")
        for (rail in railSections) {
            val cards = rail.select(".mlbd-rail .movie-card, .movie-card")
                .mapNotNull { parseMovieCard(it, finalUrl, polish) }
                .distinctBy { it.url }
            if (cards.isEmpty()) continue

            val rawTitle = rail.selectFirst(".mlbd-rail-title")?.text()?.trim()
                ?: rail.attr("aria-label").trim()
            val cleanTitle = cleanSectionTitle(BanglaTranslator.translateUi(rawTitle, polish))
                .ifBlank { "Featured" }
            if (cleanTitle.contains("18+") || cleanTitle.contains("adult", ignoreCase = true)) continue

            val moreHref = rail.selectFirst("a.mlbd-rail-showall[href]")?.absUrl("href")
                ?.takeIf { it.isNotBlank() }

            val key = "${cleanTitle.lowercase()}:${cards.first().url}"
            if (seenSectionKeys.add(key)) {
                sections.add(CatalogSection(cleanTitle, cards, moreHref))
            }
        }

        // Fallback if cards are laid out without expected containers
        if (sections.isEmpty()) {
            val allCards = doc.select(".movie-card").mapNotNull { parseMovieCard(it, finalUrl, polish) }
                .distinctBy { it.url }
            if (allCards.isNotEmpty()) {
                sections.add(CatalogSection(customTitle ?: "Catalog", allCards, null))
            }
        }

        val pageTitleRaw = customTitle
            ?: doc.selectFirst("h1, .mlbd-page-title")?.text()?.trim()
            ?: doc.title().substringBefore("—").substringBefore("|").trim().ifBlank { "MovieLink" }

        val pageTitle = cleanSectionTitle(
            BanglaTranslator.translateUi(pageTitleRaw, polish)
                .replace("MovieLinkBD", "MovieLink")
        ).ifBlank { "Catalog" }

        val nextPageUrl = doc.selectFirst("a.next, a[rel=next], .pagination li.active + li a, .pagination a:contains(Next)")
            ?.absUrl("href")
            ?.takeIf { it.isNotBlank() && it != finalUrl }

        val lowerPath = Uri.parse(finalUrl).path.orEmpty().lowercase()
        val isCategoryOrListPath = lowerPath.startsWith("/type/") ||
            lowerPath.startsWith("/genre/") ||
            lowerPath.startsWith("/language/") ||
            lowerPath.startsWith("/category/") ||
            lowerPath.startsWith("/collection/") ||
            lowerPath.startsWith("/ott") ||
            lowerPath.startsWith("/search") ||
            lowerPath.startsWith("/ongoing") ||
            lowerPath.startsWith("/mostwatch") ||
            lowerPath == "/bollywood" ||
            lowerPath == "/live"

        val (ottAllUrl, ottPlatforms) = extractOttPlatforms(doc, finalUrl)

        return CatalogPage(
            url = finalUrl,
            pageTitle = pageTitle,
            sections = sections,
            categories = categories,
            ottPlatforms = ottPlatforms,
            ottAllUrl = ottAllUrl,
            nextPageUrl = nextPageUrl,
            isSearchOrGrid = forceGrid || isCategoryOrListPath || sections.size <= 1
        )
    }

    private fun extractOttPlatforms(doc: Document, baseUrl: String): Pair<String?, List<OttPlatform>> {
        val bar = doc.selectFirst(".mlbd-ottbar") ?: return null to emptyList()
        val allUrl = bar.selectFirst(".mlbd-ottbar-hd a[href]")?.absUrl("href")?.takeIf { it.isNotBlank() }
        val platforms = bar.select("a.mlbd-ott-item[href]").mapNotNull { a ->
            val href = a.attr("href").trim()
            if (href.isEmpty() || href == "#") return@mapNotNull null
            val absUrl = LinkDecoder.resolveUrl(baseUrl, href)
            val name = a.selectFirst(".mlbd-ott-lbl")?.text()?.trim()
                ?.ifBlank { a.attr("title").trim() }
                .orEmpty()
            if (name.isBlank()) return@mapNotNull null

            val img = a.selectFirst("img")
            val iconRaw = img?.attr("src")?.trim()?.takeIf { it.isNotEmpty() && !it.startsWith("data:") }
                ?: img?.attr("data-src")?.trim().orEmpty()
            val iconUrl = if (iconRaw.isNotEmpty()) LinkDecoder.resolveUrl(baseUrl, iconRaw) else ""

            val newBadge = a.selectFirst(".mlbd-ott-new")?.text()?.trim().orEmpty()
            val styleAttr = a.attr("style")
            val colorMatch = Regex("""--oc\s*:\s*(#[0-9a-fA-F]{3,8})""").find(styleAttr)?.groupValues?.getOrNull(1)
            val accentHex = when {
                colorMatch == null -> "#22D3EE"
                colorMatch.length == 4 -> {
                    val r = colorMatch[1]
                    val g = colorMatch[2]
                    val b = colorMatch[3]
                    "#$r$r$g$g$b$b"
                }
                else -> colorMatch
            }

            OttPlatform(
                name = name,
                url = absUrl,
                iconUrl = iconUrl,
                newBadge = newBadge,
                accentHex = accentHex
            )
        }.distinctBy { it.url }
        return allUrl to platforms
    }

    private fun cleanSectionTitle(raw: String): String {
        val stripped = raw
            .replace(Regex("""[^\p{L}\p{N}\p{P}\p{Z}&+/·\-]+"""), " ")
            .replace(Regex("""\s{2,}"""), " ")
            .trim()
        if (stripped.isEmpty()) return ""
        return if (stripped == stripped.uppercase() && stripped.length > 4) {
            stripped.lowercase().split(" ").joinToString(" ") { w ->
                when (w) {
                    "tv" -> "TV"
                    "k/j/c" -> "K/J/C"
                    else -> w.replaceFirstChar { it.uppercase() }
                }
            }
        } else {
            stripped
        }
    }

    private fun extractCategories(doc: Document, baseUrl: String, settings: UserSettings): List<CategoryChip> {
        val chips = linkedMapOf<String, CategoryChip>()
        val links = doc.select("a[href]")
        for (a in links) {
            val href = a.attr("href").trim()
            if (href.isEmpty() || href == "#" || href.startsWith("javascript:", true)) continue
            val abs = LinkDecoder.resolveUrl(baseUrl, href)
            val uri = Uri.parse(abs)
            if (!Config.isInternal(uri.host, settings.mirrorUrl)) continue
            val path = uri.path.orEmpty()
            val isCategoryPath = path.startsWith("/language/") ||
                path.startsWith("/genre/") ||
                path.startsWith("/type/") ||
                path.startsWith("/category/") ||
                path.startsWith("/collection/") ||
                path.startsWith("/ongoing") ||
                path == "/bollywood" ||
                path == "/live"
            if (!isCategoryPath) continue
            if (path.contains("how2download", true)) continue
            val translated = BanglaTranslator.translateUi(a.text().trim(), settings.sitePolishEnabled)
            val cleaned = cleanSectionTitle(translated)
                .replace(Regex("""\s+\d+\s+titles$""", RegexOption.IGNORE_CASE), "")
                .trim()
            if (cleaned.isBlank() || cleaned.length > 30) continue
            if (BanglaTranslator.isClutterText(cleaned)) continue
            chips.putIfAbsent(abs, CategoryChip(cleaned, abs))
        }
        return chips.values.take(36)
    }

    private fun findSectionHeading(container: Element): Element? {
        var prev = container.previousElementSibling()
        var steps = 0
        while (prev != null && steps < 4) {
            val h = prev.selectFirst("h1, h2, h3, h4, .section-title, .mlbd-sec-title") ?: if (prev.tagName().matches(Regex("h[1-4]"))) prev else null
            if (h != null && h.text().isNotBlank() && !BanglaTranslator.isClutterText(h.text())) {
                return h
            }
            prev = prev.previousElementSibling()
            steps++
        }
        val parentPrev = container.parent()?.previousElementSibling()
        val ph = parentPrev?.selectFirst("h1, h2, h3, h4, .section-title, .mlbd-sec-title")
        if (ph != null && ph.text().isNotBlank() && !BanglaTranslator.isClutterText(ph.text())) {
            return ph
        }
        return null
    }

    private fun isValidPosterCandidate(raw: String): Boolean {
        val u = raw.trim()
        if (u.isEmpty()) return false
        val lower = u.lowercase()
        if (lower.startsWith("data:") || lower.startsWith("javascript:") || lower == "#") return false
        if (lower.contains("mlbd_load") ||
            lower.contains("placeholder") ||
            lower.contains("spinner") ||
            lower.contains("loading.") ||
            lower.contains("/blank.") ||
            lower.contains("1x1.")
        ) {
            return false
        }
        return true
    }

    private fun extractFirstSrcsetUrl(rawSrcset: String): String {
        if (rawSrcset.isBlank()) return ""
        return rawSrcset.split(",")
            .mapNotNull { entry ->
                entry.trim().split(Regex("""\s+""")).firstOrNull()?.trim()?.takeIf { isValidPosterCandidate(it) }
            }
            .firstOrNull()
            .orEmpty()
    }

    private fun parseMovieCard(card: Element, baseUrl: String, polish: Boolean): MediaCard? {
        val anchor = card.selectFirst("a[href*=/movie/], a[href*=/series/], a[href*=/drama/], a[href*=/anime/], a[href]")
            ?: return null
        val href = anchor.attr("href").trim()
        if (href.isEmpty() || href == "#") return null
        val absUrl = LinkDecoder.resolveUrl(baseUrl, href)

        val imgs = card.select("img")
        val primaryImg = imgs.firstOrNull { el ->
            val cls = el.className().lowercase()
            !cls.contains("icon") && !cls.contains("flag") && !cls.contains("badge")
        } ?: imgs.firstOrNull()

        val rawTitle = card.selectFirst(".title, .movie-title, h3, h4")?.text()?.trim()
            ?.takeIf { it.isNotEmpty() }
            ?: primaryImg?.attr("alt")?.trim()?.takeIf { it.isNotEmpty() }
            ?: anchor.attr("title").trim()
        if (rawTitle.isBlank()) return null

        val posterCandidates = LinkedHashSet<String>()
        fun addCandidate(raw: String) {
            val clean = raw.trim()
            if (isValidPosterCandidate(clean)) {
                posterCandidates.add(LinkDecoder.resolveUrl(baseUrl, clean))
            }
        }

        for (el in imgs) {
            listOf(
                el.attr("data-src"),
                el.attr("data-lazy-src"),
                el.attr("data-original"),
                el.attr("data-url"),
                el.attr("data-bg"),
                extractFirstSrcsetUrl(el.attr("data-srcset")),
                extractFirstSrcsetUrl(el.attr("srcset")),
                el.attr("src")
            ).forEach(::addCandidate)
        }
        for (srcEl in card.select("picture source")) {
            listOf(
                extractFirstSrcsetUrl(srcEl.attr("data-srcset")),
                extractFirstSrcsetUrl(srcEl.attr("srcset")),
                srcEl.attr("src")
            ).forEach(::addCandidate)
        }
        for (styledEl in card.select("[data-bg], [data-background], [style*=background-image]")) {
            addCandidate(styledEl.attr("data-bg"))
            addCandidate(styledEl.attr("data-background"))
            val styleAttr = styledEl.attr("style")
            if (styleAttr.isNotBlank()) {
                Regex("""url\((['"]?)(.*?)\1\)""", RegexOption.IGNORE_CASE)
                    .findAll(styleAttr)
                    .forEach { m -> addCandidate(m.groupValues[2]) }
            }
        }

        val orderedPosters = posterCandidates.toList()
        val posterUrl = orderedPosters.firstOrNull().orEmpty()
        val fallbackPosterUrl = orderedPosters.getOrNull(1).orEmpty()

        // Skip PINNED / FEATURED badge clutter so artwork stays clean
        val qualityRaw = card.select(".badge-group .badge, .quality")
            .map { it.text().trim() }
            .firstOrNull { txt ->
                txt.isNotBlank() &&
                    !txt.equals("PINNED", ignoreCase = true) &&
                    !txt.equals("FEATURED", ignoreCase = true)
            }
            .orEmpty()
        val quality = BanglaTranslator.translateUi(qualityRaw, polish)
        val language = BanglaTranslator.translateUi(
            card.selectFirst(".language")?.text()?.trim().orEmpty(),
            polish
        )
        val type = BanglaTranslator.translateUi(
            card.selectFirst(".type")?.text()?.trim().orEmpty(),
            polish
        )

        return MediaCard(
            title = rawTitle, // Strictly keep original movie/series title intact
            url = absUrl,
            posterUrl = posterUrl,
            quality = quality,
            language = language,
            type = type,
            fallbackPosterUrl = fallbackPosterUrl
        )
    }

    private fun parseDetailDocument(finalUrl: String, html: String, settings: UserSettings): MediaDetail {
        val doc = Jsoup.parse(html, finalUrl)
        val polish = settings.sitePolishEnabled

        val infoView = doc.selectFirst(".movie-info-view") ?: doc.body()
        // Keep original movie/series title intact
        val title = infoView.selectFirst("h1")?.text()?.trim()
            ?.takeIf { it.isNotEmpty() }
            ?: doc.title().substringBefore("|").substringBefore("—").trim()

        val subtitleRaw = infoView.selectFirst("p.text-yellow, .movie-subtitle")?.text()?.trim().orEmpty()
        val subtitle = BanglaTranslator.translateUi(subtitleRaw, polish)

        val posterCandidates = doc.select(
            ".movie-poster img, .poster-img, .poster img, .image-container img, .movie-info-view img, meta[property=og:image], meta[name=twitter:image]"
        )
        var posterRaw = ""
        for (el in posterCandidates) {
            val attrs = if (el.tagName().equals("meta", ignoreCase = true)) {
                listOf(el.attr("content"))
            } else {
                listOf(
                    el.attr("data-src"),
                    el.attr("data-lazy-src"),
                    el.attr("data-original"),
                    el.attr("src")
                )
            }
            val found = attrs
                .map { it.trim() }
                .firstOrNull { u ->
                    u.isNotEmpty() &&
                        !u.startsWith("data:", ignoreCase = true) &&
                        !u.contains("mlbd_load", ignoreCase = true) &&
                        !u.contains("placeholder", ignoreCase = true) &&
                        !u.contains("spinner", ignoreCase = true)
                }
            if (!found.isNullOrBlank()) {
                posterRaw = found
                break
            }
        }
        val posterUrl = if (posterRaw.isNotBlank()) LinkDecoder.resolveUrl(finalUrl, posterRaw) else ""

        var typeVal = if (finalUrl.contains("/series/", true)) "Series" else "Movie"
        var langVal = "Multi"
        var qualVal = "HD"

        val flexItems = doc.select("ul.flex-container li.flex-item")
        for (li in flexItems) {
            val bold = li.selectFirst("b")?.text()?.trim().orEmpty()
            val full = li.text().trim()
            val key = full.removeSuffix(bold).trim().lowercase()
            val cleanVal = BanglaTranslator.translateUi(bold, polish)
            when {
                key.contains("type") -> if (cleanVal.isNotBlank()) typeVal = cleanVal
                key.contains("lang") -> if (cleanVal.isNotBlank()) langVal = cleanVal
                key.contains("qual") -> if (cleanVal.isNotBlank()) qualVal = cleanVal
            }
        }

        val scheduleCandidate = doc.select(".mlbd-ongoing, .ongoing-badge, .series-schedule, .movie-info-view p")
            .map { it.text().trim() }
            .firstOrNull { txt ->
                txt.isNotBlank() &&
                    txt != subtitleRaw &&
                    !BanglaTranslator.isClutterText(txt) &&
                    (txt.contains("Ongoing", true) || txt.contains("পর্ব") || txt.contains("প্রতি") || txt.contains("Every ", true))
            }.orEmpty()
        val scheduleText = BanglaTranslator.translateUi(scheduleCandidate, polish)

        val trailerYoutubeId = doc.selectFirst("[data-mlbd-trailer]")?.attr("data-mlbd-trailer")?.trim()
            ?.takeIf { it.isNotEmpty() }

        val watchSrc = doc.selectFirst("iframe#mlbdHdFrame, iframe[src*=/p/]")?.attr("src")?.trim()
        val watchEmbedUrl = if (!watchSrc.isNullOrBlank()) LinkDecoder.resolveUrl(finalUrl, watchSrc) else null

        val storylineRaw = doc.selectFirst(".storyline-box .story-text, .storyline-box p")?.text()?.trim().orEmpty()
        val storyline = BanglaTranslator.translateUi(storylineRaw, polish)

        val extraLines = doc.select(".movie-extra-info .info-line, .movie-extra-info p")
            .map { BanglaTranslator.translateUi(it.text().trim(), polish) }
            .filter { it.isNotBlank() && !BanglaTranslator.isClutterText(it) }
            .distinct()

        val cast = doc.select(".mlbd-cast__p").mapNotNull { el ->
            val name = el.selectFirst("b")?.text()?.trim().orEmpty()
            if (name.isBlank()) return@mapNotNull null
            val role = el.selectFirst("small")?.text()?.trim().orEmpty()
            val avatar = el.selectFirst("img")?.attr("src")?.trim().orEmpty()
            val profile = el.attr("href").trim().let {
                if (it.isNotEmpty()) LinkDecoder.resolveUrl(finalUrl, it) else ""
            }
            CastMember(name, role, avatar, profile)
        }

        val screenshotImgs = doc.select(
            ".screenshot-wrapper img, .screenshots-wrapper img, .preview-wrapper img, .previews-wrapper img, " +
            ".movie-screenshots img, .movie-previews img, #screenshots img, #previews img, " +
            ".screenshot-box img, .preview-box img, a[data-fancybox] img, a[data-fslightbox] img, a[data-lightbox] img"
        ).mapNotNull { img ->
            val dsrc = img.attr("data-src").trim()
            val src = img.attr("src").trim()
            val u = if (dsrc.isNotEmpty() && !dsrc.contains("mlbd_load")) dsrc else src
            if (u.isNotEmpty() && !u.startsWith("data:") && !u.contains("mlbd_load")) {
                LinkDecoder.resolveUrl(finalUrl, u)
            } else null
        }
        val previewAnchors = doc.select(
            ".screenshot-wrapper a, .preview-wrapper a, .screenshots-wrapper a, .previews-wrapper a, #screenshots a, #previews a"
        ).mapNotNull { a ->
            val href = a.attr("href").trim()
            if (href.isNotEmpty() && (href.endsWith(".jpg", true) || href.endsWith(".png", true) || href.endsWith(".webp", true) || href.endsWith(".jpeg", true))) {
                LinkDecoder.resolveUrl(finalUrl, href)
            } else null
        }
        val screenshotUrls = (screenshotImgs + previewAnchors)
            .filter { it.isNotBlank() && !it.contains("mlbd_load") }
            .distinct()

        // Episodes (for series)
        val episodes = mutableListOf<EpisodeItem>()
        val epCards = doc.select("#mlbdEpisodeDownloadGrid .ep-card")
        for (card in epCards) {
            val epTitleRaw = card.selectFirst(".mlbd-episode-title, h5, h4")?.ownText()?.trim()
                ?.ifBlank { card.selectFirst(".mlbd-episode-title, h5, h4")?.text()?.replace("NEW", "")?.trim().orEmpty() }
                .orEmpty()
            val epTitle = BanglaTranslator.translateUi(epTitleRaw, polish)
            val seasonNum = card.attr("data-season-number").trim().toIntOrNull()
            val epNum = card.attr("data-episode-number").trim().toIntOrNull()
            val isNew = card.selectFirst(".mlbd-ep-flag.is-new") != null
            val epLinks = extractDownloadLinks(card.select("a[data-dl], a.btn-user"), finalUrl, polish)
            if (epLinks.isNotEmpty()) {
                episodes.add(
                    EpisodeItem(
                        title = epTitle.ifBlank { "Episode ${epNum ?: episodes.size + 1}" },
                        seasonNumber = seasonNum,
                        episodeNumber = epNum,
                        isNew = isNew,
                        downloads = epLinks
                    )
                )
            }
        }

        // Season zip packs
        val seasonZips = extractDownloadLinks(
            doc.select("#mlbdSeasonZipDownloads a[data-dl], #mlbdZipDownloadGrid a[data-dl]"),
            finalUrl,
            polish,
            markZip = true
        )

        // Direct movie downloads (excluding those already inside #mlbdEpisodeDownloadGrid or #mlbdSeasonZipDownloads)
        val allAnchors = doc.select("a[data-dl], a.btn-dark.btn-user")
            .filter { el ->
                el.parents().none { p ->
                    p.id() == "mlbdEpisodeDownloadGrid" ||
                        p.id() == "mlbdSeasonZipDownloads" ||
                        p.id() == "mlbdZipDownloadGrid"
                }
            }
        val movieDownloads = extractDownloadLinks(allAnchors, finalUrl, polish)

        val related = doc.select(".movie-card")
            .mapNotNull { parseMovieCard(it, finalUrl, polish) }
            .filterNot { it.url == finalUrl }
            .distinctBy { it.url }
            .take(12)

        val ratingRaw = doc.selectFirst(".mlbd-rating-box, .community-rating, .rating-summary")?.text()?.trim()
        val ratingSummary = ratingRaw?.let { BanglaTranslator.translateUi(it, polish) }
            ?.takeIf { it.isNotBlank() && !BanglaTranslator.isClutterText(it) }

        val imdbId = doc.select("a[href*=imdb.com/title/tt]")
            .firstOrNull()
            ?.attr("href")
            ?.let { Regex("""tt\d{5,}""", RegexOption.IGNORE_CASE).find(it)?.value?.lowercase() }
            ?: Regex("""imdb\.com/title/(tt\d{5,})""", RegexOption.IGNORE_CASE)
                .find(html)
                ?.groupValues
                ?.getOrNull(1)
                ?.lowercase()

        val parsedGenres = doc.select(".genre a, .genres a, a[href*=/genre/], a[href*=/category/]")
            .map { BanglaTranslator.translateUi(it.text().trim(), polish) }
            .filter { it.isNotBlank() && it.length <= 28 && !BanglaTranslator.isClutterText(it) }
            .distinct()
            .take(5)

        return MediaDetail(
            url = finalUrl,
            title = title,
            subtitle = subtitle,
            posterUrl = posterUrl,
            type = typeVal,
            language = langVal,
            quality = qualVal,
            scheduleText = scheduleText,
            trailerYoutubeId = trailerYoutubeId,
            watchEmbedUrl = watchEmbedUrl,
            storyline = storyline,
            extraInfoLines = extraLines,
            cast = cast,
            screenshotUrls = screenshotUrls,
            downloadLinks = movieDownloads,
            episodes = episodes,
            seasonZipLinks = seasonZips,
            relatedItems = related,
            communityRatingSummary = ratingSummary,
            imdbId = imdbId,
            genres = parsedGenres
        )
    }

    private fun extractDownloadLinks(
        elements: List<Element>,
        baseUrl: String,
        polish: Boolean,
        markZip: Boolean = false
    ): List<DownloadOption> {
        val out = mutableListOf<DownloadOption>()
        val seen = hashSetOf<String>()
        for (a in elements) {
            val dataDl = a.attr("data-dl").trim()
            val decodedPath = if (dataDl.isNotEmpty()) {
                val ds = a.attr("data-ds").trim()
                val dr = a.attr("data-dr").trim().toIntOrNull() ?: 0
                LinkDecoder.decodeToken(dataDl, ds, dr)
            } else {
                a.attr("href").trim().takeIf { it.isNotEmpty() && it != "#" }
            }
            if (decodedPath.isNullOrBlank()) continue
            val abs = LinkDecoder.resolveUrl(baseUrl, decodedPath)
            if (BanglaTranslator.isClutterText(a.text())) continue
            val rawLabel = a.text().trim().replace(Regex("""\s+"""), " ")
            val label = BanglaTranslator.translateUi(rawLabel, polish)
                .ifBlank { "Download" }
            val key = "$label|$abs"
            if (seen.add(key)) {
                out.add(DownloadOption(label, abs, markZip || label.contains("zip", true)))
            }
        }
        return out
    }
}
