package com.personal.movielink.addons

import android.net.Uri
import com.personal.movielink.CastMember
import com.personal.movielink.Config
import com.personal.movielink.ExternalRatingBadge
import com.personal.movielink.MediaDetail
import com.personal.movielink.UserSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

data class AddonCastMember(
    val name: String,
    val role: String = "",
    val avatarUrl: String = ""
)

data class AddonEpisodeItem(
    val id: String,
    val title: String,
    val season: Int,
    val episode: Int,
    val overview: String = "",
    val released: String = "",
    val thumbnailUrl: String = ""
)

data class AddonDetailedMeta(
    val id: String,
    val type: String,
    val title: String,
    val posterUrl: String = "",
    val backdropUrl: String = "",
    val logoUrl: String = "",
    val description: String = "",
    val releaseYear: String = "",
    val rating: String = "",
    val runtime: String = "",
    val status: String = "",
    val country: String = "",
    val genres: List<String> = emptyList(),
    val cast: List<String> = emptyList(),
    val castDetails: List<AddonCastMember> = emptyList(),
    val externalRatings: List<ExternalRatingBadge> = emptyList(),
    val director: List<String> = emptyList(),
    val videos: List<AddonEpisodeItem> = emptyList(),
    val sourceAddonName: String = "",
    val sourceManifestUrl: String = "",
    val fromFallbackPreview: Boolean = false,
    val screenshots: List<String> = emptyList(),
    val recommendations: List<UnifiedPosterItem> = emptyList()
)

class AddonMetadataRepository {

    private data class CacheEntry(
        val fetchedAtMs: Long,
        val meta: AddonDetailedMeta
    )

    private val cache = ConcurrentHashMap<String, CacheEntry>()

    fun buildMetaUrl(addon: InstalledAddon, type: String, id: String): String {
        val typeSeg = Uri.encode(type.trim())
        val idSeg = Uri.encode(id.trim())
        val basePath = "${addon.baseUrl.trimEnd('/')}/meta/$typeSeg/$idSeg.json"
        val query = addon.manifestUrl.substringAfter('?', "")
        return if (query.isNotBlank()) "$basePath?$query" else basePath
    }

    fun candidateMetaAddons(
        addons: List<InstalledAddon>,
        type: String,
        id: String,
        preferredManifestUrl: String? = null
    ): List<InstalledAddon> {
        val enabled = addons.filter { it.enabled }
        val preferred = preferredManifestUrl
            ?.takeIf { it.isNotBlank() }
            ?.let { url -> enabled.firstOrNull { it.manifestUrl == url } }

        val compatibleOthers = enabled.filter { addon ->
            addon.manifestUrl != preferredManifestUrl &&
                addon.manifest.supportsResource("meta", type, id)
        }

        return buildList {
            if (preferred != null && preferred.manifest.supportsResource("meta", type, id)) {
                add(preferred)
            }
            addAll(compatibleOthers)
        }
    }

    suspend fun fetchMeta(
        addons: List<InstalledAddon>,
        type: String,
        id: String,
        preferredManifestUrl: String? = null,
        fallbackPreview: AddonDetailedMeta? = null,
        forceRefresh: Boolean = false
    ): Result<AddonDetailedMeta> {
        val cleanType = type.trim().ifBlank { "movie" }
        val cleanId = id.trim()
        if (cleanId.isBlank()) {
            return Result.failure(IllegalArgumentException("Missing content identifier"))
        }

        val cacheKey = "${preferredManifestUrl.orEmpty()}|$cleanType|$cleanId"
        if (!forceRefresh) {
            val cached = cache[cacheKey]
            if (cached != null && System.currentTimeMillis() - cached.fetchedAtMs < CACHE_TTL_MS) {
                return Result.success(cached.meta)
            }
        }

        val candidates = candidateMetaAddons(addons, cleanType, cleanId, preferredManifestUrl)
        if (candidates.isEmpty()) {
            return if (fallbackPreview != null) {
                Result.success(fallbackPreview.copy(fromFallbackPreview = true))
            } else {
                Result.failure(UnsupportedOperationException("No enabled addon supports metadata for $cleanType ($cleanId)"))
            }
        }

        var lastError: Throwable? = null
        for (addon in candidates) {
            try {
                val url = buildMetaUrl(addon, cleanType, cleanId)
                val json = AddonHttp.getJsonObject(url)
                val metaObj = json.optJSONObject("meta")
                if (metaObj != null) {
                    val parsed = parseDetailedMeta(
                        obj = metaObj,
                        addon = addon,
                        fallbackType = cleanType,
                        fallbackId = cleanId,
                        fallbackPreview = fallbackPreview
                    )
                    if (parsed != null) {
                        if (cache.size > MAX_CACHE_ENTRIES) cache.clear()
                        cache[cacheKey] = CacheEntry(System.currentTimeMillis(), parsed)
                        return Result.success(parsed)
                    }
                }
            } catch (e: Exception) {
                lastError = e
            }
        }

        if (fallbackPreview != null) {
            return Result.success(fallbackPreview.copy(fromFallbackPreview = true))
        }
        return Result.failure(lastError ?: IllegalStateException("Unable to load metadata"))
    }

    fun clearCache() {
        cache.clear()
    }

    private fun parseDetailedMeta(
        obj: JSONObject,
        addon: InstalledAddon,
        fallbackType: String,
        fallbackId: String,
        fallbackPreview: AddonDetailedMeta?
    ): AddonDetailedMeta? {
        val id = obj.optString("id", fallbackId).trim().ifBlank { fallbackId }
        val title = obj.optString("name", obj.optString("title", ""))
            .trim()
            .ifBlank { fallbackPreview?.title.orEmpty() }
        if (title.isBlank()) return null

        val type = obj.optString("type", fallbackType).trim().ifBlank { fallbackType }
        val poster = sanitizeHttpUrl(obj.optString("poster", ""))
            .ifBlank { fallbackPreview?.posterUrl.orEmpty() }
        val backdrop = sanitizeHttpUrl(obj.optString("background", ""))
            .ifBlank { fallbackPreview?.backdropUrl.orEmpty() }
            .ifBlank { poster }
        val logo = sanitizeHttpUrl(obj.optString("logo", ""))
            .ifBlank { fallbackPreview?.logoUrl.orEmpty() }
        val description = obj.optString("description", "")
            .trim()
            .ifBlank { fallbackPreview?.description.orEmpty() }

        val releaseYear = obj.optString("releaseInfo", "").trim()
            .ifBlank {
                val rawYear = obj.opt("year")?.toString()?.trim().orEmpty()
                if (rawYear.equals("null", true)) "" else rawYear
            }
            .ifBlank { fallbackPreview?.releaseYear.orEmpty() }

        val ratingRaw = obj.opt("imdbRating")
        val rating = when (ratingRaw) {
            is Number -> ratingRaw.toString()
            is String -> ratingRaw.trim().takeIf {
                it.isNotEmpty() && !it.equals("null", true) && !it.equals("N/A", true)
            }.orEmpty()
            else -> ""
        }.ifBlank { fallbackPreview?.rating.orEmpty() }

        val runtime = obj.optString("runtime", "").trim().takeUnless { it.equals("null", true) }.orEmpty()
        val status = obj.optString("status", "").trim().takeUnless { it.equals("null", true) }.orEmpty()
        val country = obj.optString("country", "").trim().takeUnless { it.equals("null", true) }.orEmpty()

        val genres = readStringList(obj.optJSONArray("genres") ?: obj.optJSONArray("genre"))
            .ifEmpty { fallbackPreview?.genres.orEmpty() }
        val cast = readCastList(obj)
        val director = readStringList(obj.optJSONArray("director"))

        val videosArr = obj.optJSONArray("videos") ?: JSONArray()
        val episodes = buildList {
            for (i in 0 until videosArr.length()) {
                val vObj = videosArr.optJSONObject(i) ?: continue
                val epNum = vObj.optInt("episode", vObj.optInt("number", 0))
                val seasonNum = vObj.optInt("season", 0)
                val rawEpId = vObj.optString("id", "").trim()
                val epId = rawEpId.ifBlank { "$id:$seasonNum:$epNum" }
                val epTitle = vObj.optString("name", vObj.optString("title", ""))
                    .trim()
                    .ifBlank { if (epNum > 0) "Episode $epNum" else "Video ${i + 1}" }
                val overview = vObj.optString("overview", vObj.optString("description", "")).trim()
                val rawReleased = vObj.optString("released", "").trim()
                val cleanReleased = if (rawReleased.length >= 10 && rawReleased[4] == '-' && rawReleased[7] == '-') {
                    rawReleased.substring(0, 10)
                } else {
                    rawReleased
                }
                val thumb = sanitizeHttpUrl(vObj.optString("thumbnail", ""))
                add(
                    AddonEpisodeItem(
                        id = epId,
                        title = epTitle,
                        season = seasonNum,
                        episode = epNum,
                        overview = overview,
                        released = cleanReleased,
                        thumbnailUrl = thumb
                    )
                )
            }
        }.sortedWith(compareBy<AddonEpisodeItem> { it.season }.thenBy { it.episode })

        val parsedScreenshots = buildList {
            val scArr = obj.optJSONArray("screenshots") ?: obj.optJSONArray("stills")
            if (scArr != null) {
                for (i in 0 until scArr.length()) {
                    val u = sanitizeHttpUrl(scArr.optString(i, ""))
                    if (u.isNotBlank()) add(u)
                }
            }
            val bgArr = obj.optJSONArray("backgrounds") ?: obj.optJSONArray("backdrops")
            if (bgArr != null) {
                for (i in 0 until bgArr.length()) {
                    val u = sanitizeHttpUrl(bgArr.optString(i, ""))
                    if (u.isNotBlank()) add(u)
                }
            }
        }.distinct()

        return AddonDetailedMeta(
            id = id,
            type = type,
            title = title,
            posterUrl = poster,
            backdropUrl = backdrop,
            logoUrl = logo,
            description = description,
            releaseYear = releaseYear,
            rating = rating,
            runtime = runtime,
            status = status,
            country = country,
            genres = genres,
            cast = cast,
            director = director,
            videos = episodes,
            sourceAddonName = addon.manifest.name,
            sourceManifestUrl = addon.manifestUrl,
            fromFallbackPreview = false,
            screenshots = parsedScreenshots,
            recommendations = emptyList()
        )
    }

    private fun readStringList(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        return buildList {
            for (i in 0 until arr.length()) {
                val s = arr.optString(i, "").trim()
                if (s.isNotEmpty() && !s.equals("null", true)) add(s)
            }
        }
    }

    private fun readCastList(obj: JSONObject): List<String> {
        val simple = readStringList(obj.optJSONArray("cast"))
        if (simple.isNotEmpty()) return simple
        val credits = obj.optJSONArray("credits_cast") ?: return emptyList()
        return buildList {
            for (i in 0 until credits.length()) {
                val c = credits.optJSONObject(i) ?: continue
                val n = c.optString("name", "").trim()
                if (n.isNotEmpty()) add(n)
            }
        }
    }

    private fun sanitizeHttpUrl(raw: String): String {
        val clean = raw.trim()
        if (clean.isEmpty() || clean.equals("null", true)) return ""
        return if (clean.startsWith("http://", true) || clean.startsWith("https://", true)) {
            clean
        } else {
            ""
        }
    }

    companion object {
        private const val CACHE_TTL_MS = 5 * 60 * 1000L
        private const val MAX_CACHE_ENTRIES = 60
    }
}

class MetadataEnrichmentService {

    private data class TmdbEnrichment(
        val tmdbId: String? = null,
        val imdbId: String? = null,
        val overview: String = "",
        val posterUrl: String = "",
        val backdropUrl: String = "",
        val logoUrl: String = "",
        val releaseYear: String = "",
        val voteAverage: String = "",
        val runtime: String = "",
        val genres: List<String> = emptyList(),
        val cast: List<AddonCastMember> = emptyList(),
        val backdrops: List<String> = emptyList(),
        val recommendations: List<UnifiedPosterItem> = emptyList()
    )

    private data class CinemetaArtwork(
        val imdbId: String? = null,
        val background: String = "",
        val logo: String = "",
        val poster: String = "",
        val releaseInfo: String = "",
        val imdbRating: String = "",
        val genres: List<String> = emptyList(),
        val description: String = ""
    )

    private data class CachedTmdb(val fetchedAtMs: Long, val value: TmdbEnrichment)
    private data class CachedRatings(val fetchedAtMs: Long, val value: List<ExternalRatingBadge>)
    private data class CachedCinemeta(val fetchedAtMs: Long, val value: CinemetaArtwork)
    private data class CachedHeroArtwork(
        val fetchedAtMs: Long,
        val backdropUrl: String,
        val logoUrl: String,
        val posterUrl: String,
        val rating: String,
        val yearOrRelease: String,
        val genres: List<String>,
        val description: String
    )

    private val tmdbCache = ConcurrentHashMap<String, CachedTmdb>()
    private val mdbCache = ConcurrentHashMap<String, CachedRatings>()
    private val cinemetaCache = ConcurrentHashMap<String, CachedCinemeta>()
    private val heroArtworkCache = ConcurrentHashMap<String, CachedHeroArtwork>()

    fun clearCache() {
        tmdbCache.clear()
        mdbCache.clear()
        cinemetaCache.clear()
        heroArtworkCache.clear()
    }

    suspend fun enrichAddonMeta(
        meta: AddonDetailedMeta,
        settings: UserSettings
    ): AddonDetailedMeta {
        var resolvedImdb = extractImdbId(meta.id)
        var tmdbData: TmdbEnrichment? = null

        if (settings.tmdbMetadataEnabled && settings.tmdbApiKey.isNotBlank()) {
            tmdbData = fetchTmdbForItem(
                apiKeyRaw = settings.tmdbApiKey,
                itemId = meta.id,
                title = meta.title,
                year = meta.releaseYear,
                mediaType = meta.type
            )
            if (resolvedImdb == null && !tmdbData?.imdbId.isNullOrBlank()) {
                resolvedImdb = tmdbData?.imdbId
            }
        }

        val mdbRatings = if (settings.mdbListEnabled && settings.mdbListApiKey.isNotBlank()) {
            fetchMdbListRatings(
                apiKeyRaw = settings.mdbListApiKey,
                imdbId = resolvedImdb,
                tmdbId = tmdbData?.tmdbId ?: extractTmdbNumericId(meta.id),
                mediaType = meta.type
            )
        } else {
            emptyList()
        }

        val combinedRatings = mergeRatings(
            existing = meta.externalRatings,
            tmdbScore = tmdbData?.voteAverage,
            mdbRatings = mdbRatings
        )

        val betterPoster = Config.buildBetterPosterUrl(
            provider = settings.betterPosterProvider,
            imdbId = resolvedImdb,
            rpdbApiKey = settings.rpdbApiKey,
            customTemplate = settings.betterPosterCustomTemplate,
            mediaType = meta.type
        )

        val mergedCastDetails = if (tmdbData != null && tmdbData.cast.isNotEmpty()) {
            tmdbData.cast
        } else if (meta.castDetails.isNotEmpty()) {
            meta.castDetails
        } else {
            meta.cast.map { AddonCastMember(name = it) }
        }

        val resolvedPoster = betterPoster
            ?: meta.posterUrl.ifBlank { tmdbData?.posterUrl.orEmpty() }
        var resolvedBackdrop = meta.backdropUrl
            .takeIf { it.isNotBlank() && it != meta.posterUrl }
            .orEmpty()
            .ifBlank { tmdbData?.backdropUrl.orEmpty() }
        var resolvedLogo = if (meta.logoUrl.isNotBlank()) meta.logoUrl else tmdbData?.logoUrl.orEmpty()

        var cinemetaFallback: CinemetaArtwork? = null
        if (resolvedBackdrop.isBlank() || resolvedLogo.isBlank()) {
            cinemetaFallback = fetchCinemetaArtwork(
                imdbId = resolvedImdb,
                title = cleanTitleForSearch(meta.title),
                year = meta.releaseYear.ifBlank { tmdbData?.releaseYear.orEmpty() },
                mediaType = meta.type
            )
            if (resolvedBackdrop.isBlank()) {
                resolvedBackdrop = cinemetaFallback?.background.orEmpty()
            }
            if (resolvedLogo.isBlank()) {
                resolvedLogo = cinemetaFallback?.logo.orEmpty()
            }
        }
        resolvedBackdrop = resolvedBackdrop.ifBlank { resolvedPoster }

        val mergedScreenshots = (meta.screenshots + tmdbData?.backdrops.orEmpty()).distinct()
        val mergedRecommendations = if (meta.recommendations.isNotEmpty()) {
            meta.recommendations
        } else {
            tmdbData?.recommendations.orEmpty()
        }

        return meta.copy(
            posterUrl = resolvedPoster,
            backdropUrl = resolvedBackdrop,
            logoUrl = resolvedLogo,
            description = meta.description.ifBlank { tmdbData?.overview.orEmpty() }.ifBlank { cinemetaFallback?.description.orEmpty() },
            releaseYear = meta.releaseYear.ifBlank { tmdbData?.releaseYear.orEmpty() }.ifBlank { cinemetaFallback?.releaseInfo.orEmpty() },
            rating = meta.rating.ifBlank { tmdbData?.voteAverage.orEmpty() }.ifBlank { cinemetaFallback?.imdbRating.orEmpty() },
            runtime = meta.runtime.ifBlank { tmdbData?.runtime.orEmpty() },
            genres = meta.genres.ifEmpty { tmdbData?.genres.orEmpty() }.ifEmpty { cinemetaFallback?.genres.orEmpty() },
            cast = if (meta.cast.isNotEmpty()) meta.cast else mergedCastDetails.map { it.name },
            castDetails = mergedCastDetails,
            externalRatings = combinedRatings,
            screenshots = mergedScreenshots,
            recommendations = mergedRecommendations
        )
    }

    suspend fun enrichHeroItem(
        item: UnifiedPosterItem,
        settings: UserSettings
    ): UnifiedPosterItem {
        val currentBackdrop = item.backdropUrl
            .takeIf { it.isNotBlank() && it != item.posterUrl }
            .orEmpty()
        val currentLogo = item.logoUrl.trim()
        if (currentBackdrop.isNotBlank() && currentLogo.isNotBlank()) {
            return item
        }

        val cacheKey = "${item.stableKey}|${settings.tmdbMetadataEnabled}|${settings.tmdbApiKey.take(6)}"
        heroArtworkCache[cacheKey]
            ?.takeIf { System.currentTimeMillis() - it.fetchedAtMs < HERO_CACHE_TTL_MS }
            ?.let { cached ->
                val resolvedPoster = item.posterUrl.ifBlank { cached.posterUrl }
                val resolvedFallback = item.fallbackPosterUrl
                    .ifBlank { cached.posterUrl.takeIf { it.isNotBlank() && it != resolvedPoster }.orEmpty() }
                return item.copy(
                    posterUrl = resolvedPoster,
                    fallbackPosterUrl = resolvedFallback,
                    backdropUrl = currentBackdrop.ifBlank { cached.backdropUrl },
                    logoUrl = currentLogo.ifBlank { cached.logoUrl },
                    rating = item.rating.ifBlank { cached.rating },
                    yearOrRelease = item.yearOrRelease.ifBlank { cached.yearOrRelease },
                    genres = item.genres.ifEmpty { cached.genres },
                    description = item.description.ifBlank { cached.description }
                )
            }

        val mediaType = inferMediaType(
            rawType = item.stremioType ?: item.type,
            url = item.movieLinkUrl.orEmpty(),
            title = item.title
        )
        val yearHint = extractYearHint("${item.yearOrRelease} ${item.title}")
        val cleanTitle = cleanTitleForSearch(item.title)
        val itemId = item.stremioId.orEmpty()

        var tmdbData: TmdbEnrichment? = null
        if (settings.tmdbMetadataEnabled && settings.tmdbApiKey.isNotBlank() && (itemId.isNotBlank() || cleanTitle.isNotBlank())) {
            tmdbData = fetchTmdbForItem(
                apiKeyRaw = settings.tmdbApiKey,
                itemId = itemId,
                title = cleanTitle,
                year = yearHint,
                mediaType = mediaType
            )
        }

        var resolvedBackdrop = currentBackdrop.ifBlank { tmdbData?.backdropUrl.orEmpty() }
        var resolvedLogo = currentLogo.ifBlank { tmdbData?.logoUrl.orEmpty() }

        var cinemetaData: CinemetaArtwork? = null
        if (resolvedBackdrop.isBlank() || resolvedLogo.isBlank() || item.posterUrl.isBlank()) {
            val imdbHint = extractImdbId(itemId) ?: tmdbData?.imdbId
            cinemetaData = fetchCinemetaArtwork(
                imdbId = imdbHint,
                title = cleanTitle,
                year = yearHint,
                mediaType = mediaType
            )
            if (resolvedBackdrop.isBlank()) {
                resolvedBackdrop = cinemetaData?.background.orEmpty()
            }
            if (resolvedLogo.isBlank()) {
                resolvedLogo = cinemetaData?.logo.orEmpty()
            }
        }

        val enrichedPosterCandidate = tmdbData?.posterUrl.orEmpty()
            .ifBlank { cinemetaData?.poster.orEmpty() }
        val resolvedPoster = item.posterUrl.ifBlank { enrichedPosterCandidate }
        val resolvedFallbackPoster = listOf(
            item.fallbackPosterUrl,
            tmdbData?.posterUrl.orEmpty(),
            cinemetaData?.poster.orEmpty(),
            resolvedBackdrop
        ).firstOrNull { it.isNotBlank() && it != resolvedPoster }.orEmpty()

        val resolvedRating = item.rating.ifBlank { tmdbData?.voteAverage.orEmpty() }.ifBlank { cinemetaData?.imdbRating.orEmpty() }
        val resolvedYear = item.yearOrRelease.ifBlank { tmdbData?.releaseYear.orEmpty() }.ifBlank { cinemetaData?.releaseInfo.orEmpty() }
        val resolvedGenres = item.genres.ifEmpty { tmdbData?.genres.orEmpty() }.ifEmpty { cinemetaData?.genres.orEmpty() }
        val resolvedDesc = item.description.ifBlank { tmdbData?.overview.orEmpty() }.ifBlank { cinemetaData?.description.orEmpty() }

        if (resolvedBackdrop.isNotBlank() || resolvedLogo.isNotBlank() || resolvedPoster.isNotBlank()) {
            if (heroArtworkCache.size > MAX_HERO_CACHE) heroArtworkCache.clear()
            heroArtworkCache[cacheKey] = CachedHeroArtwork(
                fetchedAtMs = System.currentTimeMillis(),
                backdropUrl = resolvedBackdrop,
                logoUrl = resolvedLogo,
                posterUrl = enrichedPosterCandidate,
                rating = resolvedRating,
                yearOrRelease = resolvedYear,
                genres = resolvedGenres,
                description = resolvedDesc
            )
        }

        return item.copy(
            posterUrl = resolvedPoster,
            fallbackPosterUrl = resolvedFallbackPoster,
            backdropUrl = resolvedBackdrop,
            logoUrl = resolvedLogo,
            rating = resolvedRating,
            yearOrRelease = resolvedYear,
            genres = resolvedGenres,
            description = resolvedDesc
        )
    }

    suspend fun enrichMovieLinkDetail(
        detail: MediaDetail,
        settings: UserSettings,
        titleHint: String = ""
    ): MediaDetail {
        val mediaType = inferMediaType(
            rawType = detail.type,
            url = detail.url,
            title = "${detail.title} ${detail.subtitle} $titleHint"
        )
        val yearHint = extractYearHint("${detail.subtitle} ${detail.title} $titleHint ${detail.extraInfoLines.joinToString(" ")}")
        val titleCandidates = listOf(
            cleanTitleForSearch(detail.title),
            cleanTitleForSearch(titleHint)
        ).filter { it.isNotBlank() }.distinct()
        val primaryTitle = titleCandidates.firstOrNull().orEmpty()
        val initialImdb = detail.imdbId
            ?: extractImdbId("${detail.subtitle} ${detail.extraInfoLines.joinToString(" ")}")

        var tmdbData: TmdbEnrichment? = null
        if (settings.tmdbMetadataEnabled && settings.tmdbApiKey.isNotBlank() && (initialImdb != null || titleCandidates.isNotEmpty())) {
            tmdbData = fetchTmdbForItem(
                apiKeyRaw = settings.tmdbApiKey,
                itemId = initialImdb.orEmpty(),
                title = primaryTitle,
                year = yearHint,
                mediaType = mediaType
            )
            if (tmdbData == null && titleCandidates.size > 1) {
                tmdbData = fetchTmdbForItem(
                    apiKeyRaw = settings.tmdbApiKey,
                    itemId = "",
                    title = titleCandidates[1],
                    year = yearHint,
                    mediaType = mediaType
                )
            }
        }

        val resolvedImdb = initialImdb ?: tmdbData?.imdbId
        var resolvedBackdrop = detail.backdropUrl
            .takeIf { it.isNotBlank() && it != detail.posterUrl }
            .orEmpty()
            .ifBlank { tmdbData?.backdropUrl.orEmpty() }
        var resolvedLogo = detail.logoUrl.ifBlank { tmdbData?.logoUrl.orEmpty() }

        var cinemetaData: CinemetaArtwork? = null
        if (resolvedBackdrop.isBlank() || resolvedLogo.isBlank() || detail.posterUrl.isBlank()) {
            cinemetaData = fetchCinemetaArtwork(
                imdbId = resolvedImdb,
                title = primaryTitle,
                year = yearHint,
                mediaType = mediaType
            )
            if ((cinemetaData == null || (cinemetaData.background.isBlank() && cinemetaData.logo.isBlank())) && titleCandidates.size > 1) {
                val hintCinemeta = fetchCinemetaArtwork(
                    imdbId = null,
                    title = titleCandidates[1],
                    year = yearHint,
                    mediaType = mediaType
                )
                if (hintCinemeta != null) cinemetaData = hintCinemeta
            }
            if (resolvedBackdrop.isBlank()) {
                resolvedBackdrop = cinemetaData?.background.orEmpty()
            }
            if (resolvedLogo.isBlank()) {
                resolvedLogo = cinemetaData?.logo.orEmpty()
            }
        }

        val resolvedPoster = detail.posterUrl
            .ifBlank { tmdbData?.posterUrl.orEmpty() }
            .ifBlank { cinemetaData?.poster.orEmpty() }

        val finalImdb = resolvedImdb ?: cinemetaData?.imdbId
        val mdbRatings = if (settings.mdbListEnabled && settings.mdbListApiKey.isNotBlank()) {
            fetchMdbListRatings(
                apiKeyRaw = settings.mdbListApiKey,
                imdbId = finalImdb,
                tmdbId = tmdbData?.tmdbId,
                mediaType = mediaType
            )
        } else {
            emptyList()
        }

        val combinedRatings = mergeRatings(
            existing = detail.externalRatings,
            tmdbScore = tmdbData?.voteAverage?.takeIf { it.isNotBlank() } ?: cinemetaData?.imdbRating,
            mdbRatings = mdbRatings
        )

        val mergedGenres = detail.genres
            .ifEmpty { tmdbData?.genres.orEmpty() }
            .ifEmpty { cinemetaData?.genres.orEmpty() }

        return detail.copy(
            posterUrl = resolvedPoster,
            backdropUrl = resolvedBackdrop,
            logoUrl = resolvedLogo,
            genres = mergedGenres,
            imdbId = finalImdb,
            externalRatings = combinedRatings,
            screenshotUrls = detail.screenshotUrls.ifEmpty { tmdbData?.backdrops.orEmpty() }
        )
    }

    suspend fun fetchTitleLogoOnly(
        title: String,
        subtitle: String,
        mediaType: String,
        settings: UserSettings
    ): String {
        val yearHint = extractYearHint("$subtitle $title")
        val cleanTitle = cleanTitleForSearch(title)
        if (cleanTitle.isBlank()) return ""
        if (settings.tmdbMetadataEnabled && settings.tmdbApiKey.isNotBlank()) {
            val tmdbLogo = try {
                fetchTmdbForItem(
                    apiKeyRaw = settings.tmdbApiKey,
                    itemId = "",
                    title = cleanTitle,
                    year = yearHint,
                    mediaType = mediaType
                )?.logoUrl.orEmpty()
            } catch (_: Exception) {
                ""
            }
            if (tmdbLogo.isNotBlank()) return tmdbLogo
        }
        return fetchCinemetaArtwork(
            imdbId = null,
            title = cleanTitle,
            year = yearHint,
            mediaType = mediaType
        )?.logo.orEmpty()
    }

    suspend fun testTmdbConnection(apiKeyRaw: String): Result<String> {
        val cleanKey = apiKeyRaw.trim()
        if (cleanKey.isEmpty()) return Result.failure(IllegalArgumentException("Enter a TMDB API key or v4 token first"))
        return try {
            val (url, headers) = buildTmdbAuth("https://api.themoviedb.org/3/configuration", cleanKey)
            val json = AddonHttp.getJsonObjectWithHeaders(url, headers)
            val base = json.optJSONObject("images")?.optString("secure_base_url", "").orEmpty()
            if (base.isNotBlank()) {
                Result.success("Connected to TMDB API ($base)")
            } else {
                Result.success("Connected to TMDB API")
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun testMdbListConnection(apiKeyRaw: String): Result<String> {
        val cleanKey = apiKeyRaw.trim()
        if (cleanKey.isEmpty()) return Result.failure(IllegalArgumentException("Enter an MDBList (MDBD) API key first"))
        return try {
            val url = "https://api.mdblist.com/imdb/movie/tt0133093?apikey=${Uri.encode(cleanKey)}"
            val json = AddonHttp.getJsonObject(url)
            val err = json.optString("error", "").trim()
            if (err.isNotBlank()) {
                Result.failure(IllegalStateException(err))
            } else {
                val ratingsCount = json.optJSONArray("ratings")?.length() ?: 0
                Result.success("Connected to MDBList API ($ratingsCount rating sources)")
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun testBetterPoster(
        provider: Config.BetterPosterProvider,
        rpdbApiKey: String,
        customTemplate: String
    ): Result<String> = withContext(Dispatchers.IO) {
        if (provider == Config.BetterPosterProvider.NONE) {
            return@withContext Result.failure(IllegalArgumentException("Select Better Posters, RPDB, or Custom Template first"))
        }
        val sampleUrl = Config.buildBetterPosterUrl(
            provider = provider,
            imdbId = "tt0137523",
            rpdbApiKey = rpdbApiKey,
            customTemplate = customTemplate,
            mediaType = "movie"
        ) ?: return@withContext Result.failure(IllegalArgumentException("Enter a valid API key or http(s) template"))

        try {
            val req = Request.Builder()
                .url(sampleUrl)
                .header("User-Agent", Config.MOBILE_USER_AGENT)
                .build()
            AddonHttp.client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    Result.failure(IllegalStateException("Poster server returned HTTP ${resp.code}"))
                } else {
                    val ct = resp.header("Content-Type").orEmpty()
                    Result.success("Verified poster endpoint (${ct.ifBlank { "HTTP ${resp.code}" }})")
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private suspend fun fetchTmdbForItem(
        apiKeyRaw: String,
        itemId: String,
        title: String,
        year: String,
        mediaType: String
    ): TmdbEnrichment? {
        val isSeries = mediaType.equals("series", ignoreCase = true) ||
            mediaType.equals("tv", ignoreCase = true) ||
            mediaType.contains("series", ignoreCase = true)
        val cacheKey = "${apiKeyRaw.take(8)}|$itemId|$title|$year|$isSeries"
        tmdbCache[cacheKey]?.takeIf { System.currentTimeMillis() - it.fetchedAtMs < CACHE_TTL_MS }?.let {
            return it.value
        }

        return try {
            val imdbId = extractImdbId(itemId)
            var tmdbId = extractTmdbNumericId(itemId)
            var resolvedMediaKind = if (isSeries) "tv" else "movie"

            if (tmdbId == null && imdbId != null) {
                val (findUrl, findHdr) = buildTmdbAuth(
                    "https://api.themoviedb.org/3/find/${Uri.encode(imdbId)}?external_source=imdb_id",
                    apiKeyRaw
                )
                val findJson = AddonHttp.getJsonObjectWithHeaders(findUrl, findHdr)
                val movieHits = findJson.optJSONArray("movie_results")
                val tvHits = findJson.optJSONArray("tv_results")
                when {
                    !isSeries && movieHits != null && movieHits.length() > 0 -> {
                        tmdbId = movieHits.optJSONObject(0)?.optInt("id")?.takeIf { it > 0 }?.toString()
                        resolvedMediaKind = "movie"
                    }
                    tvHits != null && tvHits.length() > 0 -> {
                        tmdbId = tvHits.optJSONObject(0)?.optInt("id")?.takeIf { it > 0 }?.toString()
                        resolvedMediaKind = "tv"
                    }
                    movieHits != null && movieHits.length() > 0 -> {
                        tmdbId = movieHits.optJSONObject(0)?.optInt("id")?.takeIf { it > 0 }?.toString()
                        resolvedMediaKind = "movie"
                    }
                }
            }

            if (tmdbId == null && title.isNotBlank()) {
                val primaryEndpoint = if (isSeries) "search/tv" else "search/movie"
                val fallbackEndpoint = if (isSeries) "search/movie" else "search/tv"
                val cleanYear = year.trim().takeIf { it.length == 4 && it.all(Char::isDigit) }

                suspend fun searchTmdb(endpoint: String, yr: String?): String? {
                    val yearParam = yr?.let {
                        if (endpoint == "search/tv") "&first_air_date_year=$it" else "&year=$it"
                    }.orEmpty()
                    val (searchUrl, searchHdr) = buildTmdbAuth(
                        "https://api.themoviedb.org/3/$endpoint?query=${Uri.encode(title)}&include_adult=false$yearParam",
                        apiKeyRaw
                    )
                    val searchJson = AddonHttp.getJsonObjectWithHeaders(searchUrl, searchHdr)
                    val results = searchJson.optJSONArray("results")
                    return if (results != null && results.length() > 0) {
                        results.optJSONObject(0)?.optInt("id")?.takeIf { it > 0 }?.toString()
                    } else null
                }

                val hitPrimaryYear = if (cleanYear != null) searchTmdb(primaryEndpoint, cleanYear) else null
                if (hitPrimaryYear != null) {
                    tmdbId = hitPrimaryYear
                    resolvedMediaKind = if (primaryEndpoint == "search/tv") "tv" else "movie"
                } else {
                    val hitPrimaryNoYear = searchTmdb(primaryEndpoint, null)
                    if (hitPrimaryNoYear != null) {
                        tmdbId = hitPrimaryNoYear
                        resolvedMediaKind = if (primaryEndpoint == "search/tv") "tv" else "movie"
                    } else {
                        val hitAlt = searchTmdb(fallbackEndpoint, cleanYear)
                            ?: if (cleanYear != null) searchTmdb(fallbackEndpoint, null) else null
                        if (hitAlt != null) {
                            tmdbId = hitAlt
                            resolvedMediaKind = if (fallbackEndpoint == "search/tv") "tv" else "movie"
                        }
                    }
                }
            }

            if (tmdbId == null) return null

            val (detailUrl, detailHdr) = buildTmdbAuth(
                "https://api.themoviedb.org/3/$resolvedMediaKind/$tmdbId?append_to_response=credits,external_ids,images,recommendations&include_image_language=en,null",
                apiKeyRaw
            )
            val detailJson = AddonHttp.getJsonObjectWithHeaders(detailUrl, detailHdr)

            val extImdb = detailJson.optJSONObject("external_ids")?.optString("imdb_id", "")?.trim()
                ?.takeIf { it.startsWith("tt", ignoreCase = true) }
                ?: detailJson.optString("imdb_id", "").trim().takeIf { it.startsWith("tt", ignoreCase = true) }
                ?: imdbId
            val overview = detailJson.optString("overview", "").trim()
            val posterPath = detailJson.optString("poster_path", "").trim()
            val backdropPath = detailJson.optString("backdrop_path", "").trim()
            val posterUrl = if (posterPath.startsWith("/")) "https://image.tmdb.org/t/p/w780$posterPath" else ""
            val imagesObj = detailJson.optJSONObject("images")
            val backdropsArr = imagesObj?.optJSONArray("backdrops")
            val fallbackBackdropPath = if (backdropPath.startsWith("/")) {
                backdropPath
            } else {
                var firstBp = ""
                if (backdropsArr != null) {
                    for (i in 0 until backdropsArr.length()) {
                        val bp = backdropsArr.optJSONObject(i)?.optString("file_path", "")?.trim().orEmpty()
                        if (bp.startsWith("/") && !bp.endsWith(".svg", ignoreCase = true)) {
                            firstBp = bp
                            break
                        }
                    }
                }
                firstBp
            }
            val backdropUrl = if (fallbackBackdropPath.startsWith("/")) {
                "https://image.tmdb.org/t/p/w1280$fallbackBackdropPath"
            } else ""

            val logosArr = imagesObj?.optJSONArray("logos")
            val selectedLogo = selectBestTmdbLogoUrl(logosArr)

            val backdrops = buildList {
                if (backdropsArr != null) {
                    for (i in 0 until minOf(backdropsArr.length(), 10)) {
                        val bp = backdropsArr.optJSONObject(i)?.optString("file_path", "")?.trim().orEmpty()
                        if (bp.startsWith("/")) add("https://image.tmdb.org/t/p/w1280$bp")
                    }
                }
            }

            val recsArr = detailJson.optJSONObject("recommendations")?.optJSONArray("results")
            val recommendations = buildList {
                if (recsArr != null) {
                    for (i in 0 until minOf(recsArr.length(), 12)) {
                        val rObj = recsArr.optJSONObject(i) ?: continue
                        val rId = rObj.optInt("id", 0).takeIf { it > 0 }?.toString() ?: continue
                        val rTitle = rObj.optString("title", rObj.optString("name", "")).trim()
                        val rPoster = rObj.optString("poster_path", "").trim()
                        if (rTitle.isEmpty() || !rPoster.startsWith("/")) continue
                        val rVote = rObj.optDouble("vote_average", 0.0).takeIf { it > 0 }
                            ?.let { String.format(Locale.US, "%.1f", it) }.orEmpty()
                        val rRel = rObj.optString("release_date", rObj.optString("first_air_date", "")).trim().take(4)
                        add(
                            UnifiedPosterItem(
                                provider = ContentProviderKind.STREMIO_ADDON,
                                type = resolvedMediaKind,
                                title = rTitle,
                                posterUrl = "https://image.tmdb.org/t/p/w500$rPoster",
                                stremioId = "tmdb:$rId",
                                stremioType = resolvedMediaKind,
                                yearOrRelease = rRel,
                                rating = rVote
                            )
                        )
                    }
                }
            }

            val relDate = detailJson.optString("release_date", detailJson.optString("first_air_date", "")).trim()
            val relYear = relDate.take(4).takeIf { it.length == 4 && it.all(Char::isDigit) }.orEmpty()
            val voteAvg = detailJson.optDouble("vote_average", 0.0)
                .takeIf { it > 0.0 }
                ?.let { String.format(Locale.US, "%.1f", it) }
                .orEmpty()

            val runtimeMins = detailJson.optInt("runtime", 0)
                .takeIf { it > 0 }
                ?: detailJson.optJSONArray("episode_run_time")?.optInt(0, 0)?.takeIf { it > 0 }
            val runtimeStr = runtimeMins?.let { "$it min" }.orEmpty()

            val genresArr = detailJson.optJSONArray("genres")
            val genres = buildList {
                if (genresArr != null) {
                    for (i in 0 until genresArr.length()) {
                        val name = genresArr.optJSONObject(i)?.optString("name", "")?.trim().orEmpty()
                        if (name.isNotEmpty()) add(name)
                    }
                }
            }

            val castArr = detailJson.optJSONObject("credits")?.optJSONArray("cast")
            val cast = buildList {
                if (castArr != null) {
                    for (i in 0 until minOf(castArr.length(), 18)) {
                        val obj = castArr.optJSONObject(i) ?: continue
                        val name = obj.optString("name", "").trim()
                        if (name.isEmpty()) continue
                        val role = obj.optString("character", "").trim()
                        val profile = obj.optString("profile_path", "").trim()
                        val avatar = if (profile.startsWith("/")) "https://image.tmdb.org/t/p/w185$profile" else ""
                        add(AddonCastMember(name = name, role = role, avatarUrl = avatar))
                    }
                }
            }

            val parsed = TmdbEnrichment(
                tmdbId = tmdbId,
                imdbId = extImdb,
                overview = overview,
                posterUrl = posterUrl,
                backdropUrl = backdropUrl,
                logoUrl = selectedLogo,
                releaseYear = relYear,
                voteAverage = voteAvg,
                runtime = runtimeStr,
                genres = genres,
                cast = cast,
                backdrops = backdrops,
                recommendations = recommendations
            )
            if (tmdbCache.size > MAX_ENRICH_CACHE) tmdbCache.clear()
            tmdbCache[cacheKey] = CachedTmdb(System.currentTimeMillis(), parsed)
            parsed
        } catch (_: Exception) {
            null
        }
    }

    private suspend fun fetchMdbListRatings(
        apiKeyRaw: String,
        imdbId: String?,
        tmdbId: String?,
        mediaType: String
    ): List<ExternalRatingBadge> {
        val cleanKey = apiKeyRaw.trim()
        if (cleanKey.isEmpty()) return emptyList()
        val provider = when {
            !imdbId.isNullOrBlank() -> "imdb"
            !tmdbId.isNullOrBlank() -> "tmdb"
            else -> return emptyList()
        }
        val idValue = if (provider == "imdb") imdbId!! else tmdbId!!
        val typeSeg = if (mediaType.equals("series", true) || mediaType.equals("tv", true) || mediaType.contains("series", true)) {
            "show"
        } else {
            "movie"
        }

        val cacheKey = "${cleanKey.take(6)}|$provider|$typeSeg|$idValue"
        mdbCache[cacheKey]?.takeIf { System.currentTimeMillis() - it.fetchedAtMs < CACHE_TTL_MS }?.let {
            return it.value
        }

        return try {
            val url = "https://api.mdblist.com/$provider/$typeSeg/${Uri.encode(idValue)}?apikey=${Uri.encode(cleanKey)}"
            val json = AddonHttp.getJsonObject(url)
            val arr = json.optJSONArray("ratings") ?: return emptyList()
            val list = buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val src = obj.optString("source", "").trim().lowercase(Locale.US)
                    val valueNum = obj.opt("value")
                    if (src.isEmpty() || valueNum == null || valueNum == JSONObject.NULL) continue
                    val valueStr = valueNum.toString().trim()
                    if (valueStr.isEmpty() || valueStr == "0" || valueStr == "0.0") continue

                    val (label, formattedVal) = when (src) {
                        "imdb" -> "IMDb" to valueStr
                        "tomatoes" -> "RT" to "$valueStr%"
                        "tomatoesaudience" -> "RT Audience" to "$valueStr%"
                        "metacritic" -> "Metacritic" to valueStr
                        "trakt" -> "Trakt" to "$valueStr%"
                        "letterboxd" -> "Letterboxd" to valueStr
                        "tmdb" -> "TMDB" to "$valueStr%"
                        "rogerebert" -> "Ebert" to valueStr
                        else -> src.replaceFirstChar { it.uppercase() } to valueStr
                    }
                    add(ExternalRatingBadge(source = label, value = formattedVal))
                }
            }.distinctBy { it.source }.take(6)

            if (mdbCache.size > MAX_ENRICH_CACHE) mdbCache.clear()
            mdbCache[cacheKey] = CachedRatings(System.currentTimeMillis(), list)
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun mergeRatings(
        existing: List<ExternalRatingBadge>,
        tmdbScore: String?,
        mdbRatings: List<ExternalRatingBadge>
    ): List<ExternalRatingBadge> {
        val map = linkedMapOf<String, ExternalRatingBadge>()
        existing.forEach { map[it.source.lowercase(Locale.US)] = it }
        mdbRatings.forEach { map[it.source.lowercase(Locale.US)] = it }
        if (!tmdbScore.isNullOrBlank() && !map.containsKey("tmdb")) {
            map["tmdb"] = ExternalRatingBadge("TMDB", tmdbScore)
        }
        return map.values.toList()
    }

    private fun selectBestTmdbLogoUrl(logosArr: JSONArray?): String {
        if (logosArr == null || logosArr.length() == 0) return ""
        data class Candidate(val path: String, val langRank: Int, val voteAvg: Double)
        val candidates = buildList {
            for (i in 0 until logosArr.length()) {
                val obj = logosArr.optJSONObject(i) ?: continue
                val fp = obj.optString("file_path", "").trim()
                if (!fp.startsWith("/") || fp.endsWith(".svg", ignoreCase = true)) continue
                val lang = if (obj.isNull("iso_639_1")) "" else obj.optString("iso_639_1", "").trim().lowercase(Locale.US)
                val rank = when (lang) {
                    "en" -> 3
                    "" -> 2
                    else -> 1
                }
                val vote = obj.optDouble("vote_average", 0.0)
                add(Candidate(fp, rank, vote))
            }
        }
        val best = candidates.sortedWith(
            compareByDescending<Candidate> { it.langRank }
                .thenByDescending { it.voteAvg }
        ).firstOrNull() ?: return ""
        return "https://image.tmdb.org/t/p/w500${best.path}"
    }

    private suspend fun fetchCinemetaArtwork(
        imdbId: String?,
        title: String,
        year: String,
        mediaType: String
    ): CinemetaArtwork? {
        val isSeries = mediaType.equals("series", true) ||
            mediaType.equals("tv", true) ||
            mediaType.contains("series", true)
        val primaryType = if (isSeries) "series" else "movie"
        val secondaryType = if (isSeries) "movie" else "series"
        val cleanImdb = imdbId?.takeIf { it.startsWith("tt", ignoreCase = true) }
        val cleanTitle = title.trim()
        if (cleanImdb == null && cleanTitle.isBlank()) return null

        val cacheKey = "${cleanImdb.orEmpty()}|$cleanTitle|$year|$primaryType"
        cinemetaCache[cacheKey]?.takeIf { System.currentTimeMillis() - it.fetchedAtMs < HERO_CACHE_TTL_MS }?.let {
            return it.value
        }

        return try {
            var resolvedImdb = cleanImdb
            var metaObj: JSONObject? = null

            if (resolvedImdb != null) {
                metaObj = runCatching {
                    AddonHttp.getJsonObject("https://v3-cinemeta.strem.io/meta/$primaryType/${Uri.encode(resolvedImdb)}.json")
                        .optJSONObject("meta")
                }.getOrNull() ?: runCatching {
                    AddonHttp.getJsonObject("https://v3-cinemeta.strem.io/meta/$secondaryType/${Uri.encode(resolvedImdb)}.json")
                        .optJSONObject("meta")
                }.getOrNull()
            } else {
                suspend fun searchCinemeta(type: String): JSONObject? {
                    val json = AddonHttp.getJsonObject(
                        "https://v3-cinemeta.strem.io/catalog/$type/top/search=${Uri.encode(cleanTitle)}.json"
                    )
                    val arr = json.optJSONArray("metas") ?: return null
                    if (arr.length() == 0) return null
                    var bestObj: JSONObject? = null
                    var bestScore = Int.MIN_VALUE
                    val targetLower = cleanTitle.lowercase(Locale.US)
                    for (i in 0 until minOf(arr.length(), 8)) {
                        val candidate = arr.optJSONObject(i) ?: continue
                        val cName = candidate.optString("name", "").trim()
                        val cRel = candidate.optString("releaseInfo", "").trim()
                        var score = 0
                        if (cName.equals(cleanTitle, ignoreCase = true)) score += 100
                        else if (cName.lowercase(Locale.US).contains(targetLower) || targetLower.contains(cName.lowercase(Locale.US))) score += 40
                        if (year.isNotBlank() && cRel.contains(year)) score += 50
                        if (candidate.optString("background", "").isNotBlank()) score += 10
                        if (candidate.optString("logo", "").isNotBlank()) score += 10
                        score -= i
                        if (score > bestScore) {
                            bestScore = score
                            bestObj = candidate
                        }
                    }
                    return bestObj
                }

                metaObj = runCatching { searchCinemeta(primaryType) }.getOrNull()
                    ?: runCatching { searchCinemeta(secondaryType) }.getOrNull()
                val foundId = metaObj?.optString("id", "")?.trim()
                    ?.takeIf { it.startsWith("tt", ignoreCase = true) }
                if (foundId != null) {
                    resolvedImdb = foundId
                    val foundType = metaObj?.optString("type", primaryType)?.ifBlank { primaryType } ?: primaryType
                    val fullMeta = runCatching {
                        AddonHttp.getJsonObject("https://v3-cinemeta.strem.io/meta/$foundType/${Uri.encode(foundId)}.json")
                            .optJSONObject("meta")
                    }.getOrNull()
                    if (fullMeta != null) metaObj = fullMeta
                }
            }

            if (metaObj == null && resolvedImdb == null) return null

            val bg = metaObj?.optString("background", "")?.trim()
                ?.takeIf { it.startsWith("http", true) }
                .orEmpty()
                .ifBlank {
                    resolvedImdb?.let { "https://images.metahub.space/background/medium/$it/img" }.orEmpty()
                }
            val logo = metaObj?.optString("logo", "")?.trim()
                ?.takeIf { it.startsWith("http", true) }
                .orEmpty()
                .ifBlank {
                    resolvedImdb?.let { "https://images.metahub.space/logo/medium/$it/img" }.orEmpty()
                }
            val poster = metaObj?.optString("poster", "")?.trim()
                ?.takeIf { it.startsWith("http", true) }
                .orEmpty()
            val releaseInfo = metaObj?.optString("releaseInfo", "")?.trim().orEmpty()
            val ratingRaw = metaObj?.optString("imdbRating", "")?.trim()
                ?.takeIf { it.isNotBlank() && !it.equals("null", true) && !it.equals("N/A", true) }
                .orEmpty()
            val desc = metaObj?.optString("description", "")?.trim().orEmpty()
            val genres = buildList {
                val gArr = metaObj?.optJSONArray("genres")
                if (gArr != null) {
                    for (i in 0 until gArr.length()) {
                        val g = gArr.optString(i, "").trim()
                        if (g.isNotEmpty()) add(g)
                    }
                }
            }

            val parsed = CinemetaArtwork(
                imdbId = resolvedImdb,
                background = bg,
                logo = logo,
                poster = poster,
                releaseInfo = releaseInfo,
                imdbRating = ratingRaw,
                genres = genres,
                description = desc
            )
            if (cinemetaCache.size > MAX_HERO_CACHE) cinemetaCache.clear()
            cinemetaCache[cacheKey] = CachedCinemeta(System.currentTimeMillis(), parsed)
            parsed
        } catch (_: Exception) {
            null
        }
    }

    private fun inferMediaType(rawType: String, url: String, title: String): String {
        val combined = "$rawType $url $title".lowercase(Locale.US)
        return if (
            combined.contains("series") ||
            combined.contains("/tv") ||
            combined.contains("tv show") ||
            combined.contains("drama") ||
            combined.contains("anime") ||
            Regex("""\bseason\s*\d+|\bs\d{1,2}e?\d{0,2}\b""", RegexOption.IGNORE_CASE).containsMatchIn(combined)
        ) {
            "series"
        } else {
            "movie"
        }
    }

    private fun extractYearHint(text: String): String {
        val matches = Regex("""\b(19\d{2}|20[0-3]\d)\b""").findAll(text).toList()
        return matches.lastOrNull()?.value.orEmpty()
    }

    private fun buildTmdbAuth(baseUrl: String, apiKeyRaw: String): Pair<String, Map<String, String>> {
        val clean = apiKeyRaw.trim()
        // TMDB v4 Read Access Tokens are JWTs starting with "eyJ" or explicitly > 45 chars
        return if (clean.startsWith("eyJ") || clean.length > 45) {
            baseUrl to mapOf("Authorization" to "Bearer $clean")
        } else {
            val sep = if (baseUrl.contains('?')) "&" else "?"
            "$baseUrl${sep}api_key=${Uri.encode(clean)}" to emptyMap()
        }
    }

    private fun extractImdbId(raw: String): String? {
        val match = Regex("""tt\d{5,}""", RegexOption.IGNORE_CASE).find(raw)
        return match?.value?.lowercase(Locale.US)
    }

    private fun extractTmdbNumericId(raw: String): String? {
        val trimmed = raw.trim()
        return when {
            trimmed.startsWith("tmdb:", ignoreCase = true) ->
                trimmed.substringAfter(':').substringBefore(':').trim().takeIf { it.all(Char::isDigit) }
            else -> null
        }
    }

    private fun cleanTitleForSearch(rawTitle: String): String {
        return rawTitle
            .replace(Regex("""^\s*(?i)(download|watch\s+online|watch|stream|free)\s+"""), "")
            .replace(Regex("""\[[^\]]*]"""), " ")
            .replace(Regex("""\((19|20)\d{2}[^)]*\)"""), " ")
            .replace(Regex("""(?i)\b(19\d{2}|20[0-3]\d)\b"""), " ")
            .replace(
                Regex(
                    """(?i)\b(movielinkbd|mlbd|480p|720p|1080p|2160p|4k|uhd|fhd|hdrip|web-?dl|web-?rip|bluray|brrip|dvdrip|hevc|x264|x265|10bit|aac|ddp?5\.1|dual\s*audio|multi\s*audio|hindi|bengali|bangla|english|tamil|telugu|malayalam|korean|japanese|dubbed|subbed|e?sub|uncut|extended|remastered|season\s*\d+|s\d{1,2}(?:e\d{1,2})?|episode\s*\d+|full\s*movie|movie\s*download|full\s*series|all\s*episodes|complete)\b"""
                ),
                " "
            )
            .replace(Regex("""[|/:•–—]+"""), " ")
            .replace(Regex("""\s+-\s+.*$"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim(' ', '-', '_', '.', ',')
    }

    companion object {
        private const val CACHE_TTL_MS = 15 * 60 * 1000L
        private const val HERO_CACHE_TTL_MS = 30 * 60 * 1000L
        private const val MAX_ENRICH_CACHE = 60
        private const val MAX_HERO_CACHE = 120
    }
}
