package com.personal.movielink

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

class MetadataEnrichmentService {
    private val client = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .callTimeout(8, TimeUnit.SECONDS)
        .build()

    private val tmdbCache = ConcurrentHashMap<String, TmdbBundle>()
    private val mdbRatingsCache = ConcurrentHashMap<String, List<ExternalRatingBadge>>()

    suspend fun testTmdbConnection(apiKey: String): Result<String> = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("Enter a TMDB API v3 key first"))
        }
        try {
            val url = "https://api.themoviedb.org/3/configuration?api_key=${encode(cleanKey)}"
            val json = fetchJsonObject(url)
                ?: return@withContext Result.failure(IllegalStateException("Empty TMDB response"))
            val images = json.optJSONObject("images")
            if (images != null) {
                Result.success("TMDB connected")
            } else {
                Result.failure(IllegalStateException("Invalid TMDB configuration response"))
            }
        } catch (e: Exception) {
            Result.failure(IllegalStateException(e.message ?: "TMDB connection failed"))
        }
    }

    suspend fun testMdbListConnection(apiKey: String): Result<String> = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("Enter an MDBList API key first"))
        }
        try {
            val url = "https://mdblist.com/api/?apikey=${encode(cleanKey)}&i=tt0133093"
            val json = fetchJsonObject(url)
                ?: return@withContext Result.failure(IllegalStateException("Empty MDBList response"))
            if (json.has("error")) {
                Result.failure(IllegalStateException(json.optString("error", "MDBList error")))
            } else {
                val title = json.optString("title", "Connected")
                Result.success("MDBList connected ($title)")
            }
        } catch (e: Exception) {
            Result.failure(IllegalStateException(e.message ?: "MDBList connection failed"))
        }
    }

    suspend fun testBetterPoster(
        provider: Config.BetterPosterProvider,
        rpdbApiKey: String,
        customTemplate: String
    ): Result<String> = withContext(Dispatchers.IO) {
        if (provider == Config.BetterPosterProvider.NONE) {
            return@withContext Result.failure(IllegalArgumentException("Select a Better Poster provider first"))
        }
        val testUrl = Config.buildBetterPosterUrl(
            provider = provider,
            imdbId = "tt0133093",
            rpdbApiKey = rpdbApiKey,
            customTemplate = customTemplate,
            mediaType = "movie"
        ) ?: return@withContext Result.failure(IllegalArgumentException("Enter a valid API key or URL template"))

        try {
            val req = Request.Builder()
                .url(testUrl)
                .header("User-Agent", Config.MOBILE_USER_AGENT)
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("HTTP ${resp.code} from ${provider.label}"))
                }
                val contentType = resp.header("Content-Type").orEmpty().lowercase(Locale.US)
                if (contentType.contains("image")) {
                    Result.success("${provider.label} verified")
                } else {
                    Result.failure(IllegalStateException("URL did not return an image"))
                }
            }
        } catch (e: Exception) {
            Result.failure(IllegalStateException(e.message ?: "Failed to reach ${provider.label}"))
        }
    }

    suspend fun enrichHeroItem(
        item: UnifiedPosterItem,
        settings: UserSettings
    ): UnifiedPosterItem = withContext(Dispatchers.IO) {
        val tmdbKey = settings.tmdbApiKey.trim()
        val hasTmdb = settings.tmdbMetadataEnabled && tmdbKey.isNotEmpty()
        val hasBetterPoster = settings.betterPosterProvider != Config.BetterPosterProvider.NONE
        if (!hasTmdb && !hasBetterPoster) {
            return@withContext item
        }

        val cleanedQuery = cleanSearchTitle(item.title)
        val yearHint = extractYear(item.yearOrRelease).ifBlank { extractYear(item.title) }
        val isSeries = item.type.contains("series", ignoreCase = true) ||
            item.type.contains("tv", ignoreCase = true) ||
            item.type.contains("drama", ignoreCase = true) ||
            item.type.contains("anime", ignoreCase = true)

        val tmdbBundle = if (hasTmdb && cleanedQuery.isNotBlank()) {
            fetchTmdbBundle(
                apiKey = tmdbKey,
                imdbId = item.imdbId,
                title = cleanedQuery,
                year = yearHint,
                preferSeries = isSeries
            )
        } else null

        val resolvedImdbId = item.imdbId?.takeIf { it.startsWith("tt", ignoreCase = true) }
            ?: tmdbBundle?.imdbId

        val betterPosterUrl = if (hasBetterPoster && !resolvedImdbId.isNullOrBlank()) {
            Config.buildBetterPosterUrl(
                provider = settings.betterPosterProvider,
                imdbId = resolvedImdbId,
                rpdbApiKey = settings.rpdbApiKey,
                customTemplate = settings.betterPosterCustomTemplate,
                mediaType = if (isSeries) "series" else "movie"
            )
        } else null

        val mergedPoster = betterPosterUrl
            ?: item.posterUrl.ifBlank { tmdbBundle?.posterUrl.orEmpty() }
        val mergedFallback = listOf(item.fallbackPosterUrl, item.posterUrl, tmdbBundle?.posterUrl.orEmpty())
            .firstOrNull { it.isNotBlank() && it != mergedPoster }
            .orEmpty()

        item.copy(
            posterUrl = mergedPoster,
            fallbackPosterUrl = mergedFallback,
            backdropUrl = tmdbBundle?.backdropUrl?.takeIf { it.isNotBlank() } ?: item.backdropUrl,
            logoUrl = tmdbBundle?.logoUrl?.takeIf { it.isNotBlank() } ?: item.logoUrl,
            rating = item.rating.ifBlank { tmdbBundle?.rating.orEmpty() },
            yearOrRelease = item.yearOrRelease.ifBlank { tmdbBundle?.year.orEmpty() },
            genres = item.genres.ifEmpty { tmdbBundle?.genres.orEmpty() },
            description = item.description.ifBlank { tmdbBundle?.overview.orEmpty() },
            imdbId = resolvedImdbId
        )
    }

    suspend fun enrichMovieLinkDetail(
        detail: MediaDetail,
        settings: UserSettings,
        titleHint: String = ""
    ): MediaDetail = withContext(Dispatchers.IO) {
        val tmdbKey = settings.tmdbApiKey.trim()
        val mdbKey = settings.mdbListApiKey.trim()
        val hasTmdb = settings.tmdbMetadataEnabled && tmdbKey.isNotEmpty()
        val hasMdb = settings.mdbListEnabled && mdbKey.isNotEmpty()
        val hasBetterPoster = settings.betterPosterProvider != Config.BetterPosterProvider.NONE

        if (!hasTmdb && !hasMdb && !hasBetterPoster) {
            return@withContext detail
        }

        val queryTitle = cleanSearchTitle(detail.title.ifBlank { titleHint })
        val yearHint = extractYear(detail.subtitle)
            .ifBlank { extractYear(detail.title) }
            .ifBlank { detail.extraInfoLines.firstNotNullOfOrNull { extractYear(it).takeIf { y -> y.isNotBlank() } }.orEmpty() }

        val isSeries = detail.episodes.isNotEmpty() ||
            detail.type.contains("series", ignoreCase = true) ||
            detail.type.contains("tv", ignoreCase = true) ||
            detail.type.contains("drama", ignoreCase = true) ||
            detail.type.contains("anime", ignoreCase = true)

        val tmdbBundle = if (hasTmdb && queryTitle.isNotBlank()) {
            fetchTmdbBundle(
                apiKey = tmdbKey,
                imdbId = detail.imdbId,
                title = queryTitle,
                year = yearHint,
                preferSeries = isSeries
            )
        } else null

        val resolvedImdbId = detail.imdbId?.takeIf { it.startsWith("tt", ignoreCase = true) }
            ?: tmdbBundle?.imdbId

        val mdbResult = if (hasMdb) {
            fetchMdbRatings(
                apiKey = mdbKey,
                imdbId = resolvedImdbId,
                title = queryTitle,
                year = yearHint,
                isSeries = isSeries
            )
        } else null

        val finalImdbId = resolvedImdbId ?: mdbResult?.second

        val betterPosterUrl = if (hasBetterPoster && !finalImdbId.isNullOrBlank()) {
            Config.buildBetterPosterUrl(
                provider = settings.betterPosterProvider,
                imdbId = finalImdbId,
                rpdbApiKey = settings.rpdbApiKey,
                customTemplate = settings.betterPosterCustomTemplate,
                mediaType = if (isSeries) "series" else "movie"
            )
        } else null

        val combinedBadges = buildList {
            tmdbBundle?.rating?.takeIf { it.isNotBlank() }?.let {
                add(ExternalRatingBadge("TMDB", "$it/10"))
            }
            addAll(mdbResult?.first.orEmpty())
            addAll(detail.externalRatings)
        }.distinctBy { it.source.lowercase(Locale.US) }

        detail.copy(
            posterUrl = betterPosterUrl ?: detail.posterUrl.ifBlank { tmdbBundle?.posterUrl.orEmpty() },
            backdropUrl = tmdbBundle?.backdropUrl?.takeIf { it.isNotBlank() }
                ?: detail.backdropUrl,
            logoUrl = tmdbBundle?.logoUrl?.takeIf { it.isNotBlank() }
                ?: detail.logoUrl,
            genres = detail.genres.ifEmpty { tmdbBundle?.genres.orEmpty() },
            storyline = detail.storyline.ifBlank { tmdbBundle?.overview.orEmpty() },
            externalRatings = combinedBadges,
            imdbId = finalImdbId
        )
    }

    private data class TmdbBundle(
        val imdbId: String? = null,
        val backdropUrl: String = "",
        val posterUrl: String = "",
        val logoUrl: String = "",
        val rating: String = "",
        val year: String = "",
        val overview: String = "",
        val genres: List<String> = emptyList()
    )

    private fun fetchTmdbBundle(
        apiKey: String,
        imdbId: String?,
        title: String,
        year: String,
        preferSeries: Boolean
    ): TmdbBundle? {
        val cacheKey = "${imdbId.orEmpty()}|${title.lowercase(Locale.US)}|$year|$preferSeries"
        tmdbCache[cacheKey]?.let { return it }

        val cleanImdb = imdbId?.trim()?.takeIf { it.startsWith("tt", ignoreCase = true) }
        var mediaType: String? = null
        var tmdbId = 0

        if (cleanImdb != null) {
            val findUrl = "https://api.themoviedb.org/3/find/${encode(cleanImdb)}?api_key=${encode(apiKey)}&external_source=imdb_id"
            val findObj = fetchJsonObject(findUrl)
            val movieHit = findObj?.optJSONArray("movie_results")?.optJSONObject(0)
            val tvHit = findObj?.optJSONArray("tv_results")?.optJSONObject(0)
            if (preferSeries && tvHit != null) {
                mediaType = "tv"
                tmdbId = tvHit.optInt("id", 0)
            } else if (movieHit != null) {
                mediaType = "movie"
                tmdbId = movieHit.optInt("id", 0)
            } else if (tvHit != null) {
                mediaType = "tv"
                tmdbId = tvHit.optInt("id", 0)
            }
        }

        if (tmdbId <= 0 && title.isNotBlank()) {
            val yearParam = if (year.length == 4) {
                if (preferSeries) "&first_air_date_year=$year" else "&year=$year"
            } else ""
            val primaryType = if (preferSeries) "tv" else "movie"
            val primaryUrl = "https://api.themoviedb.org/3/search/$primaryType?api_key=${encode(apiKey)}&query=${encode(title)}$yearParam"
            val primaryHit = fetchJsonObject(primaryUrl)?.optJSONArray("results")?.optJSONObject(0)
            if (primaryHit != null) {
                mediaType = primaryType
                tmdbId = primaryHit.optInt("id", 0)
            } else {
                val multiUrl = "https://api.themoviedb.org/3/search/multi?api_key=${encode(apiKey)}&query=${encode(title)}"
                val results = fetchJsonObject(multiUrl)?.optJSONArray("results")
                if (results != null) {
                    for (i in 0 until results.length()) {
                        val obj = results.optJSONObject(i) ?: continue
                        val mt = obj.optString("media_type", "")
                        if (mt == "movie" || mt == "tv") {
                            mediaType = mt
                            tmdbId = obj.optInt("id", 0)
                            if (tmdbId > 0) break
                        }
                    }
                }
            }
        }

        if (tmdbId <= 0 || mediaType == null) return null

        val detailUrl = "https://api.themoviedb.org/3/$mediaType/$tmdbId?api_key=${encode(apiKey)}&append_to_response=images,external_ids&include_image_language=en,null"
        val detailObj = fetchJsonObject(detailUrl) ?: return null

        val backdropPath = detailObj.optString("backdrop_path", "").trim()
        val posterPath = detailObj.optString("poster_path", "").trim()
        val logos = detailObj.optJSONObject("images")?.optJSONArray("logos")
        val pickedLogo = pickBestTmdbLogo(logos)

        val resolvedImdb = detailObj.optJSONObject("external_ids")
            ?.optString("imdb_id", "")
            ?.takeIf { it.startsWith("tt", ignoreCase = true) }
            ?: detailObj.optString("imdb_id", "").takeIf { it.startsWith("tt", ignoreCase = true) }
            ?: cleanImdb

        val vote = detailObj.optDouble("vote_average", 0.0)
        val ratingStr = if (vote > 0.1) String.format(Locale.US, "%.1f", vote) else ""
        val releaseRaw = detailObj.optString("release_date", "")
            .ifBlank { detailObj.optString("first_air_date", "") }
        val resolvedYear = releaseRaw.take(4).takeIf { it.length == 4 }.orEmpty()

        val genreArr = detailObj.optJSONArray("genres")
        val genres = buildList {
            if (genreArr != null) {
                for (i in 0 until genreArr.length()) {
                    val gName = genreArr.optJSONObject(i)?.optString("name", "").orEmpty().trim()
                    if (gName.isNotEmpty()) add(gName)
                }
            }
        }

        val bundle = TmdbBundle(
            imdbId = resolvedImdb,
            backdropUrl = if (backdropPath.isNotBlank()) "https://image.tmdb.org/t/p/w1280$backdropPath" else "",
            posterUrl = if (posterPath.isNotBlank()) "https://image.tmdb.org/t/p/w780$posterPath" else "",
            logoUrl = if (pickedLogo.isNotBlank()) "https://image.tmdb.org/t/p/w500$pickedLogo" else "",
            rating = ratingStr,
            year = resolvedYear,
            overview = detailObj.optString("overview", "").trim(),
            genres = genres
        )
        tmdbCache[cacheKey] = bundle
        return bundle
    }

    private fun pickBestTmdbLogo(logos: JSONArray?): String {
        if (logos == null || logos.length() == 0) return ""
        var bestEn = ""
        var bestAny = ""
        for (i in 0 until logos.length()) {
            val obj = logos.optJSONObject(i) ?: continue
            val path = obj.optString("file_path", "").trim()
            if (path.isBlank() || path.endsWith(".svg", ignoreCase = true)) continue
            val lang = obj.optString("iso_639_1", "").trim().lowercase(Locale.US)
            if (lang == "en" && bestEn.isEmpty()) {
                bestEn = path
                break
            }
            if (bestAny.isEmpty()) {
                bestAny = path
            }
        }
        return bestEn.ifBlank { bestAny }
    }

    private fun fetchMdbRatings(
        apiKey: String,
        imdbId: String?,
        title: String,
        year: String,
        isSeries: Boolean
    ): Pair<List<ExternalRatingBadge>, String?>? {
        val cleanImdb = imdbId?.trim()?.takeIf { it.startsWith("tt", ignoreCase = true) }
        val cacheKey = cleanImdb ?: "${title.lowercase(Locale.US)}|$year|$isSeries"
        mdbRatingsCache[cacheKey]?.let { return it to cleanImdb }

        val url = if (cleanImdb != null) {
            "https://mdblist.com/api/?apikey=${encode(apiKey)}&i=${encode(cleanImdb)}"
        } else if (title.isNotBlank()) {
            val mParam = if (isSeries) "show" else "movie"
            val yParam = if (year.length == 4) "&y=$year" else ""
            "https://mdblist.com/api/?apikey=${encode(apiKey)}&s=${encode(title)}&m=$mParam$yParam"
        } else {
            return null
        }

        val root = fetchJsonObject(url) ?: return null
        val targetObj = if (cleanImdb != null) {
            root
        } else {
            val firstSearchId = root.optJSONArray("search")?.optJSONObject(0)?.optString("imdbid", "").orEmpty()
            if (firstSearchId.startsWith("tt", ignoreCase = true)) {
                fetchJsonObject("https://mdblist.com/api/?apikey=${encode(apiKey)}&i=${encode(firstSearchId)}") ?: root
            } else {
                root
            }
        }

        val resolvedImdb = targetObj.optString("imdbid", "").takeIf { it.startsWith("tt", ignoreCase = true) }
            ?: cleanImdb
        val badges = mutableListOf<ExternalRatingBadge>()
        val ratingsArr = targetObj.optJSONArray("ratings")
        if (ratingsArr != null) {
            for (i in 0 until ratingsArr.length()) {
                val rObj = ratingsArr.optJSONObject(i) ?: continue
                val src = rObj.optString("source", "").trim()
                val valAny = rObj.opt("value") ?: continue
                val valStr = valAny.toString().trim()
                if (src.isEmpty() || valStr.isEmpty() || valStr == "null" || valStr == "0") continue
                val label = when (src.lowercase(Locale.US)) {
                    "imdb" -> "IMDb"
                    "tomatoes" -> "Rotten Tomatoes"
                    "tomatoesaudience" -> "RT Audience"
                    "metacritic" -> "Metacritic"
                    "trakt" -> "Trakt"
                    "letterboxd" -> "Letterboxd"
                    "tmdb" -> "TMDB"
                    else -> src.replaceFirstChar { it.uppercase() }
                }
                val formatted = when (src.lowercase(Locale.US)) {
                    "tomatoes", "tomatoesaudience", "metacritic", "trakt" ->
                        if (valStr.endsWith("%")) valStr else "$valStr%"
                    else -> valStr
                }
                badges.add(ExternalRatingBadge(label, formatted))
            }
        }
        if (badges.isNotEmpty()) {
            mdbRatingsCache[cacheKey] = badges
        }
        return badges to resolvedImdb
    }

    private fun fetchJsonObject(url: String): JSONObject? {
        return try {
            val req = Request.Builder()
                .url(url)
                .header("Accept", "application/json")
                .header("User-Agent", Config.MOBILE_USER_AGENT)
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val body = resp.body?.string().orEmpty()
                if (body.isBlank()) null else JSONObject(body)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun cleanSearchTitle(raw: String): String {
        return raw
            .replace(Regex("""\((?:19|20)\d{2}\)"""), " ")
            .replace(Regex("""\[[^\]]*\]"""), " ")
            .replace(Regex("""(?i)\b(480p|720p|1080p|2160p|4k|web-dl|webrip|bluray|hdrip|hevc|x264|x265|dual audio|bangla|hindi dubbed|english|season \d+)\b.*"""), "")
            .replace(Regex("""\s+"""), " ")
            .trim()
    }

    private fun extractYear(raw: String): String {
        val m = Regex("""\b(19\d{2}|20\d{2})\b""").find(raw)
        return m?.groupValues?.getOrNull(1).orEmpty()
    }

    private fun encode(v: String): String = URLEncoder.encode(v, "UTF-8")
}
