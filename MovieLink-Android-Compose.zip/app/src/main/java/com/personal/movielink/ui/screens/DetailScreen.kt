package com.personal.movielink.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.FormatListBulleted
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.OpenInBrowser
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.ColorUtils
import coil.ImageLoader
import coil.compose.AsyncImage
import com.personal.movielink.Config
import com.personal.movielink.DownloadAndPlayerRouter
import com.personal.movielink.DownloadOption
import com.personal.movielink.MediaCard
import com.personal.movielink.MediaDetail
import com.personal.movielink.UserSettings
import com.personal.movielink.ui.components.SingleCoverScreenshotsSection
import com.personal.movielink.ui.components.focusedAlignment
import com.personal.movielink.ui.components.rememberBackdropFocusState
import com.personal.movielink.ui.components.revealAlpha
import com.personal.movielink.ui.components.scaleHeroBannerHeight
import com.personal.movielink.ui.theme.LocalMovieLinkPalette

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    detail: MediaDetail?,
    currentUrl: String,
    isLoading: Boolean,
    errorMessage: String?,
    settings: UserSettings,
    imageLoader: ImageLoader,
    isInMyList: Boolean,
    myListCount: Int,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
    onWatchTrailer: (String) -> Unit,
    onToggleMyList: (MediaDetail) -> Unit,
    onOpenMyListDialog: () -> Unit,
    onWatchOnline: (String, MediaDetail) -> Unit,
    onDownloadOption: (DownloadOption, MediaDetail) -> Unit,
    onOpenRelated: (MediaCard) -> Unit,
    onOpenFallbackWeb: (String) -> Unit,
    onOpenSettings: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.pageBg)
    ) {
        PullToRefreshBox(
            isRefreshing = isLoading && detail != null,
            onRefresh = onRefresh,
            modifier = Modifier.fillMaxSize()
        ) {
            when {
                isLoading && detail == null -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = palette.fg)
                    }
                }
                errorMessage != null && detail == null -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "Could not load page",
                                color = palette.textPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(text = errorMessage, color = palette.textSecondary, fontSize = 13.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = onRefresh,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = palette.fg,
                                        contentColor = palette.onAccent
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Retry", fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = { onOpenFallbackWeb(currentUrl) },
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("Open WebView", color = palette.textPrimary)
                                }
                            }
                        }
                    }
                }
                detail != null -> {
                    DetailContentBody(
                        detail = detail,
                        settings = settings,
                        imageLoader = imageLoader,
                        isInMyList = isInMyList,
                        myListCount = myListCount,
                        onWatchTrailer = onWatchTrailer,
                        onToggleMyList = { onToggleMyList(detail) },
                        onOpenMyListDialog = onOpenMyListDialog,
                        onWatchOnline = { embed -> onWatchOnline(embed, detail) },
                        onDownloadOption = { opt -> onDownloadOption(opt, detail) },
                        onOpenRelated = onOpenRelated,
                        onOpenFallbackWeb = onOpenFallbackWeb
                    )
                }
            }
        }

        // Overlaid translucent circular top controls matching editorial hero detail layout
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            DetailCircleActionButton(
                icon = Icons.AutoMirrored.Rounded.ArrowBack,
                contentDescription = "Back",
                onClick = onBack
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (detail != null) {
                    DetailCircleActionButton(
                        icon = if (isInMyList) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        contentDescription = if (isInMyList) "Remove from My List" else "Add to My List",
                        tint = if (isInMyList) Color(0xFFEF4444) else Color.White,
                        onClick = { onToggleMyList(detail) }
                    )
                }
                DetailCircleActionButton(
                    icon = Icons.Rounded.OpenInBrowser,
                    contentDescription = "Open in Chrome",
                    onClick = { DownloadAndPlayerRouter.openInChrome(context, currentUrl) }
                )
                DetailCircleActionButton(
                    icon = Icons.Rounded.Tune,
                    contentDescription = "Settings",
                    tint = palette.fg,
                    onClick = onOpenSettings
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DetailContentBody(
    detail: MediaDetail,
    settings: UserSettings,
    imageLoader: ImageLoader,
    isInMyList: Boolean,
    myListCount: Int,
    onWatchTrailer: (String) -> Unit,
    onToggleMyList: () -> Unit,
    onOpenMyListDialog: () -> Unit,
    onWatchOnline: (String) -> Unit,
    onDownloadOption: (DownloadOption) -> Unit,
    onOpenRelated: (MediaCard) -> Unit,
    onOpenFallbackWeb: (String) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    var plotExpanded by remember(detail.url) { mutableStateOf(false) }
    var episodeQuery by remember(detail.url) { mutableStateOf("") }
    val seasons = remember(detail.episodes) {
        detail.episodes.mapNotNull { it.seasonNumber }.distinct().sorted()
    }
    var selectedSeason by remember(detail.url) { mutableStateOf<Int?>(null) }

    val filteredEpisodes = remember(detail.episodes, episodeQuery, selectedSeason) {
        detail.episodes.filter { ep ->
            val seasonMatch = selectedSeason == null || ep.seasonNumber == selectedSeason
            val q = episodeQuery.trim().lowercase()
            val queryMatch = q.isEmpty() || ep.title.lowercase().contains(q)
            seasonMatch && queryMatch
        }
    }

    val boxEnabled = settings.detailBoxEnabled
    val boxScale = settings.detailBoxSizePercent.coerceIn(75, 130) / 100f
    val boxOpacity = if (boxEnabled) settings.detailBoxOpacityPercent.coerceIn(0, 100) / 100f else 0f
    val boxShape: Shape = when (settings.detailBoxStyle) {
        Config.DetailBoxStyle.SQUARE -> RoundedCornerShape(0.dp)
        Config.DetailBoxStyle.CIRCLE -> RoundedCornerShape(50)
        Config.DetailBoxStyle.ROUNDED -> RoundedCornerShape(12.dp)
    }
    val boxBaseColor = remember(settings.detailBoxColorHex) {
        try {
            Color(android.graphics.Color.parseColor(settings.detailBoxColorHex))
        } catch (_: Throwable) {
            Color(0xFF71717A)
        }
    }
    val boxBaseLum = remember(boxBaseColor) { ColorUtils.calculateLuminance(boxBaseColor.toArgb()) }
    val isBlackBoxOnDark = !palette.isLightBg && boxBaseLum < 0.05
    val detailBoxBg = when {
        !boxEnabled || boxOpacity <= 0f -> Color.Transparent
        isBlackBoxOnDark -> Color.Black.copy(alpha = 0.88f * boxOpacity)
        else -> boxBaseColor.copy(alpha = 0.22f * boxOpacity)
    }
    val detailBoxBorder = when {
        !boxEnabled || boxOpacity <= 0f -> Color.Transparent
        isBlackBoxOnDark -> Color(0xFF3F3F46).copy(alpha = boxOpacity)
        else -> boxBaseColor.copy(alpha = boxOpacity)
    }
    val detailBoxLabelColor = if (boxEnabled && boxOpacity > 0.08f) {
        when {
            !palette.isLightBg && boxBaseLum < 0.22 -> Color(0xFFD4D4D8)
            palette.isLightBg && boxBaseLum > 0.72 -> Color(0xFF3F3F46)
            else -> boxBaseColor
        }
    } else {
        palette.textSecondary
    }
    val countPillTextColor = if (boxBaseLum > 0.45) {
        Color(0xFF0A0D12)
    } else {
        Color.White
    }

    val canWatchOnline = settings.movieLinkWatchOnlineEnabled && !detail.watchEmbedUrl.isNullOrBlank()
    val hasTrailer = !detail.trailerYoutubeId.isNullOrBlank()
    val playBtnColor = Color(0xFFE50914)

    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val listState = rememberLazyListState()

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isTablet = maxWidth >= 600.dp
        val baseHeroHeight = if (isTablet) {
            (maxWidth * 0.44f).coerceIn(300.dp, 420.dp)
        } else {
            (maxWidth * 1.18f).coerceIn(360.dp, 560.dp)
        }
        val heroHeight = scaleHeroBannerHeight(baseHeroHeight, settings.detailHeroSizePercent).coerceIn(260.dp, 720.dp)
        val heroHeightPx = with(LocalDensity.current) { heroHeight.toPx() }
        val scrollOffsetPx by remember(listState, heroHeightPx) {
            derivedStateOf {
                if (listState.firstVisibleItemIndex > 0) heroHeightPx else listState.firstVisibleItemScrollOffset.toFloat()
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 28.dp + navBottom),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
        // Full-bleed Hero Artwork + Saliency Framing + Parallax + NuvioMobile 7-stop Scrim
        item(key = "hero_cover") {
            var backdropLoadError by remember(detail.url, detail.backdropUrl) { mutableStateOf(false) }
            var posterLoadError by remember(detail.url, detail.posterUrl) { mutableStateOf(false) }
            val fallbackShot = detail.screenshotUrls.firstOrNull().orEmpty()
            val heroCoverUrl = when {
                detail.backdropUrl.isNotBlank() && detail.backdropUrl != detail.posterUrl && !backdropLoadError -> detail.backdropUrl
                detail.posterUrl.isNotBlank() && !posterLoadError -> detail.posterUrl
                else -> fallbackShot
            }
            val backdropFocus = rememberBackdropFocusState(heroCoverUrl)
            val revealAlpha by animateFloatAsState(
                targetValue = backdropFocus.revealAlpha,
                animationSpec = tween(260),
                label = "detail_hero_reveal"
            )
            var isPortraitArtwork by remember(heroCoverUrl) {
                mutableStateOf(heroCoverUrl.isNotBlank() && heroCoverUrl == detail.posterUrl)
            }
            var logoLoadError by remember(detail.url, detail.logoUrl) { mutableStateOf(false) }

            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(heroHeight)
                        .background(palette.pageBg)
                        .graphicsLayer { clip = true }
                ) {
                    if (heroCoverUrl.isNotBlank()) {
                        if (isPortraitArtwork) {
                            AsyncImage(
                                model = heroCoverUrl,
                                imageLoader = imageLoader,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .graphicsLayer {
                                        alpha = 0.24f
                                        translationY = (scrollOffsetPx * 0.28f).coerceAtMost(heroHeightPx * 0.30f)
                                        scaleX = 1.08f
                                        scaleY = 1.08f
                                    }
                            )
                        }
                        AsyncImage(
                            model = heroCoverUrl,
                            imageLoader = imageLoader,
                            contentDescription = detail.title,
                            alignment = if (isPortraitArtwork) {
                                Alignment.TopCenter
                            } else {
                                backdropFocus.focusedAlignment(Alignment.Center)
                            },
                            contentScale = if (isPortraitArtwork) ContentScale.Fit else ContentScale.Crop,
                            onSuccess = { state ->
                                val d = state.result.drawable
                                val iw = d.intrinsicWidth
                                val ih = d.intrinsicHeight
                                if (iw > 0 && ih > 0) {
                                    isPortraitArtwork = ih > iw * 1.03f
                                }
                                backdropFocus.onDrawableLoaded(d)
                            },
                            onError = {
                                when {
                                    !backdropLoadError && heroCoverUrl == detail.backdropUrl && detail.posterUrl.isNotBlank() && detail.backdropUrl != detail.posterUrl ->
                                        backdropLoadError = true
                                    !posterLoadError && heroCoverUrl == detail.posterUrl && fallbackShot.isNotBlank() && fallbackShot != detail.posterUrl ->
                                        posterLoadError = true
                                    else ->
                                        backdropFocus.onImageFailed()
                                }
                            },
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer {
                                    alpha = revealAlpha
                                    translationY = (scrollOffsetPx * if (isPortraitArtwork) 0.28f else 0.40f)
                                        .coerceAtMost(heroHeightPx * 0.42f)
                                    val zoom = if (isPortraitArtwork) 1f else 1.03f
                                    scaleX = zoom
                                    scaleY = zoom
                                }
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(palette.cardBg)
                        )
                    }

                    // Top subtle scrim for back/heart/settings circle contrast
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .fillMaxWidth()
                            .height(86.dp)
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color(0x99000000), Color.Transparent)
                                )
                            )
                    )

                    // NuvioMobile DetailHero 7-stop bottom scrim seamlessly blending into pageBg
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .height((heroHeight * 0.54f).coerceIn(160.dp, 290.dp))
                            .background(
                                Brush.verticalGradient(
                                    colorStops = arrayOf(
                                        0.00f to Color.Transparent,
                                        0.16f to palette.pageBg.copy(alpha = 0.04f),
                                        0.32f to palette.pageBg.copy(alpha = 0.14f),
                                        0.50f to palette.pageBg.copy(alpha = 0.34f),
                                        0.68f to palette.pageBg.copy(alpha = 0.62f),
                                        0.84f to palette.pageBg.copy(alpha = 0.84f),
                                        1.00f to palette.pageBg
                                    )
                                )
                            )
                    )

                    // Movie-specific title logo artwork positioned centrally over hero artwork
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 14.dp, start = 20.dp, end = 20.dp)
                            .fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (detail.logoUrl.isNotBlank() && !logoLoadError) {
                            AsyncImage(
                                model = detail.logoUrl,
                                imageLoader = imageLoader,
                                contentDescription = detail.title,
                                alignment = Alignment.Center,
                                contentScale = ContentScale.Fit,
                                onError = { logoLoadError = true },
                                modifier = Modifier
                                    .fillMaxWidth(0.72f)
                                    .widthIn(max = 280.dp)
                                    .heightIn(min = 34.dp, max = 90.dp)
                            )
                        } else {
                            Text(
                                text = detail.title,
                                fontSize = 24.sp,
                                lineHeight = 28.sp,
                                fontWeight = FontWeight.Black,
                                color = palette.textPrimary,
                                textAlign = TextAlign.Center,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        if (detail.genres.isNotEmpty()) {
                            Text(
                                text = detail.genres.take(3).joinToString(" • "),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = palette.textSecondary,
                                textAlign = TextAlign.Center,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val metaSummary = listOfNotNull(
                        detail.type.takeIf { it.isNotBlank() },
                        detail.language.takeIf { it.isNotBlank() },
                        detail.quality.takeIf { it.isNotBlank() },
                        detail.episodes.takeIf { it.isNotEmpty() }?.let { "${it.size} Episodes" }
                    ).joinToString(" · ")

                    if (metaSummary.isNotBlank()) {
                        Text(
                            text = metaSummary,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = palette.textSecondary,
                            textAlign = TextAlign.Center
                        )
                    }

                    if (detail.subtitle.isNotBlank()) {
                        Text(
                            text = detail.subtitle,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = palette.fg,
                            textAlign = TextAlign.Center
                        )
                    }

                    if (!detail.communityRatingSummary.isNullOrBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Star,
                                contentDescription = null,
                                tint = Color(0xFFFBBF24),
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = detail.communityRatingSummary,
                                color = palette.textPrimary,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    if (detail.externalRatings.isNotEmpty()) {
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            detail.externalRatings.forEach { badge ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(palette.cardBg)
                                        .border(1.dp, palette.border.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = "${badge.source} · ${badge.value}",
                                        color = palette.textPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }

                    if (detail.scheduleText.isNotBlank()) {
                        Text(
                            text = detail.scheduleText,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF4ADE80),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        // Primary & Secondary CTAs (Watch Online, Watch Trailer, My List)
        item(key = "detail_actions") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (canWatchOnline) {
                    val accentLum = ColorUtils.calculateLuminance(palette.accent.toArgb())
                    val buttonBorder = if (!palette.isLightBg && accentLum < 0.06) {
                        BorderStroke(1.2.dp, Color(0xFF3F3F46))
                    } else {
                        null
                    }
                    Button(
                        onClick = { onWatchOnline(detail.watchEmbedUrl!!) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = palette.accent,
                            contentColor = palette.onPureAccent
                        ),
                        border = buttonBorder,
                        shape = boxShape,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height((48f * boxScale).dp)
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Watch Online", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 380.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (hasTrailer) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height((44f * boxScale).dp)
                                .clip(boxShape)
                                .background(detailBoxBg)
                                .border(1.3.dp, detailBoxBorder, boxShape)
                                .clickable { onWatchTrailer(detail.trailerYoutubeId!!) },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.PlayArrow,
                                    contentDescription = null,
                                    tint = palette.textPrimary,
                                    modifier = Modifier.size(17.dp)
                                )
                                Text(
                                    text = "Trailer",
                                    color = palette.textPrimary,
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    val savedBorder = if (isInMyList && boxEnabled && boxOpacity > 0f) {
                        Color(0xFF4ADE80).copy(alpha = boxOpacity)
                    } else {
                        detailBoxBorder
                    }
                    val savedText = if (isInMyList) Color(0xFF4ADE80) else palette.textPrimary

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height((44f * boxScale).dp)
                            .clip(boxShape)
                            .background(detailBoxBg)
                            .border(1.3.dp, savedBorder, boxShape)
                            .clickable(onClick = onToggleMyList),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isInMyList) "✓ In My List" else "＋ My List",
                            color = savedText,
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height((44f * boxScale).dp)
                            .clip(boxShape)
                            .background(detailBoxBg)
                            .border(1.3.dp, detailBoxBorder, boxShape)
                            .clickable(onClick = onOpenMyListDialog),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.FormatListBulleted,
                                contentDescription = null,
                                tint = palette.textPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "List",
                                color = palette.textPrimary,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                            if (myListCount > 0) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (boxEnabled) boxBaseColor else palette.altBg)
                                        .padding(horizontal = 5.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = myListCount.toString(),
                                        color = if (boxEnabled) countPillTextColor else palette.textPrimary,
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // The Plot (Expandable Synopsis matching Reference Image 3)
        if (detail.storyline.isNotBlank()) {
            item(key = "the_plot") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "The Plot",
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary
                    )
                    Text(
                        text = detail.storyline,
                        fontSize = 13.5.sp,
                        lineHeight = 20.sp,
                        color = palette.textSecondary,
                        maxLines = if (plotExpanded) Int.MAX_VALUE else 3,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (detail.storyline.length > 135) {
                        Text(
                            text = if (plotExpanded) "Read Less" else "Read More",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFEF4444),
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { plotExpanded = !plotExpanded }
                                .padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }

        // Casts (Circular Avatars Carousel matching Reference Image 3)
        if (detail.cast.isNotEmpty()) {
            item(key = "casts") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Casts",
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(detail.cast) { actor ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.width(68.dp)
                            ) {
                                if (actor.avatarUrl.isNotBlank()) {
                                    AsyncImage(
                                        model = actor.avatarUrl,
                                        imageLoader = imageLoader,
                                        contentDescription = actor.name,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(60.dp)
                                            .clip(CircleShape)
                                            .background(palette.cardBg)
                                            .border(1.dp, palette.border.copy(alpha = 0.25f), CircleShape)
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(60.dp)
                                            .clip(CircleShape)
                                            .background(palette.altBg)
                                            .border(1.dp, palette.border.copy(alpha = 0.25f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = actor.name.take(1).uppercase(),
                                            color = palette.fg,
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = actor.name,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = palette.textPrimary,
                                    maxLines = 1,
                                    textAlign = TextAlign.Center,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (actor.role.isNotBlank()) {
                                    Text(
                                        text = actor.role,
                                        fontSize = 9.5.sp,
                                        color = palette.textSecondary,
                                        maxLines = 1,
                                        textAlign = TextAlign.Center,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Single-Cover Screenshot Card + Pop-Up Gallery
        if (detail.screenshotUrls.isNotEmpty()) {
            item(key = "screenshots") {
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    SingleCoverScreenshotsSection(
                        screenshotUrls = detail.screenshotUrls,
                        imageLoader = imageLoader
                    )
                }
            }
        }

        // Customizable 3 equal-width centered boxes: Type, Language, Quality
        if (boxEnabled) {
            item(key = "meta_boxes") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetaRoundedBox(
                        label = "Type",
                        value = detail.type,
                        shape = boxShape,
                        bg = detailBoxBg,
                        border = detailBoxBorder,
                        labelColor = detailBoxLabelColor,
                        valueColor = palette.textPrimary,
                        sizeScale = boxScale,
                        modifier = Modifier.weight(1f)
                    )
                    MetaRoundedBox(
                        label = "Language",
                        value = detail.language,
                        shape = boxShape,
                        bg = detailBoxBg,
                        border = detailBoxBorder,
                        labelColor = detailBoxLabelColor,
                        valueColor = palette.textPrimary,
                        sizeScale = boxScale,
                        modifier = Modifier.weight(1f)
                    )
                    MetaRoundedBox(
                        label = "Quality",
                        value = detail.quality,
                        shape = boxShape,
                        bg = detailBoxBg,
                        border = detailBoxBorder,
                        labelColor = detailBoxLabelColor,
                        valueColor = palette.textPrimary,
                        sizeScale = boxScale,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Series Episodes with Season filter + English Episode Search
        if (detail.episodes.isNotEmpty()) {
            item(key = "episodes_header") {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Episodes (${detail.episodes.size})",
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary
                    )

                    if (seasons.size > 1) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            item {
                                SeasonPill(
                                    label = "All Seasons",
                                    selected = selectedSeason == null,
                                    onClick = { selectedSeason = null }
                                )
                            }
                            items(seasons) { s ->
                                SeasonPill(
                                    label = "Season $s",
                                    selected = selectedSeason == s,
                                    onClick = { selectedSeason = s }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = episodeQuery,
                        onValueChange = { episodeQuery = it },
                        placeholder = {
                            Text(
                                text = "Search season or episode…",
                                fontSize = 13.sp,
                                color = palette.textSecondary
                            )
                        },
                        leadingIcon = {
                            Icon(Icons.Rounded.Search, contentDescription = null, tint = palette.fg)
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = palette.cardBg,
                            unfocusedContainerColor = palette.cardBg,
                            focusedBorderColor = palette.boxBorder,
                            unfocusedBorderColor = palette.border.copy(alpha = 0.4f),
                            focusedTextColor = palette.textPrimary,
                            unfocusedTextColor = palette.textPrimary
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            items(filteredEpisodes) { ep ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(palette.cardBg)
                        .border(1.dp, palette.border.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = ep.title,
                            color = palette.textPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        if (ep.isNew) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(palette.fg)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                Text(
                                    text = "NEW",
                                    color = palette.onAccent,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }

                    ep.downloads.forEach { opt ->
                        DownloadOptionRow(opt = opt, onClick = { onDownloadOption(opt) })
                    }
                }
            }
        }

        // Direct Movie Download Links
        if (detail.downloadLinks.isNotEmpty()) {
            item(key = "downloads") {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Download Links",
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary
                    )
                    detail.downloadLinks.forEach { opt ->
                        DownloadOptionRow(opt = opt, onClick = { onDownloadOption(opt) })
                    }
                }
            }
        }

        // Season ZIP Packs
        if (detail.seasonZipLinks.isNotEmpty()) {
            item(key = "season_zips") {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Complete Season Packs",
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary
                    )
                    detail.seasonZipLinks.forEach { opt ->
                        DownloadOptionRow(opt = opt, onClick = { onDownloadOption(opt) })
                    }
                }
            }
        }

        // Related Titles
        if (detail.relatedItems.isNotEmpty()) {
            item(key = "related") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "You May Also Like",
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(detail.relatedItems, key = { it.url }) { rel ->
                            MediaPosterCard(
                                card = rel,
                                imageLoader = imageLoader,
                                onClick = { onOpenRelated(rel) },
                                modifier = Modifier.width(128.dp)
                            )
                        }
                    }
                }
            }
        }

        item(key = "fallback_web") {
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                OutlinedButton(
                    onClick = { onOpenFallbackWeb(detail.url) },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Open Page in Fallback WebView", color = palette.textSecondary, fontSize = 12.5.sp)
                }
            }
        }
    }
    }
}

@Composable
private fun DetailCircleActionButton(
    icon: ImageVector,
    contentDescription: String,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(Color(0x9916161C))
            .border(1.dp, Color(0x2EFFFFFF), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = tint,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun MetaRoundedBox(
    label: String,
    value: String,
    shape: Shape,
    bg: Color,
    border: Color,
    labelColor: Color,
    valueColor: Color,
    sizeScale: Float,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .heightIn(min = (60f * sizeScale).dp)
            .clip(shape)
            .background(bg)
            .border(1.5.dp, border, shape)
            .padding(
                horizontal = (8f * sizeScale).dp,
                vertical = (10f * sizeScale).dp
            ),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = labelColor,
            maxLines = 1
        )
        Spacer(Modifier.height(3.dp))
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = FontWeight.ExtraBold,
            color = valueColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun DownloadOptionRow(
    opt: DownloadOption,
    onClick: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.boxBg)
            .border(1.2.dp, palette.boxBorder.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = Icons.Rounded.Download,
                contentDescription = null,
                tint = palette.fg,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = opt.label,
                color = palette.textPrimary,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
        Text(
            text = "Open",
            color = palette.fg,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun SeasonPill(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) palette.fg else palette.boxBg)
            .border(1.dp, if (selected) palette.fg else palette.boxBorder, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = if (selected) palette.onAccent else palette.textPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
