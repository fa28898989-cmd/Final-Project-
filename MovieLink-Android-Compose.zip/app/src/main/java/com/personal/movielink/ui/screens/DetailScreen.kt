package com.personal.movielink.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.OpenInBrowser
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.ColorUtils
import coil.ImageLoader
import coil.compose.AsyncImage
import com.personal.movielink.DownloadAndPlayerRouter
import com.personal.movielink.DownloadOption
import com.personal.movielink.EpisodeItem
import com.personal.movielink.MediaCard
import com.personal.movielink.MediaDetail
import com.personal.movielink.UserSettings
import com.personal.movielink.ui.components.SingleCoverScreenshotsSection
import com.personal.movielink.ui.components.focusedAlignment
import com.personal.movielink.ui.components.rememberBackdropFocusState
import com.personal.movielink.ui.components.revealAlpha
import com.personal.movielink.ui.components.scaleHeroBannerHeight
import com.personal.movielink.ui.theme.LocalMovieLinkPalette

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    detail: MediaDetail?,
    currentUrl: String,
    isLoading: Boolean,
    errorMessage: String?,
    settings: UserSettings,
    imageLoader: ImageLoader,
    isInMyList: Boolean,
    isWatched: Boolean,
    myListCount: Int,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
    onWatchTrailer: (String) -> Unit,
    onToggleMyList: (MediaDetail) -> Unit,
    onToggleWatched: (MediaDetail) -> Unit,
    onOpenMyListDialog: () -> Unit,
    onWatchOnline: (String, MediaDetail) -> Unit,
    onPlayEpisode: (EpisodeItem, MediaDetail) -> Unit,
    onDownloadOption: (DownloadOption, MediaDetail) -> Unit,
    onOpenRelated: (MediaCard) -> Unit,
    onOpenFallbackWeb: (String) -> Unit,
    @Suppress("UNUSED_PARAMETER") onOpenSettings: () -> Unit = {}
) {
    val palette = LocalMovieLinkPalette.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.pageBg)
    ) {
        PullToRefreshBox(
            isRefreshing = isLoading && detail != null,
            onRefresh = onRefresh,
            modifier = Modifier.fillMaxSize()
        ) {
            when {
                isLoading && detail == null -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = palette.fg)
                    }
                }
                errorMessage != null && detail == null -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "Could not load page",
                                color = palette.textPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(text = errorMessage, color = palette.textSecondary, fontSize = 13.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = onRefresh,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = palette.fg,
                                        contentColor = palette.onAccent
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Retry", fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = { onOpenFallbackWeb(currentUrl) },
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("Open WebView", color = palette.textPrimary)
                                }
                            }
                        }
                    }
                }
                detail != null -> {
                    DetailContentBody(
                        detail = detail,
                        settings = settings,
                        imageLoader = imageLoader,
                        isInMyList = isInMyList,
                        isWatched = isWatched,
                        myListCount = myListCount,
                        onWatchTrailer = onWatchTrailer,
                        onToggleMyList = { onToggleMyList(detail) },
                        onToggleWatched = { onToggleWatched(detail) },
                        onOpenMyListDialog = onOpenMyListDialog,
                        onWatchOnline = { embed -> onWatchOnline(embed, detail) },
                        onPlayEpisode = { ep -> onPlayEpisode(ep, detail) },
                        onDownloadOption = { opt -> onDownloadOption(opt, detail) },
                        onOpenRelated = onOpenRelated,
                        onOpenFallbackWeb = onOpenFallbackWeb
                    )
                }
            }
        }

        // Clean borderless slightly-bold white back arrow matching Image 2 (top-right buttons removed)
        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .statusBarsPadding()
                .padding(horizontal = 10.dp, vertical = 10.dp)
                .size(42.dp)
                .clip(CircleShape)
                .clickable(onClick = onBack),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(22.dp)) {
                val w = size.width
                val h = size.height
                val cy = h * 0.5f
                val leftX = w * 0.16f
                val rightX = w * 0.84f
                val tipOffset = w * 0.30f
                val sw = 2.65.dp.toPx()
                drawLine(
                    color = Color.White,
                    start = Offset(leftX + sw * 0.35f, cy),
                    end = Offset(rightX, cy),
                    strokeWidth = sw,
                    cap = StrokeCap.Round
                )
                val chevron = Path().apply {
                    moveTo(leftX + tipOffset, cy - tipOffset)
                    lineTo(leftX, cy)
                    lineTo(leftX + tipOffset, cy + tipOffset)
                }
                drawPath(
                    path = chevron,
                    color = Color.White,
                    style = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)
@Composable
private fun DetailContentBody(
    detail: MediaDetail,
    settings: UserSettings,
    imageLoader: ImageLoader,
    isInMyList: Boolean,
    isWatched: Boolean,
    myListCount: Int,
    onWatchTrailer: (String) -> Unit,
    onToggleMyList: () -> Unit,
    onToggleWatched: () -> Unit,
    onOpenMyListDialog: () -> Unit,
    onWatchOnline: (String) -> Unit,
    onPlayEpisode: (EpisodeItem) -> Unit,
    onDownloadOption: (DownloadOption) -> Unit,
    onOpenRelated: (MediaCard) -> Unit,
    onOpenFallbackWeb: (String) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val context = LocalContext.current
    var plotExpanded by remember(detail.url) { mutableStateOf(false) }
    var episodesExpanded by remember(detail.url) { mutableStateOf(false) }
    var downloadsExpanded by remember(detail.url) { mutableStateOf(false) }
    var seasonPacksExpanded by remember(detail.url) { mutableStateOf(false) }
    var episodeQuery by remember(detail.url) { mutableStateOf("") }
    val seasons = remember(detail.episodes) {
        detail.episodes.mapNotNull { it.seasonNumber }.distinct().sorted()
    }
    var selectedSeason by remember(detail.url, seasons) {
        mutableStateOf(seasons.firstOrNull())
    }

    val filteredEpisodes = remember(detail.episodes, episodeQuery, selectedSeason) {
        detail.episodes.filter { ep ->
            val seasonMatch = selectedSeason == null || ep.seasonNumber == selectedSeason
            val q = episodeQuery.trim().lowercase()
            val queryMatch = q.isEmpty() || ep.title.lowercase().contains(q)
            seasonMatch && queryMatch
        }
    }

    val canWatchOnline = settings.movieLinkWatchOnlineEnabled && !detail.watchEmbedUrl.isNullOrBlank()
    val hasTrailer = !detail.trailerYoutubeId.isNullOrBlank()
    val isSeries = detail.episodes.isNotEmpty() ||
        detail.type.contains("series", ignoreCase = true) ||
        detail.type.contains("tv", ignoreCase = true) ||
        detail.type.contains("drama", ignoreCase = true) ||
        detail.type.contains("anime", ignoreCase = true)

    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val listState = rememberLazyListState()

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isTablet = maxWidth >= 600.dp
        val baseHeroHeight = if (isTablet) {
            (maxWidth * 0.44f).coerceIn(300.dp, 420.dp)
        } else {
            (maxWidth * 1.18f).coerceIn(360.dp, 560.dp)
        }
        val heroHeight = scaleHeroBannerHeight(baseHeroHeight, settings.detailHeroSizePercent).coerceIn(260.dp, 720.dp)
        val heroHeightPx = with(LocalDensity.current) { heroHeight.toPx() }

        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 28.dp + navBottom),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
        // Full-bleed Hero Artwork + Saliency Framing + Parallax + Editorial 7-stop Scrim
        item(key = "hero_cover", contentType = "detail_hero") {
            var backdropLoadError by remember(detail.url, detail.backdropUrl) { mutableStateOf(false) }
            var shotLoadError by remember(detail.url, detail.screenshotUrls) { mutableStateOf(false) }
            var posterLoadError by remember(detail.url, detail.posterUrl) { mutableStateOf(false) }
            val fallbackShot = detail.screenshotUrls.firstOrNull { shot ->
                shot.isNotBlank() &&
                    shot != detail.posterUrl &&
                    !shot.contains("mlbd_load", ignoreCase = true) &&
                    !shot.contains("placeholder", ignoreCase = true)
            }.orEmpty()
            val heroCoverUrl = when {
                detail.backdropUrl.isNotBlank() && detail.backdropUrl != detail.posterUrl && !backdropLoadError -> detail.backdropUrl
                fallbackShot.isNotBlank() && !shotLoadError -> fallbackShot
                detail.posterUrl.isNotBlank() && !posterLoadError -> detail.posterUrl
                else -> fallbackShot
            }
            val backdropFocus = rememberBackdropFocusState(heroCoverUrl)
            val revealAlpha by animateFloatAsState(
                targetValue = backdropFocus.revealAlpha,
                animationSpec = tween(260),
                label = "detail_hero_reveal"
            )
            var isPortraitArtwork by remember(heroCoverUrl) {
                mutableStateOf(
                    heroCoverUrl.isNotBlank() &&
                        heroCoverUrl == detail.posterUrl &&
                        heroCoverUrl != detail.backdropUrl &&
                        heroCoverUrl != fallbackShot
                )
            }
            var logoLoadError by remember(detail.url, detail.logoUrl) { mutableStateOf(false) }

            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(heroHeight)
                        .background(palette.pageBg)
                        .graphicsLayer { clip = true }
                ) {
                    if (heroCoverUrl.isNotBlank()) {
                        AsyncImage(
                            model = heroCoverUrl,
                            imageLoader = imageLoader,
                            contentDescription = detail.title,
                            alignment = if (isPortraitArtwork) {
                                BiasAlignment(0f, -0.35f)
                            } else {
                                backdropFocus.focusedAlignment(Alignment.Center)
                            },
                            contentScale = ContentScale.Crop,
                            onSuccess = { state ->
                                val d = state.result.drawable
                                val iw = d.intrinsicWidth
                                val ih = d.intrinsicHeight
                                if (iw > 0 && ih > 0) {
                                    isPortraitArtwork = ih > iw * 1.03f
                                }
                                backdropFocus.onDrawableLoaded(d)
                            },
                            onError = {
                                when {
                                    !backdropLoadError && heroCoverUrl == detail.backdropUrl ->
                                        backdropLoadError = true
                                    !shotLoadError && heroCoverUrl == fallbackShot ->
                                        shotLoadError = true
                                    !posterLoadError && heroCoverUrl == detail.posterUrl ->
                                        posterLoadError = true
                                    else ->
                                        backdropFocus.onImageFailed()
                                }
                            },
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer {
                                    val offsetPx = if (listState.firstVisibleItemIndex > 0) heroHeightPx else listState.firstVisibleItemScrollOffset.toFloat()
                                    alpha = revealAlpha
                                    translationY = (offsetPx * if (isPortraitArtwork) 0.28f else 0.40f)
                                        .coerceAtMost(heroHeightPx * 0.42f)
                                    val zoom = if (isPortraitArtwork) 1f else 1.03f
                                    scaleX = zoom
                                    scaleY = zoom
                                }
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(palette.cardBg)
                        )
                    }

                    // Top subtle scrim for back/heart/settings circle contrast
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .fillMaxWidth()
                            .height(86.dp)
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color(0x99000000), Color.Transparent)
                                )
                            )
                    )

                    // Editorial DetailHero 7-stop bottom scrim seamlessly blending into pageBg
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .height((heroHeight * 0.54f).coerceIn(160.dp, 290.dp))
                            .background(
                                Brush.verticalGradient(
                                    colorStops = arrayOf(
                                        0.00f to Color.Transparent,
                                        0.16f to palette.pageBg.copy(alpha = 0.04f),
                                        0.32f to palette.pageBg.copy(alpha = 0.14f),
                                        0.50f to palette.pageBg.copy(alpha = 0.34f),
                                        0.68f to palette.pageBg.copy(alpha = 0.62f),
                                        0.84f to palette.pageBg.copy(alpha = 0.84f),
                                        1.00f to palette.pageBg
                                    )
                                )
                            )
                    )

                    // Movie-specific title logo artwork positioned centrally over hero artwork (no text fallback if logo unavailable)
                    if (detail.logoUrl.isNotBlank() && !logoLoadError) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 14.dp, start = 20.dp, end = 20.dp)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            AsyncImage(
                                model = detail.logoUrl,
                                imageLoader = imageLoader,
                                contentDescription = detail.title,
                                alignment = Alignment.Center,
                                contentScale = ContentScale.Fit,
                                onError = { logoLoadError = true },
                                modifier = Modifier
                                    .fillMaxWidth(0.72f)
                                    .widthIn(max = 280.dp)
                                    .heightIn(min = 34.dp, max = 90.dp)
                            )
                        }
                    } else if (detail.title.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 14.dp, start = 20.dp, end = 20.dp)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = detail.title,
                                color = palette.textPrimary,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (detail.genres.isNotEmpty()) {
                        Text(
                            text = detail.genres.take(3).joinToString(" • "),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = palette.textSecondary,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    val metaSummary = listOfNotNull(
                        detail.type.takeIf { it.isNotBlank() },
                        detail.language.takeIf { it.isNotBlank() },
                        detail.quality.takeIf { it.isNotBlank() },
                        detail.episodes.takeIf { it.isNotEmpty() }?.let { "${it.size} Episodes" }
                    ).joinToString(" · ")

                    if (metaSummary.isNotBlank()) {
                        Text(
                            text = metaSummary,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = palette.textSecondary,
                            textAlign = TextAlign.Center
                        )
                    }

                    if (detail.subtitle.isNotBlank() || detail.externalRatings.isNotEmpty()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (detail.subtitle.isNotBlank()) {
                                Text(
                                    text = detail.subtitle,
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = palette.fg
                                )
                            }
                            if (detail.subtitle.isNotBlank() && detail.externalRatings.isNotEmpty()) {
                                Spacer(Modifier.width(10.dp))
                            }
                            detail.externalRatings.firstOrNull()?.let { badge ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(palette.cardBg)
                                        .border(1.dp, palette.border.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = "${badge.source} · ${badge.value}",
                                        color = palette.textPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }

                    if (detail.externalRatings.size > 1) {
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            detail.externalRatings.drop(1).forEach { badge ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(palette.cardBg)
                                        .border(1.dp, palette.border.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = "${badge.source} · ${badge.value}",
                                        color = palette.textPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }

                    if (detail.scheduleText.isNotBlank()) {
                        Text(
                            text = detail.scheduleText,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF4ADE80),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        // Primary Row: Side-by-side Play & Trailer (keeping existing box colors) + 3-column utility row
        item(key = "detail_actions") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (canWatchOnline || hasTrailer) {
                    val actionShape = RoundedCornerShape(15.dp)
                    val playBg = if (palette.isLightBg) Color(0xFF18181B) else Color(0xFFF4F4F5)
                    val playFg = if (palette.isLightBg) Color.White else Color(0xFF111216)
                    val trailerBg = if (palette.isLightBg) Color(0xFFE4E4E7) else Color(0xFF1E1F23)
                    val trailerFg = if (palette.isLightBg) Color(0xFF18181B) else Color(0xFFF4F4F5)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (canWatchOnline) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .clip(actionShape)
                                    .background(playBg)
                                    .clickable { onWatchOnline(detail.watchEmbedUrl!!) },
                                contentAlignment = Alignment.Center
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.PlayCircle,
                                        contentDescription = null,
                                        tint = playFg,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = "Play",
                                        color = playFg,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        maxLines = 1
                                    )
                                }
                            }
                        }

                        if (hasTrailer) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .clip(actionShape)
                                    .background(trailerBg)
                                    .clickable { onWatchTrailer(detail.trailerYoutubeId!!) },
                                contentAlignment = Alignment.Center
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Movie,
                                        contentDescription = null,
                                        tint = trailerFg,
                                        modifier = Modifier.size(19.dp)
                                    )
                                    Text(
                                        text = "Trailer",
                                        color = trailerFg,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }

                // 3-Icon Minimal Utility Row: Open Browser (from current top bar), Mark Watched, Add to Watchlist
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    DetailQuickIconButton(
                        icon = Icons.Rounded.OpenInBrowser,
                        label = "Open Browser",
                        tint = palette.textPrimary,
                        labelColor = palette.textSecondary,
                        onClick = { DownloadAndPlayerRouter.openInChrome(context, detail.url) },
                        modifier = Modifier.weight(1f)
                    )
                    DetailQuickIconButton(
                        icon = if (isWatched) Icons.Rounded.Visibility else Icons.Outlined.Visibility,
                        label = if (isWatched) "Watched" else "Mark Watched",
                        tint = if (isWatched) palette.fg else palette.textPrimary,
                        labelColor = if (isWatched) palette.fg else palette.textSecondary,
                        onClick = onToggleWatched,
                        modifier = Modifier.weight(1f)
                    )
                    DetailQuickIconButton(
                        icon = if (isInMyList) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
                        label = if (isInMyList) "In Watchlist" else "Add to Watchlist",
                        tint = if (isInMyList) palette.fg else palette.textPrimary,
                        labelColor = if (isInMyList) palette.fg else palette.textSecondary,
                        onClick = onToggleMyList,
                        onLongClick = if (myListCount > 0) onOpenMyListDialog else null,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Synopsis directly below action row (matching Reference Image 1)
        if (detail.storyline.isNotBlank()) {
            item(key = "the_plot") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .clickable {
                            if (detail.storyline.length > 135) {
                                plotExpanded = !plotExpanded
                            }
                        },
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Text(
                        text = detail.storyline,
                        fontSize = 13.5.sp,
                        lineHeight = 20.sp,
                        color = palette.textSecondary,
                        maxLines = if (plotExpanded) Int.MAX_VALUE else 3,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (detail.storyline.length > 135) {
                        Text(
                            text = if (plotExpanded) "Show less" else "Read more",
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = palette.fg
                        )
                    }
                }
            }
        }

        // Single-Cover Screenshot Box combining Website Preview + Screenshot sections
        if (detail.screenshotUrls.isNotEmpty()) {
            item(key = "screenshots") {
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    SingleCoverScreenshotsSection(
                        screenshotUrls = detail.screenshotUrls,
                        imageLoader = imageLoader
                    )
                }
            }
        }

        // Movie / Series Details Table (matching Reference Image 1)
        item(key = "movie_details_table") {
            val fallbackYear = remember(detail.subtitle, detail.releaseInfo) {
                detail.releaseInfo.ifBlank {
                    Regex("""\b(19\d{2}|20\d{2})\b""").find(detail.subtitle)?.value.orEmpty()
                }
            }
            val detailRows = remember(detail, fallbackYear) {
                buildList {
                    if (detail.status.isNotBlank()) add("Status" to detail.status)
                    if (fallbackYear.isNotBlank()) add("Release Info" to fallbackYear)
                    if (detail.runtime.isNotBlank()) add("Runtime" to detail.runtime)
                    if (detail.certification.isNotBlank()) add("Certification" to detail.certification)
                    if (detail.originCountry.isNotBlank()) add("Origin Country" to detail.originCountry)
                    val origLang = detail.originalLanguage.ifBlank { detail.language }
                    if (origLang.isNotBlank()) add("Original Language" to origLang)
                    if (detail.quality.isNotBlank()) add("Quality" to detail.quality)
                    if (size < 4 && detail.type.isNotBlank()) add("Type" to detail.type)
                }
            }
            if (detailRows.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = if (isSeries) "Series Details" else "Movie Details",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    detailRows.forEachIndexed { idx, (label, value) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 11.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = label,
                                fontSize = 13.5.sp,
                                color = palette.textSecondary,
                                fontWeight = FontWeight.Normal,
                                modifier = Modifier.padding(end = 16.dp)
                            )
                            Text(
                                text = value,
                                fontSize = 13.5.sp,
                                color = palette.textPrimary,
                                fontWeight = FontWeight.SemiBold,
                                textAlign = TextAlign.End,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        if (idx < detailRows.lastIndex) {
                            HorizontalDivider(
                                thickness = 0.8.dp,
                                color = palette.border.copy(alpha = 0.14f)
                            )
                        }
                    }
                }
            }
        }

        // Collapsible Series Seasons & Episodes Selector (collapsed by default, playable + downloads)
        if (detail.episodes.isNotEmpty()) {
            item(key = "episodes_section") {
                val countBadge = if (seasons.size > 1) {
                    "${seasons.size} Seasons · ${detail.episodes.size} Episodes"
                } else {
                    "${detail.episodes.size} Episodes"
                }
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CollapsibleSectionHeader(
                        title = "Seasons & Episodes",
                        badgeText = countBadge,
                        expanded = episodesExpanded,
                        onToggle = { episodesExpanded = !episodesExpanded }
                    )

                    AnimatedVisibility(
                        visible = episodesExpanded,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (seasons.size > 1) {
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(seasons) { s ->
                                        SeasonPill(
                                            label = "Season $s",
                                            selected = selectedSeason == s,
                                            onClick = { selectedSeason = s }
                                        )
                                    }
                                    item {
                                        SeasonPill(
                                            label = "All Seasons",
                                            selected = selectedSeason == null,
                                            onClick = { selectedSeason = null }
                                        )
                                    }
                                }
                            }

                            if (detail.episodes.size > 6) {
                                OutlinedTextField(
                                    value = episodeQuery,
                                    onValueChange = { episodeQuery = it },
                                    placeholder = {
                                        Text(
                                            text = "Search season or episode…",
                                            fontSize = 13.sp,
                                            color = palette.textSecondary
                                        )
                                    },
                                    leadingIcon = {
                                        Icon(Icons.Rounded.Search, contentDescription = null, tint = palette.fg)
                                    },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = palette.cardBg,
                                        unfocusedContainerColor = palette.cardBg,
                                        focusedBorderColor = palette.boxBorder,
                                        unfocusedBorderColor = palette.border.copy(alpha = 0.4f),
                                        focusedTextColor = palette.textPrimary,
                                        unfocusedTextColor = palette.textPrimary
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            filteredEpisodes.forEach { ep ->
                                EpisodeSelectorCard(
                                    ep = ep,
                                    canPlay = canWatchOnline || !ep.watchEmbedUrl.isNullOrBlank() || ep.downloads.isNotEmpty(),
                                    onPlay = { onPlayEpisode(ep) },
                                    onDownloadOption = onDownloadOption
                                )
                            }
                        }
                    }
                }
            }
        }

        // Collapsible Download Links (collapsed by default)
        if (detail.downloadLinks.isNotEmpty()) {
            item(key = "downloads") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CollapsibleSectionHeader(
                        title = "Download Links",
                        badgeText = if (detail.downloadLinks.size == 1) "1 link" else "${detail.downloadLinks.size} links",
                        expanded = downloadsExpanded,
                        onToggle = { downloadsExpanded = !downloadsExpanded }
                    )

                    AnimatedVisibility(
                        visible = downloadsExpanded,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            detail.downloadLinks.forEach { opt ->
                                DownloadOptionRow(opt = opt, onClick = { onDownloadOption(opt) })
                            }
                        }
                    }
                }
            }
        }

        // Collapsible Season ZIP Packs (collapsed by default)
        if (detail.seasonZipLinks.isNotEmpty()) {
            item(key = "season_zips") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CollapsibleSectionHeader(
                        title = "Complete Season Packs",
                        badgeText = if (detail.seasonZipLinks.size == 1) "1 pack" else "${detail.seasonZipLinks.size} packs",
                        expanded = seasonPacksExpanded,
                        onToggle = { seasonPacksExpanded = !seasonPacksExpanded }
                    )

                    AnimatedVisibility(
                        visible = seasonPacksExpanded,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            detail.seasonZipLinks.forEach { opt ->
                                DownloadOptionRow(opt = opt, onClick = { onDownloadOption(opt) })
                            }
                        }
                    }
                }
            }
        }

        // Cast (Circular Avatars Carousel matching Reference Image 1)
        if (detail.cast.isNotEmpty()) {
            item(key = "casts") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Cast",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(detail.cast, contentType = { "cast_member" }) { actor ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.width(72.dp)
                            ) {
                                if (actor.avatarUrl.isNotBlank()) {
                                    AsyncImage(
                                        model = actor.avatarUrl,
                                        imageLoader = imageLoader,
                                        contentDescription = actor.name,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(62.dp)
                                            .clip(CircleShape)
                                            .background(palette.cardBg)
                                            .border(1.dp, palette.border.copy(alpha = 0.25f), CircleShape)
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(62.dp)
                                            .clip(CircleShape)
                                            .background(palette.altBg)
                                            .border(1.dp, palette.border.copy(alpha = 0.25f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = actor.name.take(1).uppercase(),
                                            color = palette.fg,
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = actor.name,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = palette.textPrimary,
                                    maxLines = 1,
                                    textAlign = TextAlign.Center,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (actor.role.isNotBlank()) {
                                    Text(
                                        text = actor.role,
                                        fontSize = 10.sp,
                                        color = palette.textSecondary,
                                        maxLines = 1,
                                        textAlign = TextAlign.Center,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // More Like This (matching Reference Image 1)
        if (detail.relatedItems.isNotEmpty()) {
            item(key = "related") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "More Like This",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(detail.relatedItems, key = { it.url }, contentType = { "related_poster" }) { rel ->
                            MediaPosterCard(
                                card = rel,
                                imageLoader = imageLoader,
                                onClick = { onOpenRelated(rel) },
                                modifier = Modifier.width(124.dp)
                            )
                        }
                    }
                }
            }
        }

        item(key = "fallback_web") {
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                OutlinedButton(
                    onClick = { onOpenFallbackWeb(detail.url) },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Open Page in Fallback WebView", color = palette.textSecondary, fontSize = 12.5.sp)
                }
            }
        }
    }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DetailQuickIconButton(
    icon: ImageVector,
    label: String,
    tint: Color,
    labelColor: Color,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = tint,
            modifier = Modifier.size(21.dp)
        )
        Text(
            text = label,
            color = labelColor,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun CollapsibleSectionHeader(
    title: String,
    badgeText: String,
    expanded: Boolean,
    onToggle: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.cardBg)
            .border(1.dp, palette.border.copy(alpha = 0.28f), RoundedCornerShape(12.dp))
            .clickable(onClick = onToggle)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(2.dp),
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = palette.textPrimary
            )
            Text(
                text = badgeText,
                fontSize = 11.5.sp,
                color = palette.textSecondary
            )
        }
        Icon(
            imageVector = if (expanded) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
            contentDescription = if (expanded) "Collapse $title" else "Expand $title",
            tint = palette.fg,
            modifier = Modifier.size(22.dp)
        )
    }
}

@Composable
private fun EpisodeSelectorCard(
    ep: EpisodeItem,
    canPlay: Boolean,
    onPlay: () -> Unit,
    onDownloadOption: (DownloadOption) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    var downloadsOpen by remember(ep.title, ep.seasonNumber, ep.episodeNumber) { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.cardBg)
            .border(1.dp, palette.border.copy(alpha = 0.30f), RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = ep.title,
                        color = palette.textPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (ep.isNew) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(palette.fg)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "NEW",
                                color = palette.onAccent,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
                if (ep.downloads.isNotEmpty()) {
                    Text(
                        text = if (ep.downloads.size == 1) "1 download source" else "${ep.downloads.size} download sources",
                        color = palette.textSecondary,
                        fontSize = 11.5.sp
                    )
                }
            }

            if (canPlay) {
                val accentLum = ColorUtils.calculateLuminance(palette.accent.toArgb())
                val epPlayBorder = if (!palette.isLightBg && accentLum < 0.06) {
                    Color(0xFF3F3F46)
                } else {
                    Color.Transparent
                }
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(palette.accent)
                        .border(1.dp, epPlayBorder, RoundedCornerShape(10.dp))
                        .clickable(onClick = onPlay)
                        .padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PlayArrow,
                        contentDescription = "Play ${ep.title}",
                        tint = palette.onPureAccent,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Play",
                        color = palette.onPureAccent,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }

            if (ep.downloads.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(palette.boxBg)
                        .border(1.dp, palette.boxBorder.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                        .clickable { downloadsOpen = !downloadsOpen }
                        .padding(horizontal = 10.dp, vertical = 7.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Download,
                        contentDescription = "Episode Downloads",
                        tint = palette.fg,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = downloadsOpen && ep.downloads.isNotEmpty(),
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                ep.downloads.forEach { opt ->
                    DownloadOptionRow(opt = opt, onClick = { onDownloadOption(opt) })
                }
            }
        }
    }
}


@Composable
private fun DownloadOptionRow(
    opt: DownloadOption,
    onClick: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.boxBg)
            .border(1.2.dp, palette.boxBorder.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = Icons.Rounded.Download,
                contentDescription = null,
                tint = palette.fg,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = opt.label,
                color = palette.textPrimary,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
        Text(
            text = "Open",
            color = palette.fg,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun SeasonPill(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) palette.fg else palette.boxBg)
            .border(1.dp, if (selected) palette.fg else palette.boxBorder, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = if (selected) palette.onAccent else palette.textPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
