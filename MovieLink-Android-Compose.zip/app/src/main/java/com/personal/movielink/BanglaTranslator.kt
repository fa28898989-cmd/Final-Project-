package com.personal.movielink

object BanglaTranslator {
    private val bnDigits = mapOf(
        '০' to '0', '১' to '1', '২' to '2', '৩' to '3', '৪' to '4',
        '৫' to '5', '৬' to '6', '৭' to '7', '৮' to '8', '৯' to '9'
    )

    private val phrases = listOf(
        "সার্চ করে খুঁজে নিন আপনার পছন্দের সিজন-এপিসোড…" to "Search season or episode…",
        "সার্চ করে খুঁজে নিন আপনার পছন্দের সিজন-এপিসোড..." to "Search season or episode…",
        "Movie বা Series-এর English নাম লিখুন" to "Search Movie or Series in English",
        "বাংলা • হিন্দি • সাউথ • K/J/C ড্রামা • অ্যানিমে" to "Bangla • Hindi • South • K/J/C Drama • Anime",
        "এই কনটেন্টটি কেমন?" to "How is this title?",
        "একটি option টিক দিয়ে আপনার মতামত জানান।" to "Select an option to share your rating.",
        "একটি option টিক দিয়ে আপনার মতামত জানান।" to "Select an option to share your rating.",
        "Community score তৈরি হচ্ছে" to "Building Community Score",
        "কমপক্ষে ২০টি vote হলে Community Score দেখানো হবে" to "Community Score shows once 20+ votes are recorded",
        "দর্শক এটি দেখার পরামর্শ দিয়েছেন" to "of viewers recommend watching this",
        "দর্শক এটি দেখার পরামর্শ দিয়েছেন" to "of viewers recommend watching this",
        "অবশ্যই দেখুন" to "Must Watch",
        "ভালো লেগেছে" to "Good",
        "মোটামুটি" to "Average",
        "মুভি প্লে করলে যদি সাউন্ড না আসে" to "No sound while playing the video?",
        "দিয়ে প্লে করুন — সমস্যা ঠিক হবে।" to "— play with it to fix audio issues.",
        "দিয়ে প্লে করুন — সমস্যা ঠিক হবে।" to "— play with it to fix audio issues.",
        "📥 VLC Player ডাউনলোড" to "Download VLC Player",
        "VLC Player ডাউনলোড" to "Download VLC Player",
        "অনলাইনে দেখুন" to "Watch Online",
        "Ads ছাড়াই" to "Ad-Free",
        "Ads ছাড়াই" to "Ad-Free",
        "সম্পূর্ণ ফ্রি" to "100% Free",
        ", শুধু " to ", only on ",
        "ভিডিও লোড হচ্ছে..." to "Loading video…",
        "ভিডিও লোড হচ্ছে…" to "Loading video…",
        "ভিডিও লোড হচ্ছে" to "Loading video…",
        "Ready হচ্ছে" to "Getting Ready",
        "লোড হচ্ছে" to "Loading",
        "তুমি সম্পূর্ণ" to "You are watching",
        "দেখছ — কোনো অ্যাড নেই!" to "— with zero ads!",
        "কোনো অ্যাড নেই" to "No ads",
        "নতুন পর্ব" to "New Episode",
        "নতুন এপিসোড" to "New Episode",
        "প্রতিদিন" to "Daily",
        "প্রতি " to "Every ",
        "শনিবার" to "Saturday",
        "রবিবার" to "Sunday",
        "সোমবার" to "Monday",
        "মঙ্গলবার" to "Tuesday",
        "বুধবার" to "Wednesday",
        "বৃহস্পতিবার" to "Thursday",
        "শুক্রবার" to "Friday",
        "আগেও ফ্রি ছিল," to "was always free,",
        "সবসময় ফ্রিই থাকবে" to "and will stay free forever",
        "সবসময় ফ্রিই থাকবে" to "and will stay free forever",
        "মুভিটা আজকে হয়তো" to "movie might drop today in",
        "মুভিটা আজকে হয়তো" to "movie might drop today in",
        "আসবে আসা মাত্রই সাইটে দিয়ে দিবো" to "— will be added as soon as it arrives",
        "আসবে আসা মাত্রই সাইটে দিয়ে দিবো" to "— will be added as soon as it arrives",
        "আসা মাত্রই সাইটে দিয়ে দিবো" to "— will be added as soon as it arrives",
        "আসা মাত্রই সাইটে দিয়ে দিবো" to "— will be added as soon as it arrives",
        "ডাউনলোড করার নিয়ম" to "How to Download",
        "ডাউনলোড করার নিয়ম" to "How to Download",
        "খুব শীঘ্রই" to "coming soon",
        "তারিখ" to "th",
        "সামনের" to "coming",
        "আজকে" to "today",
        "আসবে" to "is coming",
        "পর্ব" to "Episode",
        "সিজন" to "Season",
        "নতুন" to "New",
        "হিন্দি" to "Hindi",
        "বাংলা" to "Bangla",
        "ইংরেজি" to "English",
        "ডাউনলোড" to "Download",
        "মুভিটা" to "movie",
        "সিরিজটা" to "series",
        "নোট" to "Notice",
        "বিঃদ্রঃ" to "Note"
    )

    private val clutterPatterns = listOf(
        Regex("""MovieLinkBD\s*[—\-]+\s*Unlimited\s+Downloads""", RegexOption.IGNORE_CASE),
        Regex("""Working\s+official\s+link""", RegexOption.IGNORE_CASE),
        Regex("""1\.1\.1\.1\s*VPN""", RegexOption.IGNORE_CASE),
        Regex("""Join\s+(?:Us\s+On\s+)?Telegram""", RegexOption.IGNORE_CASE),
        Regex("""Join\s+(?:Facebook\s+)?Group""", RegexOption.IGNORE_CASE)
    )

    fun isClutterText(text: String): Boolean {
        val clean = text.trim()
        if (clean.isEmpty()) return false
        return clutterPatterns.any { it.containsMatchIn(clean) }
    }

    fun convertNumerals(input: String): String {
        if (input.none { it in '০'..'৯' }) return input
        val sb = StringBuilder(input.length)
        for (ch in input) {
            sb.append(bnDigits[ch] ?: ch)
        }
        return sb.toString()
    }

    fun translateUi(input: String, enabled: Boolean = true): String {
        if (!enabled || input.isBlank()) return input
        val hasBangla = input.any { it in '\u0980'..'\u09FF' }
        if (!hasBangla) return input
        var out = input
        for ((bn, en) in phrases) {
            if (out.contains(bn)) {
                out = out.replace(bn, en)
            }
        }
        out = convertNumerals(out)
        return out.replace(Regex("""\s{2,}"""), " ").trim()
    }
}
