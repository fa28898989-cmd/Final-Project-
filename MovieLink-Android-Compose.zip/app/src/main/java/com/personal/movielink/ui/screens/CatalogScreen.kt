package com.personal.movielink.ui.screens

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.FormatListBulleted
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.OpenInBrowser
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material.icons.rounded.ViewCarousel
import androidx.compose.material.icons.rounded.ViewList
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.graphics.ColorUtils
import coil.ImageLoader
import coil.compose.AsyncImage
import com.personal.movielink.AppSettingsStore
import com.personal.movielink.CatalogPage
import com.personal.movielink.CategoryChip
import com.personal.movielink.CombinedHomeSectionState
import com.personal.movielink.Config
import com.personal.movielink.DownloadAndPlayerRouter
import com.personal.movielink.HeroSectionState
import com.personal.movielink.HistoryItem
import com.personal.movielink.MediaCard
import com.personal.movielink.MyListItem
import com.personal.movielink.OttPlatform
import com.personal.movielink.PlaybackProgressItem
import com.personal.movielink.UnifiedSearchState
import com.personal.movielink.UserSettings
import com.personal.movielink.addons.ContentProviderKind
import com.personal.movielink.addons.UnifiedPosterItem
import com.personal.movielink.ui.components.focusedAlignment
import com.personal.movielink.ui.components.rememberBackdropFocusState
import com.personal.movielink.ui.components.revealAlpha
import com.personal.movielink.ui.components.scaleHeroBannerHeight
import com.personal.movielink.ui.theme.LocalMovieLinkPalette
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.absoluteValue

private enum class HomeBottomTab { HOME, SEARCH, LIBRARY }
private enum class SearchResultsTab { DEFAULT, ADDON }

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CatalogScreen(
    catalog: CatalogPage?,
    combinedHomeSections: List<CombinedHomeSectionState>,
    heroState: HeroSectionState,
    heroEnrichedItems: Map<String, UnifiedPosterItem> = emptyMap(),
    unifiedSearch: UnifiedSearchState,
    useCombinedHomeFeed: Boolean,
    isLoading: Boolean,
    errorMessage: String?,
    settings: UserSettings,
    imageLoader: ImageLoader,
    myList: List<MyListItem>,
    history: List<HistoryItem>,
    continueWatching: List<PlaybackProgressItem>,
    onRefresh: () -> Unit,
    onSearch: (String) -> Unit,
    onClearSearch: () -> Unit,
    onRetryMovieLinkSearch: () -> Unit,
    onLoadMoreMovieLinkSearch: () -> Unit,
    onRetryAddonSearchGroup: (String) -> Unit,
    onLoadMoreAddonSearchGroup: (String) -> Unit,
    onOpenUrl: (String) -> Unit,
    onOpenMedia: (MediaCard) -> Unit,
    onOpenPoster: (UnifiedPosterItem) -> Unit,
    onTogglePosterMyList: (UnifiedPosterItem) -> Boolean,
    isPosterInMyList: (UnifiedPosterItem) -> Boolean,
    onResumeContinueWatching: (PlaybackProgressItem) -> Unit,
    onRemoveContinueWatching: (String) -> Unit,
    onToggleContinueWatchingLayout: () -> Unit,
    onOpenAddonViewAll: (CombinedHomeSectionState) -> Unit,
    onRetryAddonSection: (String) -> Unit,
    onOpenHistoryItem: (HistoryItem) -> Unit,
    onOpenMyListItem: (MyListItem) -> Unit,
    onRemoveMyList: (String) -> Unit,
    onClearHistory: () -> Unit,
    onOpenHistoryDialog: () -> Unit,
    onOpenFallbackWeb: () -> Unit,
    onPlayLocalVideo: () -> Unit,
    onOpenSettings: () -> Unit,
    onEnsureHeroEnriched: (List<UnifiedPosterItem>) -> Unit = {},
    onQuickAddonStreams: (UnifiedPosterItem) -> Unit = {}
) {
    val palette = LocalMovieLinkPalette.current
    val keyboard = LocalSoftwareKeyboardController.current
    var activeBottomTab by remember { mutableStateOf(HomeBottomTab.HOME) }
    var activeSearchTab by remember { mutableStateOf(SearchResultsTab.DEFAULT) }
    var librarySection by remember { mutableIntStateOf(0) } // 0 = My List, 1 = History
    var searchText by remember { mutableStateOf("") }
    var showCategoriesModal by remember { mutableStateOf(false) }
    var pendingRemoveContinueItem by remember { mutableStateOf<PlaybackProgressItem?>(null) }
    var contextMenuPoster by remember { mutableStateOf<UnifiedPosterItem?>(null) }

    val baseMirror = remember(settings.mirrorUrl) { settings.mirrorUrl.trimEnd('/') }
    val seriesUrl = remember(catalog, baseMirror) {
        catalog?.categories?.firstOrNull { it.url.contains("/type/series", true) }?.url
            ?: "$baseMirror/type/series"
    }
    val moviesUrl = remember(catalog, baseMirror) {
        catalog?.categories?.firstOrNull { it.url.contains("/type/movies", true) }?.url
            ?: "$baseMirror/type/movies"
    }

    val currentPath = catalog?.url.orEmpty().lowercase()
    val isTvActive = currentPath.contains("/type/series")
    val isMoviesActive = currentPath.contains("/type/movies")
    val isSearchCatalog = currentPath.contains("/search")

    // Stay cleanly on SEARCH tab whenever unified search or site /search URL is active
    LaunchedEffect(catalog?.url, unifiedSearch.hasSearched) {
        if (unifiedSearch.hasSearched || catalog?.url?.contains("/search", ignoreCase = true) == true) {
            activeBottomTab = HomeBottomTab.SEARCH
        }
    }
    LaunchedEffect(unifiedSearch.query) {
        if (unifiedSearch.query.isNotBlank() && searchText != unifiedSearch.query) {
            searchText = unifiedSearch.query
        }
    }
    LaunchedEffect(
        unifiedSearch.hasSearched,
        settings.movieLinkSearchEnabled,
        settings.nuvioIntegrationEnabled,
        settings.nuvioSearchEnabled
    ) {
        if (!settings.movieLinkSearchEnabled && settings.nuvioIntegrationEnabled && settings.nuvioSearchEnabled) {
            activeSearchTab = SearchResultsTab.ADDON
        } else if (settings.movieLinkSearchEnabled && !(settings.nuvioIntegrationEnabled && settings.nuvioSearchEnabled)) {
            activeSearchTab = SearchResultsTab.DEFAULT
        }
    }

    val statusBarTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navBarBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val floatingExtraBottom = if (settings.floatingNavBar) {
        (settings.floatingNavHeightDp.coerceIn(44, 80) + settings.floatingNavSpacingDp.coerceIn(4, 40) + 18).dp + navBarBottom
    } else {
        0.dp
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.pageBg)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Box(modifier = Modifier.weight(1f)) {
            when (activeBottomTab) {
                HomeBottomTab.HOME -> {
                    Column(modifier = Modifier.fillMaxSize()) {
                        PullToRefreshBox(
                            isRefreshing = isLoading && catalog != null,
                            onRefresh = onRefresh,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            when {
                                isLoading && catalog == null -> {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            CircularProgressIndicator(color = palette.fg)
                                            Spacer(Modifier.height(12.dp))
                                            Text(
                                                text = "Loading live catalog…",
                                                color = palette.textSecondary,
                                                fontSize = 13.5.sp
                                            )
                                        }
                                    }
                                }
                                errorMessage != null && catalog == null -> {
                                    ErrorRetryState(
                                        message = errorMessage,
                                        onRetry = onRefresh,
                                        onOpenWeb = onOpenFallbackWeb,
                                        onOpenSettings = onOpenSettings
                                    )
                                }
                                catalog == null || catalog.sections.isEmpty() -> {
                                    ErrorRetryState(
                                        message = "No titles found on this page.",
                                        onRetry = onRefresh,
                                        onOpenWeb = onOpenFallbackWeb,
                                        onOpenSettings = onOpenSettings
                                    )
                                }
                                catalog.isSearchOrGrid -> {
                                    val gridItems = catalog.sections.flatMap { it.items }.distinctBy { it.url }
                                    LazyColumn(
                                        modifier = Modifier.fillMaxSize(),
                                        contentPadding = PaddingValues(
                                            start = 14.dp,
                                            top = 14.dp + statusBarTop,
                                            end = 14.dp,
                                            bottom = 14.dp + floatingExtraBottom
                                        ),
                                        verticalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        item {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(
                                                    text = catalog.pageTitle,
                                                    fontSize = 16.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = palette.textPrimary,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    modifier = Modifier.weight(1f)
                                                )
                                                Text(
                                                    text = "Back to Home",
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = palette.fg,
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .clickable { onOpenUrl(settings.mirrorUrl) }
                                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                        }
                                        val rows = gridItems.chunked(2)
                                        items(rows) { rowCards ->
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                                            ) {
                                                rowCards.forEach { card ->
                                                    MediaPosterCard(
                                                        card = card,
                                                        imageLoader = imageLoader,
                                                        onClick = { onOpenMedia(card) },
                                                        onLongClick = {
                                                            contextMenuPoster = UnifiedPosterItem.fromMovieLink(card)
                                                        },
                                                        modifier = Modifier.weight(1f)
                                                    )
                                                }
                                                if (rowCards.size == 1) {
                                                    Spacer(Modifier.weight(1f))
                                                }
                                            }
                                        }
                                        if (catalog.nextPageUrl != null) {
                                            item {
                                                OutlinedButton(
                                                    onClick = { onOpenUrl(catalog.nextPageUrl) },
                                                    shape = RoundedCornerShape(12.dp),
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Text("Next Page", color = palette.fg, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                }
                                else -> {
                                    val baseSubpageHeroItems = remember(catalog) {
                                        val movieSectionItems = catalog.sections
                                            .filter {
                                                it.title.equals("Movies", ignoreCase = true) ||
                                                    (it.title.contains("Movie", ignoreCase = true) &&
                                                        !it.title.contains("Recently", ignoreCase = true))
                                            }
                                            .flatMap { it.items }
                                        val otherMovieItems = catalog.sections
                                            .filterNot {
                                                it.title.contains("Recently Updated", ignoreCase = true) ||
                                                    it.title.contains("Recently Uploaded", ignoreCase = true)
                                            }
                                            .flatMap { it.items }
                                            .filter { it.url.contains("/movie/", ignoreCase = true) }
                                        val nonRecentFallback = catalog.sections
                                            .filterNot {
                                                it.title.contains("Recently Updated", ignoreCase = true) ||
                                                    it.title.contains("Recently Uploaded", ignoreCase = true)
                                            }
                                            .flatMap { it.items }
                                        val prioritized = (movieSectionItems + otherMovieItems).ifEmpty {
                                            nonRecentFallback.ifEmpty { catalog.sections.flatMap { it.items } }
                                        }
                                        prioritized
                                            .filter { it.posterUrl.isNotBlank() }
                                            .distinctBy { it.url }
                                            .take(6)
                                            .map { UnifiedPosterItem.fromMovieLink(it) }
                                    }

                                    LaunchedEffect(useCombinedHomeFeed, baseSubpageHeroItems) {
                                        if (!useCombinedHomeFeed && baseSubpageHeroItems.isNotEmpty()) {
                                            onEnsureHeroEnriched(baseSubpageHeroItems)
                                        }
                                    }

                                    val subpageHeroItems = remember(baseSubpageHeroItems, heroEnrichedItems) {
                                        if (heroEnrichedItems.isEmpty()) {
                                            baseSubpageHeroItems
                                        } else {
                                            baseSubpageHeroItems.map { item ->
                                                val enriched = heroEnrichedItems[item.stableKey] ?: return@map item
                                                item.copy(
                                                    backdropUrl = enriched.backdropUrl.ifBlank { item.backdropUrl },
                                                    logoUrl = enriched.logoUrl.ifBlank { item.logoUrl },
                                                    rating = item.rating.ifBlank { enriched.rating },
                                                    yearOrRelease = item.yearOrRelease.ifBlank { enriched.yearOrRelease },
                                                    genres = item.genres.ifEmpty { enriched.genres },
                                                    description = item.description.ifBlank { enriched.description }
                                                )
                                            }
                                        }
                                    }

                                    val isSpotlightShown = settings.heroLayoutStyle == Config.HeroLayoutStyle.SPOTLIGHT &&
                                        ((useCombinedHomeFeed && !heroState.hidden && heroState.items.isNotEmpty()) ||
                                            (!useCombinedHomeFeed && subpageHeroItems.isNotEmpty()))
                                    val homeListState = rememberLazyListState()
                                    LazyColumn(
                                        state = homeListState,
                                        modifier = Modifier.fillMaxSize(),
                                        contentPadding = PaddingValues(
                                            top = if (isSpotlightShown) 0.dp else statusBarTop + 8.dp,
                                            bottom = 18.dp + floatingExtraBottom
                                        ),
                                        verticalArrangement = Arrangement.spacedBy(18.dp)
                                    ) {
                                        if (useCombinedHomeFeed) {
                                            if (!heroState.hidden) {
                                                if (heroState.items.isNotEmpty()) {
                                                    item(key = "hero_${settings.heroLayoutStyle.id}") {
                                                        if (settings.heroLayoutStyle == Config.HeroLayoutStyle.SPOTLIGHT) {
                                                            HeroSpotlightBanner(
                                                                items = heroState.items,
                                                                sourceTitle = heroState.activeSourceTitle,
                                                                autoRotate = settings.heroAutoRotate,
                                                                heroSizePercent = settings.heroSizePercent,
                                                                listState = homeListState,
                                                                imageLoader = imageLoader,
                                                                isInMyList = isPosterInMyList,
                                                                onToggleMyList = onTogglePosterMyList,
                                                                onOpenPoster = onOpenPoster
                                                            )
                                                        } else {
                                                            HeroCoverflowCarousel(
                                                                items = heroState.items,
                                                                autoRotate = settings.heroAutoRotate,
                                                                heroSizePercent = settings.heroSizePercent,
                                                                imageLoader = imageLoader,
                                                                onOpenPoster = onOpenPoster
                                                            )
                                                        }
                                                    }
                                                } else if (heroState.isLoading) {
                                                    item(key = "hero_loading") {
                                                        Box(
                                                            modifier = Modifier
                                                                .fillMaxWidth()
                                                                .height(scaleHeroBannerHeight(220.dp, settings.heroSizePercent)),
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            CircularProgressIndicator(
                                                                color = palette.fg,
                                                                strokeWidth = 2.dp,
                                                                modifier = Modifier.size(26.dp)
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        } else if (subpageHeroItems.isNotEmpty()) {
                                            item(key = "subpage_hero_${settings.heroLayoutStyle.id}") {
                                                if (settings.heroLayoutStyle == Config.HeroLayoutStyle.SPOTLIGHT) {
                                                    HeroSpotlightBanner(
                                                        items = subpageHeroItems,
                                                        sourceTitle = catalog.pageTitle.takeIf { it.isNotBlank() },
                                                        autoRotate = settings.heroAutoRotate,
                                                        heroSizePercent = settings.heroSizePercent,
                                                        listState = homeListState,
                                                        imageLoader = imageLoader,
                                                        isInMyList = isPosterInMyList,
                                                        onToggleMyList = onTogglePosterMyList,
                                                        onOpenPoster = onOpenPoster
                                                    )
                                                } else {
                                                    HeroCoverflowCarousel(
                                                        items = subpageHeroItems,
                                                        autoRotate = settings.heroAutoRotate,
                                                        heroSizePercent = settings.heroSizePercent,
                                                        imageLoader = imageLoader,
                                                        onOpenPoster = onOpenPoster
                                                    )
                                                }
                                            }
                                        }

                                        if (continueWatching.isNotEmpty()) {
                                            item(key = "continue_watching_${settings.continueWatchingLayout.id}") {
                                                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                                    Row(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .padding(horizontal = 14.dp),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = "Continue Watching",
                                                            fontSize = 18.sp,
                                                            fontWeight = FontWeight.ExtraBold,
                                                            color = palette.textPrimary
                                                        )
                                                        Row(
                                                            verticalAlignment = Alignment.CenterVertically,
                                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                        ) {
                                                            Row(
                                                                modifier = Modifier
                                                                    .clip(RoundedCornerShape(50))
                                                                    .background(palette.altBg)
                                                                    .border(
                                                                        1.dp,
                                                                        palette.border.copy(alpha = 0.25f),
                                                                        RoundedCornerShape(50)
                                                                    )
                                                                    .clickable(onClick = onToggleContinueWatchingLayout)
                                                                    .padding(horizontal = 9.dp, vertical = 4.dp),
                                                                verticalAlignment = Alignment.CenterVertically,
                                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                            ) {
                                                                Icon(
                                                                    imageVector = if (settings.continueWatchingLayout == Config.ContinueWatchingLayout.VERTICAL) {
                                                                        Icons.Rounded.ViewCarousel
                                                                    } else {
                                                                        Icons.Rounded.ViewList
                                                                    },
                                                                    contentDescription = "Switch Continue Watching layout",
                                                                    tint = palette.fg,
                                                                    modifier = Modifier.size(13.dp)
                                                                )
                                                                Text(
                                                                    text = if (settings.continueWatchingLayout == Config.ContinueWatchingLayout.VERTICAL) {
                                                                        "Vertical"
                                                                    } else {
                                                                        "Horizontal"
                                                                    },
                                                                    fontSize = 11.sp,
                                                                    fontWeight = FontWeight.SemiBold,
                                                                    color = palette.textPrimary
                                                                )
                                                            }
                                                            Text(
                                                                text = "History",
                                                                fontSize = 12.sp,
                                                                fontWeight = FontWeight.SemiBold,
                                                                color = palette.fg,
                                                                modifier = Modifier
                                                                    .clip(RoundedCornerShape(8.dp))
                                                                    .clickable(onClick = onOpenHistoryDialog)
                                                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                                                            )
                                                        }
                                                    }
                                                    LazyRow(
                                                        contentPadding = PaddingValues(horizontal = 14.dp),
                                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                                    ) {
                                                        items(continueWatching, key = { it.mediaKey }) { cw ->
                                                            if (settings.continueWatchingLayout == Config.ContinueWatchingLayout.VERTICAL) {
                                                                ContinueWatchingVerticalCard(
                                                                    item = cw,
                                                                    imageLoader = imageLoader,
                                                                    onClick = { onResumeContinueWatching(cw) },
                                                                    onLongClick = { pendingRemoveContinueItem = cw }
                                                                )
                                                            } else {
                                                                ContinueWatchingHorizontalCard(
                                                                    item = cw,
                                                                    imageLoader = imageLoader,
                                                                    onClick = { onResumeContinueWatching(cw) },
                                                                    onLongClick = { pendingRemoveContinueItem = cw }
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        if (settings.showOttSection && catalog.ottPlatforms.isNotEmpty()) {
                                            item(key = "watch_by_ott") {
                                                WatchByOttSection(
                                                    platforms = catalog.ottPlatforms,
                                                    imageLoader = imageLoader,
                                                    onOpenUrl = onOpenUrl
                                                )
                                            }
                                        }

                                        if (useCombinedHomeFeed) {
                                            items(combinedHomeSections, key = { it.key }) { section ->
                                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                                    Row(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .padding(horizontal = 14.dp),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                                                            Text(
                                                                text = section.title,
                                                                fontSize = 16.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = palette.textPrimary,
                                                                maxLines = 1,
                                                                overflow = TextOverflow.Ellipsis
                                                            )
                                                            if (section.provider == ContentProviderKind.STREMIO_ADDON &&
                                                                !section.addonName.isNullOrBlank()
                                                            ) {
                                                                Text(
                                                                    text = section.addonName,
                                                                    fontSize = 10.5.sp,
                                                                    fontWeight = FontWeight.Medium,
                                                                    color = palette.textSecondary,
                                                                    maxLines = 1,
                                                                    overflow = TextOverflow.Ellipsis
                                                                )
                                                            }
                                                        }

                                                        if (section.moreUrl != null) {
                                                            Text(
                                                                text = "View all",
                                                                fontSize = 12.sp,
                                                                fontWeight = FontWeight.SemiBold,
                                                                color = palette.fg,
                                                                modifier = Modifier
                                                                    .clip(RoundedCornerShape(8.dp))
                                                                    .clickable { onOpenUrl(section.moreUrl) }
                                                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                                                            )
                                                        } else if (section.hasAddonViewAll) {
                                                            Text(
                                                                text = "View all",
                                                                fontSize = 12.sp,
                                                                fontWeight = FontWeight.SemiBold,
                                                                color = palette.fg,
                                                                modifier = Modifier
                                                                    .clip(RoundedCornerShape(8.dp))
                                                                    .clickable { onOpenAddonViewAll(section) }
                                                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                                                            )
                                                        }
                                                    }

                                                    when {
                                                        section.isLoading && section.items.isEmpty() -> {
                                                            Row(
                                                                modifier = Modifier
                                                                    .fillMaxWidth()
                                                                    .padding(horizontal = 14.dp, vertical = 20.dp),
                                                                verticalAlignment = Alignment.CenterVertically,
                                                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                            ) {
                                                                CircularProgressIndicator(
                                                                    color = palette.fg,
                                                                    strokeWidth = 2.dp,
                                                                    modifier = Modifier.size(18.dp)
                                                                )
                                                                Text(
                                                                    text = "Loading ${section.title}…",
                                                                    color = palette.textSecondary,
                                                                    fontSize = 12.sp
                                                                )
                                                            }
                                                        }
                                                        section.error != null && section.items.isEmpty() -> {
                                                            Row(
                                                                modifier = Modifier
                                                                    .fillMaxWidth()
                                                                    .padding(horizontal = 14.dp)
                                                                    .clip(RoundedCornerShape(10.dp))
                                                                    .background(palette.altBg)
                                                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                                                verticalAlignment = Alignment.CenterVertically,
                                                                horizontalArrangement = Arrangement.SpaceBetween
                                                            ) {
                                                                Text(
                                                                    text = section.error,
                                                                    color = palette.textSecondary,
                                                                    fontSize = 11.5.sp,
                                                                    maxLines = 2,
                                                                    overflow = TextOverflow.Ellipsis,
                                                                    modifier = Modifier.weight(1f).padding(end = 8.dp)
                                                                )
                                                                Text(
                                                                    text = "Retry",
                                                                    color = palette.fg,
                                                                    fontSize = 12.sp,
                                                                    fontWeight = FontWeight.Bold,
                                                                    modifier = Modifier
                                                                        .clip(RoundedCornerShape(6.dp))
                                                                        .clickable { onRetryAddonSection(section.key) }
                                                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                                                )
                                                            }
                                                        }
                                                        section.items.isNotEmpty() -> {
                                                            LazyRow(
                                                                contentPadding = PaddingValues(horizontal = 14.dp),
                                                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                            ) {
                                                                items(section.items, key = { it.stableKey }) { poster ->
                                                                    UnifiedHomeRailPosterCard(
                                                                        item = poster,
                                                                        imageLoader = imageLoader,
                                                                        onClick = { onOpenPoster(poster) },
                                                                        onLongClick = { contextMenuPoster = poster }
                                                                    )
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        } else {
                                            // Website sub-pages (Movies / TV Shows / Categories) preserve live site sections directly
                                            items(catalog.sections, key = { it.title + (it.items.firstOrNull()?.url ?: "") }) { section ->
                                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                                    Row(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .padding(horizontal = 14.dp),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = section.title,
                                                            fontSize = 16.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = palette.textPrimary,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis,
                                                            modifier = Modifier.weight(1f)
                                                        )
                                                        if (section.moreUrl != null) {
                                                            Text(
                                                                text = "View all",
                                                                fontSize = 12.sp,
                                                                fontWeight = FontWeight.SemiBold,
                                                                color = palette.fg,
                                                                modifier = Modifier
                                                                    .clip(RoundedCornerShape(8.dp))
                                                                    .clickable { onOpenUrl(section.moreUrl) }
                                                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                                                            )
                                                        }
                                                    }

                                                    LazyRow(
                                                        contentPadding = PaddingValues(horizontal = 14.dp),
                                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                    ) {
                                                        items(section.items, key = { it.url }) { card ->
                                                            HomeRailPosterCard(
                                                                card = card,
                                                                imageLoader = imageLoader,
                                                                onClick = { onOpenMedia(card) },
                                                                onLongClick = {
                                                                    contextMenuPoster = UnifiedPosterItem.fromMovieLink(card)
                                                                }
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        if (catalog.nextPageUrl != null) {
                                            item {
                                                Box(modifier = Modifier.padding(horizontal = 14.dp)) {
                                                    OutlinedButton(
                                                        onClick = { onOpenUrl(catalog.nextPageUrl) },
                                                        shape = RoundedCornerShape(12.dp),
                                                        modifier = Modifier.fillMaxWidth()
                                                    ) {
                                                        Text("Next Page", color = palette.fg, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                HomeBottomTab.SEARCH -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .statusBarsPadding()
                            .padding(top = 12.dp)
                    ) {
                        Text(
                            text = "Search",
                            color = palette.textPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = searchText,
                            onValueChange = { searchText = it },
                            placeholder = {
                                Text(
                                    text = "Search Movie or Series in English",
                                    fontSize = 13.5.sp,
                                    color = palette.textSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            leadingIcon = {
                                Icon(Icons.Rounded.Search, contentDescription = null, tint = palette.fg)
                            },
                            trailingIcon = {
                                if (searchText.isNotEmpty() || unifiedSearch.hasSearched) {
                                    IconButton(
                                        onClick = {
                                            searchText = ""
                                            onClearSearch()
                                        }
                                    ) {
                                        Icon(Icons.Rounded.Close, contentDescription = "Clear", tint = palette.textSecondary)
                                    }
                                }
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(
                                onSearch = {
                                    if (searchText.isNotBlank()) {
                                        keyboard?.hide()
                                        onSearch(searchText)
                                    }
                                }
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = palette.cardBg,
                                unfocusedContainerColor = palette.cardBg,
                                focusedBorderColor = palette.boxBorder,
                                unfocusedBorderColor = palette.border.copy(alpha = 0.45f),
                                focusedTextColor = palette.textPrimary,
                                unfocusedTextColor = palette.textPrimary,
                                cursorColor = palette.fg
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp)
                        )

                        Spacer(Modifier.height(10.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TopFilterPill(
                                label = "TV Shows",
                                selected = isTvActive,
                                onClick = {
                                    activeBottomTab = HomeBottomTab.HOME
                                    onOpenUrl(seriesUrl)
                                },
                                modifier = Modifier.weight(1f)
                            )
                            TopFilterPill(
                                label = "Movies",
                                selected = isMoviesActive,
                                onClick = {
                                    activeBottomTab = HomeBottomTab.HOME
                                    onOpenUrl(moviesUrl)
                                },
                                modifier = Modifier.weight(1f)
                            )
                            TopFilterPill(
                                label = "Categories",
                                selected = showCategoriesModal,
                                hasCaret = true,
                                onClick = { showCategoriesModal = true },
                                modifier = Modifier.weight(1.1f)
                            )
                        }

                        Spacer(Modifier.height(10.dp))

                        if (!unifiedSearch.hasSearched && catalog != null && catalog.categories.isNotEmpty() && !isSearchCatalog) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState())
                                    .padding(
                                        start = 14.dp,
                                        top = 14.dp,
                                        end = 14.dp,
                                        bottom = 14.dp + floatingExtraBottom
                                    ),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = "Browse by Genre & Language",
                                    color = palette.textSecondary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    catalog.categories.forEach { cat ->
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(palette.boxBg)
                                                .border(1.dp, palette.boxBorder.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                                                .clickable {
                                                    activeBottomTab = HomeBottomTab.HOME
                                                    onOpenUrl(cat.url)
                                                }
                                                .padding(horizontal = 12.dp, vertical = 8.dp)
                                        ) {
                                            Text(
                                                text = cat.label,
                                                color = palette.textPrimary,
                                                fontSize = 12.5.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                }
                            }
                        } else if (!unifiedSearch.hasSearched) {
                            if (isLoading) {
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator(color = palette.fg)
                                }
                            } else {
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "Search movies or series across enabled providers.",
                                        color = palette.textSecondary,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        } else {
                            val mlSearchEnabled = settings.movieLinkSearchEnabled
                            val nuvioSearchActive = settings.nuvioIntegrationEnabled && settings.nuvioSearchEnabled
                            val mlState = unifiedSearch.movieLink
                            val addonState = unifiedSearch.addons
                            val totalAddonItems = addonState.groups.sumOf { it.items.size }

                            Column(modifier = Modifier.fillMaxSize()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Results for \"${unifiedSearch.query}\"",
                                        color = palette.textPrimary,
                                        fontSize = 13.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f).padding(end = 8.dp)
                                    )
                                    Text(
                                        text = "Genres",
                                        color = palette.fg,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable {
                                                searchText = ""
                                                onClearSearch()
                                            }
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }

                                // Separate Search Results Tabs: Default Results vs Addon Results
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    TopFilterPill(
                                        label = if (mlState.isLoading && mlState.items.isEmpty()) {
                                            "Default Results…"
                                        } else {
                                            "Default Results (${mlState.items.size})"
                                        },
                                        selected = activeSearchTab == SearchResultsTab.DEFAULT,
                                        onClick = { activeSearchTab = SearchResultsTab.DEFAULT },
                                        modifier = Modifier.weight(1f)
                                    )
                                    val anyAddonLoading = addonState.groups.any { it.isLoading && it.items.isEmpty() }
                                    TopFilterPill(
                                        label = if (anyAddonLoading && totalAddonItems == 0) {
                                            "Addon Results…"
                                        } else {
                                            "Addon Results ($totalAddonItems)"
                                        },
                                        selected = activeSearchTab == SearchResultsTab.ADDON,
                                        onClick = { activeSearchTab = SearchResultsTab.ADDON },
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                LazyColumn(
                                    modifier = Modifier.fillMaxSize(),
                                    contentPadding = PaddingValues(
                                        start = 14.dp,
                                        top = 6.dp,
                                        end = 14.dp,
                                        bottom = 18.dp + floatingExtraBottom
                                    ),
                                    verticalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    if (!mlSearchEnabled && !nuvioSearchActive) {
                                        item(key = "search_all_disabled") {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(12.dp))
                                                    .background(palette.altBg)
                                                    .padding(14.dp)
                                            ) {
                                                Text(
                                                    text = "Both MovieLinkBD Search and Nuvio Addon Search are turned off in Settings → Search & Streaming.",
                                                    color = palette.textSecondary,
                                                    fontSize = 12.5.sp
                                                )
                                            }
                                        }
                                    } else if (activeSearchTab == SearchResultsTab.DEFAULT) {
                                        if (!mlSearchEnabled) {
                                            item(key = "ml_search_disabled") {
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clip(RoundedCornerShape(12.dp))
                                                        .background(palette.altBg)
                                                        .padding(14.dp)
                                                ) {
                                                    Text(
                                                        text = "MovieLinkBD Search is turned off in Settings → Search & Streaming. Switch to Addon Results or re-enable it in Settings.",
                                                        color = palette.textSecondary,
                                                        fontSize = 12.5.sp
                                                    )
                                                }
                                            }
                                        } else {
                                            item(key = "ml_search_header") {
                                                SearchProviderSectionHeader(
                                                    title = "MOVIELINKBD RESULTS",
                                                    count = mlState.items.size
                                                )
                                            }

                                            when {
                                                mlState.isLoading && mlState.items.isEmpty() -> {
                                                    item(key = "ml_search_loading") {
                                                        Row(
                                                            modifier = Modifier
                                                                .fillMaxWidth()
                                                                .padding(vertical = 12.dp),
                                                            verticalAlignment = Alignment.CenterVertically,
                                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                        ) {
                                                            CircularProgressIndicator(
                                                                color = palette.fg,
                                                                strokeWidth = 2.dp,
                                                                modifier = Modifier.size(18.dp)
                                                            )
                                                            Text(
                                                                text = "Searching MovieLinkBD…",
                                                                color = palette.textSecondary,
                                                                fontSize = 12.5.sp
                                                            )
                                                        }
                                                    }
                                                }
                                                mlState.error != null && mlState.items.isEmpty() -> {
                                                    item(key = "ml_search_error") {
                                                        SearchProviderErrorBox(
                                                            message = mlState.error,
                                                            onRetry = onRetryMovieLinkSearch
                                                        )
                                                    }
                                                }
                                                mlState.items.isEmpty() -> {
                                                    item(key = "ml_search_empty") {
                                                        Text(
                                                            text = "No matching MovieLinkBD titles found.",
                                                            color = palette.textSecondary,
                                                            fontSize = 12.5.sp
                                                        )
                                                    }
                                                }
                                                else -> {
                                                    val mlRows = mlState.items.chunked(2)
                                                    items(mlRows, key = { row -> "ml_" + row.joinToString("|") { it.stableKey } }) { rowItems ->
                                                        Row(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                        ) {
                                                            rowItems.forEach { poster ->
                                                                MediaPosterCard(
                                                                    card = poster.toMediaCard(),
                                                                    imageLoader = imageLoader,
                                                                    onClick = { onOpenPoster(poster) },
                                                                    onLongClick = { contextMenuPoster = poster },
                                                                    modifier = Modifier.weight(1f)
                                                                )
                                                            }
                                                            if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                                                        }
                                                    }
                                                    if (mlState.nextPageUrl != null) {
                                                        item(key = "ml_search_next") {
                                                            OutlinedButton(
                                                                enabled = !mlState.isLoadingMore,
                                                                onClick = onLoadMoreMovieLinkSearch,
                                                                shape = RoundedCornerShape(12.dp),
                                                                modifier = Modifier.fillMaxWidth()
                                                            ) {
                                                                if (mlState.isLoadingMore) {
                                                                    CircularProgressIndicator(
                                                                        color = palette.fg,
                                                                        strokeWidth = 2.dp,
                                                                        modifier = Modifier.size(16.dp)
                                                                    )
                                                                } else {
                                                                    Text("Load More MovieLinkBD Results", color = palette.fg, fontWeight = FontWeight.Bold)
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    } else {
                                        if (!nuvioSearchActive) {
                                            item(key = "addon_search_disabled") {
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clip(RoundedCornerShape(12.dp))
                                                        .background(palette.altBg)
                                                        .padding(14.dp)
                                                ) {
                                                    Text(
                                                        text = "Nuvio Addon Search is turned off in Settings → Search & Streaming.",
                                                        color = palette.textSecondary,
                                                        fontSize = 12.5.sp
                                                    )
                                                }
                                            }
                                        } else {
                                            item(key = "addon_search_header") {
                                                SearchProviderSectionHeader(
                                                    title = "ADDON RESULTS",
                                                    count = totalAddonItems
                                                )
                                            }

                                            if (addonState.noSearchableAddons || addonState.groups.isEmpty()) {
                                                item(key = "addon_search_none") {
                                                    Text(
                                                        text = "No enabled Stremio addons declare search-capable catalogues.",
                                                        color = palette.textSecondary,
                                                        fontSize = 12.5.sp
                                                    )
                                                }
                                            } else {
                                                addonState.groups.forEach { group ->
                                                    item(key = "addon_grp_${group.key}") {
                                                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                                            Row(
                                                                modifier = Modifier.fillMaxWidth(),
                                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                                verticalAlignment = Alignment.CenterVertically
                                                            ) {
                                                                Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                                                                    Text(
                                                                        text = "${group.addon.manifest.name} · ${group.catalog.name}",
                                                                        color = palette.textPrimary,
                                                                        fontSize = 13.5.sp,
                                                                        fontWeight = FontWeight.Bold,
                                                                        maxLines = 1,
                                                                        overflow = TextOverflow.Ellipsis
                                                                    )
                                                                    Text(
                                                                        text = group.catalog.type.replaceFirstChar { it.uppercase() },
                                                                        color = palette.textSecondary,
                                                                        fontSize = 10.5.sp
                                                                    )
                                                                }
                                                                if (group.hasMore && group.items.isNotEmpty()) {
                                                                    Text(
                                                                        text = if (group.isLoadingMore) "Loading…" else "Load More",
                                                                        color = palette.fg,
                                                                        fontSize = 12.sp,
                                                                        fontWeight = FontWeight.Bold,
                                                                        modifier = Modifier
                                                                            .clip(RoundedCornerShape(8.dp))
                                                                            .clickable(enabled = !group.isLoadingMore) {
                                                                                onLoadMoreAddonSearchGroup(group.key)
                                                                            }
                                                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                                                    )
                                                                }
                                                            }

                                                            when {
                                                                group.isLoading && group.items.isEmpty() -> {
                                                                    Row(
                                                                        modifier = Modifier.padding(vertical = 8.dp),
                                                                        verticalAlignment = Alignment.CenterVertically,
                                                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                                    ) {
                                                                        CircularProgressIndicator(
                                                                            color = palette.fg,
                                                                            strokeWidth = 2.dp,
                                                                            modifier = Modifier.size(16.dp)
                                                                        )
                                                                        Text(
                                                                            text = "Searching ${group.addon.manifest.name}…",
                                                                            color = palette.textSecondary,
                                                                            fontSize = 12.sp
                                                                        )
                                                                    }
                                                                }
                                                                group.error != null && group.items.isEmpty() -> {
                                                                    SearchProviderErrorBox(
                                                                        message = group.error,
                                                                        onRetry = { onRetryAddonSearchGroup(group.key) }
                                                                    )
                                                                }
                                                                group.items.isEmpty() -> {
                                                                    Text(
                                                                        text = "No results from ${group.addon.manifest.name} (${group.catalog.name}).",
                                                                        color = palette.textSecondary,
                                                                        fontSize = 11.5.sp
                                                                    )
                                                                }
                                                                else -> {
                                                                    LazyRow(
                                                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                                    ) {
                                                                        items(group.items, key = { it.stableKey }) { poster ->
                                                                            UnifiedHomeRailPosterCard(
                                                                                item = poster,
                                                                                imageLoader = imageLoader,
                                                                                onClick = { onOpenPoster(poster) },
                                                                                onLongClick = { contextMenuPoster = poster }
                                                                            )
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                HomeBottomTab.LIBRARY -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .statusBarsPadding()
                            .padding(top = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (librarySection == 0) "My List (${myList.size})" else "History (${history.size}/25)",
                                color = palette.textPrimary,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            if (librarySection == 1 && history.isNotEmpty()) {
                                TextButton(onClick = onClearHistory) {
                                    Text("Clear History", color = palette.fg, fontSize = 12.5.sp)
                                }
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TopFilterPill(
                                label = "My List (${myList.size})",
                                selected = librarySection == 0,
                                onClick = { librarySection = 0 },
                                modifier = Modifier.weight(1f)
                            )
                            TopFilterPill(
                                label = "Visit History (${history.size})",
                                selected = librarySection == 1,
                                onClick = { librarySection = 1 },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        if (librarySection == 0) {
                            if (myList.isEmpty()) {
                                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "Tap ＋ My List on any movie or series to save it here.",
                                        color = palette.textSecondary,
                                        fontSize = 13.5.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            } else {
                                LazyColumn(
                                    modifier = Modifier.fillMaxSize(),
                                    contentPadding = PaddingValues(
                                        start = 14.dp,
                                        top = 14.dp,
                                        end = 14.dp,
                                        bottom = 14.dp + floatingExtraBottom
                                    ),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    items(myList, key = { it.url }) { item ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(palette.cardBg)
                                                .border(1.dp, palette.border.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                                                .clickable { onOpenMyListItem(item) }
                                                .padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            if (item.posterUrl.isNotBlank()) {
                                                AsyncImage(
                                                    model = item.posterUrl,
                                                    imageLoader = imageLoader,
                                                    contentDescription = item.title,
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier
                                                        .width(54.dp)
                                                        .aspectRatio(2f / 2.8f)
                                                        .clip(RoundedCornerShape(8.dp))
                                                )
                                            } else {
                                                Box(
                                                    modifier = Modifier
                                                        .width(54.dp)
                                                        .aspectRatio(2f / 2.8f)
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .background(palette.altBg),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(Icons.Rounded.Bookmark, contentDescription = null, tint = palette.fg)
                                                }
                                            }
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = item.title,
                                                    color = palette.textPrimary,
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 2,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Spacer(Modifier.height(2.dp))
                                                Text(
                                                    text = "${item.type} · ${item.language} · ${item.quality}",
                                                    color = palette.textSecondary,
                                                    fontSize = 11.5.sp,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                            IconButton(onClick = { onRemoveMyList(item.url) }) {
                                                Icon(
                                                    imageVector = Icons.Rounded.Delete,
                                                    contentDescription = "Remove",
                                                    tint = palette.textSecondary,
                                                    modifier = Modifier.size(19.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            if (history.isEmpty()) {
                                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "No recent visits yet.",
                                        color = palette.textSecondary,
                                        fontSize = 13.5.sp
                                    )
                                }
                            } else {
                                LazyColumn(
                                    modifier = Modifier.fillMaxSize(),
                                    contentPadding = PaddingValues(
                                        start = 14.dp,
                                        top = 14.dp,
                                        end = 14.dp,
                                        bottom = 14.dp + floatingExtraBottom
                                    ),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(history, key = { it.url }) { item ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(palette.cardBg)
                                                .border(1.dp, palette.border.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                                                .clickable { onOpenHistoryItem(item) }
                                                .padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.History,
                                                contentDescription = null,
                                                tint = palette.fg,
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = item.title,
                                                    color = palette.textPrimary,
                                                    fontSize = 13.5.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Text(
                                                    text = "${item.url.removePrefix("https://")} · ${AppSettingsStore.formatRelativeTime(item.timestamp)}",
                                                    color = palette.textSecondary,
                                                    fontSize = 11.sp,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

            if (!settings.floatingNavBar) {
                HorizontalDivider(color = palette.border.copy(alpha = 0.22f))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(palette.pageBg)
                        .navigationBarsPadding()
                        .height(58.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    BottomNavIconItem(
                        selected = activeBottomTab == HomeBottomTab.HOME,
                        icon = if (activeBottomTab == HomeBottomTab.HOME) Icons.Rounded.Home else Icons.Outlined.Home,
                        contentDescription = "Home",
                        onClick = {
                            if (activeBottomTab == HomeBottomTab.HOME && catalog?.url?.trimEnd('/') != baseMirror) {
                                onOpenUrl(settings.mirrorUrl)
                            } else {
                                activeBottomTab = HomeBottomTab.HOME
                            }
                        }
                    )
                    BottomNavIconItem(
                        selected = activeBottomTab == HomeBottomTab.SEARCH,
                        icon = Icons.Rounded.Search,
                        contentDescription = "Search",
                        onClick = { activeBottomTab = HomeBottomTab.SEARCH }
                    )
                    BottomNavIconItem(
                        selected = activeBottomTab == HomeBottomTab.LIBRARY,
                        icon = Icons.AutoMirrored.Rounded.FormatListBulleted,
                        contentDescription = "My List & History",
                        onClick = { activeBottomTab = HomeBottomTab.LIBRARY }
                    )
                    if (settings.showLocalPlayerTab) {
                        BottomNavIconItem(
                            selected = false,
                            icon = Icons.Rounded.VideoLibrary,
                            contentDescription = "Play Local Video",
                            onClick = onPlayLocalVideo
                        )
                    }
                    BottomNavIconItem(
                        selected = false,
                        icon = if (palette.isLightBg) Icons.Rounded.Settings else Icons.Outlined.Settings,
                        contentDescription = "Settings",
                        onClick = onOpenSettings
                    )
                }
            }
        }

        if (settings.floatingNavBar) {
            val customBarColor = remember(settings.floatingNavColorHex, palette.cardBg) {
                settings.floatingNavColorHex?.let {
                    try {
                        Color(android.graphics.Color.parseColor(it))
                    } catch (_: Throwable) {
                        null
                    }
                } ?: palette.cardBg
            }
            val barAlpha = settings.floatingNavAlphaPercent.coerceIn(20, 100) / 100f
            val barShape = RoundedCornerShape(50)
            val barIsLight = if (barAlpha >= 0.45f) {
                ColorUtils.calculateLuminance(customBarColor.toArgb()) > 0.45
            } else {
                palette.isLightBg
            }
            val inactiveTint = if (barIsLight) Color(0xFF3F3F46) else Color(0xFFD4D4D8)
            val activeTint = if (barIsLight && ColorUtils.calculateLuminance(palette.fg.toArgb()) > 0.72) {
                Color(0xFF09090B)
            } else {
                palette.fg
            }

            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = settings.floatingNavSpacingDp.coerceIn(4, 40).dp)
                    .fillMaxWidth(settings.floatingNavWidthPercent.coerceIn(60, 96) / 100f)
                    .height(settings.floatingNavHeightDp.coerceIn(44, 80).dp)
                    .shadow(elevation = 14.dp, shape = barShape, clip = false)
                    .clip(barShape)
                    .background(customBarColor.copy(alpha = barAlpha))
                    .border(1.dp, palette.boxBorder.copy(alpha = 0.42f), barShape),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                BottomNavIconItem(
                    selected = activeBottomTab == HomeBottomTab.HOME,
                    icon = if (activeBottomTab == HomeBottomTab.HOME) Icons.Rounded.Home else Icons.Outlined.Home,
                    contentDescription = "Home",
                    activeTint = activeTint,
                    inactiveTint = inactiveTint,
                    onClick = {
                        if (activeBottomTab == HomeBottomTab.HOME && catalog?.url?.trimEnd('/') != baseMirror) {
                            onOpenUrl(settings.mirrorUrl)
                        } else {
                            activeBottomTab = HomeBottomTab.HOME
                        }
                    }
                )
                BottomNavIconItem(
                    selected = activeBottomTab == HomeBottomTab.SEARCH,
                    icon = Icons.Rounded.Search,
                    contentDescription = "Search",
                    activeTint = activeTint,
                    inactiveTint = inactiveTint,
                    onClick = { activeBottomTab = HomeBottomTab.SEARCH }
                )
                BottomNavIconItem(
                    selected = activeBottomTab == HomeBottomTab.LIBRARY,
                    icon = Icons.AutoMirrored.Rounded.FormatListBulleted,
                    contentDescription = "My List & History",
                    activeTint = activeTint,
                    inactiveTint = inactiveTint,
                    onClick = { activeBottomTab = HomeBottomTab.LIBRARY }
                )
                if (settings.showLocalPlayerTab) {
                    BottomNavIconItem(
                        selected = false,
                        icon = Icons.Rounded.VideoLibrary,
                        contentDescription = "Play Local Video",
                        activeTint = activeTint,
                        inactiveTint = inactiveTint,
                        onClick = onPlayLocalVideo
                    )
                }
                BottomNavIconItem(
                    selected = false,
                    icon = if (barIsLight) Icons.Rounded.Settings else Icons.Outlined.Settings,
                    contentDescription = "Settings",
                    activeTint = activeTint,
                    inactiveTint = inactiveTint,
                    onClick = onOpenSettings
                )
            }
        }
    }

    pendingRemoveContinueItem?.let { cwItem ->
        AlertDialog(
            onDismissRequest = { pendingRemoveContinueItem = null },
            containerColor = palette.cardBg,
            title = {
                Text(
                    text = "Remove from Continue Watching?",
                    color = palette.textPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Text(
                    text = listOf(cwItem.title, cwItem.subtitle).filter { it.isNotBlank() }.joinToString(" · "),
                    color = palette.textSecondary,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onRemoveContinueWatching(cwItem.mediaKey)
                        pendingRemoveContinueItem = null
                    }
                ) {
                    Text("Remove", color = palette.fg, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingRemoveContinueItem = null }) {
                    Text("Cancel", color = palette.textSecondary)
                }
            }
        )
    }

    contextMenuPoster?.let { poster ->
        PosterContextMenuDialog(
            poster = poster,
            inMyList = isPosterInMyList(poster),
            canQuickAddonStreams = settings.nuvioIntegrationEnabled &&
                settings.watchFromAddonsEnabled &&
                poster.provider == ContentProviderKind.STREMIO_ADDON &&
                !poster.stremioId.isNullOrBlank(),
            imageLoader = imageLoader,
            onOpenDetails = {
                contextMenuPoster = null
                onOpenPoster(poster)
            },
            onToggleMyList = {
                onTogglePosterMyList(poster)
                contextMenuPoster = null
            },
            onQuickAddonStreams = {
                contextMenuPoster = null
                onQuickAddonStreams(poster)
            },
            onDismiss = { contextMenuPoster = null }
        )
    }

    if (showCategoriesModal) {
        CategoriesPickerDialog(
            categories = catalog?.categories.orEmpty(),
            currentUrl = catalog?.url.orEmpty(),
            mirrorUrl = settings.mirrorUrl,
            onSelectUrl = { url ->
                showCategoriesModal = false
                activeBottomTab = HomeBottomTab.HOME
                onOpenUrl(url)
            },
            onOpenFallbackWeb = {
                showCategoriesModal = false
                onOpenFallbackWeb()
            },
            onDismiss = { showCategoriesModal = false }
        )
    }
}

@Composable
private fun TopFilterPill(
    label: String,
    selected: Boolean,
    hasCaret: Boolean = false,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalMovieLinkPalette.current
    Row(
        modifier = modifier
            .height(32.dp)
            .clip(RoundedCornerShape(50))
            .background(if (selected) palette.fg else Color.Transparent)
            .border(
                width = 1.dp,
                color = if (selected) palette.fg else palette.textSecondary.copy(alpha = 0.55f),
                shape = RoundedCornerShape(50)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Text(
            text = label,
            color = if (selected) palette.onAccent else palette.textPrimary,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        if (hasCaret) {
            Icon(
                imageVector = Icons.Rounded.KeyboardArrowDown,
                contentDescription = null,
                tint = if (selected) palette.onAccent else palette.textPrimary,
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

@Composable
private fun HeroCoverflowCarousel(
    items: List<UnifiedPosterItem>,
    autoRotate: Boolean,
    heroSizePercent: Int = 100,
    imageLoader: ImageLoader,
    onOpenPoster: (UnifiedPosterItem) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val initialPage = if (items.size >= 3) 1 else 0
    val pagerState = rememberPagerState(initialPage = initialPage, pageCount = { items.size })
    val featuredSignature = items.getOrNull(initialPage)?.stableKey ?: items.firstOrNull()?.stableKey
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(featuredSignature) {
        if (items.isNotEmpty()) {
            pagerState.scrollToPage(initialPage.coerceIn(0, items.lastIndex))
        }
    }

    LaunchedEffect(autoRotate, items.size) {
        if (autoRotate && items.size > 1) {
            while (true) {
                delay(4500L)
                if (!pagerState.isScrollInProgress) {
                    val nextPage = (pagerState.currentPage + 1) % items.size
                    pagerState.animateScrollToPage(nextPage)
                }
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
            val scaleFactor = heroSizePercent.coerceIn(75, 130) / 100f
            val cardWidth = (196f * scaleFactor).dp.coerceIn(144.dp, (maxWidth * 0.72f).coerceAtLeast(160.dp))
            val sidePadding = ((maxWidth - cardWidth) / 2).coerceAtLeast(36.dp)

            HorizontalPager(
                state = pagerState,
                contentPadding = PaddingValues(horizontal = sidePadding),
                pageSpacing = 12.dp,
                beyondViewportPageCount = 1,
                modifier = Modifier.fillMaxWidth()
            ) { page ->
                val item = items[page]
                val pageOffset = ((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction).absoluteValue
                val scale = lerpFloat(1f, 0.85f, pageOffset.coerceIn(0f, 1f))
                val alpha = lerpFloat(1f, 0.48f, pageOffset.coerceIn(0f, 1f))
                var logoLoadError by remember(item.stableKey, item.logoUrl) { mutableStateOf(false) }

                Box(
                    modifier = Modifier
                        .width(cardWidth)
                        .aspectRatio(0.68f)
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            this.alpha = alpha
                        }
                        .clip(RoundedCornerShape(16.dp))
                        .background(palette.cardBg)
                        .border(
                            width = if (pageOffset < 0.35f) 1.2.dp else 0.8.dp,
                            color = if (pageOffset < 0.35f) palette.boxBorder.copy(alpha = 0.7f) else palette.border.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(16.dp)
                        )
                        .clickable { onOpenPoster(item) }
                ) {
                    if (item.posterUrl.isNotBlank()) {
                        AsyncImage(
                            model = item.posterUrl,
                            imageLoader = imageLoader,
                            contentDescription = item.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, Color(0xCC000000), Color(0xEE000000))
                                )
                            )
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (item.logoUrl.isNotBlank() && !logoLoadError) {
                                AsyncImage(
                                    model = item.logoUrl,
                                    imageLoader = imageLoader,
                                    contentDescription = item.title,
                                    contentScale = ContentScale.Fit,
                                    onError = { logoLoadError = true },
                                    modifier = Modifier
                                        .heightIn(max = 38.dp)
                                        .fillMaxWidth(0.86f)
                                )
                            } else {
                                Text(
                                    text = item.title,
                                    color = Color.White,
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    maxLines = 2,
                                    textAlign = TextAlign.Center,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            val sub = when (item.provider) {
                                ContentProviderKind.MOVIELINK_BD ->
                                    listOf(
                                        item.yearOrRelease,
                                        item.rating.takeIf { it.isNotBlank() }?.let { "★ $it" }.orEmpty(),
                                        item.language,
                                        item.qualityOrBadge
                                    ).filter { it.isNotBlank() }.distinct().take(3).joinToString(" · ")
                                ContentProviderKind.STREMIO_ADDON ->
                                    listOf(
                                        item.yearOrRelease,
                                        item.rating.takeIf { it.isNotBlank() }?.let { "★ $it" }.orEmpty(),
                                        item.genres.firstOrNull().orEmpty()
                                    ).filter { it.isNotBlank() }.joinToString(" · ")
                            }
                            if (sub.isNotBlank()) {
                                Spacer(Modifier.height(3.dp))
                                Text(
                                    text = sub,
                                    color = Color(0xFFD4D4D8),
                                    fontSize = 10.5.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }

        // Dot indicators underneath hero poster (active elongated accent pill)
        if (items.size > 1) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                items.indices.forEach { idx ->
                    val isSelected = idx == pagerState.currentPage
                    val pillWidth by animateDpAsState(
                        targetValue = if (isSelected) 22.dp else 6.dp,
                        animationSpec = tween(220),
                        label = "carousel_pill_w"
                    )
                    Box(
                        modifier = Modifier
                            .height(6.dp)
                            .width(pillWidth)
                            .clip(CircleShape)
                            .background(
                                if (isSelected) palette.fg else palette.textSecondary.copy(alpha = 0.35f)
                            )
                            .clickable {
                                coroutineScope.launch { pagerState.animateScrollToPage(idx) }
                            }
                    )
                }
            }
        }
    }
}

@Composable
private fun HeroSpotlightBanner(
    items: List<UnifiedPosterItem>,
    sourceTitle: String?,
    autoRotate: Boolean,
    heroSizePercent: Int = 100,
    listState: LazyListState? = null,
    imageLoader: ImageLoader,
    isInMyList: (UnifiedPosterItem) -> Boolean,
    onToggleMyList: (UnifiedPosterItem) -> Boolean,
    onOpenPoster: (UnifiedPosterItem) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val pagerState = rememberPagerState(initialPage = 0, pageCount = { items.size })
    val leadSignature = items.firstOrNull()?.stableKey
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(leadSignature) {
        if (items.isNotEmpty()) {
            pagerState.scrollToPage(0)
        }
    }

    LaunchedEffect(autoRotate, items.size) {
        if (autoRotate && items.size > 1) {
            while (true) {
                delay(4500L)
                if (!pagerState.isScrollInProgress) {
                    val nextPage = (pagerState.currentPage + 1) % items.size
                    pagerState.animateScrollToPage(nextPage)
                }
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
            val isTablet = maxWidth >= 600.dp
            val baseHeroHeight = if (isTablet) {
                (maxWidth * 0.48f).coerceIn(320.dp, 420.dp)
            } else {
                (maxWidth * 1.06f).coerceIn(340.dp, 450.dp)
            }
            val heroHeight = scaleHeroBannerHeight(baseHeroHeight, heroSizePercent).coerceIn(260.dp, 580.dp)
            val density = LocalDensity.current
            val heroHeightPx = with(density) { heroHeight.toPx() }
            val heroWidthPx = with(density) { maxWidth.toPx() }

            val scrollOffsetPx by remember(listState, heroHeightPx) {
                derivedStateOf {
                    when {
                        listState == null -> 0f
                        listState.firstVisibleItemIndex > 0 -> heroHeightPx
                        else -> listState.firstVisibleItemScrollOffset.toFloat()
                    }
                }
            }

            HorizontalPager(
                state = pagerState,
                beyondViewportPageCount = 1,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(heroHeight)
            ) { page ->
                val item = items[page]
                val artworkUrl = item.backdropUrl.ifBlank { item.posterUrl }
                val backdropFocus = rememberBackdropFocusState(artworkUrl)
                val revealAlpha by animateFloatAsState(
                    targetValue = backdropFocus.revealAlpha,
                    animationSpec = tween(260),
                    label = "hero_backdrop_reveal"
                )
                var logoLoadError by remember(item.stableKey, item.logoUrl) { mutableStateOf(false) }

                val pageOffset = (pagerState.currentPage - page) + pagerState.currentPageOffsetFraction
                val inList = isInMyList(item)
                val topLabel = item.addonName?.takeIf { it.isNotBlank() }
                    ?: if (item.provider == ContentProviderKind.STREMIO_ADDON) "Nuvio Addon" else "MovieLinkBD"

                val metaLineParts = buildList {
                    if (item.genres.isNotEmpty()) {
                        add(item.genres.take(2).joinToString(" • "))
                    } else if (item.type.isNotBlank()) {
                        add(item.type.replaceFirstChar { it.uppercase() })
                    }
                    if (item.yearOrRelease.isNotBlank()) add(item.yearOrRelease)
                    if (item.rating.isNotBlank()) add("IMDb ${item.rating}")
                    if (item.qualityOrBadge.isNotBlank()) add(item.qualityOrBadge)
                    if (item.language.isNotBlank() && isEmpty()) add(item.language)
                }.ifEmpty {
                    listOfNotNull(sourceTitle?.takeIf { it.isNotBlank() })
                }.distinct().take(4)

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(palette.cardBg)
                        .graphicsLayer { clip = true }
                        .clickable { onOpenPoster(item) }
                ) {
                    if (artworkUrl.isNotBlank()) {
                        AsyncImage(
                            model = artworkUrl,
                            imageLoader = imageLoader,
                            contentDescription = item.title,
                            alignment = backdropFocus.focusedAlignment(
                                if (isTablet) Alignment.TopCenter else Alignment.Center
                            ),
                            contentScale = ContentScale.Crop,
                            onSuccess = { state ->
                                backdropFocus.onDrawableLoaded(state.result.drawable)
                            },
                            onError = { backdropFocus.onImageFailed() },
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer {
                                    alpha = revealAlpha
                                    translationX = -pageOffset * heroWidthPx * 0.14f
                                    translationY = (scrollOffsetPx * 0.35f).coerceAtMost(heroHeightPx * 0.38f)
                                    scaleX = 1.07f
                                    scaleY = 1.07f
                                }
                        )
                    }

                    // Top subtle scrim for provider label readability
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .fillMaxWidth()
                            .height(92.dp)
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color(0xA6000000), Color.Transparent)
                                )
                            )
                    )

                    // NuvioMobile atmospheric vertical gradient over hero artwork
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        palette.pageBg.copy(alpha = 0.02f),
                                        palette.pageBg.copy(alpha = 0.14f),
                                        palette.pageBg.copy(alpha = 0.38f),
                                        palette.pageBg.copy(alpha = 0.82f)
                                    )
                                )
                            )
                    )

                    // Smooth bottom fade seamlessly blending into pageBg
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .height((heroHeight * 0.56f).coerceIn(170.dp, 280.dp))
                            .background(
                                Brush.verticalGradient(
                                    colorStops = arrayOf(
                                        0.00f to Color.Transparent,
                                        0.28f to palette.pageBg.copy(alpha = 0.34f),
                                        0.62f to palette.pageBg.copy(alpha = 0.78f),
                                        0.86f to palette.pageBg.copy(alpha = 0.96f),
                                        1.00f to palette.pageBg
                                    )
                                )
                            )
                    )

                    Text(
                        text = topLabel,
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.35.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .statusBarsPadding()
                            .padding(top = 8.dp, start = 20.dp, end = 20.dp)
                    )

                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .padding(horizontal = if (isTablet) 36.dp else 20.dp, vertical = 14.dp)
                            .animateContentSize(),
                        horizontalAlignment = if (isTablet) Alignment.Start else Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (item.logoUrl.isNotBlank() && !logoLoadError) {
                            AsyncImage(
                                model = item.logoUrl,
                                imageLoader = imageLoader,
                                contentDescription = item.title,
                                alignment = if (isTablet) Alignment.CenterStart else Alignment.Center,
                                contentScale = ContentScale.Fit,
                                onError = { logoLoadError = true },
                                modifier = Modifier
                                    .fillMaxWidth(if (isTablet) 0.52f else 0.72f)
                                    .widthIn(max = 280.dp)
                                    .heightIn(max = 82.dp)
                            )
                        } else {
                            Text(
                                text = item.title.uppercase(),
                                color = palette.textPrimary,
                                fontSize = if (isTablet) 28.sp else 24.sp,
                                lineHeight = if (isTablet) 31.sp else 27.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = (-0.4).sp,
                                textAlign = if (isTablet) TextAlign.Start else TextAlign.Center,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        if (metaLineParts.isNotEmpty()) {
                            Text(
                                text = metaLineParts.joinToString("  •  "),
                                color = palette.textSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                textAlign = if (isTablet) TextAlign.Start else TextAlign.Center,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        if (item.language.isNotBlank() && !metaLineParts.contains(item.language)) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(palette.cardBg.copy(alpha = 0.85f))
                                    .border(1.dp, palette.border.copy(alpha = 0.35f), RoundedCornerShape(50))
                                    .padding(horizontal = 10.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = item.language,
                                    color = palette.textPrimary,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(Color.White)
                                    .clickable { onToggleMyList(item) }
                                    .padding(horizontal = 18.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = if (inList) Icons.Rounded.Check else Icons.Rounded.Add,
                                    contentDescription = null,
                                    tint = Color(0xFF0A0A0D),
                                    modifier = Modifier.size(17.dp)
                                )
                                Text(
                                    text = if (inList) "In My List" else "Add to My List",
                                    color = Color(0xFF0A0A0D),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(palette.cardBg.copy(alpha = 0.78f))
                                    .border(1.dp, palette.border.copy(alpha = 0.35f), RoundedCornerShape(50))
                                    .clickable { onOpenPoster(item) }
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Info,
                                    contentDescription = null,
                                    tint = palette.textPrimary,
                                    modifier = Modifier.size(17.dp)
                                )
                                Text(
                                    text = "Details",
                                    color = palette.textPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }

        if (items.size > 1) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                items.indices.forEach { idx ->
                    val pageOffset = ((pagerState.currentPage - idx) + pagerState.currentPageOffsetFraction).absoluteValue
                    val activeFraction = (1f - pageOffset).coerceIn(0f, 1f)
                    val indicatorWidth by animateDpAsState(
                        targetValue = 7.dp + (19.dp * activeFraction),
                        animationSpec = tween(180),
                        label = "hero_indicator_w"
                    )
                    Box(
                        modifier = Modifier
                            .height(6.dp)
                            .width(indicatorWidth)
                            .clip(CircleShape)
                            .background(palette.fg)
                            .graphicsLayer {
                                alpha = 0.35f + (0.65f * activeFraction)
                            }
                            .clickable {
                                coroutineScope.launch { pagerState.animateScrollToPage(idx) }
                            }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ContinueWatchingVerticalCard(
    item: PlaybackProgressItem,
    imageLoader: ImageLoader,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val progressFraction = if (item.durationMs > 0L) {
        (item.positionMs.toFloat() / item.durationMs.toFloat()).coerceIn(0.06f, 0.98f)
    } else {
        0.35f
    }

    Column(
        modifier = Modifier
            .width(132.dp)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 2.85f)
                .clip(RoundedCornerShape(14.dp))
                .background(palette.altBg)
        ) {
            if (item.posterUrl.isNotBlank()) {
                AsyncImage(
                    model = item.posterUrl,
                    imageLoader = imageLoader,
                    contentDescription = item.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(
                    imageVector = Icons.Rounded.Movie,
                    contentDescription = null,
                    tint = palette.textSecondary,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(30.dp)
                )
            }

            if (item.quality.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 8.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xBF222228))
                        .padding(horizontal = 7.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = item.quality,
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                }
            }

            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xD916161A))
                    .padding(horizontal = 8.dp, vertical = 7.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(Color(0x47FFFFFF))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(progressFraction)
                            .fillMaxHeight()
                            .clip(CircleShape)
                            .background(Color.White)
                    )
                }
            }
        }

        Spacer(Modifier.height(7.dp))
        Text(
            text = item.title,
            color = palette.textPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            lineHeight = 16.sp,
            overflow = TextOverflow.Ellipsis
        )
        if (item.subtitle.isNotBlank()) {
            Text(
                text = item.subtitle,
                color = palette.textSecondary,
                fontSize = 10.5.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ContinueWatchingHorizontalCard(
    item: PlaybackProgressItem,
    imageLoader: ImageLoader,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val progressFraction = if (item.durationMs > 0L) {
        (item.positionMs.toFloat() / item.durationMs.toFloat()).coerceIn(0.06f, 0.98f)
    } else {
        0.35f
    }
    val remainingMin = ((item.durationMs - item.positionMs).coerceAtLeast(0L) / 60_000L).toInt()

    Column(
        modifier = Modifier
            .width(198.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(palette.cardBg)
            .border(1.dp, palette.border.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 10f)
                .background(palette.altBg)
        ) {
            if (item.posterUrl.isNotBlank()) {
                AsyncImage(
                    model = item.posterUrl,
                    imageLoader = imageLoader,
                    contentDescription = item.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(
                    imageVector = Icons.Rounded.Movie,
                    contentDescription = null,
                    tint = palette.textSecondary,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(28.dp)
                )
            }

            if (item.quality.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(7.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(Color(0xC018181C))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = item.quality,
                        color = Color.White,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (item.durationMs > 0L && remainingMin > 0) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 8.dp, bottom = 18.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(Color(0xC0141418))
                        .padding(horizontal = 5.dp, vertical = 1.5.dp)
                ) {
                    Text(
                        text = "${remainingMin}m left",
                        color = Color.White,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 7.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xD916161A))
                    .padding(horizontal = 6.dp, vertical = 5.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.5.dp)
                        .clip(CircleShape)
                        .background(Color(0x47FFFFFF))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(progressFraction)
                            .fillMaxHeight()
                            .clip(CircleShape)
                            .background(Color.White)
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = item.title,
                color = palette.textPrimary,
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            val subLine = item.subtitle.ifBlank { item.sourceLabel }
            if (subLine.isNotBlank()) {
                Text(
                    text = subLine,
                    color = palette.textSecondary,
                    fontSize = 10.5.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun HomeRailPosterCard(
    card: MediaCard,
    imageLoader: ImageLoader,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null
) {
    val palette = LocalMovieLinkPalette.current
    Column(
        modifier = Modifier
            .width(118.dp)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 2.8f)
                .clip(RoundedCornerShape(10.dp))
                .background(palette.altBg)
        ) {
            if (card.posterUrl.isNotBlank()) {
                AsyncImage(
                    model = card.posterUrl,
                    imageLoader = imageLoader,
                    contentDescription = card.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(
                    imageVector = Icons.Rounded.Movie,
                    contentDescription = null,
                    tint = palette.textSecondary,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(28.dp)
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = card.title,
            color = palette.textPrimary,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            lineHeight = 15.sp,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun UnifiedHomeRailPosterCard(
    item: UnifiedPosterItem,
    imageLoader: ImageLoader,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null
) {
    val palette = LocalMovieLinkPalette.current
    Column(
        modifier = Modifier
            .width(118.dp)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 2.8f)
                .clip(RoundedCornerShape(10.dp))
                .background(palette.altBg)
        ) {
            if (item.posterUrl.isNotBlank()) {
                AsyncImage(
                    model = item.posterUrl,
                    imageLoader = imageLoader,
                    contentDescription = item.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(
                    imageVector = Icons.Rounded.Movie,
                    contentDescription = null,
                    tint = palette.textSecondary,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(28.dp)
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = item.title,
            color = palette.textPrimary,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            lineHeight = 15.sp,
            overflow = TextOverflow.Ellipsis
        )
        if (item.provider == ContentProviderKind.STREMIO_ADDON) {
            val metaLine = listOfNotNull(
                item.yearOrRelease.takeIf { it.isNotBlank() },
                item.rating.takeIf { it.isNotBlank() }?.let { "★ $it" }
            ).joinToString(" · ")
            if (metaLine.isNotBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(
                    text = metaLine,
                    color = palette.textSecondary,
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun WatchByOttSection(
    platforms: List<OttPlatform>,
    imageLoader: ImageLoader,
    onOpenUrl: (String) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "Watch by OTT",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = palette.textPrimary,
            modifier = Modifier.padding(horizontal = 14.dp)
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(platforms, key = { it.url }) { ott ->
                val accentColor = remember(ott.accentHex, palette.fg) {
                    if (ott.accentHex.isNotBlank()) {
                        try {
                            Color(android.graphics.Color.parseColor(ott.accentHex))
                        } catch (_: Throwable) {
                            palette.fg
                        }
                    } else {
                        palette.fg
                    }
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .width(68.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onOpenUrl(ott.url) }
                        .padding(vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (ott.iconUrl.isNotBlank()) {
                            AsyncImage(
                                model = ott.iconUrl,
                                imageLoader = imageLoader,
                                contentDescription = ott.name,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(14.dp))
                            )
                        } else {
                            Text(
                                text = ott.name.take(1).uppercase(),
                                color = accentColor,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = ott.name,
                        color = palette.textPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        textAlign = TextAlign.Center,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun BottomNavIconItem(
    selected: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    activeTint: Color? = null,
    inactiveTint: Color? = null,
    onClick: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val resolvedActive = activeTint ?: palette.fg
    val resolvedInactive = inactiveTint ?: palette.textSecondary
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (selected) resolvedActive else resolvedInactive,
            modifier = Modifier.size(24.dp)
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CategoriesPickerDialog(
    categories: List<CategoryChip>,
    currentUrl: String,
    mirrorUrl: String,
    onSelectUrl: (String) -> Unit,
    onOpenFallbackWeb: () -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .heightIn(max = 580.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(palette.cardBg)
                .border(1.2.dp, palette.boxBorder, RoundedCornerShape(18.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Categories & Browse",
                    color = palette.textPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close", tint = palette.textPrimary)
                }
            }
            HorizontalDivider(color = palette.border.copy(alpha = 0.2f))

            Column(
                modifier = Modifier
                    .weight(1f, fill = false)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onSelectUrl(mirrorUrl) },
                        colors = ButtonDefaults.buttonColors(containerColor = palette.fg, contentColor = palette.onAccent),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Home Feed", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                    }
                    OutlinedButton(
                        onClick = onOpenFallbackWeb,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Rounded.Language, contentDescription = null, tint = palette.fg, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Web Browser", color = palette.textPrimary, fontSize = 12.5.sp)
                    }
                }

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { cat ->
                        val active = currentUrl == cat.url
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (active) palette.fg else palette.boxBg)
                                .border(
                                    1.dp,
                                    if (active) palette.fg else palette.boxBorder.copy(alpha = 0.55f),
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable { onSelectUrl(cat.url) }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = cat.label,
                                color = if (active) palette.onAccent else palette.textPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MediaPosterCard(
    card: MediaCard,
    imageLoader: ImageLoader,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onLongClick: (() -> Unit)? = null
) {
    val palette = LocalMovieLinkPalette.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(palette.cardBg)
            .border(1.dp, palette.border.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 2.8f)
                .background(palette.altBg)
        ) {
            if (card.posterUrl.isNotBlank()) {
                AsyncImage(
                    model = card.posterUrl,
                    imageLoader = imageLoader,
                    contentDescription = card.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(
                    imageVector = Icons.Rounded.Movie,
                    contentDescription = null,
                    tint = palette.textSecondary,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(32.dp)
                )
            }

            if (card.quality.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(palette.fg)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = card.quality,
                        color = palette.onAccent,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1
                    )
                }
            }

            if (card.language.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color(0xD9000000))
                            )
                        )
                        .padding(horizontal = 7.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = card.language,
                        color = Color.White,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        Text(
            text = card.title,
            color = palette.textPrimary,
            fontSize = 12.5.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            lineHeight = 16.sp,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)
        )
    }
}

@Composable
private fun ErrorRetryState(
    message: String,
    onRetry: () -> Unit,
    onOpenWeb: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Could not load catalog",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = palette.textPrimary
            )
            Text(
                text = message,
                fontSize = 13.sp,
                color = palette.textSecondary
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onRetry,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = palette.fg,
                        contentColor = palette.onAccent
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Retry", fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = onOpenWeb,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Open WebView", color = palette.textPrimary)
                }
            }
            OutlinedButton(
                onClick = onOpenSettings,
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Update Mirror URL", color = palette.fg)
            }
        }
    }
}

@Composable
private fun SearchProviderSectionHeader(title: String, count: Int) {
    val palette = LocalMovieLinkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            color = palette.fg,
            fontSize = 12.5.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 0.8.sp
        )
        Text(
            text = "$count result${if (count == 1) "" else "s"}",
            color = palette.textSecondary,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun SearchProviderErrorBox(message: String, onRetry: () -> Unit) {
    val palette = LocalMovieLinkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(palette.altBg)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = message,
            color = palette.textSecondary,
            fontSize = 11.5.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f).padding(end = 8.dp)
        )
        Text(
            text = "Retry",
            color = palette.fg,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .clickable(onClick = onRetry)
                .padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun PosterContextMenuDialog(
    poster: UnifiedPosterItem,
    inMyList: Boolean,
    canQuickAddonStreams: Boolean,
    imageLoader: ImageLoader,
    onOpenDetails: () -> Unit,
    onToggleMyList: () -> Unit,
    onQuickAddonStreams: () -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val context = LocalContext.current

    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(palette.cardBg)
                .border(1.dp, palette.boxBorder.copy(alpha = 0.7f), RoundedCornerShape(18.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (poster.posterUrl.isNotBlank()) {
                    AsyncImage(
                        model = poster.posterUrl,
                        imageLoader = imageLoader,
                        contentDescription = poster.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .width(56.dp)
                            .aspectRatio(2f / 2.85f)
                            .clip(RoundedCornerShape(8.dp))
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .width(56.dp)
                            .aspectRatio(2f / 2.85f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(palette.altBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Movie, contentDescription = null, tint = palette.textSecondary)
                    }
                }
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(
                        text = poster.title,
                        color = palette.textPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    val metaText = listOfNotNull(
                        poster.addonName?.takeIf { it.isNotBlank() } ?: poster.provider.displayName,
                        poster.yearOrRelease.takeIf { it.isNotBlank() },
                        poster.qualityOrBadge.takeIf { it.isNotBlank() },
                        poster.rating.takeIf { it.isNotBlank() }?.let { "★ $it" }
                    ).joinToString(" · ")
                    if (metaText.isNotBlank()) {
                        Text(
                            text = metaText,
                            color = palette.fg,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            HorizontalDivider(color = palette.border.copy(alpha = 0.25f))

            ContextMenuActionRow(
                icon = Icons.Rounded.Info,
                label = "Open Details",
                onClick = onOpenDetails
            )
            ContextMenuActionRow(
                icon = if (inMyList) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkAdd,
                label = if (inMyList) "Remove from My List" else "Add to My List",
                tint = if (inMyList) Color(0xFF4ADE80) else palette.fg,
                onClick = onToggleMyList
            )
            if (canQuickAddonStreams) {
                ContextMenuActionRow(
                    icon = Icons.Rounded.PlayArrow,
                    label = "Find Addon Streams",
                    onClick = onQuickAddonStreams
                )
            }
            ContextMenuActionRow(
                icon = Icons.Rounded.ContentCopy,
                label = "Copy Title",
                onClick = {
                    val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                    clipboard?.setPrimaryClip(android.content.ClipData.newPlainText("MovieLink Title", poster.title))
                    android.widget.Toast.makeText(context, "Copied \"${poster.title}\"", android.widget.Toast.LENGTH_SHORT).show()
                    onDismiss()
                }
            )
            val webUrl = poster.movieLinkUrl?.takeIf { it.startsWith("http", ignoreCase = true) }
            if (poster.provider == ContentProviderKind.MOVIELINK_BD && webUrl != null) {
                ContextMenuActionRow(
                    icon = Icons.Rounded.OpenInBrowser,
                    label = "Open Page in Chrome",
                    onClick = {
                        DownloadAndPlayerRouter.openInChrome(context, webUrl)
                        onDismiss()
                    }
                )
            }

            TextButton(
                onClick = onDismiss,
                modifier = Modifier.align(Alignment.End)
            ) {
                Text("Close", color = palette.textSecondary, fontSize = 12.5.sp)
            }
        }
    }
}

@Composable
private fun ContextMenuActionRow(
    icon: ImageVector,
    label: String,
    tint: Color? = null,
    onClick: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val resolvedTint = tint ?: palette.fg
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(palette.altBg)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = resolvedTint,
            modifier = Modifier.size(19.dp)
        )
        Text(
            text = label,
            color = palette.textPrimary,
            fontSize = 13.5.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

private fun lerpFloat(start: Float, stop: Float, fraction: Float): Float =
    start + (stop - start) * fraction
