package com.personal.movielink.addons

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

enum class StreamType {
    DIRECT_VIDEO,
    EXTERNAL_URL,
    TORRENT_INFO_HASH,
    UNSUPPORTED
}

data class StremioProxyHeaders(
    val requestHeaders: Map<String, String> = emptyMap()
) {
    companion object {
        fun fromJson(obj: JSONObject?): StremioProxyHeaders? {
            if (obj == null) return null
            // Stremio spec uses proxyHeaders.request; some addons use proxyHeaders.requestHeaders or flat headers
            val targetObj = obj.optJSONObject("request")
                ?: obj.optJSONObject("requestHeaders")
                ?: obj
            val map = linkedMapOf<String, String>()
            val keys = targetObj.keys()
            while (keys.hasNext()) {
                val k = keys.next().trim()
                if (k.isBlank() || k.equals("response", ignoreCase = true)) continue
                val raw = targetObj.opt(k)
                if (raw == null || raw is JSONObject || raw is JSONArray || raw == JSONObject.NULL) continue
                val v = raw.toString().trim()
                if (v.isNotEmpty() && !v.equals("null", ignoreCase = true)) {
                    map[k] = v
                }
            }
            return if (map.isNotEmpty()) StremioProxyHeaders(map) else null
        }
    }
}

data class StremioStreamItem(
    val streamId: String,
    val addonManifestUrl: String,
    val addonName: String,
    val title: String,
    val name: String,
    val description: String,
    val quality: String,
    val language: String,
    val url: String?,
    val externalUrl: String?,
    val infoHash: String?,
    val fileIdx: Int?,
    val streamType: StreamType,
    val proxyHeaders: StremioProxyHeaders? = null,
    val inlineSubtitles: List<AddonSubtitleItem> = emptyList(),
    val notWebReady: Boolean = false,
    val mimeHint: String? = null,
    val rawStreamJson: JSONObject
)

data class AddonSubtitleItem(
    val id: String,
    val lang: String,
    val url: String,
    val addonName: String
)

data class AddonStreamGroupResult(
    val addonManifestUrl: String,
    val addonName: String,
    val streams: List<StremioStreamItem> = emptyList(),
    val subtitles: List<AddonSubtitleItem> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null
)

class AddonStreamRepository {

    private data class StreamCacheEntry(
        val fetchedAtMs: Long,
        val streams: List<StremioStreamItem>,
        val subtitles: List<AddonSubtitleItem>
    )

    private val cache = ConcurrentHashMap<String, StreamCacheEntry>()

    fun buildStreamUrl(addon: InstalledAddon, type: String, streamId: String): String {
        val typeSeg = Uri.encode(type.trim().ifBlank { "movie" })
        val idSeg = Uri.encode(streamId.trim())
        val basePath = "${addon.baseUrl.trimEnd('/')}/stream/$typeSeg/$idSeg.json"
        val query = addon.manifestUrl.substringAfter('?', "")
        return if (query.isNotBlank()) "$basePath?$query" else basePath
    }

    fun buildSubtitleUrl(addon: InstalledAddon, type: String, streamId: String): String {
        val typeSeg = Uri.encode(type.trim().ifBlank { "movie" })
        val idSeg = Uri.encode(streamId.trim())
        val basePath = "${addon.baseUrl.trimEnd('/')}/subtitles/$typeSeg/$idSeg.json"
        val query = addon.manifestUrl.substringAfter('?', "")
        return if (query.isNotBlank()) "$basePath?$query" else basePath
    }

    suspend fun fetchStreamsForAddon(
        addon: InstalledAddon,
        type: String,
        streamId: String,
        forceRefresh: Boolean = false
    ): Result<Pair<List<StremioStreamItem>, List<AddonSubtitleItem>>> {
        if (!addon.enabled) {
            return Result.failure(IllegalStateException("${addon.manifest.name} is disabled"))
        }
        val cleanType = type.trim().ifBlank { "movie" }
        val cleanId = streamId.trim()
        if (cleanId.isBlank()) {
            return Result.failure(IllegalArgumentException("Missing stream identifier"))
        }
        if (!addon.manifest.supportsResource("stream", cleanType, cleanId)) {
            return Result.failure(UnsupportedOperationException("${addon.manifest.name} does not support stream for $cleanType"))
        }

        val cacheKey = "${addon.manifestUrl}|$cleanType|$cleanId"
        if (!forceRefresh) {
            val cached = cache[cacheKey]
            if (cached != null && System.currentTimeMillis() - cached.fetchedAtMs < CACHE_TTL_MS) {
                return Result.success(cached.streams to cached.subtitles)
            }
        }

        return try {
            val streamUrl = buildStreamUrl(addon, cleanType, cleanId)
            val streamJson = AddonHttp.getJsonObject(streamUrl)
            val streamsArr = streamJson.optJSONArray("streams") ?: JSONArray()
            val parsedStreams = buildList {
                for (i in 0 until streamsArr.length()) {
                    val sObj = streamsArr.optJSONObject(i) ?: continue
                    val parsed = parseStreamItem(sObj, addon)
                    if (parsed != null) add(parsed)
                }
            }

            val parsedSubtitles = mutableListOf<AddonSubtitleItem>()
            if (addon.manifest.supportsResource("subtitles", cleanType, cleanId)) {
                try {
                    val subUrl = buildSubtitleUrl(addon, cleanType, cleanId)
                    val subJson = AddonHttp.getJsonObject(subUrl)
                    val subsArr = subJson.optJSONArray("subtitles") ?: JSONArray()
                    parsedSubtitles.addAll(parseSubtitleArray(subsArr, addon))
                } catch (_: Exception) {
                    // Subtitles endpoint optional; do not fail streams
                }
            }

            if (cache.size > MAX_CACHE_ENTRIES) cache.clear()
            cache[cacheKey] = StreamCacheEntry(System.currentTimeMillis(), parsedStreams, parsedSubtitles)
            Result.success(parsedStreams to parsedSubtitles)
        } catch (e: AddonHttpException) {
            val prefix = when (e.category) {
                AddonErrorCategory.ADDON_SERVER -> "[Addon Server]"
                AddonErrorCategory.NETWORK -> "[Network]"
                AddonErrorCategory.APP_OR_CONFIG -> "[App Config]"
            }
            Result.failure(AddonHttpException(e.category, e.httpCode, "$prefix ${e.message}", e))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun clearCache() {
        cache.clear()
    }

    private fun parseStreamItem(obj: JSONObject, addon: InstalledAddon): StremioStreamItem? {
        val url = sanitizeStreamUrl(obj.optString("url", ""), addon.baseUrl)
        val rawExternalUrl = sanitizeStreamUrl(obj.optString("externalUrl", ""), addon.baseUrl)
        val ytId = obj.optString("ytId", "").trim().takeIf { it.isNotEmpty() && !it.equals("null", true) }
        val externalUrl = if (rawExternalUrl.isNotBlank()) {
            rawExternalUrl
        } else if (ytId != null) {
            "https://www.youtube.com/watch?v=${Uri.encode(ytId)}"
        } else {
            ""
        }

        val infoHash = obj.optString("infoHash", "").trim().takeIf { it.isNotEmpty() && !it.equals("null", true) }
        val fileIdx = if (obj.has("fileIdx") && !obj.isNull("fileIdx")) obj.optInt("fileIdx") else null

        val bhObj = obj.optJSONObject("behaviorHints")
        val notWebReady = bhObj?.optBoolean("notWebReady", false) ?: false
        val bhFilename = bhObj?.optString("filename", "").orEmpty().trim()
            .takeIf { it.isNotEmpty() && !it.equals("null", true) }

        val title = obj.optString("title", obj.optString("name", "")).trim()
        val name = obj.optString("name", addon.manifest.name).trim().ifBlank { addon.manifest.name }
        val description = obj.optString("description", "").trim()
            .takeIf { it.isNotEmpty() && !it.equals("null", true) }
            ?: bhFilename.orEmpty()

        val proxyHeaders = StremioProxyHeaders.fromJson(
            bhObj?.optJSONObject("proxyHeaders")
                ?: obj.optJSONObject("proxyHeaders")
        )
        val inlineSubs = parseSubtitleArray(obj.optJSONArray("subtitles"), addon)

        val streamType = when {
            url.isNotBlank() -> {
                val low = url.lowercase()
                if (low.startsWith("http://") || low.startsWith("https://") || low.startsWith("content://")) {
                    StreamType.DIRECT_VIDEO
                } else {
                    StreamType.UNSUPPORTED
                }
            }
            externalUrl.isNotBlank() -> StreamType.EXTERNAL_URL
            infoHash != null -> StreamType.TORRENT_INFO_HASH
            else -> StreamType.UNSUPPORTED
        }

        val mimeHint = detectMimeHint(url)
        val quality = extractQuality(listOf(title, description, name))
        val language = extractLanguage(listOf(title, description))

        return StremioStreamItem(
            streamId = obj.optString("id", "${addon.id}:${title.hashCode()}:${url.hashCode()}"),
            addonManifestUrl = addon.manifestUrl,
            addonName = addon.manifest.name,
            title = title,
            name = name,
            description = description,
            quality = quality,
            language = language,
            url = url.takeIf { it.isNotBlank() },
            externalUrl = externalUrl.takeIf { it.isNotBlank() },
            infoHash = infoHash,
            fileIdx = fileIdx,
            streamType = streamType,
            proxyHeaders = proxyHeaders,
            inlineSubtitles = inlineSubs,
            notWebReady = notWebReady,
            mimeHint = mimeHint,
            rawStreamJson = obj
        )
    }

    private fun parseSubtitleArray(arr: JSONArray?, addon: InstalledAddon): List<AddonSubtitleItem> {
        if (arr == null) return emptyList()
        return buildList {
            for (i in 0 until arr.length()) {
                val subObj = arr.optJSONObject(i) ?: continue
                val subUrl = sanitizeStreamUrl(subObj.optString("url", ""), addon.baseUrl)
                if (subUrl.isBlank()) continue
                val subLang = subObj.optString("lang", subObj.optString("id", "English")).trim()
                    .takeIf { it.isNotEmpty() && !it.equals("null", true) }
                    ?: "English"
                val subId = subObj.optString("id", "sub_$i").trim().ifBlank { "sub_$i" }
                add(
                    AddonSubtitleItem(
                        id = subId,
                        lang = subLang,
                        url = subUrl,
                        addonName = addon.manifest.name
                    )
                )
            }
        }
    }

    private fun detectMimeHint(url: String): String? {
        if (url.isBlank()) return null
        val lowerPath = url.substringBefore('?').substringBefore('#').lowercase()
        val lowerFull = url.lowercase()
        return when {
            lowerPath.endsWith(".m3u8") ||
                lowerPath.contains("/hls/") ||
                lowerFull.contains("format=m3u8") ||
                lowerFull.contains("type=m3u8") ||
                lowerFull.contains(".m3u8") -> "application/x-mpegURL"
            lowerPath.endsWith(".mpd") || lowerFull.contains(".mpd") -> "application/dash+xml"
            lowerPath.endsWith(".mp4") -> "video/mp4"
            lowerPath.endsWith(".mkv") -> "video/x-matroska"
            lowerPath.endsWith(".webm") -> "video/webm"
            lowerPath.endsWith(".ts") -> "video/mp2t"
            else -> null
        }
    }

    private fun extractQuality(texts: List<String>): String {
        val combined = texts.joinToString(" ").uppercase()
        return when {
            "2160P" in combined || "4K" in combined || "UHD" in combined -> "4K UHD"
            "1080P" in combined || "FHD" in combined -> "1080p FHD"
            "720P" in combined || "HD" in combined -> "720p HD"
            "480P" in combined || "SD" in combined -> "480p SD"
            else -> "HD"
        }
    }

    private fun extractLanguage(texts: List<String>): String {
        val combined = texts.joinToString(" ").lowercase()
        return when {
            "dual" in combined -> "Dual Audio"
            "hindi" in combined -> "Hindi"
            "bengali" in combined || "bangla" in combined -> "Bangla"
            "english" in combined -> "English"
            "korean" in combined -> "Korean"
            "japanese" in combined -> "Japanese"
            "spanish" in combined -> "Spanish"
            "french" in combined -> "French"
            else -> ""
        }
    }

    private fun sanitizeStreamUrl(raw: String, addonBaseUrl: String): String {
        val clean = raw.trim()
        if (clean.isEmpty() || clean.equals("null", true)) return ""
        val resolved = when {
            clean.startsWith("//") -> "https:$clean"
            clean.startsWith("/") && addonBaseUrl.isNotBlank() ->
                "${addonBaseUrl.trimEnd('/')}$clean"
            else -> clean
        }
        return if (resolved.startsWith("http://", true) ||
            resolved.startsWith("https://", true) ||
            resolved.startsWith("magnet:", true) ||
            resolved.startsWith("content://", true)
        ) {
            resolved.replace(" ", "%20")
        } else {
            ""
        }
    }

    companion object {
        private const val CACHE_TTL_MS = 3 * 60 * 1000L
        private const val MAX_CACHE_ENTRIES = 50
    }
}
