package com.personal.movielink

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.personal.movielink.addons.AddonCatalogDescriptor
import com.personal.movielink.addons.AddonCatalogPage
import com.personal.movielink.addons.AddonCatalogRepository
import com.personal.movielink.addons.AddonCatalogSearchGroup
import com.personal.movielink.addons.AddonDetailedMeta
import com.personal.movielink.addons.AddonManager
import com.personal.movielink.addons.AddonMetadataRepository
import com.personal.movielink.addons.AddonStreamGroupResult
import com.personal.movielink.addons.AddonStreamRepository
import com.personal.movielink.addons.ContentProviderKind
import com.personal.movielink.addons.InstalledAddon
import com.personal.movielink.addons.MetadataEnrichmentService
import com.personal.movielink.addons.StremioCatalogSpec
import com.personal.movielink.addons.UnifiedHomeCatalogEntry
import com.personal.movielink.addons.UnifiedHomeCatalogManager
import com.personal.movielink.addons.UnifiedPosterItem
import com.personal.movielink.addons.UnifiedSearchRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

sealed interface NavScreen {
    data class Catalog(val url: String) : NavScreen
    data class Detail(val url: String) : NavScreen
    data class AddonCatalogGrid(
        val entryKey: String,
        val addonManifestUrl: String,
        val catalogType: String,
        val catalogId: String,
        val title: String
    ) : NavScreen
    data class AddonDetail(
        val type: String,
        val id: String,
        val addonManifestUrl: String? = null,
        val addonNameHint: String? = null,
        val titleHint: String = "",
        val posterHint: String = "",
        val backdropHint: String = "",
        val yearHint: String = "",
        val ratingHint: String = "",
        val descriptionHint: String = "",
        val genresHint: List<String> = emptyList(),
        val logoHint: String = ""
    ) : NavScreen
    data class AddonSources(
        val contentType: String,
        val streamId: String,
        val title: String,
        val subtitle: String,
        val posterUrl: String
    ) : NavScreen
}

data class AddonDetailUiState(
    val meta: AddonDetailedMeta? = null,
    val isLoading: Boolean = false,
    val error: String? = null
)

data class AddonSourcesUiState(
    val contentType: String = "",
    val streamId: String = "",
    val title: String = "",
    val subtitle: String = "",
    val posterUrl: String = "",
    val groupResults: List<AddonStreamGroupResult> = emptyList(),
    val isLoadingAny: Boolean = false
)

data class AddonHomeRowData(
    val items: List<UnifiedPosterItem> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val hasMore: Boolean = false
)

data class CombinedHomeSectionState(
    val key: String,
    val provider: ContentProviderKind,
    val title: String,
    val addonName: String? = null,
    val addonManifestUrl: String? = null,
    val catalogType: String? = null,
    val catalogId: String? = null,
    val items: List<UnifiedPosterItem> = emptyList(),
    val moreUrl: String? = null,
    val hasAddonViewAll: Boolean = false,
    val isLoading: Boolean = false,
    val error: String? = null
)

data class AddonGridState(
    val title: String = "",
    val addonName: String = "",
    val addonManifestUrl: String = "",
    val catalogType: String = "",
    val catalogId: String = "",
    val items: List<UnifiedPosterItem> = emptyList(),
    val isLoading: Boolean = false,
    val hasMore: Boolean = false,
    val nextSkip: Int = 0,
    val error: String? = null
)

data class HeroSourceOption(
    val key: String,
    val provider: ContentProviderKind,
    val title: String,
    val providerLabel: String,
    val isAvailable: Boolean = true
)

private data class HeroBaseInputs(
    val page: CatalogPage?,
    val userSettings: UserSettings,
    val addonList: List<InstalledAddon>,
    val heroRowsMap: Map<String, AddonHomeRowData>
)

data class HeroSectionState(
    val items: List<UnifiedPosterItem> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val activeSourceTitle: String? = null,
    val hidden: Boolean = false
)

data class MovieLinkSearchSectionState(
    val items: List<UnifiedPosterItem> = emptyList(),
    val nextPageUrl: String? = null,
    val isLoading: Boolean = false,
    val isLoadingMore: Boolean = false,
    val error: String? = null
)

data class AddonSearchSectionState(
    val groups: List<AddonCatalogSearchGroup> = emptyList(),
    val noSearchableAddons: Boolean = false
)

data class UnifiedSearchState(
    val query: String = "",
    val hasSearched: Boolean = false,
    val movieLink: MovieLinkSearchSectionState = MovieLinkSearchSectionState(),
    val addons: AddonSearchSectionState = AddonSearchSectionState()
)

data class PendingVideoChoice(
    val url: String,
    val title: String,
    val userAgent: String,
    val contentDisposition: String?,
    val mimeType: String?
)

data class PendingDownloaderChoice(
    val url: String,
    val userAgent: String,
    val contentDisposition: String?,
    val mimeType: String?
)

data class FallbackWebRequest(
    val url: String,
    val title: String,
    val isCloudflareChallenge: Boolean = false,
    val retryTargetUrl: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    val settingsStore = AppSettingsStore(application)
    val addonManager = AddonManager(application)
    val addonCatalogRepository = AddonCatalogRepository()
    val addonMetadataRepository = AddonMetadataRepository()
    val metadataEnrichmentService = MetadataEnrichmentService()
    val addonStreamRepository = AddonStreamRepository()
    val unifiedSearchRepository = UnifiedSearchRepository(addonCatalogRepository)
    val unifiedHomeCatalogManager = UnifiedHomeCatalogManager(application)
    val imageLoader = MovieLinkNetwork.buildImageLoader(application) { settingsStore.settings.value }
    val httpClient = MovieLinkNetwork.buildHttpClient { settingsStore.settings.value }
    val streamHttpClient = MovieLinkNetwork.buildStreamHttpClient { settingsStore.settings.value }
    private val repository = MovieLinkRepository(httpClient) { settingsStore.settings.value }

    val settings: StateFlow<UserSettings> = settingsStore.settings
    val addons: StateFlow<List<InstalledAddon>> = addonManager.addons
    val addonsBusy: StateFlow<Boolean> = addonManager.isBusy
    val unifiedHomeCatalogs: StateFlow<List<UnifiedHomeCatalogEntry>> = unifiedHomeCatalogManager.entries
    val history: StateFlow<List<HistoryItem>> = settingsStore.history
    val myList: StateFlow<List<MyListItem>> = settingsStore.myList
    val playbackProgress: StateFlow<List<PlaybackProgressItem>> = settingsStore.playbackProgress
    val unifiedContinueWatching: StateFlow<List<PlaybackProgressItem>> = playbackProgress
        .map { items -> deduplicateContinueWatching(items) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val sessionBlockedCount: StateFlow<Int> = AdBlocker.sessionBlockedCount
    private var latestMovieLinkHomeSections: List<CatalogSection>? = null

    private val _heroEnrichedItems = MutableStateFlow<Map<String, UnifiedPosterItem>>(emptyMap())
    val heroEnrichedItems: StateFlow<Map<String, UnifiedPosterItem>> = _heroEnrichedItems.asStateFlow()
    private val inFlightHeroEnrichKeys = java.util.Collections.synchronizedSet(HashSet<String>())
    private val heroEnrichPermits = Semaphore(4)

    private val _backStack = MutableStateFlow<List<NavScreen>>(emptyList())
    val backStack: StateFlow<List<NavScreen>> = _backStack.asStateFlow()

    private val _catalog = MutableStateFlow<CatalogPage?>(null)
    val catalog: StateFlow<CatalogPage?> = combine(
        _catalog,
        _heroEnrichedItems,
        settings
    ) { page, enrichedMap, userSettings ->
        if (page == null) return@combine null
        val updatedSections = page.sections.map { sec ->
            sec.copy(
                items = sec.items.map { card ->
                    val posterItem = UnifiedPosterItem.fromMovieLink(card)
                    val enriched = enrichedMap[posterItem.stableKey]
                    val resolvedPoster = card.posterUrl.ifBlank { enriched?.posterUrl.orEmpty() }
                    val resolvedFallback = card.fallbackPosterUrl.ifBlank { enriched?.fallbackPosterUrl.orEmpty() }.ifBlank { enriched?.posterUrl.orEmpty() }
                    card.copy(
                        posterUrl = resolvedPoster,
                        fallbackPosterUrl = resolvedFallback
                    )
                }
            )
        }
        val enrichedPage = page.copy(sections = updatedSections)
        if (userSettings.betterPosterProvider == Config.BetterPosterProvider.NONE || !userSettings.betterPosterOnCards) {
            enrichedPage
        } else {
            val betterSections = enrichedPage.sections.map { sec ->
                sec.copy(
                    items = sec.items.map { card ->
                        val posterItem = UnifiedPosterItem.fromMovieLink(card)
                        val bpList = listOf(posterItem).withBetterPosters(userSettings)
                        val bpItem = bpList.firstOrNull()
                        if (bpItem != null && bpItem.posterUrl.isNotBlank() && bpItem.posterUrl != card.posterUrl) {
                            card.copy(
                                fallbackPosterUrl = card.posterUrl.ifBlank { card.fallbackPosterUrl },
                                posterUrl = bpItem.posterUrl
                            )
                        } else {
                            card
                        }
                    }
                )
            }
            enrichedPage.copy(sections = betterSections)
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val _catalogLoading = MutableStateFlow(false)
    val catalogLoading: StateFlow<Boolean> = _catalogLoading.asStateFlow()

    private val _catalogError = MutableStateFlow<String?>(null)
    val catalogError: StateFlow<String?> = _catalogError.asStateFlow()

    private val _detail = MutableStateFlow<MediaDetail?>(null)
    val detail: StateFlow<MediaDetail?> = _detail.asStateFlow()

    private val _detailLoading = MutableStateFlow(false)
    val detailLoading: StateFlow<Boolean> = _detailLoading.asStateFlow()

    private val _detailError = MutableStateFlow<String?>(null)
    val detailError: StateFlow<String?> = _detailError.asStateFlow()

    private val _playerRequest = MutableStateFlow<PlayerLaunchRequest?>(null)
    val playerRequest: StateFlow<PlayerLaunchRequest?> = _playerRequest.asStateFlow()

    private val _fallbackWeb = MutableStateFlow<FallbackWebRequest?>(null)
    val fallbackWeb: StateFlow<FallbackWebRequest?> = _fallbackWeb.asStateFlow()

    private val _trailerId = MutableStateFlow<Pair<String, String>?>(null)
    val trailerId: StateFlow<Pair<String, String>?> = _trailerId.asStateFlow()

    private val _pendingVideoChoice = MutableStateFlow<PendingVideoChoice?>(null)
    val pendingVideoChoice: StateFlow<PendingVideoChoice?> = _pendingVideoChoice.asStateFlow()

    private val _pendingDownloaderChoice = MutableStateFlow<PendingDownloaderChoice?>(null)
    val pendingDownloaderChoice: StateFlow<PendingDownloaderChoice?> = _pendingDownloaderChoice.asStateFlow()

    private val _addonHomeRows = MutableStateFlow<Map<String, AddonHomeRowData>>(emptyMap())
    private val inFlightAddonCatalogKeys = HashSet<String>()

    private val _categoryHomeRows = MutableStateFlow<Map<String, AddonHomeRowData>>(emptyMap())
    private val inFlightCategoryCatalogKeys = HashSet<String>()

    private val _heroAddonRows = MutableStateFlow<Map<String, AddonHomeRowData>>(emptyMap())
    private val inFlightHeroKeys = HashSet<String>()

    private val _heroCategoryRows = MutableStateFlow<Map<String, AddonHomeRowData>>(emptyMap())
    private val inFlightHeroCategoryKeys = HashSet<String>()
    private val _heroShuffleSeed = MutableStateFlow(System.nanoTime())
    private var activeDetailSeq = 0L
    private var activeAddonDetailSeq = 0L
    private val initialSessionHeroKey: String? = settingsStore.getLastHeroLeadKey()
    private var lastSavedHeroKey: String? = initialSessionHeroKey
    private var excludeHeroKeyForSeed: String? = initialSessionHeroKey

    private val _addonGridState = MutableStateFlow<AddonGridState?>(null)
    val addonGridState: StateFlow<AddonGridState?> = combine(
        _addonGridState,
        settings
    ) { grid, userSettings ->
        grid?.copy(items = grid.items.withBetterPosters(userSettings))
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val _addonDetailState = MutableStateFlow(AddonDetailUiState())
    val addonDetailState: StateFlow<AddonDetailUiState> = _addonDetailState.asStateFlow()

    private val _addonSourcesState = MutableStateFlow(AddonSourcesUiState())
    val addonSourcesState: StateFlow<AddonSourcesUiState> = _addonSourcesState.asStateFlow()

    private val _unifiedSearch = MutableStateFlow(UnifiedSearchState())
    val unifiedSearch: StateFlow<UnifiedSearchState> = combine(
        _unifiedSearch,
        _heroEnrichedItems,
        settings
    ) { searchState, enrichedMap, userSettings ->
        val mlItems = searchState.movieLink.items.map { item ->
            val enriched = enrichedMap[item.stableKey]
            val resolvedPoster = item.posterUrl.ifBlank { enriched?.posterUrl.orEmpty() }
            val resolvedFallback = item.fallbackPosterUrl.ifBlank { enriched?.fallbackPosterUrl.orEmpty() }.ifBlank { enriched?.posterUrl.orEmpty() }
            item.copy(
                posterUrl = resolvedPoster,
                fallbackPosterUrl = resolvedFallback,
                backdropUrl = item.backdropUrl.ifBlank { enriched?.backdropUrl.orEmpty() }
            )
        }.withBetterPosters(userSettings)

        val addonGroups = searchState.addons.groups.map { grp ->
            val grpItems = grp.items.map { item ->
                val enriched = enrichedMap[item.stableKey]
                val resolvedPoster = item.posterUrl.ifBlank { enriched?.posterUrl.orEmpty() }
                val resolvedFallback = item.fallbackPosterUrl.ifBlank { enriched?.fallbackPosterUrl.orEmpty() }.ifBlank { enriched?.posterUrl.orEmpty() }
                item.copy(
                    posterUrl = resolvedPoster,
                    fallbackPosterUrl = resolvedFallback,
                    backdropUrl = item.backdropUrl.ifBlank { enriched?.backdropUrl.orEmpty() }
                )
            }.withBetterPosters(userSettings)
            grp.copy(items = grpItems)
        }
        searchState.copy(
            movieLink = searchState.movieLink.copy(items = mlItems),
            addons = searchState.addons.copy(groups = addonGroups)
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, UnifiedSearchState())
    private var activeSearchJob: Job? = null

    val availableHeroSources: StateFlow<List<HeroSourceOption>> = combine(
        _catalog,
        unifiedHomeCatalogs,
        addons
    ) { page, homeEntries, addonList ->
        val mlTitles = if (page != null && !page.isSearchOrGrid && isHomePageUrl(page.url) && page.sections.isNotEmpty()) {
            page.sections.map { it.title.trim() }.filter { it.isNotEmpty() }.distinctBy { it.lowercase() }
        } else {
            UnifiedHomeCatalogManager.DEFAULT_MOVIELINK_SECTIONS
        }
        val mlOptions = mlTitles.map { title ->
            HeroSourceOption(
                key = UnifiedHomeCatalogManager.movieLinkKey(title),
                provider = ContentProviderKind.MOVIELINK_BD,
                title = title,
                providerLabel = "MovieLinkBD Home",
                isAvailable = true
            )
        }
        val catEntries = homeEntries.filter { it.movieLinkCategoryUrl != null || it.key.startsWith("ml:cat:") }
        val catOptions = if (catEntries.isNotEmpty()) {
            catEntries.map { entry ->
                HeroSourceOption(
                    key = entry.key,
                    provider = ContentProviderKind.MOVIELINK_BD,
                    title = entry.title,
                    providerLabel = "Category · MovieLinkBD",
                    isAvailable = true
                )
            }
        } else {
            UnifiedHomeCatalogManager.DEFAULT_MOVIELINK_CATEGORIES.map { chip ->
                HeroSourceOption(
                    key = UnifiedHomeCatalogManager.movieLinkCategoryKey(chip.label),
                    provider = ContentProviderKind.MOVIELINK_BD,
                    title = chip.label,
                    providerLabel = "Category · MovieLinkBD",
                    isAvailable = true
                )
            }
        }
        val addonOptions = addonCatalogRepository.availableHomeCatalogs(addonList).map { desc ->
            HeroSourceOption(
                key = UnifiedHomeCatalogManager.addonKey(desc.addon.manifestUrl, desc.catalog.type, desc.catalog.id),
                provider = ContentProviderKind.STREMIO_ADDON,
                title = desc.catalog.name,
                providerLabel = "Nuvio · ${desc.addon.manifest.name}",
                isAvailable = true
            )
        }
        mlOptions + catOptions + addonOptions
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // kotlinx.coroutines only has typed combine() overloads for up to 5 flows,
    // so the first four inputs are grouped and then combined with the remaining three.
    private val baseHeroInputs: Flow<HeroBaseInputs> = combine(
        _catalog,
        settings,
        addons,
        _heroAddonRows
    ) { page, userSettings, addonList, heroRowsMap ->
        HeroBaseInputs(page, userSettings, addonList, heroRowsMap)
    }

    private val baseHeroState: StateFlow<HeroSectionState> = combine(
        baseHeroInputs,
        _heroCategoryRows,
        _categoryHomeRows,
        _heroShuffleSeed
    ) { baseInputs, heroCatRowsMap, catHomeRowsMap, shuffleSeed ->
        val page = baseInputs.page
        val userSettings = baseInputs.userSettings
        val addonList = baseInputs.addonList
        val heroRowsMap = baseInputs.heroRowsMap
        val nuvioHeroOn = userSettings.nuvioIntegrationEnabled && userSettings.nuvioHeroEnabled
        val mlHeroOn = userSettings.movieLinkHeroEnabled
        if (!mlHeroOn && !nuvioHeroOn) {
            return@combine HeroSectionState(hidden = true)
        }

        val selectedKeys = userSettings.effectiveHeroSourceKeys()
        val isHomePage = page != null && !page.isSearchOrGrid && isHomePageUrl(page.url)
        val sourcePools = mutableListOf<List<UnifiedPosterItem>>()
        val sourceLabels = mutableListOf<String>()
        var anyAddonLoading = false
        var firstAddonError: String? = null

        if (selectedKeys.isEmpty()) {
            // Auto default: MovieLinkBD Home hero prioritization
            if (!mlHeroOn || !isHomePage || page == null) {
                return@combine HeroSectionState(hidden = true)
            }
            val movieSectionItems = page.sections
                .filter {
                    it.title.equals("Movies", ignoreCase = true) ||
                        (it.title.contains("Movie", ignoreCase = true) &&
                            !it.title.contains("Recently", ignoreCase = true))
                }
                .flatMap { it.items }
            val otherMovieItems = page.sections
                .filterNot {
                    it.title.contains("Recently Updated", ignoreCase = true) ||
                        it.title.contains("Recently Uploaded", ignoreCase = true)
                }
                .flatMap { it.items }
                .filter { it.url.contains("/movie/", ignoreCase = true) }
            val nonRecentFallback = page.sections
                .filterNot {
                    it.title.contains("Recently Updated", ignoreCase = true) ||
                        it.title.contains("Recently Uploaded", ignoreCase = true)
                }
                .flatMap { it.items }
            val prioritized = (movieSectionItems + otherMovieItems).ifEmpty {
                nonRecentFallback.ifEmpty { page.sections.flatMap { it.items } }
            }
            val autoPool = prioritized
                .filter { it.posterUrl.isNotBlank() }
                .distinctBy { it.url }
                .take(18)
                .map { UnifiedPosterItem.fromMovieLink(it) }
            if (autoPool.isNotEmpty()) {
                sourcePools += autoPool
                sourceLabels += "MovieLinkBD Auto"
            }
        } else {
            val activeKeys = selectedKeys.filter { key ->
                when {
                    key.startsWith("ml:") -> mlHeroOn
                    key.startsWith("addon:") -> nuvioHeroOn
                    else -> false
                }
            }
            if (activeKeys.isEmpty()) {
                return@combine HeroSectionState(hidden = true)
            }

            activeKeys.sorted().forEach { key ->
                when {
                    key.startsWith("ml:cat:") -> {
                        val cached = heroCatRowsMap[key] ?: catHomeRowsMap[key]
                        if (cached == null || cached.isLoading) {
                            anyAddonLoading = true
                        }
                        if (firstAddonError == null && !cached?.error.isNullOrBlank()) {
                            firstAddonError = cached?.error
                        }
                        val catItems = cached?.items.orEmpty()
                            .filter { it.posterUrl.isNotBlank() }
                            .distinctBy { it.url }
                            .take(18)
                        if (catItems.isNotEmpty()) {
                            sourcePools += catItems
                            val catTitle = unifiedHomeCatalogs.value.firstOrNull { it.key == key }?.title
                                ?: key.removePrefix("ml:cat:").replaceFirstChar { it.uppercase() }
                            sourceLabels += catTitle
                        }
                    }
                    key.startsWith("ml:") -> {
                        if (isHomePage && page != null) {
                            val targetTitle = key.removePrefix("ml:").trim().lowercase()
                            val sec = page.sections.firstOrNull { it.title.trim().lowercase() == targetTitle }
                            val mlItems = sec?.items.orEmpty()
                                .filter { it.posterUrl.isNotBlank() }
                                .distinctBy { it.url }
                                .take(14)
                                .map { UnifiedPosterItem.fromMovieLink(it) }
                            if (mlItems.isNotEmpty()) {
                                sourcePools += mlItems
                                sec?.title?.takeIf { it.isNotBlank() }?.let { sourceLabels += it }
                            }
                        }
                    }
                    key.startsWith("addon:") -> {
                        val parts = key.removePrefix("addon:").split("|")
                        val manifestUrl = parts.getOrNull(0).orEmpty()
                        val catType = parts.getOrNull(1).orEmpty()
                        val catId = parts.getOrNull(2).orEmpty()
                        val addon = addonList.firstOrNull { it.enabled && it.manifestUrl == manifestUrl }
                        val spec = addon?.manifest?.catalogs?.firstOrNull {
                            it.type.equals(catType, ignoreCase = true) && it.id.equals(catId, ignoreCase = true)
                        }
                        if (addon != null && spec != null) {
                            val cached = heroRowsMap[key]
                            if (cached == null || cached.isLoading) {
                                anyAddonLoading = true
                            }
                            if (firstAddonError == null && !cached?.error.isNullOrBlank()) {
                                firstAddonError = cached?.error
                            }
                            val addonItems = cached?.items.orEmpty()
                                .withBetterPosters(userSettings)
                                .filter { it.posterUrl.isNotBlank() }
                                .take(14)
                            if (addonItems.isNotEmpty()) {
                                sourcePools += addonItems
                            }
                            sourceLabels += "${addon.manifest.name} · ${spec.name}"
                        }
                    }
                }
            }
        }

        val combinedCandidates = interleaveAndDeduplicate(sourcePools, maxItems = 36)
        if (combinedCandidates.isEmpty()) {
            val hasAddonSelected = selectedKeys.any { it.startsWith("addon:") } && nuvioHeroOn
            if (hasAddonSelected && anyAddonLoading) {
                return@combine HeroSectionState(
                    items = emptyList(),
                    isLoading = true,
                    error = firstAddonError,
                    activeSourceTitle = sourceLabels.firstOrNull(),
                    hidden = false
                )
            }
            return@combine HeroSectionState(
                items = emptyList(),
                isLoading = false,
                error = firstAddonError,
                hidden = true
            )
        }

        val shuffled = combinedCandidates
            .shuffled(kotlin.random.Random(shuffleSeed))
            .take(10)
            .toMutableList()

        val featuredIdx = if (userSettings.heroLayoutStyle == Config.HeroLayoutStyle.CAROUSEL && shuffled.size >= 3) {
            1
        } else {
            0
        }
        val excludedKey = excludeHeroKeyForSeed
        if (excludedKey != null && shuffled.size > 1 && shuffled[featuredIdx].stableKey == excludedKey) {
            val swapIdx = shuffled.indices.firstOrNull { idx ->
                idx != featuredIdx && shuffled[idx].stableKey != excludedKey
            }
            if (swapIdx != null) {
                val tmp = shuffled[featuredIdx]
                shuffled[featuredIdx] = shuffled[swapIdx]
                shuffled[swapIdx] = tmp
            }
        }

        val currentFeaturedKey = shuffled.getOrNull(featuredIdx)?.stableKey
        if (!currentFeaturedKey.isNullOrBlank() && currentFeaturedKey != lastSavedHeroKey) {
            lastSavedHeroKey = currentFeaturedKey
            settingsStore.setLastHeroLeadKey(currentFeaturedKey)
        }

        val activeTitle = when {
            sourceLabels.isEmpty() -> null
            sourceLabels.size == 1 -> sourceLabels.first()
            else -> "${sourceLabels.size} Catalogues"
        }

        HeroSectionState(
            items = shuffled,
            isLoading = anyAddonLoading && shuffled.isEmpty(),
            error = firstAddonError,
            activeSourceTitle = activeTitle,
            hidden = false
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, HeroSectionState())

    val heroState: StateFlow<HeroSectionState> = combine(
        baseHeroState,
        _heroEnrichedItems
    ) { state, enrichedMap ->
        if (state.items.isEmpty() || enrichedMap.isEmpty()) {
            state
        } else {
            state.copy(
                items = state.items.map { item ->
                    val enriched = enrichedMap[item.stableKey] ?: return@map item
                    item.copy(
                        posterUrl = item.posterUrl.ifBlank { enriched.posterUrl },
                        fallbackPosterUrl = item.fallbackPosterUrl.ifBlank { enriched.fallbackPosterUrl },
                        backdropUrl = enriched.backdropUrl.ifBlank { item.backdropUrl },
                        logoUrl = enriched.logoUrl.ifBlank { item.logoUrl },
                        rating = item.rating.ifBlank { enriched.rating },
                        yearOrRelease = item.yearOrRelease.ifBlank { enriched.yearOrRelease },
                        genres = item.genres.ifEmpty { enriched.genres },
                        description = item.description.ifBlank { enriched.description }
                    )
                }
            )
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, HeroSectionState())

    val combinedHomeSections: StateFlow<List<CombinedHomeSectionState>> = combine(
        _catalog,
        settings,
        unifiedHomeCatalogs,
        _addonHomeRows,
        _categoryHomeRows
    ) { page, userSettings, entries, addonRowsMap, categoryRowsMap ->
        if (page == null || page.isSearchOrGrid || !isHomePageUrl(page.url)) {
            emptyList()
        } else {
            val mlSectionByLower = page.sections.associateBy { it.title.trim().lowercase() }
            if (entries.isEmpty()) {
                page.sections.map { sec ->
                    CombinedHomeSectionState(
                        key = UnifiedHomeCatalogManager.movieLinkKey(sec.title),
                        provider = ContentProviderKind.MOVIELINK_BD,
                        title = sec.title,
                        items = sec.items.map { UnifiedPosterItem.fromMovieLink(it) },
                        moreUrl = sec.moreUrl
                    )
                }
            } else {
                val showNuvio = userSettings.nuvioIntegrationEnabled && userSettings.nuvioHomeCatalogsEnabled
                entries.mapNotNull { entry ->
                    if (!entry.enabled || !entry.isAvailable) return@mapNotNull null
                    when {
                        entry.movieLinkCategoryUrl != null || entry.key.startsWith("ml:cat:") -> {
                            val rowState = categoryRowsMap[entry.key]
                            val catItems = rowState?.items.orEmpty()
                            val catUrl = entry.movieLinkCategoryUrl ?: findKnownCategoryUrl(entry.key)
                            CombinedHomeSectionState(
                                key = entry.key,
                                provider = ContentProviderKind.MOVIELINK_BD,
                                title = entry.title,
                                items = catItems,
                                moreUrl = catUrl,
                                isLoading = (rowState == null || rowState.isLoading) && catItems.isEmpty(),
                                error = rowState?.error
                            )
                        }
                        entry.provider == ContentProviderKind.MOVIELINK_BD -> {
                            val secTitle = (entry.movieLinkSectionTitle ?: entry.title).trim().lowercase()
                            val matched = mlSectionByLower[secTitle] ?: return@mapNotNull null
                            CombinedHomeSectionState(
                                key = entry.key,
                                provider = ContentProviderKind.MOVIELINK_BD,
                                title = matched.title,
                                items = matched.items.map { UnifiedPosterItem.fromMovieLink(it) },
                                moreUrl = matched.moreUrl
                            )
                        }
                        entry.provider == ContentProviderKind.STREMIO_ADDON -> {
                            if (!showNuvio) return@mapNotNull null
                            val rowState = addonRowsMap[entry.key] ?: AddonHomeRowData(isLoading = true)
                            val resolvedItems = rowState.items.withBetterPosters(userSettings)
                            CombinedHomeSectionState(
                                key = entry.key,
                                provider = ContentProviderKind.STREMIO_ADDON,
                                title = entry.title,
                                addonName = entry.addonName,
                                addonManifestUrl = entry.addonManifestUrl,
                                catalogType = entry.addonCatalogType,
                                catalogId = entry.addonCatalogId,
                                items = resolvedItems,
                                hasAddonViewAll = resolvedItems.isNotEmpty(),
                                isLoading = rowState.isLoading,
                                error = rowState.error
                            )
                        }
                        else -> null
                    }
                }
            }
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        unifiedHomeCatalogManager.syncSources(null, null, addons.value, settings.value.mirrorUrl)
        val startUrl = settingsStore.startupUrl()
        if (isDetailUrl(startUrl)) {
            _backStack.value = listOf(
                NavScreen.Catalog(settings.value.mirrorUrl),
                NavScreen.Detail(startUrl)
            )
            loadCatalog(settings.value.mirrorUrl, recordVisit = false)
            loadDetail(startUrl)
        } else {
            _backStack.value = listOf(NavScreen.Catalog(startUrl))
            loadCatalog(startUrl, recordVisit = true)
        }

        viewModelScope.launch {
            combine(settings, unifiedHomeCatalogs, addons) { s, list, _ ->
                Triple(s.nuvioIntegrationEnabled, s.nuvioHomeCatalogsEnabled, list)
            }.collect { (nuvioOn, homeOn, _) ->
                if (nuvioOn && homeOn) {
                    refreshEnabledAddonHomeSections(forceRefresh = false)
                }
            }
        }

        viewModelScope.launch {
            unifiedHomeCatalogs.collect {
                refreshEnabledCategoryHomeSections(forceRefresh = false)
            }
        }

        viewModelScope.launch {
            settings.collect { s ->
                val heroCatKeys = s.effectiveHeroSourceKeys().filter { it.startsWith("ml:cat:") }
                if (heroCatKeys.isNotEmpty()) {
                    refreshHeroCategorySources(heroCatKeys.toSet(), forceRefresh = false)
                }
            }
        }

        viewModelScope.launch {
            var lastSelectedHeroKeys: Set<String>? = null
            combine(settings, addons) { s, _ ->
                Triple(s.nuvioIntegrationEnabled, s.nuvioHeroEnabled, s.effectiveHeroSourceKeys())
            }.collect { (nuvioOn, heroOn, heroKeys) ->
                if (lastSelectedHeroKeys != null && lastSelectedHeroKeys != heroKeys) {
                    bumpHeroShuffleSeed()
                }
                lastSelectedHeroKeys = heroKeys
                if (nuvioOn && heroOn && heroKeys.any { it.startsWith("addon:") }) {
                    refreshHeroAddonSources(forceRefresh = false)
                }
            }
        }

        viewModelScope.launch {
            combine(baseHeroState, settings) { state, s ->
                state.items to (s.tmdbMetadataEnabled to s.tmdbApiKey)
            }.collect { (items, _) ->
                if (items.isNotEmpty()) {
                    ensureHeroArtworkEnriched(items)
                }
            }
        }
    }

    fun currentUrl(): String {
        return when (val top = _backStack.value.lastOrNull()) {
            is NavScreen.Detail -> top.url
            is NavScreen.Catalog -> top.url
            is NavScreen.AddonCatalogGrid, is NavScreen.AddonDetail, is NavScreen.AddonSources, null -> settings.value.mirrorUrl
        }
    }

    fun isDetailUrl(url: String): Boolean {
        val lower = url.lowercase()
        return lower.contains("/movie/") ||
            lower.contains("/series/") ||
            lower.contains("/drama/") ||
            lower.contains("/anime/")
    }

    fun openCatalogUrl(url: String) {
        val normalized = Config.normalizeUrl(url)
        _backStack.value = listOf(NavScreen.Catalog(normalized))
        loadCatalog(normalized, recordVisit = true)
    }

    fun searchCatalog(query: String) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return

        val currentSearch = _unifiedSearch.value
        val currentlyBusy = currentSearch.movieLink.isLoading ||
            currentSearch.addons.groups.any { it.isLoading }
        if (currentSearch.hasSearched && currentSearch.query == trimmed && currentlyBusy) {
            return
        }

        activeSearchJob?.cancel()
        val s = settings.value
        val runMl = s.movieLinkSearchEnabled
        val runAddons = s.nuvioIntegrationEnabled && s.nuvioSearchEnabled
        val searchableCatalogs = if (runAddons) {
            unifiedSearchRepository.discoverSearchableCatalogs(addons.value)
        } else {
            emptyList()
        }

        val initialGroups = searchableCatalogs.map { desc ->
            AddonCatalogSearchGroup(
                key = desc.catalogKey,
                addon = desc.addon,
                catalog = desc.catalog,
                isLoading = true
            )
        }

        _unifiedSearch.value = UnifiedSearchState(
            query = trimmed,
            hasSearched = true,
            movieLink = MovieLinkSearchSectionState(isLoading = runMl),
            addons = AddonSearchSectionState(
                groups = initialGroups,
                noSearchableAddons = runAddons && searchableCatalogs.isEmpty()
            )
        )

        if (!runMl && searchableCatalogs.isEmpty()) return

        activeSearchJob = viewModelScope.launch {
            if (runMl) {
                launch {
                    executeMovieLinkSearch(trimmed)
                }
            }
            if (runAddons) {
                for (desc in searchableCatalogs) {
                    launch {
                        val res = unifiedSearchRepository.searchAddonCatalog(desc, trimmed, skip = 0)
                        _unifiedSearch.update { state ->
                            val nextGroups = state.addons.groups.map { grp ->
                                if (grp.key != desc.catalogKey) {
                                    grp
                                } else {
                                    res.fold(
                                        onSuccess = { page ->
                                            grp.copy(
                                                items = page.items,
                                                isLoading = false,
                                                hasMore = page.hasMore,
                                                nextSkip = page.nextSkip,
                                                error = null
                                            )
                                        },
                                        onFailure = { err ->
                                            grp.copy(
                                                isLoading = false,
                                                error = err.message ?: "Addon search failed"
                                            )
                                        }
                                    )
                                }
                            }
                            state.copy(addons = state.addons.copy(groups = nextGroups))
                        }
                    }
                }
            }
        }
    }

    private suspend fun executeMovieLinkSearch(query: String) {
        try {
            val page = repository.searchCatalog(query)
            val items = page.sections
                .flatMap { it.items }
                .distinctBy { it.url }
                .map { UnifiedPosterItem.fromMovieLink(it) }
            ensureHeroArtworkEnriched(items)
            _unifiedSearch.update { state ->
                state.copy(
                    movieLink = MovieLinkSearchSectionState(
                        items = items,
                        nextPageUrl = page.nextPageUrl,
                        isLoading = false,
                        error = null
                    )
                )
            }
            settingsStore.recordHistory(page.pageTitle, page.url)
        } catch (cf: CloudflareRequiredException) {
            _unifiedSearch.update { state ->
                state.copy(
                    movieLink = state.movieLink.copy(
                        isLoading = false,
                        error = "Cloudflare verification required"
                    )
                )
            }
            _fallbackWeb.value = FallbackWebRequest(cf.url, "Security Check", isCloudflareChallenge = true, retryTargetUrl = cf.url)
        } catch (e: Exception) {
            _unifiedSearch.update { state ->
                state.copy(
                    movieLink = state.movieLink.copy(
                        isLoading = false,
                        error = e.message ?: "Unable to search MovieLinkBD"
                    )
                )
            }
        }
    }

    fun clearUnifiedSearch() {
        activeSearchJob?.cancel()
        _unifiedSearch.value = UnifiedSearchState()
    }

    fun retryMovieLinkSearch() {
        val q = _unifiedSearch.value.query.trim()
        if (q.isEmpty() || !settings.value.movieLinkSearchEnabled) return
        _unifiedSearch.update { state ->
            state.copy(movieLink = state.movieLink.copy(isLoading = true, error = null))
        }
        viewModelScope.launch {
            executeMovieLinkSearch(q)
        }
    }

    fun loadMoreMovieLinkSearch() {
        val ml = _unifiedSearch.value.movieLink
        val nextUrl = ml.nextPageUrl ?: return
        if (ml.isLoading || ml.isLoadingMore) return
        _unifiedSearch.update { state ->
            state.copy(movieLink = state.movieLink.copy(isLoadingMore = true, error = null))
        }
        viewModelScope.launch {
            try {
                val page = repository.fetchCatalogPage(nextUrl)
                val nextItems = page.sections.flatMap { it.items }.map { UnifiedPosterItem.fromMovieLink(it) }
                _unifiedSearch.update { state ->
                    val merged = (state.movieLink.items + nextItems).distinctBy { it.stableKey }
                    state.copy(
                        movieLink = state.movieLink.copy(
                            items = merged,
                            nextPageUrl = page.nextPageUrl,
                            isLoadingMore = false,
                            error = null
                        )
                    )
                }
            } catch (cf: CloudflareRequiredException) {
                _unifiedSearch.update { state ->
                    state.copy(movieLink = state.movieLink.copy(isLoadingMore = false, error = "Cloudflare verification required"))
                }
                _fallbackWeb.value = FallbackWebRequest(cf.url, "Security Check", isCloudflareChallenge = true, retryTargetUrl = cf.url)
            } catch (e: Exception) {
                _unifiedSearch.update { state ->
                    state.copy(movieLink = state.movieLink.copy(isLoadingMore = false, error = e.message ?: "Failed to load more results"))
                }
            }
        }
    }

    fun retryAddonSearchGroup(groupKey: String) {
        val state = _unifiedSearch.value
        val q = state.query.trim()
        val group = state.addons.groups.firstOrNull { it.key == groupKey } ?: return
        if (q.isEmpty() || group.isLoading) return

        _unifiedSearch.update { curr ->
            val updated = curr.addons.groups.map {
                if (it.key == groupKey) it.copy(isLoading = true, error = null) else it
            }
            curr.copy(addons = curr.addons.copy(groups = updated))
        }
        viewModelScope.launch {
            val res = unifiedSearchRepository.searchAddonCatalog(
                AddonCatalogDescriptor(group.addon, group.catalog),
                query = q,
                skip = 0,
                forceRefresh = true
            )
            _unifiedSearch.update { curr ->
                val updated = curr.addons.groups.map {
                    if (it.key != groupKey) it else res.fold(
                        onSuccess = { p ->
                            it.copy(items = p.items, isLoading = false, hasMore = p.hasMore, nextSkip = p.nextSkip, error = null)
                        },
                        onFailure = { e ->
                            it.copy(isLoading = false, error = e.message ?: "Addon search failed")
                        }
                    )
                }
                curr.copy(addons = curr.addons.copy(groups = updated))
            }
        }
    }

    fun loadMoreAddonSearchGroup(groupKey: String) {
        val state = _unifiedSearch.value
        val q = state.query.trim()
        val group = state.addons.groups.firstOrNull { it.key == groupKey } ?: return
        if (q.isEmpty() || group.isLoading || group.isLoadingMore || !group.hasMore) return

        _unifiedSearch.update { curr ->
            val updated = curr.addons.groups.map {
                if (it.key == groupKey) it.copy(isLoadingMore = true, error = null) else it
            }
            curr.copy(addons = curr.addons.copy(groups = updated))
        }
        viewModelScope.launch {
            val res = unifiedSearchRepository.searchAddonCatalog(
                AddonCatalogDescriptor(group.addon, group.catalog),
                query = q,
                skip = group.nextSkip
            )
            _unifiedSearch.update { curr ->
                val updated = curr.addons.groups.map {
                    if (it.key != groupKey) it else res.fold(
                        onSuccess = { p ->
                            val merged = (it.items + p.items).distinctBy { item -> item.stableKey }
                            it.copy(
                                items = merged,
                                isLoadingMore = false,
                                hasMore = p.hasMore && p.items.isNotEmpty(),
                                nextSkip = p.nextSkip,
                                error = null
                            )
                        },
                        onFailure = { e ->
                            it.copy(isLoadingMore = false, error = e.message ?: "Failed to load more")
                        }
                    )
                }
                curr.copy(addons = curr.addons.copy(groups = updated))
            }
        }
    }

    fun openDetailUrl(url: String, titleHint: String? = null, posterHint: String = "") {
        val currentStack = _backStack.value.ifEmpty { listOf(NavScreen.Catalog(settings.value.mirrorUrl)) }
        _backStack.value = currentStack + NavScreen.Detail(url)
        _detail.value = null
        loadDetail(url, titleHint, posterHint)
    }

    fun openUrlSmart(url: String, titleHint: String? = null, posterHint: String = "") {
        if (isDetailUrl(url)) {
            openDetailUrl(url, titleHint, posterHint)
        } else {
            openCatalogUrl(url)
        }
    }

    fun refreshCurrent() {
        when (val top = _backStack.value.lastOrNull()) {
            is NavScreen.Detail -> loadDetail(top.url)
            is NavScreen.Catalog -> {
                if (isHomePageUrl(top.url)) {
                    bumpHeroShuffleSeed()
                }
                loadCatalog(top.url, recordVisit = false)
                if (isHomePageUrl(top.url) && settings.value.nuvioIntegrationEnabled) {
                    if (settings.value.nuvioHomeCatalogsEnabled) {
                        refreshEnabledAddonHomeSections(forceRefresh = true)
                    }
                    if (settings.value.nuvioHeroEnabled &&
                        settings.value.effectiveHeroSourceKeys().any { it.startsWith("addon:") }
                    ) {
                        refreshHeroAddonSources(forceRefresh = true)
                    }
                }
            }
            is NavScreen.AddonCatalogGrid -> loadAddonGridInitial(top, forceRefresh = true)
            is NavScreen.AddonDetail -> loadAddonDetail(top, forceRefresh = true)
            is NavScreen.AddonSources -> loadAddonSources(top, forceRefresh = true)
            null -> openCatalogUrl(settings.value.mirrorUrl)
        }
    }

    fun navigateBack(): Boolean {
        val stack = _backStack.value
        if (stack.size <= 1) return false
        val next = stack.dropLast(1)
        _backStack.value = next
        when (val top = next.last()) {
            is NavScreen.Detail -> loadDetail(top.url)
            is NavScreen.Catalog -> {
                if (_catalog.value?.url != top.url) {
                    loadCatalog(top.url, recordVisit = false)
                }
            }
            is NavScreen.AddonCatalogGrid -> {
                if (_addonGridState.value?.catalogId != top.catalogId ||
                    _addonGridState.value?.addonManifestUrl != top.addonManifestUrl
                ) {
                    loadAddonGridInitial(top, forceRefresh = false)
                }
            }
            is NavScreen.AddonDetail -> {
                val curr = _addonDetailState.value.meta
                if (curr == null || curr.id != top.id || curr.type != top.type) {
                    loadAddonDetail(top, forceRefresh = false)
                }
            }
            is NavScreen.AddonSources -> {
                val curr = _addonSourcesState.value
                if (curr.streamId != top.streamId || curr.contentType != top.contentType) {
                    loadAddonSources(top, forceRefresh = false)
                }
            }
        }
        return true
    }

    fun isHomePageUrl(url: String): Boolean {
        val cleanPath = android.net.Uri.parse(Config.normalizeUrl(url)).path?.trim('/').orEmpty()
        return cleanPath.isEmpty() || cleanPath.equals("index.php", ignoreCase = true)
    }

    private fun loadCatalog(url: String, recordVisit: Boolean) {
        viewModelScope.launch {
            _catalogLoading.value = true
            _catalogError.value = null
            try {
                val page = repository.fetchCatalogPage(url)
                _catalog.value = page
                val allCatalogItems = page.sections.flatMap { it.items }.map { UnifiedPosterItem.fromMovieLink(it) }
                ensureHeroArtworkEnriched(allCatalogItems)
                if (!page.isSearchOrGrid && isHomePageUrl(page.url)) {
                    latestMovieLinkHomeSections = page.sections
                    unifiedHomeCatalogManager.syncSources(
                        page.sections,
                        page.categories,
                        addons.value,
                        settings.value.mirrorUrl
                    )
                } else if (page.categories.isNotEmpty()) {
                    unifiedHomeCatalogManager.syncSources(
                        latestMovieLinkHomeSections,
                        page.categories,
                        addons.value,
                        settings.value.mirrorUrl
                    )
                }
                if (recordVisit) {
                    settingsStore.recordHistory(page.pageTitle, page.url)
                }
            } catch (cf: CloudflareRequiredException) {
                _catalogError.value = "Cloudflare verification required"
                _fallbackWeb.value = FallbackWebRequest(cf.url, "Security Check", isCloudflareChallenge = true, retryTargetUrl = cf.url)
            } catch (e: Exception) {
                _catalogError.value = e.message ?: "Connection failed"
            } finally {
                _catalogLoading.value = false
            }
        }
    }

    private fun loadDetail(url: String, titleHint: String? = null, posterHint: String = "") {
        val reqSeq = ++activeDetailSeq
        val heroCached = _heroEnrichedItems.value.values.firstOrNull { cached ->
            cached.movieLinkUrl.equals(url, ignoreCase = true) ||
                (!titleHint.isNullOrBlank() && cached.title.equals(titleHint, ignoreCase = true))
        }
        viewModelScope.launch {
            _detailLoading.value = true
            _detailError.value = null
            try {
                val d = repository.fetchDetail(url)
                if (reqSeq != activeDetailSeq) return@launch
                val mergedPoster = d.posterUrl
                    .ifBlank { heroCached?.posterUrl.orEmpty() }
                    .ifBlank { posterHint }
                val preEnriched = d.copy(
                    posterUrl = mergedPoster,
                    backdropUrl = d.backdropUrl.ifBlank { heroCached?.backdropUrl.orEmpty() },
                    logoUrl = d.logoUrl.ifBlank { heroCached?.logoUrl.orEmpty() },
                    genres = d.genres.ifEmpty { heroCached?.genres.orEmpty() }
                )
                _detail.value = preEnriched
                settingsStore.recordHistory(preEnriched.title.ifBlank { titleHint }, preEnriched.url, mergedPoster)
                val s = settings.value
                val enriched = metadataEnrichmentService.enrichMovieLinkDetail(
                    detail = preEnriched,
                    settings = s,
                    titleHint = titleHint.orEmpty()
                )
                if (reqSeq == activeDetailSeq && _detail.value?.url == preEnriched.url) {
                    _detail.value = enriched
                }
            } catch (cf: CloudflareRequiredException) {
                if (reqSeq == activeDetailSeq) {
                    _detailError.value = "Cloudflare verification required"
                    _fallbackWeb.value = FallbackWebRequest(cf.url, "Security Check", isCloudflareChallenge = true, retryTargetUrl = cf.url)
                }
            } catch (e: Exception) {
                if (reqSeq == activeDetailSeq) {
                    _detailError.value = e.message ?: "Unable to load movie details"
                }
            } finally {
                if (reqSeq == activeDetailSeq) {
                    _detailLoading.value = false
                }
            }
        }
    }

    fun launchPlayer(request: PlayerLaunchRequest) {
        _playerRequest.value = request
    }

    fun closePlayer() {
        _playerRequest.value = null
    }

    fun resumeContinueWatching(item: PlaybackProgressItem) {
        if (item.streamUrl.isNotBlank()) {
            launchPlayer(
                PlayerLaunchRequest(
                    streamUrl = item.streamUrl,
                    title = item.title,
                    subtitle = item.subtitle,
                    refererUrl = item.refererUrl,
                    isEmbedPage = item.isEmbedPage,
                    requestHeaders = item.requestHeaders,
                    mimeTypeHint = item.mimeTypeHint,
                    sourceLabel = item.sourceLabel,
                    mediaKey = item.mediaKey,
                    posterUrl = item.posterUrl,
                    contentType = item.contentType,
                    isLocalMedia = item.sourceType == "local"
                )
            )
            return
        }
        when {
            item.sourceType == "movielink" && item.refererUrl.isNotBlank() ->
                openDetailUrl(item.refererUrl, item.title, item.posterUrl)
            item.sourceType == "addon" && item.mediaKey.startsWith("addon:") -> {
                val parts = item.mediaKey.removePrefix("addon:").split(":")
                val type = parts.getOrNull(0).orEmpty().ifBlank { "movie" }
                val rawId = parts.getOrNull(1).orEmpty()
                if (rawId.isNotBlank()) {
                    val nav = NavScreen.AddonDetail(
                        type = type,
                        id = rawId,
                        titleHint = item.title,
                        posterHint = item.posterUrl
                    )
                    val currentStack = _backStack.value.ifEmpty { listOf(NavScreen.Catalog(settings.value.mirrorUrl)) }
                    _backStack.value = currentStack + nav
                    loadAddonDetail(nav, forceRefresh = false)
                }
            }
        }
    }

    fun myListKeyForPoster(item: UnifiedPosterItem): String {
        return when (item.provider) {
            ContentProviderKind.MOVIELINK_BD -> item.movieLinkUrl.orEmpty()
            ContentProviderKind.STREMIO_ADDON -> {
                val t = item.stremioType?.takeIf { it.isNotBlank() } ?: item.type.ifBlank { "movie" }
                val id = item.stremioId.orEmpty()
                val manifest = android.net.Uri.encode(item.addonManifestUrl.orEmpty())
                "addon://$t/$id?manifest=$manifest"
            }
        }
    }

    fun togglePosterMyList(item: UnifiedPosterItem): Boolean {
        val key = myListKeyForPoster(item)
        if (key.isBlank()) return false
        return settingsStore.toggleMyList(
            MyListItem(
                url = key,
                title = item.title,
                posterUrl = item.posterUrl,
                type = item.stremioType?.takeIf { it.isNotBlank() } ?: item.type.ifBlank { "Title" },
                quality = item.qualityOrBadge.ifBlank { item.rating.takeIf { it.isNotBlank() }?.let { "★ $it" }.orEmpty() },
                language = item.language.ifBlank { item.yearOrRelease },
                addedAt = System.currentTimeMillis()
            )
        )
    }

    fun isAddonInMyList(type: String, id: String, list: List<MyListItem>): Boolean {
        val cleanType = type.trim().ifBlank { "movie" }
        val cleanId = id.trim()
        if (cleanId.isBlank()) return false
        val prefix = "addon://$cleanType/$cleanId"
        return list.any { it.url == prefix || it.url.startsWith("$prefix?") }
    }

    fun toggleAddonMetaMyList(meta: AddonDetailedMeta): Boolean {
        val cleanType = meta.type.trim().ifBlank { "movie" }
        val manifest = android.net.Uri.encode(meta.sourceManifestUrl)
        val key = "addon://$cleanType/${meta.id}?manifest=$manifest"
        val existing = settingsStore.myList.value.firstOrNull {
            it.url == key || it.url.startsWith("addon://$cleanType/${meta.id}")
        }
        if (existing != null) {
            settingsStore.removeFromMyList(existing.url)
            return false
        }
        return settingsStore.toggleMyList(
            MyListItem(
                url = key,
                title = meta.title,
                posterUrl = meta.posterUrl.ifBlank { meta.backdropUrl },
                type = cleanType,
                quality = meta.rating.takeIf { it.isNotBlank() }?.let { "★ $it" }.orEmpty(),
                language = meta.releaseYear,
                addedAt = System.currentTimeMillis()
            )
        )
    }

    fun openMyListItem(item: MyListItem) {
        if (item.url.startsWith("addon://")) {
            val parsed = android.net.Uri.parse(item.url)
            val contentType = parsed.host.orEmpty().ifBlank { "movie" }
            val streamId = parsed.path?.trim('/').orEmpty()
            val manifestUrl = parsed.getQueryParameter("manifest")?.takeIf { it.isNotBlank() }
            if (streamId.isNotBlank()) {
                val nav = NavScreen.AddonDetail(
                    type = contentType,
                    id = streamId,
                    addonManifestUrl = manifestUrl,
                    titleHint = item.title,
                    posterHint = item.posterUrl,
                    yearHint = item.language
                )
                val currentStack = _backStack.value.ifEmpty { listOf(NavScreen.Catalog(settings.value.mirrorUrl)) }
                _backStack.value = currentStack + nav
                loadAddonDetail(nav, forceRefresh = false)
            }
        } else {
            openDetailUrl(item.url, item.title, item.posterUrl)
        }
    }

    private fun deduplicateContinueWatching(items: List<PlaybackProgressItem>): List<PlaybackProgressItem> {
        if (items.isEmpty()) return emptyList()
        val seenKeys = HashSet<String>()
        val result = ArrayList<PlaybackProgressItem>(items.size)
        for (item in items.sortedByDescending { it.updatedAt }) {
            if (item.positionMs < 5_000L) continue
            val canonicalKey = when {
                item.mediaKey.startsWith("addon:") -> {
                    val parts = item.mediaKey.removePrefix("addon:").split(":")
                    val type = parts.getOrNull(0)?.lowercase().orEmpty()
                    val baseId = parts.getOrNull(1)?.lowercase().orEmpty()
                    if (type.isNotBlank() && baseId.isNotBlank()) "addon:$type:$baseId" else item.mediaKey.lowercase()
                }
                item.mediaKey.startsWith("ml:") -> {
                    "ml:" + item.mediaKey.removePrefix("ml:").trim().trimEnd('/').lowercase()
                }
                else -> item.mediaKey.trim().trimEnd('/').lowercase()
            }
            if (seenKeys.add(canonicalKey)) {
                result.add(item)
            }
            if (result.size >= 15) break
        }
        return result
    }

    fun openFallbackWeb(url: String, title: String = "MovieLink Browser") {
        _fallbackWeb.value = FallbackWebRequest(url, title, isCloudflareChallenge = false, retryTargetUrl = null)
    }

    fun closeFallbackWeb() {
        _fallbackWeb.value = null
    }

    fun onCloudflareSolved() {
        val retryUrl = _fallbackWeb.value?.retryTargetUrl
        _fallbackWeb.value = null
        if (!retryUrl.isNullOrBlank()) {
            when {
                retryUrl.contains("/search", ignoreCase = true) && _unifiedSearch.value.hasSearched ->
                    retryMovieLinkSearch()
                isDetailUrl(retryUrl) -> loadDetail(retryUrl)
                else -> loadCatalog(retryUrl, recordVisit = true)
            }
        } else {
            refreshCurrent()
        }
    }

    fun openTrailer(youtubeId: String, title: String) {
        _trailerId.value = youtubeId to title
    }

    fun closeTrailer() {
        _trailerId.value = null
    }

    fun showVideoChoice(choice: PendingVideoChoice) {
        _pendingVideoChoice.value = choice
    }

    fun dismissVideoChoice() {
        _pendingVideoChoice.value = null
    }

    fun showDownloaderChoice(choice: PendingDownloaderChoice) {
        _pendingDownloaderChoice.value = choice
    }

    fun dismissDownloaderChoice() {
        _pendingDownloaderChoice.value = null
    }

    suspend fun installAddon(url: String): Result<InstalledAddon> {
        val res = addonManager.installAddon(url)
        if (res.isSuccess) {
            addonCatalogRepository.clearCache()
            unifiedHomeCatalogManager.syncSources(latestMovieLinkHomeSections, _catalog.value?.categories, addons.value, settings.value.mirrorUrl)
        }
        return res
    }

    fun setAddonEnabled(manifestUrl: String, enabled: Boolean) {
        addonManager.setAddonEnabled(manifestUrl, enabled)
        addonCatalogRepository.clearCache()
        unifiedHomeCatalogManager.syncSources(latestMovieLinkHomeSections, _catalog.value?.categories, addons.value, settings.value.mirrorUrl)
    }

    fun removeAddon(manifestUrl: String) {
        addonManager.removeAddon(manifestUrl)
        addonCatalogRepository.clearCache()
        unifiedHomeCatalogManager.syncSources(latestMovieLinkHomeSections, _catalog.value?.categories, addons.value, settings.value.mirrorUrl)
    }

    suspend fun refreshAddon(manifestUrl: String): Result<InstalledAddon> {
        val res = addonManager.refreshAddon(manifestUrl)
        addonCatalogRepository.clearCache()
        unifiedHomeCatalogManager.syncSources(latestMovieLinkHomeSections, _catalog.value?.categories, addons.value, settings.value.mirrorUrl)
        return res
    }

    fun refreshAllAddons() {
        viewModelScope.launch {
            addonManager.refreshAllAddons()
            addonCatalogRepository.clearCache()
            unifiedHomeCatalogManager.syncSources(latestMovieLinkHomeSections, _catalog.value?.categories, addons.value, settings.value.mirrorUrl)
        }
    }

    fun setUnifiedHomeCatalogEnabled(key: String, enabled: Boolean) {
        unifiedHomeCatalogManager.setCatalogEnabled(key, enabled)
    }

    fun moveUnifiedHomeCatalog(fromIndex: Int, toIndex: Int) {
        unifiedHomeCatalogManager.moveCatalog(fromIndex, toIndex)
    }

    fun removeUnifiedHomeCatalogEntry(key: String) {
        unifiedHomeCatalogManager.removeEntry(key)
    }

    fun availableAddonHomeCatalogs(): List<AddonCatalogDescriptor> =
        addonCatalogRepository.availableHomeCatalogs(addons.value)

    suspend fun fetchAddonCatalog(
        addon: InstalledAddon,
        catalog: StremioCatalogSpec,
        skip: Int = 0,
        searchQuery: String? = null,
        genre: String? = null,
        forceRefresh: Boolean = false
    ): Result<AddonCatalogPage> =
        addonCatalogRepository.fetchCatalog(
            addon = addon,
            catalog = catalog,
            skip = skip,
            searchQuery = searchQuery,
            genre = genre,
            forceRefresh = forceRefresh
        )

    fun refreshEnabledAddonHomeSections(forceRefresh: Boolean = false) {
        val s = settings.value
        if (!s.nuvioIntegrationEnabled || !s.nuvioHomeCatalogsEnabled) return
        val enabledAddonEntries = unifiedHomeCatalogs.value.filter {
            it.provider == ContentProviderKind.STREMIO_ADDON && it.enabled && it.isAvailable
        }
        val currentAddons = addons.value.associateBy { it.manifestUrl }
        for (entry in enabledAddonEntries) {
            val manifestUrl = entry.addonManifestUrl ?: continue
            val catType = entry.addonCatalogType ?: continue
            val catId = entry.addonCatalogId ?: continue
            val existing = _addonHomeRows.value[entry.key]
            if (!forceRefresh && existing != null && existing.items.isNotEmpty() && existing.error == null) {
                continue
            }
            if (!inFlightAddonCatalogKeys.add(entry.key)) continue

            val addon = currentAddons[manifestUrl]
            val spec = addon?.manifest?.catalogs?.firstOrNull {
                it.type.equals(catType, ignoreCase = true) && it.id.equals(catId, ignoreCase = true)
            }
            if (addon == null || spec == null) {
                inFlightAddonCatalogKeys.remove(entry.key)
                _addonHomeRows.update { map ->
                    map + (entry.key to AddonHomeRowData(isLoading = false, error = "Catalog unavailable"))
                }
                continue
            }

            _addonHomeRows.update { map ->
                map + (entry.key to AddonHomeRowData(
                    items = existing?.items.orEmpty(),
                    isLoading = true,
                    error = null
                ))
            }

            viewModelScope.launch {
                try {
                    val res = addonCatalogRepository.fetchCatalog(
                        addon = addon,
                        catalog = spec,
                        skip = 0,
                        forceRefresh = forceRefresh
                    )
                    res.fold(
                        onSuccess = { page ->
                            _addonHomeRows.update { map ->
                                map + (entry.key to AddonHomeRowData(
                                    items = page.items,
                                    isLoading = false,
                                    error = null,
                                    hasMore = page.hasMore
                                ))
                            }
                        },
                        onFailure = { err ->
                            _addonHomeRows.update { map ->
                                map + (entry.key to AddonHomeRowData(
                                    items = existing?.items.orEmpty(),
                                    isLoading = false,
                                    error = err.message ?: "Failed to load catalog"
                                ))
                            }
                        }
                    )
                } finally {
                    inFlightAddonCatalogKeys.remove(entry.key)
                }
            }
        }
    }

    fun retryAddonHomeSection(entryKey: String) {
        _addonHomeRows.update { map -> map - entryKey }
        refreshEnabledAddonHomeSections(forceRefresh = true)
    }

    fun findKnownCategoryUrl(key: String): String? {
        val entry = unifiedHomeCatalogs.value.firstOrNull { it.key == key }
        if (!entry?.movieLinkCategoryUrl.isNullOrBlank()) return entry?.movieLinkCategoryUrl
        val label = key.removePrefix("ml:cat:")
        val matched = UnifiedHomeCatalogManager.DEFAULT_MOVIELINK_CATEGORIES.firstOrNull {
            it.label.trim().lowercase() == label.trim().lowercase()
        } ?: return null
        val mirror = settings.value.mirrorUrl.ifBlank { Config.DEFAULT_HOME_URL }
        return if (matched.url.startsWith("http", ignoreCase = true)) {
            matched.url
        } else {
            mirror.trimEnd('/') + "/" + matched.url.trimStart('/')
        }
    }

    fun refreshEnabledCategoryHomeSections(forceRefresh: Boolean = false) {
        val enabledCatEntries = unifiedHomeCatalogs.value.filter {
            it.enabled && it.isAvailable && (it.movieLinkCategoryUrl != null || it.key.startsWith("ml:cat:"))
        }
        for (entry in enabledCatEntries) {
            val catUrl = entry.movieLinkCategoryUrl ?: findKnownCategoryUrl(entry.key) ?: continue
            val existing = _categoryHomeRows.value[entry.key]
            if (!forceRefresh && existing != null && existing.items.isNotEmpty() && existing.error == null) {
                continue
            }
            if (!inFlightCategoryCatalogKeys.add(entry.key)) continue

            _categoryHomeRows.update { map ->
                map + (entry.key to AddonHomeRowData(
                    items = existing?.items.orEmpty(),
                    isLoading = true,
                    error = null
                ))
            }

            viewModelScope.launch {
                try {
                    val page = repository.fetchCatalogPage(catUrl)
                    val rawItems = if (page.sections.isNotEmpty()) {
                        page.sections.flatMap { it.items }
                    } else {
                        emptyList()
                    }
                    val items = rawItems.distinctBy { it.url }.map { UnifiedPosterItem.fromMovieLink(it) }
                    _categoryHomeRows.update { map ->
                        map + (entry.key to AddonHomeRowData(
                            items = items,
                            isLoading = false,
                            error = null,
                            hasMore = page.nextPageUrl != null
                        ))
                    }
                    ensureHeroArtworkEnriched(items)
                } catch (e: Exception) {
                    _categoryHomeRows.update { map ->
                        map + (entry.key to AddonHomeRowData(
                            items = existing?.items.orEmpty(),
                            isLoading = false,
                            error = e.message ?: "Failed to load category"
                        ))
                    }
                } finally {
                    inFlightCategoryCatalogKeys.remove(entry.key)
                }
            }
        }
    }

    fun refreshHeroCategorySources(keys: Set<String>, forceRefresh: Boolean = false) {
        for (key in keys) {
            val catUrl = findKnownCategoryUrl(key) ?: continue
            val existing = _heroCategoryRows.value[key] ?: _categoryHomeRows.value[key]
            if (!forceRefresh && existing != null && existing.items.isNotEmpty() && existing.error == null) {
                if (_heroCategoryRows.value[key] == null) {
                    _heroCategoryRows.update { map -> map + (key to existing) }
                }
                continue
            }
            if (!inFlightHeroCategoryKeys.add(key)) continue

            _heroCategoryRows.update { map ->
                map + (key to AddonHomeRowData(
                    items = existing?.items.orEmpty(),
                    isLoading = true,
                    error = null
                ))
            }

            viewModelScope.launch {
                try {
                    val page = repository.fetchCatalogPage(catUrl)
                    val rawItems = page.sections.flatMap { it.items }.ifEmpty { emptyList() }
                    val items = rawItems.distinctBy { it.url }.map { UnifiedPosterItem.fromMovieLink(it) }
                    _heroCategoryRows.update { map ->
                        map + (key to AddonHomeRowData(
                            items = items,
                            isLoading = false,
                            error = null
                        ))
                    }
                    ensureHeroArtworkEnriched(items)
                } catch (e: Exception) {
                    _heroCategoryRows.update { map ->
                        map + (key to AddonHomeRowData(
                            items = existing?.items.orEmpty(),
                            isLoading = false,
                            error = e.message ?: "Failed to load hero category"
                        ))
                    }
                } finally {
                    inFlightHeroCategoryKeys.remove(key)
                }
            }
        }
    }

    private fun bumpHeroShuffleSeed() {
        val currentItems = heroState.value.items
        val currentFeaturedIdx = if (settings.value.heroLayoutStyle == Config.HeroLayoutStyle.CAROUSEL && currentItems.size >= 3) {
            1
        } else {
            0
        }
        excludeHeroKeyForSeed = currentItems.getOrNull(currentFeaturedIdx)?.stableKey ?: lastSavedHeroKey
        _heroShuffleSeed.value = System.nanoTime()
    }

    private fun interleaveAndDeduplicate(
        pools: List<List<UnifiedPosterItem>>,
        maxItems: Int
    ): List<UnifiedPosterItem> {
        if (pools.isEmpty()) return emptyList()
        if (pools.size == 1) return pools.first().distinctBy { it.stableKey }.take(maxItems)
        val result = ArrayList<UnifiedPosterItem>(maxItems)
        val seen = HashSet<String>()
        val maxLen = pools.maxOf { it.size }
        for (i in 0 until maxLen) {
            for (pool in pools) {
                val item = pool.getOrNull(i) ?: continue
                if (seen.add(item.stableKey)) {
                    result.add(item)
                    if (result.size >= maxItems) return result
                }
            }
        }
        return result
    }

    fun refreshHeroAddonSources(forceRefresh: Boolean = false) {
        val s = settings.value
        if (!s.nuvioIntegrationEnabled || !s.nuvioHeroEnabled) return
        val addonKeys = s.effectiveHeroSourceKeys().filter { it.startsWith("addon:") }
        if (addonKeys.isEmpty()) return

        addonKeys.forEach { key ->
            val existing = _heroAddonRows.value[key]
            if (!forceRefresh && existing != null && existing.items.isNotEmpty() && existing.error == null) {
                return@forEach
            }
            if (!inFlightHeroKeys.add(key)) return@forEach

            val parts = key.removePrefix("addon:").split("|")
            val manifestUrl = parts.getOrNull(0).orEmpty()
            val catType = parts.getOrNull(1).orEmpty()
            val catId = parts.getOrNull(2).orEmpty()
            val addon = addons.value.firstOrNull { it.enabled && it.manifestUrl == manifestUrl }
            val spec = addon?.manifest?.catalogs?.firstOrNull {
                it.type.equals(catType, ignoreCase = true) && it.id.equals(catId, ignoreCase = true)
            }
            if (addon == null || spec == null) {
                inFlightHeroKeys.remove(key)
                return@forEach
            }

            _heroAddonRows.update { map ->
                map + (key to AddonHomeRowData(items = existing?.items.orEmpty(), isLoading = true, error = null))
            }
            viewModelScope.launch {
                try {
                    val res = addonCatalogRepository.fetchCatalog(
                        addon = addon,
                        catalog = spec,
                        skip = 0,
                        forceRefresh = forceRefresh
                    )
                    res.fold(
                        onSuccess = { page ->
                            _heroAddonRows.update { map ->
                                map + (key to AddonHomeRowData(items = page.items, isLoading = false, error = null))
                            }
                        },
                        onFailure = { err ->
                            _heroAddonRows.update { map ->
                                map + (key to AddonHomeRowData(
                                    items = existing?.items.orEmpty(),
                                    isLoading = false,
                                    error = err.message ?: "Failed to load hero catalogue"
                                ))
                            }
                        }
                    )
                } finally {
                    inFlightHeroKeys.remove(key)
                }
            }
        }
    }

    fun refreshHeroAddonSource(forceRefresh: Boolean = false) {
        refreshHeroAddonSources(forceRefresh)
    }

    fun ensureHeroArtworkEnriched(items: List<UnifiedPosterItem>) {
        if (items.isEmpty()) return
        val s = settings.value
        val tmdbSig = "${s.tmdbMetadataEnabled}|${s.tmdbApiKey.take(6)}"
        items.forEach { item ->
            val hasRealBackdrop = item.backdropUrl.isNotBlank() && item.backdropUrl != item.posterUrl
            if (hasRealBackdrop && item.logoUrl.isNotBlank() && item.posterUrl.isNotBlank()) return@forEach

            val key = item.stableKey
            val cached = _heroEnrichedItems.value[key]
            val cachedOk = cached != null &&
                cached.backdropUrl.isNotBlank() &&
                cached.logoUrl.isNotBlank() &&
                cached.posterUrl.isNotBlank()
            if (cachedOk) return@forEach

            val flightKey = "$key|$tmdbSig"
            if (!inFlightHeroEnrichKeys.add(flightKey)) return@forEach

            viewModelScope.launch {
                try {
                    val enriched = heroEnrichPermits.withPermit {
                        metadataEnrichmentService.enrichHeroItem(item, settings.value)
                    }
                    if (enriched.backdropUrl.isNotBlank() || enriched.logoUrl.isNotBlank() || enriched.posterUrl.isNotBlank()) {
                        _heroEnrichedItems.update { current ->
                            current + (key to enriched)
                        }
                    }
                } finally {
                    inFlightHeroEnrichKeys.remove(flightKey)
                }
            }
        }
    }

    fun openAddonCatalogGrid(section: CombinedHomeSectionState) {
        val manifestUrl = section.addonManifestUrl ?: return
        val type = section.catalogType ?: return
        val catalogId = section.catalogId ?: return
        val nav = NavScreen.AddonCatalogGrid(
            entryKey = section.key,
            addonManifestUrl = manifestUrl,
            catalogType = type,
            catalogId = catalogId,
            title = section.title
        )
        val currentStack = _backStack.value.ifEmpty { listOf(NavScreen.Catalog(settings.value.mirrorUrl)) }
        _backStack.value = currentStack + nav
        loadAddonGridInitial(nav, forceRefresh = false)
    }

    private fun loadAddonGridInitial(nav: NavScreen.AddonCatalogGrid, forceRefresh: Boolean) {
        val addon = addons.value.firstOrNull { it.manifestUrl == nav.addonManifestUrl }
        val spec = addon?.manifest?.catalogs?.firstOrNull {
            it.type.equals(nav.catalogType, ignoreCase = true) && it.id.equals(nav.catalogId, ignoreCase = true)
        }
        val initialCached = _addonHomeRows.value[nav.entryKey]
        _addonGridState.value = AddonGridState(
            title = nav.title,
            addonName = addon?.manifest?.name.orEmpty(),
            addonManifestUrl = nav.addonManifestUrl,
            catalogType = nav.catalogType,
            catalogId = nav.catalogId,
            items = if (forceRefresh) emptyList() else initialCached?.items.orEmpty(),
            isLoading = true,
            hasMore = initialCached?.hasMore ?: false,
            nextSkip = initialCached?.items?.size ?: 0,
            error = null
        )
        if (addon == null || spec == null) {
            _addonGridState.update { it?.copy(isLoading = false, error = "Addon or catalog unavailable") }
            return
        }
        viewModelScope.launch {
            val res = addonCatalogRepository.fetchCatalog(addon, spec, skip = 0, forceRefresh = forceRefresh)
            res.fold(
                onSuccess = { page ->
                    _addonGridState.value = AddonGridState(
                        title = nav.title,
                        addonName = addon.manifest.name,
                        addonManifestUrl = nav.addonManifestUrl,
                        catalogType = nav.catalogType,
                        catalogId = nav.catalogId,
                        items = page.items,
                        isLoading = false,
                        hasMore = page.hasMore,
                        nextSkip = page.nextSkip,
                        error = null
                    )
                },
                onFailure = { err ->
                    _addonGridState.update { curr ->
                        curr?.copy(isLoading = false, error = err.message ?: "Failed to load catalog")
                    }
                }
            )
        }
    }

    fun loadMoreAddonCatalogGrid() {
        val curr = _addonGridState.value ?: return
        if (curr.isLoading || !curr.hasMore) return
        val addon = addons.value.firstOrNull { it.manifestUrl == curr.addonManifestUrl } ?: return
        val spec = addon.manifest.catalogs.firstOrNull {
            it.type.equals(curr.catalogType, ignoreCase = true) && it.id.equals(curr.catalogId, ignoreCase = true)
        } ?: return

        _addonGridState.value = curr.copy(isLoading = true, error = null)
        viewModelScope.launch {
            val res = addonCatalogRepository.fetchCatalog(addon, spec, skip = curr.nextSkip)
            res.fold(
                onSuccess = { page ->
                    val merged = (curr.items + page.items).distinctBy { it.stableKey }
                    _addonGridState.update {
                        it?.copy(
                            items = merged,
                            isLoading = false,
                            hasMore = page.hasMore && page.items.isNotEmpty(),
                            nextSkip = page.nextSkip,
                            error = null
                        )
                    }
                },
                onFailure = { err ->
                    _addonGridState.update {
                        it?.copy(isLoading = false, error = err.message ?: "Failed to load more items")
                    }
                }
            )
        }
    }

    fun retryAddonGrid() {
        val top = _backStack.value.lastOrNull() as? NavScreen.AddonCatalogGrid ?: return
        loadAddonGridInitial(top, forceRefresh = true)
    }

    fun openUnifiedPoster(item: UnifiedPosterItem) {
        val resolvedItem = _heroEnrichedItems.value[item.stableKey] ?: item
        when (resolvedItem.provider) {
            ContentProviderKind.MOVIELINK_BD -> {
                val url = resolvedItem.movieLinkUrl.orEmpty()
                if (url.isNotBlank()) {
                    openUrlSmart(url, resolvedItem.title, resolvedItem.posterUrl)
                }
            }
            ContentProviderKind.STREMIO_ADDON -> {
                val itemId = resolvedItem.stremioId.orEmpty().trim()
                if (itemId.isBlank()) return
                val itemType = resolvedItem.stremioType?.takeIf { it.isNotBlank() }
                    ?: resolvedItem.type.takeIf { it.isNotBlank() }
                    ?: "movie"
                val nav = NavScreen.AddonDetail(
                    type = itemType,
                    id = itemId,
                    addonManifestUrl = resolvedItem.addonManifestUrl,
                    addonNameHint = resolvedItem.addonName,
                    titleHint = resolvedItem.title,
                    posterHint = resolvedItem.posterUrl,
                    backdropHint = resolvedItem.backdropUrl,
                    yearHint = resolvedItem.yearOrRelease,
                    ratingHint = resolvedItem.rating,
                    descriptionHint = resolvedItem.description,
                    genresHint = resolvedItem.genres,
                    logoHint = resolvedItem.logoUrl
                )
                val currentStack = _backStack.value.ifEmpty { listOf(NavScreen.Catalog(settings.value.mirrorUrl)) }
                _backStack.value = currentStack + nav
                loadAddonDetail(nav, forceRefresh = false)
            }
        }
    }

    private fun loadAddonDetail(nav: NavScreen.AddonDetail, forceRefresh: Boolean) {
        val reqSeq = ++activeAddonDetailSeq
        val fallback = if (nav.titleHint.isNotBlank()) {
            AddonDetailedMeta(
                id = nav.id,
                type = nav.type,
                title = nav.titleHint,
                posterUrl = nav.posterHint,
                backdropUrl = nav.backdropHint.ifBlank { nav.posterHint },
                logoUrl = nav.logoHint,
                description = nav.descriptionHint,
                releaseYear = nav.yearHint,
                rating = nav.ratingHint,
                genres = nav.genresHint,
                sourceAddonName = nav.addonNameHint.orEmpty(),
                sourceManifestUrl = nav.addonManifestUrl.orEmpty(),
                fromFallbackPreview = true
            )
        } else {
            null
        }
        _addonDetailState.value = AddonDetailUiState(
            meta = fallback,
            isLoading = true,
            error = null
        )
        viewModelScope.launch {
            val res = addonMetadataRepository.fetchMeta(
                addons = addons.value,
                type = nav.type,
                id = nav.id,
                preferredManifestUrl = nav.addonManifestUrl,
                fallbackPreview = fallback,
                forceRefresh = forceRefresh
            )
            if (reqSeq != activeAddonDetailSeq) return@launch
            res.fold(
                onSuccess = { fetched ->
                    _addonDetailState.value = AddonDetailUiState(
                        meta = fetched,
                        isLoading = false,
                        error = null
                    )
                    val enriched = metadataEnrichmentService.enrichAddonMeta(fetched, settings.value)
                    if (reqSeq == activeAddonDetailSeq) {
                        val curr = _addonDetailState.value.meta
                        if (curr != null && curr.id == fetched.id && curr.type == fetched.type) {
                            _addonDetailState.update { it.copy(meta = enriched) }
                        }
                    }
                },
                onFailure = { err ->
                    val fallbackEnriched = if (fallback != null) {
                        metadataEnrichmentService.enrichAddonMeta(fallback, settings.value)
                    } else {
                        null
                    }
                    if (reqSeq == activeAddonDetailSeq) {
                        _addonDetailState.value = AddonDetailUiState(
                            meta = fallbackEnriched,
                            isLoading = false,
                            error = if (fallbackEnriched == null) err.message ?: "Unable to fetch addon metadata" else null
                        )
                    }
                }
            )
        }
    }

    fun retryAddonDetail() {
        val top = _backStack.value.lastOrNull() as? NavScreen.AddonDetail ?: return
        loadAddonDetail(top, forceRefresh = true)
    }

    fun openAddonSourcesScreen(contentType: String, streamId: String, title: String, subtitle: String, posterUrl: String) {
        val nav = NavScreen.AddonSources(
            contentType = contentType,
            streamId = streamId,
            title = title,
            subtitle = subtitle,
            posterUrl = posterUrl
        )
        val currentStack = _backStack.value.ifEmpty { listOf(NavScreen.Catalog(settings.value.mirrorUrl)) }
        _backStack.value = currentStack + nav
        loadAddonSources(nav, forceRefresh = false)
    }

    private fun loadAddonSources(nav: NavScreen.AddonSources, forceRefresh: Boolean) {
        val enabledAddons = addons.value.filter { it.enabled && it.manifest.supportsResource("stream", nav.contentType, nav.streamId) }
        val initialGroups = enabledAddons.map { addon ->
            AddonStreamGroupResult(
                addonManifestUrl = addon.manifestUrl,
                addonName = addon.manifest.name,
                isLoading = true
            )
        }
        _addonSourcesState.value = AddonSourcesUiState(
            contentType = nav.contentType,
            streamId = nav.streamId,
            title = nav.title,
            subtitle = nav.subtitle,
            posterUrl = nav.posterUrl,
            groupResults = initialGroups,
            isLoadingAny = true
        )

        for (addon in enabledAddons) {
            viewModelScope.launch {
                val res = addonStreamRepository.fetchStreamsForAddon(
                    addon = addon,
                    type = nav.contentType,
                    streamId = nav.streamId,
                    forceRefresh = forceRefresh
                )
                _addonSourcesState.update { state ->
                    val updatedGroups = state.groupResults.map { grp ->
                        if (grp.addonManifestUrl != addon.manifestUrl) {
                            grp
                        } else {
                            res.fold(
                                onSuccess = { (streams, subs) ->
                                    grp.copy(
                                        streams = streams,
                                        subtitles = subs,
                                        isLoading = false,
                                        error = null
                                    )
                                },
                                onFailure = { err ->
                                    grp.copy(
                                        isLoading = false,
                                        error = err.message ?: "Failed to fetch streams"
                                    )
                                }
                            )
                        }
                    }
                    state.copy(
                        groupResults = updatedGroups,
                        isLoadingAny = updatedGroups.any { it.isLoading }
                    )
                }
            }
        }
    }

    fun retryAddonStreamGroup(addonManifestUrl: String) {
        val top = _backStack.value.lastOrNull() as? NavScreen.AddonSources ?: return
        val addon = addons.value.firstOrNull { it.manifestUrl == addonManifestUrl } ?: return

        _addonSourcesState.update { state ->
            val updated = state.groupResults.map { g ->
                if (g.addonManifestUrl == addonManifestUrl) g.copy(isLoading = true, error = null) else g
            }
            state.copy(groupResults = updated, isLoadingAny = true)
        }

        viewModelScope.launch {
            val res = addonStreamRepository.fetchStreamsForAddon(
                addon = addon,
                type = top.contentType,
                streamId = top.streamId,
                forceRefresh = true
            )
            _addonSourcesState.update { state ->
                val updatedGroups = state.groupResults.map { grp ->
                    if (grp.addonManifestUrl != addonManifestUrl) grp.copy() else {
                        res.fold(
                            onSuccess = { (streams, subs) ->
                                grp.copy(streams = streams, subtitles = subs, isLoading = false, error = null)
                            },
                            onFailure = { err ->
                                grp.copy(isLoading = false, error = err.message ?: "Stream request failed")
                            }
                        )
                    }
                }
                state.copy(groupResults = updatedGroups, isLoadingAny = updatedGroups.any { it.isLoading })
            }
        }
    }

    fun refreshAddonSources() {
        val top = _backStack.value.lastOrNull() as? NavScreen.AddonSources ?: return
        loadAddonSources(top, forceRefresh = true)
    }

    suspend fun testMetadataIntegration(
        kind: String,
        tmdbKey: String,
        mdbKey: String,
        bpProvider: Config.BetterPosterProvider,
        rpdbKey: String,
        customTemplate: String
    ): Result<String> {
        return when (kind) {
            "tmdb" -> metadataEnrichmentService.testTmdbConnection(tmdbKey)
            "mdblist" -> metadataEnrichmentService.testMdbListConnection(mdbKey)
            "better_poster" -> metadataEnrichmentService.testBetterPoster(bpProvider, rpdbKey, customTemplate)
            else -> Result.failure(IllegalArgumentException("Unknown integration"))
        }
    }

    private fun List<UnifiedPosterItem>.withBetterPosters(s: UserSettings): List<UnifiedPosterItem> {
        if (s.betterPosterProvider == Config.BetterPosterProvider.NONE || !s.betterPosterOnCards) {
            return this
        }
        return map { item ->
            if (item.provider != ContentProviderKind.STREMIO_ADDON) {
                item
            } else {
                val bp = Config.buildBetterPosterUrl(
                    provider = s.betterPosterProvider,
                    imdbId = item.stremioId,
                    rpdbApiKey = s.rpdbApiKey,
                    customTemplate = s.betterPosterCustomTemplate,
                    mediaType = item.stremioType ?: item.type
                )
                if (bp != null) {
                    val originalFallback = listOf(item.posterUrl, item.fallbackPosterUrl, item.backdropUrl)
                        .firstOrNull { it.isNotBlank() && it != bp }
                        .orEmpty()
                    item.copy(posterUrl = bp, fallbackPosterUrl = originalFallback)
                } else {
                    item
                }
            }
        }
    }
}
