package com.personal.movielink

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.personal.movielink.ui.components.FallbackWebViewDialog
import com.personal.movielink.ui.dialogs.HistoryDialog
import com.personal.movielink.ui.dialogs.MyListDialog
import com.personal.movielink.ui.dialogs.SettingsDialog
import com.personal.movielink.ui.dialogs.TrailerDialog
import com.personal.movielink.ui.player.NativeVideoPlayerScreen
import com.personal.movielink.ui.screens.AddonCatalogGridScreen
import com.personal.movielink.ui.screens.AddonDetailScreen
import com.personal.movielink.ui.screens.AddonSourcesScreen
import com.personal.movielink.ui.screens.CatalogScreen
import com.personal.movielink.ui.screens.DetailScreen
import com.personal.movielink.ui.theme.LocalMovieLinkPalette
import com.personal.movielink.ui.theme.MovieLinkTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            window.isStatusBarContrastEnforced = false
            window.isNavigationBarContrastEnforced = false
        }
        setContent {
            val settings by vm.settings.collectAsStateWithLifecycle()
            MovieLinkTheme(settings = settings) {
                MovieLinkAppRoot(vm = vm, settings = settings)
            }
        }
    }
}

@Composable
private fun MovieLinkAppRoot(
    vm: MainViewModel,
    settings: UserSettings
) {
    val context = LocalContext.current
    val palette = LocalMovieLinkPalette.current

    val backStack by vm.backStack.collectAsStateWithLifecycle()
    val catalog by vm.catalog.collectAsStateWithLifecycle()
    val catalogLoading by vm.catalogLoading.collectAsStateWithLifecycle()
    val catalogError by vm.catalogError.collectAsStateWithLifecycle()

    val detail by vm.detail.collectAsStateWithLifecycle()
    val detailLoading by vm.detailLoading.collectAsStateWithLifecycle()
    val detailError by vm.detailError.collectAsStateWithLifecycle()

    val history by vm.history.collectAsStateWithLifecycle()
    val myList by vm.myList.collectAsStateWithLifecycle()
    val continueWatching by vm.unifiedContinueWatching.collectAsStateWithLifecycle()
    val addons by vm.addons.collectAsStateWithLifecycle()
    val addonsBusy by vm.addonsBusy.collectAsStateWithLifecycle()
    val unifiedHomeCatalogs by vm.unifiedHomeCatalogs.collectAsStateWithLifecycle()
    val availableHeroSources by vm.availableHeroSources.collectAsStateWithLifecycle()
    val heroState by vm.heroState.collectAsStateWithLifecycle()
    val heroEnrichedItems by vm.heroEnrichedItems.collectAsStateWithLifecycle()
    val combinedHomeSections by vm.combinedHomeSections.collectAsStateWithLifecycle()
    val addonGridState by vm.addonGridState.collectAsStateWithLifecycle()
    val addonDetailState by vm.addonDetailState.collectAsStateWithLifecycle()
    val addonSourcesState by vm.addonSourcesState.collectAsStateWithLifecycle()
    val unifiedSearch by vm.unifiedSearch.collectAsStateWithLifecycle()
    val blockedCount by vm.sessionBlockedCount.collectAsStateWithLifecycle()

    val playerRequest by vm.playerRequest.collectAsStateWithLifecycle()
    val fallbackWeb by vm.fallbackWeb.collectAsStateWithLifecycle()
    val trailerInfo by vm.trailerId.collectAsStateWithLifecycle()
    val pendingVideo by vm.pendingVideoChoice.collectAsStateWithLifecycle()
    val pendingDownloader by vm.pendingDownloaderChoice.collectAsStateWithLifecycle()

    var showSettings by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var showMyList by remember { mutableStateOf(false) }

    val activeUa = if (settings.desktopMode) Config.DESKTOP_USER_AGENT else Config.MOBILE_USER_AGENT

    fun routeResolvedMediaUrl(
        url: String,
        title: String,
        userAgent: String,
        contentDisposition: String?,
        mimeType: String?
    ) {
        if (DownloadAndPlayerRouter.isVideoUrl(url, mimeType)) {
            when (settings.videoActionMode) {
                Config.VideoActionMode.EXTERNAL_PLAYER -> {
                    DownloadAndPlayerRouter.launchExternalPlayer(context, url, vm.currentUrl(), userAgent, mimeType)
                    return
                }
                Config.VideoActionMode.ASK -> {
                    vm.showVideoChoice(PendingVideoChoice(url, title, userAgent, contentDisposition, mimeType))
                    return
                }
                Config.VideoActionMode.DOWNLOAD -> Unit
            }
        }
        DownloadAndPlayerRouter.launchDownloader(
            context = context,
            mode = settings.downloaderMode,
            url = url,
            referer = vm.currentUrl(),
            userAgent = userAgent,
            contentDisposition = contentDisposition,
            mimeType = mimeType,
            onNeedPicker = {
                vm.showDownloaderChoice(PendingDownloaderChoice(url, userAgent, contentDisposition, mimeType))
            }
        )
    }

    val localVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            val fileName = resolveLocalFileName(context, uri)
            vm.launchPlayer(
                PlayerLaunchRequest(
                    streamUrl = uri.toString(),
                    title = fileName,
                    subtitle = "Local Storage Media",
                    refererUrl = "",
                    isEmbedPage = false,
                    mediaKey = "local:${uri}",
                    contentType = "local",
                    isLocalMedia = true,
                    sourceLabel = "Local Media"
                )
            )
        }
    }

    val topScreen = backStack.lastOrNull()
    BackHandler(enabled = playerRequest == null && backStack.size > 1) {
        vm.navigateBack()
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = palette.pageBg
    ) {
        if (playerRequest != null) {
            val activeReq = playerRequest!!
            val effectiveKey = activeReq.mediaKey.ifBlank { activeReq.streamUrl }
            val savedPositionMs = remember(effectiveKey) {
                vm.settingsStore.getPlaybackPositionMs(effectiveKey)
            }
            val playerClient = if (activeReq.requestHeaders.isNotEmpty() || activeReq.sourceLabel.startsWith("Addon")) {
                vm.streamHttpClient
            } else {
                vm.httpClient
            }
            NativeVideoPlayerScreen(
                request = activeReq,
                settings = settings,
                httpClient = playerClient,
                savedPositionMs = savedPositionMs,
                onSaveProgress = { posMs, durMs ->
                    val srcType = when {
                        activeReq.isLocalMedia ||
                            activeReq.streamUrl.startsWith("content://") ||
                            activeReq.streamUrl.startsWith("file://") -> "local"
                        activeReq.sourceLabel.startsWith("Addon") ||
                            effectiveKey.startsWith("addon:") -> "addon"
                        else -> "movielink"
                    }
                    val detectedQuality = listOf("2160p", "4K", "1080p", "720p", "480p", "HDR", "WEB-DL", "BluRay")
                        .firstOrNull { activeReq.subtitle.contains(it, ignoreCase = true) }
                        ?: activeReq.subtitle.split("·").firstOrNull()?.trim()?.takeIf { it.length <= 12 }.orEmpty()
                    vm.settingsStore.savePlaybackProgress(
                        PlaybackProgressItem(
                            mediaKey = effectiveKey,
                            title = activeReq.title,
                            subtitle = activeReq.subtitle,
                            posterUrl = activeReq.posterUrl,
                            streamUrl = activeReq.streamUrl,
                            refererUrl = activeReq.refererUrl,
                            sourceType = srcType,
                            contentType = activeReq.contentType,
                            quality = detectedQuality,
                            requestHeaders = activeReq.requestHeaders,
                            mimeTypeHint = activeReq.mimeTypeHint,
                            sourceLabel = activeReq.sourceLabel,
                            positionMs = posMs,
                            durationMs = durMs,
                            isEmbedPage = activeReq.isEmbedPage
                        )
                    )
                },
                onClose = { vm.closePlayer() }
            )
        } else {
            when (topScreen) {
                is NavScreen.Detail -> {
                    val savedInList = myList.any { it.url == topScreen.url }
                    DetailScreen(
                        detail = detail,
                        currentUrl = topScreen.url,
                        isLoading = detailLoading,
                        errorMessage = detailError,
                        settings = settings,
                        imageLoader = vm.imageLoader,
                        isInMyList = savedInList,
                        myListCount = myList.size,
                        onBack = { vm.navigateBack() },
                        onRefresh = { vm.refreshCurrent() },
                        onWatchTrailer = { ytId ->
                            vm.openTrailer(ytId, detail?.title ?: "Trailer")
                        },
                        onToggleMyList = { d ->
                            vm.settingsStore.toggleMyList(
                                MyListItem(
                                    url = d.url,
                                    title = d.title,
                                    posterUrl = d.posterUrl,
                                    type = d.type,
                                    quality = d.quality,
                                    language = d.language,
                                    addedAt = System.currentTimeMillis()
                                )
                            )
                        },
                        onOpenMyListDialog = { showMyList = true },
                        onWatchOnline = { embedUrl, d ->
                            vm.launchPlayer(
                                PlayerLaunchRequest(
                                    streamUrl = embedUrl,
                                    title = d.title,
                                    subtitle = "${d.language} · ${d.quality}",
                                    refererUrl = d.url,
                                    isEmbedPage = true,
                                    mediaKey = "ml:${d.url}",
                                    posterUrl = d.posterUrl,
                                    contentType = d.type,
                                    sourceLabel = "MovieLinkBD"
                                )
                            )
                        },
                        onDownloadOption = { opt, d ->
                            val target = opt.decodedUrl
                            if (DownloadAndPlayerRouter.isVideoUrl(target)) {
                                routeResolvedMediaUrl(target, "${d.title} — ${opt.label}", activeUa, null, null)
                            } else {
                                // Open /file/... gateway inside fallback WebView resolver to capture direct file/stream link
                                vm.openFallbackWeb(target, "${d.title} — ${opt.label}")
                            }
                        },
                        onOpenRelated = { card ->
                            vm.openUrlSmart(card.url, card.title, card.posterUrl)
                        },
                        onOpenFallbackWeb = { url ->
                            vm.openFallbackWeb(url, detail?.title ?: "MovieLink")
                        },
                        onOpenSettings = { showSettings = true }
                    )
                }

                is NavScreen.AddonCatalogGrid -> {
                    val grid = addonGridState
                    AddonCatalogGridScreen(
                        title = grid?.title ?: topScreen.title,
                        addonName = grid?.addonName.orEmpty(),
                        items = grid?.items.orEmpty(),
                        isLoading = grid?.isLoading == true,
                        hasMore = grid?.hasMore == true,
                        errorMessage = grid?.error,
                        imageLoader = vm.imageLoader,
                        settings = settings,
                        isPosterInMyList = { poster ->
                            val k = vm.myListKeyForPoster(poster)
                            k.isNotBlank() && myList.any { it.url == k }
                        },
                        onTogglePosterMyList = { poster -> vm.togglePosterMyList(poster) },
                        onQuickAddonStreams = { poster ->
                            val sid = poster.stremioId.orEmpty()
                            if (sid.isNotBlank()) {
                                val stype = poster.stremioType?.takeIf { it.isNotBlank() } ?: poster.type.ifBlank { "movie" }
                                val sub = listOfNotNull(
                                    poster.yearOrRelease.takeIf { it.isNotBlank() },
                                    poster.rating.takeIf { it.isNotBlank() }?.let { "★ $it" }
                                ).joinToString(" · ")
                                vm.openAddonSourcesScreen(stype, sid, poster.title, sub, poster.posterUrl)
                            }
                        },
                        onBack = { vm.navigateBack() },
                        onRetry = { vm.retryAddonGrid() },
                        onLoadMore = { vm.loadMoreAddonCatalogGrid() },
                        onOpenPoster = { poster -> vm.openUnifiedPoster(poster) }
                    )
                }

                is NavScreen.AddonDetail -> {
                    val addonInMyList = vm.isAddonInMyList(
                        type = addonDetailState.meta?.type ?: topScreen.type,
                        id = addonDetailState.meta?.id ?: topScreen.id,
                        list = myList
                    )
                    AddonDetailScreen(
                        meta = addonDetailState.meta,
                        titleHint = topScreen.titleHint,
                        isLoading = addonDetailState.isLoading,
                        errorMessage = addonDetailState.error,
                        settings = settings,
                        imageLoader = vm.imageLoader,
                        isInMyList = addonInMyList,
                        onBack = { vm.navigateBack() },
                        onRetry = { vm.retryAddonDetail() },
                        onToggleMyList = { m -> vm.toggleAddonMetaMyList(m) },
                        onOpenSettings = { showSettings = true },
                        onOpenPoster = { p -> vm.openUnifiedPoster(p) },
                        onWatchFromAddons = { type, streamId, title, subtitle, posterUrl ->
                            vm.openAddonSourcesScreen(type, streamId, title, subtitle, posterUrl)
                        }
                    )
                }

                is NavScreen.AddonSources -> {
                    val srcState = addonSourcesState
                    AddonSourcesScreen(
                        contentType = srcState.contentType,
                        streamId = srcState.streamId,
                        title = srcState.title,
                        subtitle = srcState.subtitle,
                        posterUrl = srcState.posterUrl,
                        groupResults = srcState.groupResults,
                        isLoadingAny = srcState.isLoadingAny,
                        imageLoader = vm.imageLoader,
                        onBack = { vm.navigateBack() },
                        onRefresh = { vm.refreshAddonSources() },
                        onOpenSettings = { showSettings = true },
                        onSelectStream = { stream ->
                            val streamUrl = stream.url.orEmpty()
                            if (streamUrl.isNotBlank()) {
                                val addonGroupSubs = srcState.groupResults
                                    .firstOrNull { it.addonManifestUrl == stream.addonManifestUrl }
                                    ?.subtitles
                                    .orEmpty()
                                val allAddonSubs = srcState.groupResults.flatMap { it.subtitles }
                                val mergedSubs = (stream.inlineSubtitles + addonGroupSubs + allAddonSubs)
                                    .distinctBy { it.url }
                                    .map { sub ->
                                        PlayerSubtitleTrack(
                                            id = sub.id,
                                            lang = sub.lang,
                                            url = sub.url,
                                            label = "${sub.lang} (${sub.addonName})"
                                        )
                                    }
                                val rawHeaders = stream.proxyHeaders?.requestHeaders.orEmpty()
                                val explicitReferer = rawHeaders.entries
                                    .firstOrNull { it.key.equals("Referer", ignoreCase = true) }
                                    ?.value
                                    .orEmpty()

                                val mediaKey = if (srcState.contentType.isNotBlank() && srcState.streamId.isNotBlank()) {
                                    "addon:${srcState.contentType}:${srcState.streamId}"
                                } else {
                                    streamUrl
                                }
                                vm.launchPlayer(
                                    PlayerLaunchRequest(
                                        streamUrl = streamUrl,
                                        title = "${srcState.title} (${stream.addonName})",
                                        subtitle = listOf(stream.quality, stream.language, stream.title)
                                            .filter { it.isNotBlank() }
                                            .joinToString(" · "),
                                        refererUrl = explicitReferer,
                                        isEmbedPage = false,
                                        requestHeaders = rawHeaders,
                                        subtitles = mergedSubs,
                                        mimeTypeHint = stream.mimeHint,
                                        sourceLabel = "Addon · ${stream.addonName}",
                                        mediaKey = mediaKey,
                                        posterUrl = srcState.posterUrl,
                                        contentType = srcState.contentType
                                    )
                                )
                            }
                        },
                        onOpenExternalUrl = { extUrl ->
                            DownloadAndPlayerRouter.openInChrome(context, extUrl)
                        },
                        onRetryGroup = { key -> vm.retryAddonStreamGroup(key) }
                    )
                }

                is NavScreen.Catalog, null -> {
                    val useCombined = catalog?.let { !it.isSearchOrGrid && vm.isHomePageUrl(it.url) } == true
                    CatalogScreen(
                        catalog = catalog,
                        combinedHomeSections = combinedHomeSections,
                        heroState = heroState,
                        heroEnrichedItems = heroEnrichedItems,
                        unifiedSearch = unifiedSearch,
                        useCombinedHomeFeed = useCombined,
                        isLoading = catalogLoading,
                        errorMessage = catalogError,
                        settings = settings,
                        imageLoader = vm.imageLoader,
                        myList = myList,
                        history = history,
                        continueWatching = continueWatching,
                        onRefresh = { vm.refreshCurrent() },
                        onSearch = { q -> vm.searchCatalog(q) },
                        onClearSearch = { vm.clearUnifiedSearch() },
                        onRetryMovieLinkSearch = { vm.retryMovieLinkSearch() },
                        onLoadMoreMovieLinkSearch = { vm.loadMoreMovieLinkSearch() },
                        onRetryAddonSearchGroup = { key -> vm.retryAddonSearchGroup(key) },
                        onLoadMoreAddonSearchGroup = { key -> vm.loadMoreAddonSearchGroup(key) },
                        onOpenUrl = { u -> vm.openUrlSmart(u) },
                        onOpenMedia = { card -> vm.openUrlSmart(card.url, card.title, card.posterUrl) },
                        onOpenPoster = { poster -> vm.openUnifiedPoster(poster) },
                        onTogglePosterMyList = { poster -> vm.togglePosterMyList(poster) },
                        isPosterInMyList = { poster ->
                            val k = vm.myListKeyForPoster(poster)
                            k.isNotBlank() && myList.any { it.url == k }
                        },
                        onResumeContinueWatching = { item -> vm.resumeContinueWatching(item) },
                        onRemoveContinueWatching = { key -> vm.settingsStore.removePlaybackProgress(key) },
                        onToggleContinueWatchingLayout = {
                            vm.settingsStore.updateSettings { s ->
                                val nextLayout = if (s.continueWatchingLayout == Config.ContinueWatchingLayout.VERTICAL) {
                                    Config.ContinueWatchingLayout.HORIZONTAL
                                } else {
                                    Config.ContinueWatchingLayout.VERTICAL
                                }
                                s.copy(continueWatchingLayout = nextLayout)
                            }
                        },
                        onOpenAddonViewAll = { sec -> vm.openAddonCatalogGrid(sec) },
                        onRetryAddonSection = { key -> vm.retryAddonHomeSection(key) },
                        onOpenHistoryItem = { item -> vm.openUrlSmart(item.url, item.title, item.posterUrl) },
                        onOpenMyListItem = { item -> vm.openMyListItem(item) },
                        onRemoveMyList = { url -> vm.settingsStore.removeFromMyList(url) },
                        onClearHistory = { vm.settingsStore.clearHistory() },
                        onOpenHistoryDialog = { showHistory = true },
                        onOpenFallbackWeb = { vm.openFallbackWeb(vm.currentUrl(), "MovieLink Browser") },
                        onPlayLocalVideo = { localVideoLauncher.launch("video/*") },
                        onOpenSettings = { showSettings = true },
                        onEnsureHeroEnriched = { items -> vm.ensureHeroArtworkEnriched(items) },
                        onQuickAddonStreams = { poster ->
                            val sid = poster.stremioId.orEmpty()
                            if (sid.isNotBlank()) {
                                val stype = poster.stremioType?.takeIf { it.isNotBlank() } ?: poster.type.ifBlank { "movie" }
                                val sub = listOfNotNull(
                                    poster.yearOrRelease.takeIf { it.isNotBlank() },
                                    poster.rating.takeIf { it.isNotBlank() }?.let { "★ $it" }
                                ).joinToString(" · ")
                                vm.openAddonSourcesScreen(stype, sid, poster.title, sub, poster.posterUrl)
                            }
                        }
                    )
                }
            }
        }
    }

    if (showSettings) {
        SettingsDialog(
            settings = settings,
            addons = addons,
            addonsBusy = addonsBusy,
            unifiedHomeCatalogs = unifiedHomeCatalogs,
            heroSources = availableHeroSources,
            currentUrl = vm.currentUrl(),
            sessionBlockedCount = blockedCount,
            onUpdateSettings = { transform -> vm.settingsStore.updateSettings(transform) },
            onReloadHome = { newUrl -> vm.openCatalogUrl(newUrl) },
            onOpenCurrentUrlInPlayer = { url ->
                val target = detail?.watchEmbedUrl ?: url
                vm.launchPlayer(
                    PlayerLaunchRequest(
                        streamUrl = target,
                        title = detail?.title ?: "MovieLink Player",
                        refererUrl = url,
                        isEmbedPage = target.contains("/p/", true)
                    )
                )
            },
            onPlayLocalVideo = {
                localVideoLauncher.launch("video/*")
            },
            onSaveCustomDomains = { blocked, allowed ->
                vm.settingsStore.setCustomDomainsRaw(blocked, allowed)
            },
            onInstallAddon = { url -> vm.installAddon(url) },
            onToggleAddon = { url, enabled -> vm.setAddonEnabled(url, enabled) },
            onRefreshAddon = { url -> vm.refreshAddon(url) },
            onRefreshAllAddons = { vm.refreshAllAddons() },
            onRemoveAddon = { url -> vm.removeAddon(url) },
            onToggleHomeCatalog = { key, enabled -> vm.setUnifiedHomeCatalogEnabled(key, enabled) },
            onMoveHomeCatalog = { from, to -> vm.moveUnifiedHomeCatalog(from, to) },
            onRemoveHomeCatalogEntry = { key -> vm.removeUnifiedHomeCatalogEntry(key) },
            onTestMetadataIntegration = { kind, tmdbKey, mdbKey, bpProvider, rpdbKey, customTpl ->
                vm.testMetadataIntegration(kind, tmdbKey, mdbKey, bpProvider, rpdbKey, customTpl)
            },
            onDismiss = { showSettings = false }
        )
    }

    if (showHistory) {
        HistoryDialog(
            items = history,
            onSelect = { item -> vm.openUrlSmart(item.url, item.title, item.posterUrl) },
            onClear = { vm.settingsStore.clearHistory() },
            onDismiss = { showHistory = false }
        )
    }

    if (showMyList) {
        MyListDialog(
            items = myList,
            onSelect = { item -> vm.openMyListItem(item) },
            onRemove = { url -> vm.settingsStore.removeFromMyList(url) },
            onDismiss = { showMyList = false }
        )
    }

    trailerInfo?.let { (ytId, title) ->
        TrailerDialog(
            youtubeId = ytId,
            title = title,
            onDismiss = { vm.closeTrailer() }
        )
    }



    fallbackWeb?.let { req ->
        FallbackWebViewDialog(
            initialUrl = req.url,
            title = req.title,
            settings = settings,
            isCloudflareChallenge = req.isCloudflareChallenge,
            onCloudflareSolved = { vm.onCloudflareSolved() },
            onPlayUrl = { playUrl ->
                vm.closeFallbackWeb()
                vm.launchPlayer(
                    PlayerLaunchRequest(
                        streamUrl = playUrl,
                        title = req.title,
                        refererUrl = vm.currentUrl(),
                        isEmbedPage = !DownloadAndPlayerRouter.isVideoUrl(playUrl)
                    )
                )
            },
            onDownloadDetected = { hit ->
                vm.closeFallbackWeb()
                routeResolvedMediaUrl(hit.url, req.title, hit.userAgent, hit.contentDisposition, hit.mimeType)
            },
            onDismiss = { vm.closeFallbackWeb() }
        )
    }

    pendingVideo?.let { choice ->
        AlertDialog(
            onDismissRequest = { vm.dismissVideoChoice() },
            containerColor = palette.cardBg,
            titleContentColor = palette.textPrimary,
            title = { Text("Video Stream Detected", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            vm.dismissVideoChoice()
                            vm.launchPlayer(
                                PlayerLaunchRequest(
                                    streamUrl = choice.url,
                                    title = choice.title,
                                    refererUrl = vm.currentUrl(),
                                    isEmbedPage = false
                                )
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = palette.fg, contentColor = palette.onAccent),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Play in Built-in ExoPlayer", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = {
                            vm.dismissVideoChoice()
                            DownloadAndPlayerRouter.launchExternalPlayer(
                                context, choice.url, vm.currentUrl(), choice.userAgent, choice.mimeType
                            )
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Play in VLC / MX Player", color = palette.textPrimary)
                    }
                    OutlinedButton(
                        onClick = {
                            vm.dismissVideoChoice()
                            DownloadAndPlayerRouter.launchDownloader(
                                context,
                                settings.downloaderMode,
                                choice.url,
                                vm.currentUrl(),
                                choice.userAgent,
                                choice.contentDisposition,
                                choice.mimeType,
                                onNeedPicker = {
                                    vm.showDownloaderChoice(
                                        PendingDownloaderChoice(choice.url, choice.userAgent, choice.contentDisposition, choice.mimeType)
                                    )
                                }
                            )
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Download File", color = palette.textPrimary)
                    }
                    OutlinedButton(
                        onClick = {
                            vm.dismissVideoChoice()
                            DownloadAndPlayerRouter.openInChrome(context, choice.url)
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Open in Chrome", color = palette.textSecondary)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.dismissVideoChoice() }) {
                    Text("Cancel", color = palette.textSecondary)
                }
            }
        )
    }

    pendingDownloader?.let { dl ->
        val installed = DownloadAndPlayerRouter.installedDownloaders(context)
        AlertDialog(
            onDismissRequest = { vm.dismissDownloaderChoice() },
            containerColor = palette.cardBg,
            titleContentColor = palette.textPrimary,
            title = { Text("Choose Downloader", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    installed.forEach { app ->
                        Button(
                            onClick = {
                                vm.dismissDownloaderChoice()
                                DownloadAndPlayerRouter.launchSpecificDownloader(
                                    context, app.packageName, dl.url, vm.currentUrl(), dl.userAgent, dl.contentDisposition, dl.mimeType
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = palette.fg, contentColor = palette.onAccent),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Download with ${app.label}", fontWeight = FontWeight.Bold)
                        }
                    }
                    OutlinedButton(
                        onClick = {
                            vm.dismissDownloaderChoice()
                            DownloadAndPlayerRouter.launchSpecificDownloader(
                                context, null, dl.url, vm.currentUrl(), dl.userAgent, dl.contentDisposition, dl.mimeType
                            )
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Android Built-in DownloadManager", color = palette.textPrimary)
                    }
                    OutlinedButton(
                        onClick = {
                            vm.dismissDownloaderChoice()
                            DownloadAndPlayerRouter.openInChrome(context, dl.url)
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Open in Chrome", color = palette.textSecondary)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.dismissDownloaderChoice() }) {
                    Text("Cancel", color = palette.textSecondary)
                }
            }
        )
    }
}

private fun resolveLocalFileName(context: Context, uri: Uri): String {
    try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) {
                    val name = cursor.getString(idx)?.trim()
                    if (!name.isNullOrBlank()) return name
                }
            }
        }
    } catch (_: Exception) {
    }
    return uri.lastPathSegment?.substringAfterLast('/')?.ifBlank { "Local Video" } ?: "Local Video"
}
