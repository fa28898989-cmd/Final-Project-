package com.personal.movielink.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Bookmarks
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material.icons.rounded.Bookmarks
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.ColorUtils
import com.personal.movielink.Config
import com.personal.movielink.UserSettings
import com.personal.movielink.ui.theme.LocalMovieLinkPalette
import kotlin.math.min

enum class AppBottomTab { HOME, SEARCH, LIBRARY }

@Composable
fun AppBottomNavigationBar(
    settings: UserSettings,
    activeTab: AppBottomTab,
    onSelectHome: () -> Unit,
    onSelectSearch: () -> Unit,
    onSelectLibrary: () -> Unit,
    onPlayLocalVideo: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalMovieLinkPalette.current
    val visibleIcons = remember(settings.navBarIconIds, settings.showLocalPlayerTab) {
        settings.effectiveNavBarIcons()
    }
    val hasSearch = Config.NavBarIcon.SEARCH in visibleIcons
    val sideIcons = remember(visibleIcons) {
        listOf(
            Config.NavBarIcon.HOME,
            Config.NavBarIcon.LIBRARY,
            Config.NavBarIcon.LOCAL,
            Config.NavBarIcon.SETTINGS
        ).filter { it in visibleIcons }
    }

    val accentLum = remember(palette.accent) { ColorUtils.calculateLuminance(palette.accent.toArgb()) }
    val themeHighlight = remember(palette.accent, palette.fg, palette.isLightBg, accentLum) {
        when {
            !palette.isLightBg && accentLum < 0.06 -> palette.fg
            palette.isLightBg && accentLum > 0.72 -> palette.fg
            else -> palette.accent
        }
    }

    val splitIdx = when {
        sideIcons.size >= 4 -> 2
        sideIcons.size == 3 -> 2
        sideIcons.size == 2 -> 1
        else -> sideIcons.size
    }
    val leftIcons = if (hasSearch) sideIcons.take(splitIdx) else sideIcons
    val rightIcons = if (hasSearch) sideIcons.drop(splitIdx) else emptyList()

    if (settings.floatingNavBar) {
        // Floating navigation bar: detached curved-arch pill capsule matching Image 1 / Image 3
        val barColor = remember(settings.floatingNavColorHex, palette.pageBg) {
            parseNavBarColor(settings.floatingNavColorHex, palette.pageBg)
        }
        val barAlpha = settings.floatingNavAlphaPercent.coerceIn(20, 100) / 100f
        val barHeight = settings.floatingNavHeightDp.coerceIn(44, 80).dp
        val widthFraction = settings.floatingNavWidthPercent.coerceIn(62, 96) / 100f
        val bottomSpacing = settings.floatingNavSpacingDp.coerceIn(4, 36).dp
        val iconSpacing = settings.floatingNavIconSpacingDp.coerceIn(0, 28).dp
        val bumpExtra = if (hasSearch) 11.dp else 0.dp

        val barIsLight = if (barAlpha >= 0.45f) {
            ColorUtils.calculateLuminance(barColor.toArgb()) > 0.45
        } else {
            palette.isLightBg
        }
        val activeIconTint = if (barIsLight) Color(0xFF09090B) else Color.White
        val inactiveIconTint = if (barIsLight) Color(0xFF52525B) else Color(0xFF8E8E93)
        val outlineBorder = if (barIsLight) Color.Black.copy(alpha = 0.12f) else Color.White.copy(alpha = 0.10f)

        Box(
            modifier = modifier
                .navigationBarsPadding()
                .padding(bottom = bottomSpacing)
                .fillMaxWidth(widthFraction)
                .height(barHeight + bumpExtra)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val topY = bumpExtra.toPx()
                val botY = size.height
                val bodyH = (botY - topY).coerceAtLeast(1f)
                val capR = bodyH / 2f
                val cx = size.width / 2f
                val path = Path()

                if (hasSearch && size.width > bodyH * 2.2f) {
                    val bumpHalfW = min(size.width * 0.145f, bodyH * 0.96f)
                    path.moveTo(capR, topY)
                    path.lineTo(cx - bumpHalfW, topY)
                    path.cubicTo(
                        cx - bumpHalfW * 0.50f, topY,
                        cx - bumpHalfW * 0.40f, 0f,
                        cx, 0f
                    )
                    path.cubicTo(
                        cx + bumpHalfW * 0.40f, 0f,
                        cx + bumpHalfW * 0.50f, topY,
                        cx + bumpHalfW, topY
                    )
                    path.lineTo(size.width - capR, topY)
                    path.arcTo(
                        rect = Rect(size.width - bodyH, topY, size.width, botY),
                        startAngleDegrees = -90f,
                        sweepAngleDegrees = 180f,
                        forceMoveTo = false
                    )
                    path.lineTo(capR, botY)
                    path.arcTo(
                        rect = Rect(0f, topY, bodyH, botY),
                        startAngleDegrees = 90f,
                        sweepAngleDegrees = 180f,
                        forceMoveTo = false
                    )
                    path.close()
                } else {
                    path.moveTo(capR, topY)
                    path.lineTo(size.width - capR, topY)
                    path.arcTo(
                        rect = Rect(size.width - bodyH, topY, size.width, botY),
                        startAngleDegrees = -90f,
                        sweepAngleDegrees = 180f,
                        forceMoveTo = false
                    )
                    path.lineTo(capR, botY)
                    path.arcTo(
                        rect = Rect(0f, topY, bodyH, botY),
                        startAngleDegrees = 90f,
                        sweepAngleDegrees = 180f,
                        forceMoveTo = false
                    )
                    path.close()
                }

                drawPath(path = path, color = barColor.copy(alpha = barAlpha))
                drawPath(
                    path = path,
                    color = outlineBorder,
                    style = Stroke(width = 1.dp.toPx())
                )
            }

            ArchNavBarContentRow(
                hasSearch = hasSearch,
                leftIcons = leftIcons,
                rightIcons = rightIcons,
                activeTab = activeTab,
                barHeight = barHeight,
                iconSpacing = iconSpacing,
                barColor = barColor,
                barAlpha = barAlpha,
                activeIconTint = activeIconTint,
                inactiveIconTint = inactiveIconTint,
                themeHighlight = themeHighlight,
                onSelectHome = onSelectHome,
                onSelectSearch = onSelectSearch,
                onSelectLibrary = onSelectLibrary,
                onPlayLocalVideo = onPlayLocalVideo,
                onOpenSettings = onOpenSettings,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(barHeight)
                    .padding(horizontal = 10.dp)
            )
        }
    } else {
        // Normal (default) navigation bar: connected seamlessly to bottom, left, and right screen edges
        val barColor = remember(settings.normalNavColorHex, palette.pageBg) {
            parseNavBarColor(settings.normalNavColorHex, palette.pageBg)
        }
        val barAlpha = settings.normalNavAlphaPercent.coerceIn(20, 100) / 100f
        val barHeight = settings.normalNavHeightDp.coerceIn(46, 80).dp
        val bottomSpacing = settings.normalNavSpacingDp.coerceIn(0, 36).dp
        val iconSpacing = settings.normalNavIconSpacingDp.coerceIn(0, 28).dp
        val bumpExtra = if (hasSearch) 11.dp else 0.dp
        val navBarBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
        val totalDockedHeight = barHeight + bumpExtra + bottomSpacing + navBarBottom

        val barIsLight = if (barAlpha >= 0.45f) {
            ColorUtils.calculateLuminance(barColor.toArgb()) > 0.45
        } else {
            palette.isLightBg
        }
        val activeIconTint = if (barIsLight) Color(0xFF09090B) else Color.White
        val inactiveIconTint = if (barIsLight) Color(0xFF52525B) else Color(0xFF8E8E93)
        val outlineBorder = if (barIsLight) Color.Black.copy(alpha = 0.12f) else Color.White.copy(alpha = 0.10f)

        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(totalDockedHeight)
        ) {
            // Full edge-to-edge bottom-docked arch contour connected at left, right, and bottom
            Canvas(modifier = Modifier.fillMaxSize()) {
                val topY = bumpExtra.toPx()
                val bodyRef = barHeight.toPx().coerceAtLeast(1f)
                val cx = size.width / 2f

                val fillPath = Path()
                val topStrokePath = Path()

                if (hasSearch && size.width > bodyRef * 2.2f) {
                    val bumpHalfW = min(size.width * 0.145f, bodyRef * 0.96f)
                    fillPath.moveTo(0f, topY)
                    fillPath.lineTo(cx - bumpHalfW, topY)
                    fillPath.cubicTo(
                        cx - bumpHalfW * 0.50f, topY,
                        cx - bumpHalfW * 0.40f, 0f,
                        cx, 0f
                    )
                    fillPath.cubicTo(
                        cx + bumpHalfW * 0.40f, 0f,
                        cx + bumpHalfW * 0.50f, topY,
                        cx + bumpHalfW, topY
                    )
                    fillPath.lineTo(size.width, topY)
                    fillPath.lineTo(size.width, size.height)
                    fillPath.lineTo(0f, size.height)
                    fillPath.close()

                    topStrokePath.moveTo(0f, topY)
                    topStrokePath.lineTo(cx - bumpHalfW, topY)
                    topStrokePath.cubicTo(
                        cx - bumpHalfW * 0.50f, topY,
                        cx - bumpHalfW * 0.40f, 0f,
                        cx, 0f
                    )
                    topStrokePath.cubicTo(
                        cx + bumpHalfW * 0.40f, 0f,
                        cx + bumpHalfW * 0.50f, topY,
                        cx + bumpHalfW, topY
                    )
                    topStrokePath.lineTo(size.width, topY)
                } else {
                    fillPath.moveTo(0f, topY)
                    fillPath.lineTo(size.width, topY)
                    fillPath.lineTo(size.width, size.height)
                    fillPath.lineTo(0f, size.height)
                    fillPath.close()

                    topStrokePath.moveTo(0f, topY)
                    topStrokePath.lineTo(size.width, topY)
                }

                drawPath(path = fillPath, color = barColor.copy(alpha = barAlpha))
                drawPath(
                    path = topStrokePath,
                    color = outlineBorder,
                    style = Stroke(width = 1.dp.toPx())
                )
            }

            ArchNavBarContentRow(
                hasSearch = hasSearch,
                leftIcons = leftIcons,
                rightIcons = rightIcons,
                activeTab = activeTab,
                barHeight = barHeight,
                iconSpacing = iconSpacing,
                barColor = barColor,
                barAlpha = barAlpha,
                activeIconTint = activeIconTint,
                inactiveIconTint = inactiveIconTint,
                themeHighlight = themeHighlight,
                onSelectHome = onSelectHome,
                onSelectSearch = onSelectSearch,
                onSelectLibrary = onSelectLibrary,
                onPlayLocalVideo = onPlayLocalVideo,
                onOpenSettings = onOpenSettings,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = bottomSpacing)
                    .fillMaxWidth()
                    .height(barHeight)
                    .padding(horizontal = 10.dp)
            )
        }
    }
}

@Composable
private fun ArchNavBarContentRow(
    hasSearch: Boolean,
    leftIcons: List<Config.NavBarIcon>,
    rightIcons: List<Config.NavBarIcon>,
    activeTab: AppBottomTab,
    barHeight: Dp,
    iconSpacing: Dp,
    barColor: Color,
    barAlpha: Float,
    activeIconTint: Color,
    inactiveIconTint: Color,
    themeHighlight: Color,
    onSelectHome: () -> Unit,
    onSelectSearch: () -> Unit,
    onSelectLibrary: () -> Unit,
    onPlayLocalVideo: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (hasSearch) {
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(iconSpacing, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically
            ) {
                leftIcons.forEach { navIcon ->
                    val isSelected = isNavIconSelected(navIcon, activeTab)
                    val (selectedVec, unselectedVec, desc) = navIconVectors(navIcon)
                    Box(
                        modifier = Modifier
                            .size(width = 44.dp, height = barHeight)
                            .clip(RoundedCornerShape(14.dp))
                            .clickable {
                                dispatchNavClick(
                                    icon = navIcon,
                                    onSelectHome = onSelectHome,
                                    onSelectSearch = onSelectSearch,
                                    onSelectLibrary = onSelectLibrary,
                                    onPlayLocalVideo = onPlayLocalVideo,
                                    onOpenSettings = onOpenSettings
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Image3StyleTabIcon(
                            selected = isSelected,
                            selectedIcon = selectedVec,
                            unselectedIcon = unselectedVec,
                            contentDescription = desc,
                            activeTint = activeIconTint,
                            inactiveTint = inactiveIconTint,
                            dotColor = themeHighlight
                        )
                    }
                }
            }

            // Center glowing accent ring with Search icon
            val ringDiameter = (barHeight * 0.76f).coerceIn(38.dp, 48.dp)
            val glowDiameter = ringDiameter + 18.dp
            val searchSelected = activeTab == AppBottomTab.SEARCH
            Box(
                modifier = Modifier
                    .width(glowDiameter)
                    .height(barHeight)
                    .offset(y = (-4).dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(glowDiameter)) {
                    val r = size.minDimension / 2f
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                themeHighlight.copy(alpha = if (searchSelected) 0.48f else 0.30f),
                                themeHighlight.copy(alpha = 0.08f),
                                Color.Transparent
                            ),
                            center = Offset(r, r),
                            radius = r
                        ),
                        radius = r
                    )
                }
                Box(
                    modifier = Modifier
                        .size(ringDiameter)
                        .clip(CircleShape)
                        .background(
                            if (searchSelected) {
                                themeHighlight.copy(alpha = 0.22f)
                            } else {
                                barColor.copy(alpha = barAlpha.coerceAtLeast(0.85f))
                            }
                        )
                        .border(2.3.dp, themeHighlight, CircleShape)
                        .clickable(onClick = onSelectSearch),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Search,
                        contentDescription = "Search",
                        tint = activeIconTint,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(iconSpacing, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically
            ) {
                rightIcons.forEach { navIcon ->
                    val isSelected = isNavIconSelected(navIcon, activeTab)
                    val (selectedVec, unselectedVec, desc) = navIconVectors(navIcon)
                    Box(
                        modifier = Modifier
                            .size(width = 44.dp, height = barHeight)
                            .clip(RoundedCornerShape(14.dp))
                            .clickable {
                                dispatchNavClick(
                                    icon = navIcon,
                                    onSelectHome = onSelectHome,
                                    onSelectSearch = onSelectSearch,
                                    onSelectLibrary = onSelectLibrary,
                                    onPlayLocalVideo = onPlayLocalVideo,
                                    onOpenSettings = onOpenSettings
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Image3StyleTabIcon(
                            selected = isSelected,
                            selectedIcon = selectedVec,
                            unselectedIcon = unselectedVec,
                            contentDescription = desc,
                            activeTint = activeIconTint,
                            inactiveTint = inactiveIconTint,
                            dotColor = themeHighlight
                        )
                    }
                }
            }
        } else {
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(iconSpacing, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically
            ) {
                leftIcons.forEach { navIcon ->
                    val isSelected = isNavIconSelected(navIcon, activeTab)
                    val (selectedVec, unselectedVec, desc) = navIconVectors(navIcon)
                    Box(
                        modifier = Modifier
                            .size(width = 46.dp, height = barHeight)
                            .clip(RoundedCornerShape(14.dp))
                            .clickable {
                                dispatchNavClick(
                                    icon = navIcon,
                                    onSelectHome = onSelectHome,
                                    onSelectSearch = onSelectSearch,
                                    onSelectLibrary = onSelectLibrary,
                                    onPlayLocalVideo = onPlayLocalVideo,
                                    onOpenSettings = onOpenSettings
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Image3StyleTabIcon(
                            selected = isSelected,
                            selectedIcon = selectedVec,
                            unselectedIcon = unselectedVec,
                            contentDescription = desc,
                            activeTint = activeIconTint,
                            inactiveTint = inactiveIconTint,
                            dotColor = themeHighlight
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Image3StyleTabIcon(
    selected: Boolean,
    selectedIcon: ImageVector,
    unselectedIcon: ImageVector,
    contentDescription: String,
    activeTint: Color,
    inactiveTint: Color,
    dotColor: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = if (selected) selectedIcon else unselectedIcon,
            contentDescription = contentDescription,
            tint = if (selected) activeTint else inactiveTint,
            modifier = Modifier.size(23.dp)
        )
        if (selected) {
            Spacer(Modifier.height(3.dp))
            Box(
                modifier = Modifier
                    .size(4.5.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
        }
    }
}

private fun parseNavBarColor(hex: String?, defaultColor: Color): Color {
    if (hex.isNullOrBlank()) return defaultColor
    return try {
        Color(android.graphics.Color.parseColor(hex))
    } catch (_: Throwable) {
        defaultColor
    }
}

private fun isNavIconSelected(icon: Config.NavBarIcon, activeTab: AppBottomTab): Boolean = when (icon) {
    Config.NavBarIcon.HOME -> activeTab == AppBottomTab.HOME
    Config.NavBarIcon.SEARCH -> activeTab == AppBottomTab.SEARCH
    Config.NavBarIcon.LIBRARY -> activeTab == AppBottomTab.LIBRARY
    Config.NavBarIcon.LOCAL -> false
    Config.NavBarIcon.SETTINGS -> false
}

private fun navIconVectors(icon: Config.NavBarIcon): Triple<ImageVector, ImageVector, String> = when (icon) {
    Config.NavBarIcon.HOME -> Triple(Icons.Rounded.Home, Icons.Outlined.Home, "Home")
    Config.NavBarIcon.LIBRARY -> Triple(Icons.Rounded.Bookmarks, Icons.Outlined.Bookmarks, "List & Library")
    Config.NavBarIcon.SEARCH -> Triple(Icons.Rounded.Search, Icons.Rounded.Search, "Search")
    Config.NavBarIcon.LOCAL -> Triple(Icons.Rounded.VideoLibrary, Icons.Outlined.VideoLibrary, "Local Video")
    Config.NavBarIcon.SETTINGS -> Triple(Icons.Rounded.Settings, Icons.Outlined.Settings, "Settings")
}

private fun dispatchNavClick(
    icon: Config.NavBarIcon,
    onSelectHome: () -> Unit,
    onSelectSearch: () -> Unit,
    onSelectLibrary: () -> Unit,
    onPlayLocalVideo: () -> Unit,
    onOpenSettings: () -> Unit
) {
    when (icon) {
        Config.NavBarIcon.HOME -> onSelectHome()
        Config.NavBarIcon.SEARCH -> onSelectSearch()
        Config.NavBarIcon.LIBRARY -> onSelectLibrary()
        Config.NavBarIcon.LOCAL -> onPlayLocalVideo()
        Config.NavBarIcon.SETTINGS -> onOpenSettings()
    }
}
