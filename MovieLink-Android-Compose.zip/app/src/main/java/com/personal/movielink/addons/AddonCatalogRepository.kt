package com.personal.movielink.addons

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

class AddonCatalogRepository {

    private data class CacheEntry(
        val fetchedAtMs: Long,
        val page: AddonCatalogPage
    )

    private val cache = ConcurrentHashMap<String, CacheEntry>()

    fun availableHomeCatalogs(addons: List<InstalledAddon>): List<AddonCatalogDescriptor> {
        return addons
            .filter { it.enabled }
            .flatMap { addon ->
                addon.manifest.catalogs
                    .filter { cat ->
                        !cat.requiresSearch() &&
                            addon.manifest.supportsResource("catalog", cat.type)
                    }
                    .map { cat -> AddonCatalogDescriptor(addon = addon, catalog = cat) }
            }
    }

    fun availableSearchCatalogs(addons: List<InstalledAddon>): List<AddonCatalogDescriptor> {
        return addons
            .filter { it.enabled }
            .flatMap { addon ->
                addon.manifest.catalogs
                    .filter { cat ->
                        cat.supportsSearch() &&
                            addon.manifest.supportsResource("catalog", cat.type)
                    }
                    .map { cat -> AddonCatalogDescriptor(addon = addon, catalog = cat) }
            }
    }

    fun buildCatalogUrl(
        addon: InstalledAddon,
        catalog: StremioCatalogSpec,
        skip: Int = 0,
        searchQuery: String? = null,
        genre: String? = null
    ): String {
        val extras = mutableListOf<Pair<String, String>>()
        val trimmedSearch = searchQuery?.trim().orEmpty()
        if (trimmedSearch.isNotEmpty() && catalog.supportsSearch()) {
            extras.add("search" to trimmedSearch)
        }
        val trimmedGenre = genre?.trim().orEmpty()
        if (trimmedGenre.isNotEmpty() && catalog.extra.any { it.name.equals("genre", ignoreCase = true) }) {
            extras.add("genre" to trimmedGenre)
        }
        if (skip > 0 && catalog.supportsSkip()) {
            extras.add("skip" to skip.toString())
        }

        val typeSeg = Uri.encode(catalog.type)
        val idSeg = Uri.encode(catalog.id)
        val basePath = if (extras.isEmpty()) {
            "${addon.baseUrl.trimEnd('/')}/catalog/$typeSeg/$idSeg.json"
        } else {
            val extraSegment = extras.joinToString("&") { (k, v) ->
                "${Uri.encode(k)}=${Uri.encode(v)}"
            }
            "${addon.baseUrl.trimEnd('/')}/catalog/$typeSeg/$idSeg/$extraSegment.json"
        }

        val query = addon.manifestUrl.substringAfter('?', "")
        return if (query.isNotBlank()) "$basePath?$query" else basePath
    }

    suspend fun fetchCatalog(
        addon: InstalledAddon,
        catalog: StremioCatalogSpec,
        skip: Int = 0,
        searchQuery: String? = null,
        genre: String? = null,
        forceRefresh: Boolean = false
    ): Result<AddonCatalogPage> {
        if (!addon.enabled) {
            return Result.failure(IllegalStateException("${addon.manifest.name} is disabled"))
        }
        if (!addon.manifest.supportsResource("catalog", catalog.type)) {
            return Result.failure(
                UnsupportedOperationException("${addon.manifest.name} does not support catalog for ${catalog.type}")
            )
        }
        if (catalog.requiresSearch() && searchQuery.isNullOrBlank()) {
            return Result.failure(IllegalArgumentException("Catalog '${catalog.name}' requires a search query"))
        }

        val cacheKey = listOf(
            addon.manifestUrl,
            catalog.type,
            catalog.id,
            skip.toString(),
            searchQuery?.trim().orEmpty(),
            genre?.trim().orEmpty()
        ).joinToString("|")

        if (!forceRefresh) {
            val cached = cache[cacheKey]
            if (cached != null && System.currentTimeMillis() - cached.fetchedAtMs < CACHE_TTL_MS) {
                return Result.success(cached.page)
            }
        }

        return try {
            val url = buildCatalogUrl(
                addon = addon,
                catalog = catalog,
                skip = skip,
                searchQuery = searchQuery,
                genre = genre
            )
            val json = AddonHttp.getJsonObject(url)
            val metasArr = json.optJSONArray("metas") ?: JSONArray()
            val seenIds = HashSet<String>(metasArr.length())
            val items = buildList {
                for (i in 0 until metasArr.length()) {
                    val mObj = metasArr.optJSONObject(i) ?: continue
                    val mapped = parseMetaPreview(mObj, addon, catalog.type) ?: continue
                    val idKey = mapped.stremioId.orEmpty()
                    if (idKey.isNotEmpty() && seenIds.add(idKey)) {
                        add(mapped)
                    }
                }
            }

            val explicitHasMore = if (json.has("hasMore") && !json.isNull("hasMore")) {
                json.optBoolean("hasMore", false)
            } else {
                null
            }
            val canSkipMore = explicitHasMore ?: (catalog.supportsSkip() && items.isNotEmpty())
            val nextSkip = if (canSkipMore) skip + items.size else skip

            val page = AddonCatalogPage(
                addonManifestUrl = addon.manifestUrl,
                addonName = addon.manifest.name,
                catalogSpec = catalog,
                items = items,
                skip = skip,
                hasMore = canSkipMore && items.isNotEmpty(),
                nextSkip = nextSkip,
                genreFilter = genre?.trim()?.takeIf { it.isNotEmpty() },
                searchQuery = searchQuery?.trim()?.takeIf { it.isNotEmpty() }
            )

            if (cache.size > MAX_CACHE_ENTRIES) {
                cache.clear()
            }
            cache[cacheKey] = CacheEntry(System.currentTimeMillis(), page)
            Result.success(page)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun clearCache() {
        cache.clear()
    }

    private fun parseMetaPreview(
        obj: JSONObject,
        addon: InstalledAddon,
        fallbackType: String
    ): UnifiedPosterItem? {
        val id = obj.optString("id", "").trim()
        val title = obj.optString("name", obj.optString("title", "")).trim()
        if (id.isBlank() || title.isBlank()) return null

        val itemType = obj.optString("type", fallbackType).trim().ifBlank { fallbackType }
        val poster = sanitizeHttpUrl(obj.optString("poster", ""))
        val backdrop = sanitizeHttpUrl(obj.optString("background", ""))
        val logo = sanitizeHttpUrl(obj.optString("logo", ""))
        val description = obj.optString("description", "").trim()
        val releaseInfo = obj.optString("releaseInfo", "").trim().ifBlank {
            val rawYear = obj.opt("year")?.toString()?.trim().orEmpty()
            if (rawYear.equals("null", true)) "" else rawYear
        }

        val ratingRaw = obj.opt("imdbRating")
        val rating = when (ratingRaw) {
            is Number -> ratingRaw.toString()
            is String -> ratingRaw.trim().takeIf {
                it.isNotEmpty() && !it.equals("null", true) && !it.equals("N/A", true)
            }.orEmpty()
            else -> ""
        }

        val genresArr = obj.optJSONArray("genres")
        val genres = buildList {
            if (genresArr != null) {
                for (i in 0 until genresArr.length()) {
                    val g = genresArr.optString(i, "").trim()
                    if (g.isNotEmpty()) add(g)
                }
            }
        }

        return UnifiedPosterItem(
            provider = ContentProviderKind.STREMIO_ADDON,
            title = title,
            posterUrl = poster.ifBlank { backdrop },
            backdropUrl = backdrop,
            type = itemType,
            yearOrRelease = releaseInfo,
            rating = rating,
            description = description,
            genres = genres,
            addonManifestUrl = addon.manifestUrl,
            addonName = addon.manifest.name,
            stremioId = id,
            stremioType = itemType,
            logoUrl = logo
        )
    }

    private fun sanitizeHttpUrl(raw: String): String {
        val clean = raw.trim()
        if (clean.isEmpty() || clean.equals("null", true)) return ""
        return if (clean.startsWith("http://", true) || clean.startsWith("https://", true)) {
            clean
        } else {
            ""
        }
    }

    companion object {
        private const val CACHE_TTL_MS = 5 * 60 * 1000L
        private const val MAX_CACHE_ENTRIES = 80
    }
}
