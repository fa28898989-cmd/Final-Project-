package com.movielink.app.core.sources.providers

import com.movielink.app.core.adblock.AdBlockerEngine
import com.movielink.app.core.model.CatalogSection
import com.movielink.app.core.model.DownloadSourceLink
import com.movielink.app.core.model.MediaDetail
import com.movielink.app.core.model.MediaKind
import com.movielink.app.core.model.MediaSummary
import com.movielink.app.core.model.MovieInfoField
import com.movielink.app.core.model.ProviderCatalog
import com.movielink.app.core.model.ProviderId
import com.movielink.app.core.network.MovieLinkHttpClient
import com.movielink.app.core.sources.MediaSourceProvider
import com.movielink.app.core.sources.ProviderCapabilities
import com.movielink.app.core.sources.WebsiteSourcesStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLEncoder

/**
 * Website 3 — Rtally live Jsoup/OkHttp provider with Cloudflare challenge detection & ad-filter.
 */
class RtallyProvider : MediaSourceProvider {
    override val providerId: ProviderId = ProviderId.RTALLY

    override val capabilities = ProviderCapabilities(
        supportsHomeCatalog = true,
        supportsOttFilter = false,
        supportsSeries = true,
        supportsDownloads = true,
        supportsDirectStreams = true
    )

    override suspend fun fetchHomeCatalog(baseUrl: String): Result<ProviderCatalog> = withContext(Dispatchers.IO) {
        runCatching {
            val cfg = WebsiteSourcesStore.configFor(providerId)
            val fetch = MovieLinkHttpClient.fetchHtml(baseUrl, providerId, cfg.timeoutSeconds, cfg.customUserAgent)
            val doc = Jsoup.parse(fetch.html, fetch.finalUrl)
            parseCatalogDocument(doc, fetch.finalUrl)
        }
    }

    override suspend fun search(baseUrl: String, query: String): Result<List<MediaSummary>> = withContext(Dispatchers.IO) {
        runCatching {
            val cfg = WebsiteSourcesStore.configFor(providerId)
            val encoded = URLEncoder.encode(query.trim(), "UTF-8")
            val searchUrl = "${baseUrl.trimEnd('/')}/?s=$encoded"
            val fetch = MovieLinkHttpClient.fetchHtml(searchUrl, providerId, cfg.timeoutSeconds, cfg.customUserAgent)
            val doc = Jsoup.parse(fetch.html, fetch.finalUrl)
            extractCards(doc, fetch.finalUrl)
        }
    }

    override suspend fun fetchDetails(baseUrl: String, mediaId: String): Result<MediaDetail> = withContext(Dispatchers.IO) {
        runCatching {
            val cfg = WebsiteSourcesStore.configFor(providerId)
            val targetUrl = if (mediaId.startsWith("http", true)) {
                mediaId
            } else {
                ProviderParsingUtils.resolveUrl(baseUrl, mediaId)
            }
            val fetch = MovieLinkHttpClient.fetchHtml(targetUrl, providerId, cfg.timeoutSeconds, cfg.customUserAgent)
            val doc = Jsoup.parse(fetch.html, fetch.finalUrl)
            parseDetailDocument(doc, fetch.finalUrl)
        }
    }

    private fun parseCatalogDocument(doc: Document, finalUrl: String): ProviderCatalog {
        val cards = extractCards(doc, finalUrl)
        val sections = if (cards.isNotEmpty()) {
            listOf(CatalogSection(id = "rt_latest", title = "Latest on Rtally", items = cards))
        } else {
            emptyList()
        }
        val categories = doc.select("a[href*=/category/], a[href*=/genre/]")
            .mapNotNull { it.text().trim().takeIf { t -> t.isNotBlank() && t.length <= 28 } }
            .distinct()
            .take(20)

        return ProviderCatalog(
            providerId = providerId,
            heroItems = cards.take(8),
            ottPlatforms = emptyList(),
            categories = categories,
            sections = sections
        )
    }

    private fun extractCards(doc: Document, baseUrl: String): List<MediaSummary> {
        val candidates = doc.select("article, .movie-card, .post-item, .ml-item, .item")
        return candidates.mapNotNull { el -> parseCard(el, baseUrl) }.distinctBy { it.id }
    }

    private fun parseCard(el: Element, baseUrl: String): MediaSummary? {
        val anchor = if (el.tagName().equals("a", true)) el else el.selectFirst("a[href]") ?: return null
        val absUrl = ProviderParsingUtils.resolveUrl(baseUrl, anchor.attr("href"))
        if (absUrl.isBlank() || AdBlockerEngine.shouldBlockUrl(absUrl, providerId)) return null

        val img = el.selectFirst("img")
        val rawTitle = el.selectFirst("h2, h3, h4, .title, .entry-title")?.text()?.trim()
            ?.takeIf { it.isNotBlank() }
            ?: img?.attr("alt")?.trim()
            ?: anchor.attr("title").trim()
        if (rawTitle.isBlank()) return null

        val (cleanTitle, year) = ProviderParsingUtils.cleanTitleYearSplit(rawTitle)
        val posterRaw = img?.attr("data-src")?.trim()?.takeIf { it.isNotBlank() && !it.startsWith("data:") }
            ?: img?.attr("src")?.trim()?.takeIf { it.isNotBlank() && !it.startsWith("data:") }
            ?: ""
        val posterUrl = if (posterRaw.isNotBlank()) ProviderParsingUtils.resolveUrl(baseUrl, posterRaw) else ""
        val quality = el.selectFirst(".quality, .badge, .mli-quality")?.text()?.trim().orEmpty()
        val isSeries = absUrl.contains("series", true) || rawTitle.contains("Season", true)

        return MediaSummary(
            id = absUrl,
            providerId = providerId,
            title = cleanTitle,
            year = year,
            kind = if (isSeries) MediaKind.SERIES else MediaKind.MOVIE,
            posterUrl = posterUrl,
            backdropUrl = posterUrl,
            qualityBadge = quality,
            sourceUrl = absUrl
        )
    }

    private fun parseDetailDocument(doc: Document, finalUrl: String): MediaDetail {
        val rawTitle = doc.selectFirst("h1, .entry-title")?.text()?.trim()
            ?: doc.title().substringBefore("|").substringBefore("—").trim()
        val (cleanTitle, year) = ProviderParsingUtils.cleanTitleYearSplit(rawTitle)

        val posterRaw = doc.selectFirst("meta[property=og:image]")?.attr("content")?.trim()
            ?: doc.selectFirst(".poster img, .entry-content img")?.attr("src")?.trim()
            ?: ""
        val posterUrl = if (posterRaw.isNotBlank() && !posterRaw.startsWith("data:")) {
            ProviderParsingUtils.resolveUrl(finalUrl, posterRaw)
        } else ""

        val overview = doc.select(".entry-content p, .storyline p, .synopsis")
            .map { it.text().trim() }
            .firstOrNull { it.length > 30 && !BanglaUiNormalizer.isClutterText(it) }
            .orEmpty()

        val screenshots = doc.select(".screenshot-wrapper img, .screenshot-container img, .entry-content img")
            .mapNotNull { img ->
                val raw = img.attr("data-src").trim().ifBlank { img.attr("src").trim() }
                if (raw.isNotBlank() && !raw.startsWith("data:") && raw != posterRaw) {
                    ProviderParsingUtils.resolveUrl(finalUrl, raw)
                } else null
            }.distinct().take(8)

        val downloadLinks = mutableListOf<DownloadSourceLink>()
        val seen = hashSetOf<String>()
        doc.select(".entry-content a[href], a.btn[href], a.download[href], .download-links a[href]")
            .forEachIndexed { idx, a ->
                val abs = ProviderParsingUtils.resolveUrl(finalUrl, a.attr("href"))
                if (abs.isBlank() || abs == finalUrl || AdBlockerEngine.shouldBlockUrl(abs, providerId)) return@forEachIndexed
                val label = a.text().trim().replace(Regex("""\s+"""), " ")
                if (label.isBlank() || BanglaUiNormalizer.isClutterText(label)) return@forEachIndexed
                val looksRelevant = label.contains("download", true) ||
                    label.contains("1080", true) || label.contains("720", true) ||
                    label.contains("480", true) || label.contains("watch", true) ||
                    label.contains("gdrive", true) || label.contains("link", true)
                if (looksRelevant && seen.add(abs)) {
                    val quality = Regex("""(2160p|4K|1080p|720p|480p)""", RegexOption.IGNORE_CASE)
                        .find(label)?.groupValues?.getOrNull(1)?.uppercase() ?: "HD"
                    downloadLinks.add(
                        DownloadSourceLink(
                            id = "rt_dl_$idx",
                            label = label,
                            quality = quality,
                            size = "",
                            url = abs
                        )
                    )
                }
            }

        val watchEmbedUrl = doc.selectFirst("iframe[src]")?.attr("src")
            ?.let { ProviderParsingUtils.resolveUrl(finalUrl, it) }
            ?.takeIf { it.isNotBlank() && !AdBlockerEngine.shouldBlockUrl(it, providerId) }

        val related = extractCards(doc, finalUrl)
            .filterNot { it.id == finalUrl }
            .take(10)

        val summary = MediaSummary(
            id = finalUrl,
            providerId = providerId,
            title = cleanTitle,
            year = year,
            kind = if (finalUrl.contains("series", true)) MediaKind.SERIES else MediaKind.MOVIE,
            posterUrl = posterUrl,
            backdropUrl = screenshots.firstOrNull() ?: posterUrl,
            sourceUrl = finalUrl
        )

        val infoFields = buildList {
            if (year.isNotBlank()) add(MovieInfoField("Release", year))
            add(MovieInfoField("Source", providerId.displayName))
        }

        return MediaDetail(
            summary = summary,
            overview = overview,
            screenshots = screenshots,
            infoFields = infoFields,
            sources = buildList {
                if (watchEmbedUrl != null) add("Web Player (${providerId.displayName})")
                if (downloadLinks.isNotEmpty()) add("Download Links (${downloadLinks.size})")
            }.ifEmpty { listOf("Website Page") },
            downloadLinks = downloadLinks,
            cast = emptyList(),
            seasons = emptyList(),
            recommendations = related,
            watchEmbedUrl = watchEmbedUrl
        )
    }
}
