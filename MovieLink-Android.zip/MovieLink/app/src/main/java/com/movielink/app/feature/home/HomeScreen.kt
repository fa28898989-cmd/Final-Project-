package com.movielink.app.feature.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.movielink.app.core.designsystem.EmptyStateCard
import com.movielink.app.core.designsystem.FilterPill
import com.movielink.app.core.designsystem.LocalMovieLinkColors
import com.movielink.app.core.designsystem.MovieLinkRadius
import com.movielink.app.core.designsystem.PrimaryActionButton
import com.movielink.app.core.designsystem.SecondaryActionButton
import com.movielink.app.core.integrations.IntegrationsStore
import com.movielink.app.core.integrations.MetadataEnrichmentEngine
import com.movielink.app.core.model.CatalogSection
import com.movielink.app.core.model.HomeCategoryFilter
import com.movielink.app.core.model.HomeHeroStyle
import com.movielink.app.core.model.MediaKind
import com.movielink.app.core.model.MediaSummary
import com.movielink.app.core.model.ProviderCatalog
import com.movielink.app.core.player.AdBlockedWebViewDialog
import com.movielink.app.core.sources.WebsiteSourcesRepository
import com.movielink.app.core.sources.WebsiteSourcesStore
import com.movielink.app.core.sources.providers.CloudflareChallengeException
import com.movielink.app.core.state.AppUiStateStore
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.supervisorScope

@Composable
fun HomeScreen(
    onOpenDetails: (MediaSummary) -> Unit,
    onOpenWebsiteSources: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    val appearance by AppUiStateStore.appearance.collectAsStateWithLifecycle()
    val sourceConfigs by WebsiteSourcesStore.configs.collectAsStateWithLifecycle()
    val activeHomeProvider by WebsiteSourcesStore.activeHomeProvider.collectAsStateWithLifecycle()
    val integrationSettings by IntegrationsStore.settings.collectAsStateWithLifecycle()
    val activeConfig = sourceConfigs[activeHomeProvider]

    var kindFilter by remember { mutableStateOf(HomeCategoryFilter.ALL) }
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    var selectedOttId by remember { mutableStateOf<String?>(null) }
    var showCategoriesDialog by remember { mutableStateOf(false) }
    var showProviderDialog by remember { mutableStateOf(false) }
    var viewAllSection by remember { mutableStateOf<CatalogSection?>(null) }
    var reloadNonce by remember { mutableIntStateOf(0) }

    var catalog by remember { mutableStateOf<ProviderCatalog?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var cloudflareChallengeUrl by remember { mutableStateOf<String?>(null) }
    var showCloudflareDialog by remember { mutableStateOf(false) }

    LaunchedEffect(activeHomeProvider, activeConfig?.enabled, activeConfig?.activeBaseUrl, reloadNonce) {
        isLoading = true
        loadError = null
        cloudflareChallengeUrl = null
        WebsiteSourcesRepository.loadHomeCatalog(activeHomeProvider)
            .onSuccess { loaded ->
                catalog = loaded
                isLoading = false
            }
            .onFailure { err ->
                catalog = null
                if (err is CloudflareChallengeException) {
                    cloudflareChallengeUrl = err.challengeUrl
                    loadError = "Security verification is required before loading ${activeHomeProvider.displayName}."
                } else {
                    loadError = err.message ?: "Unable to load ${activeHomeProvider.displayName}"
                }
                isLoading = false
            }
    }

    LaunchedEffect(
        catalog?.providerId,
        catalog?.heroItems?.size,
        integrationSettings.artworkEnrichmentEnabled,
        integrationSettings.tmdbEnabled,
        integrationSettings.betterPosterEnabled,
        integrationSettings.preferExternalOverWebsite,
        integrationSettings.fields
    ) {
        val current = catalog ?: return@LaunchedEffect
        if (!integrationSettings.artworkEnrichmentEnabled || !integrationSettings.hasAnyArtworkSource) {
            return@LaunchedEffect
        }
        val enrichedHero = supervisorScope {
            current.heroItems.mapIndexed { idx, item ->
                async {
                    if (idx < 8) MetadataEnrichmentEngine.enrichSummaryArtwork(item) else item
                }
            }.awaitAll()
        }
        if (enrichedHero != current.heroItems) {
            catalog = current.copy(heroItems = enrichedHero)
        }
    }

    val currentCatalog = catalog
    val filteredHero = remember(currentCatalog?.heroItems, kindFilter, selectedCategory) {
        val list = currentCatalog?.heroItems.orEmpty()
        list.filter { item ->
            val kindOk = when (kindFilter) {
                HomeCategoryFilter.ALL -> true
                HomeCategoryFilter.TV_SHOWS -> item.kind == MediaKind.SERIES
                HomeCategoryFilter.MOVIES -> item.kind == MediaKind.MOVIE
            }
            val catOk = selectedCategory == null ||
                item.genres.any { it.equals(selectedCategory, ignoreCase = true) } ||
                item.languageTag.contains(selectedCategory!!, ignoreCase = true)
            kindOk && catOk
        }.ifEmpty { list }
    }

    val filteredSections = remember(currentCatalog?.sections, kindFilter, selectedCategory) {
        currentCatalog?.sections.orEmpty().mapNotNull { section ->
            val items = section.items.filter { item ->
                val kindOk = when (kindFilter) {
                    HomeCategoryFilter.ALL -> true
                    HomeCategoryFilter.TV_SHOWS -> item.kind == MediaKind.SERIES
                    HomeCategoryFilter.MOVIES -> item.kind == MediaKind.MOVIE
                }
                val catOk = selectedCategory == null ||
                    item.genres.any { it.equals(selectedCategory, ignoreCase = true) } ||
                    item.languageTag.contains(selectedCategory!!, ignoreCase = true)
                kindOk && catOk
            }
            if (items.isEmpty()) null else section.copy(items = items)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background)
    ) {
        if (isLoading && currentCatalog == null) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = colors.accent)
            }
        } else if (loadError != null && currentCatalog == null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .padding(20.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                EmptyStateCard(
                    title = "${activeHomeProvider.displayName} Unavailable",
                    description = loadError!!,
                    icon = Icons.Rounded.Language
                )
                Spacer(Modifier.height(14.dp))
                if (cloudflareChallengeUrl != null) {
                    PrimaryActionButton(
                        text = "Verify Security Check",
                        onClick = { showCloudflareDialog = true },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (cloudflareChallengeUrl != null) {
                        SecondaryActionButton(
                            text = "Manage Sources",
                            onClick = onOpenWebsiteSources,
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        PrimaryActionButton(
                            text = "Manage Sources",
                            onClick = onOpenWebsiteSources,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    SecondaryActionButton(
                        text = "Retry",
                        onClick = { reloadNonce++ },
                        modifier = Modifier.weight(0.7f)
                    )
                }
            }
        } else if (currentCatalog != null) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(22.dp)
            ) {
                item(key = "hero") {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        when (appearance.heroStyle) {
                            HomeHeroStyle.CINEMATIC -> CinematicHomeHero(
                                items = filteredHero,
                                heroHeight = appearance.homeHeroHeightDp.dp,
                                onViewDetails = onOpenDetails
                            )

                            HomeHeroStyle.POSTER_CAROUSEL -> PosterCarouselHomeHero(
                                items = filteredHero,
                                heroHeight = appearance.homeHeroHeightDp.dp,
                                onViewDetails = onOpenDetails
                            )
                        }

                        // Overlay top bar on both Hero layouts with transparent status bar spacing
                        HomeTopFilterBar(
                            activeProviderLabel = activeHomeProvider.shortLabel,
                            kindFilter = kindFilter,
                            selectedCategory = selectedCategory,
                            onProviderClick = { showProviderDialog = true },
                            onToggleKind = { clicked ->
                                kindFilter = if (kindFilter == clicked) HomeCategoryFilter.ALL else clicked
                            },
                            onOpenCategories = { showCategoriesDialog = true },
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .statusBarsPadding()
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                        )
                    }
                }

                if (currentCatalog.ottPlatforms.isNotEmpty()) {
                    item(key = "ott_bar") {
                        WatchByOttSection(
                            platforms = currentCatalog.ottPlatforms,
                            selectedOttId = selectedOttId,
                            onSelectOtt = { ott ->
                                selectedOttId = if (selectedOttId == ott.id) null else ott.id
                            }
                        )
                    }
                }

                items(filteredSections, key = { it.id }) { section ->
                    CatalogMediaRow(
                        section = section,
                        onMediaClick = onOpenDetails,
                        onViewAllClick = { clickedSection ->
                            viewAllSection = clickedSection
                        }
                    )
                }

                item { Spacer(Modifier.height(4.dp)) }
            }
        }
    }

    if (showCategoriesDialog && currentCatalog != null) {
        CategoriesFilterDialog(
            categories = currentCatalog.categories,
            selectedCategory = selectedCategory,
            onSelectCategory = { selectedCategory = it },
            onDismiss = { showCategoriesDialog = false }
        )
    }

    if (showProviderDialog) {
        ProviderSwitchDialog(
            activeProvider = activeHomeProvider,
            configs = sourceConfigs,
            onSelectProvider = { AppUiStateStore.setHomeProvider(it) },
            onManageSources = onOpenWebsiteSources,
            onDismiss = { showProviderDialog = false }
        )
    }

    viewAllSection?.let { section ->
        SectionViewAllDialog(
            section = section,
            onSelectMedia = onOpenDetails,
            onDismiss = { viewAllSection = null }
        )
    }

    if (showCloudflareDialog && cloudflareChallengeUrl != null) {
        AdBlockedWebViewDialog(
            initialUrl = cloudflareChallengeUrl!!,
            title = activeHomeProvider.displayName,
            providerId = activeHomeProvider,
            isCloudflareChallenge = true,
            onCloudflareSolved = {
                showCloudflareDialog = false
                cloudflareChallengeUrl = null
                reloadNonce++
            },
            onDismiss = { showCloudflareDialog = false }
        )
    }
}

@Composable
private fun HomeTopFilterBar(
    activeProviderLabel: String,
    kindFilter: HomeCategoryFilter,
    selectedCategory: String?,
    onProviderClick: () -> Unit,
    onToggleKind: (HomeCategoryFilter) -> Unit,
    onOpenCategories: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalMovieLinkColors.current
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(MovieLinkRadius.Sm))
                .background(colors.surface.copy(alpha = 0.85f))
                .border(1.dp, colors.borderStrong, RoundedCornerShape(MovieLinkRadius.Sm))
                .clickable(onClick = onProviderClick),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "M",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                color = colors.textPrimary
            )
        }

        Row(
            modifier = Modifier
                .weight(1f)
                .horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterPill(
                label = "TV Shows",
                selected = kindFilter == HomeCategoryFilter.TV_SHOWS,
                onClick = { onToggleKind(HomeCategoryFilter.TV_SHOWS) }
            )

            FilterPill(
                label = "Movies",
                selected = kindFilter == HomeCategoryFilter.MOVIES,
                onClick = { onToggleKind(HomeCategoryFilter.MOVIES) }
            )

            FilterPill(
                label = selectedCategory ?: "Categories",
                selected = selectedCategory != null,
                trailingIcon = Icons.Rounded.KeyboardArrowDown,
                onClick = onOpenCategories
            )
        }

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(MovieLinkRadius.Pill))
                .background(colors.surface.copy(alpha = 0.85f))
                .border(1.dp, colors.borderSubtle, RoundedCornerShape(MovieLinkRadius.Pill))
                .clickable(onClick = onProviderClick)
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Text(
                text = activeProviderLabel.replace("Website ", "W"),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = colors.textSecondary
            )
        }
    }
}
